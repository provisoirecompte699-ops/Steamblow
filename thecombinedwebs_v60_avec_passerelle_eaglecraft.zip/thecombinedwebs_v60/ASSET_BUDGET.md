# TheCombinedWebs asset budget

The project deliberately does not contain fake/random 1 GB filler.
For a mobile web game, a forced 1 GB payload would increase first-load time,
RAM pressure, storage use and bandwidth without improving gameplay.

The architecture is ready for real asset packs: sprites, animations, music,
sound effects, maps and downloadable game content can be added separately.
