import { onNetlify } from "./runtime";
// Shared across Next route bundles. Single authoritative Node writer required.
const root = globalThis as typeof globalThis & { tcbFeatureLocks?: Map<string, Promise<unknown>> };
const locks = root.tcbFeatureLocks ||= new Map();
export async function serial<T>(key: string, fn: () => Promise<T>): Promise<T> {
  const previous = locks.get(key) || Promise.resolve();
  const next = previous.catch(() => {}).then(fn);
  locks.set(key, next);
  try { return await next; } finally { if (locks.get(key) === next) locks.delete(key); }
}
export function singleWriter() {
  if (onNetlify() && process.env.TCB_SINGLE_WRITER !== "true")
    throw new Error("Ces opérations nécessitent un serveur Node unique. Configure TCB_SINGLE_WRITER uniquement sur un serveur dédié, pas sur plusieurs fonctions.");
}
