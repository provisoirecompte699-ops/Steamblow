// Classements mondiaux (semaine / depuis toujours), défi du jour et rediffusions.
import { getJSON, listJSON, setJSON, updateJSON } from "./data-store";
import { credit } from "./bobux";
import { grantBadge } from "./progression";

const STORE = "steamblox-leaderboards";
export const ARCADE_GAMES: { id: string; mode: string; title: string }[] = [
  { id: "meteor-mayhem", mode: "meteor", title: "Meteor Mayhem" },
  { id: "neon-tag", mode: "tag", title: "Neon Tag" },
  { id: "crystal-rush", mode: "crystal", title: "Crystal Rush" },
  { id: "mystic-mines", mode: "mines", title: "Mystic Mines" },
  { id: "pixel-heist", mode: "heist", title: "Pixel Heist" },
  { id: "block-brawl", mode: "brawl", title: "Block Brawl" },
  { id: "castle-clash", mode: "castle", title: "Castle Clash" },
  { id: "cyber-siege", mode: "cyber", title: "Cyber Siege" },
  { id: "neon-arena", mode: "arena", title: "Neon Arena" },
  { id: "party-pals", mode: "party", title: "Party Pals" },
  { id: "rooftop-rivals", mode: "roof", title: "Rooftop Rivals" },
  { id: "blocus-simulator", mode: "blocus", title: "Blocus Simulator" },
];
export const gameById = (id: string) => ARCADE_GAMES.find((g) => g.id === id);
export const WEEKLY_PRIZE = 150;
export const DAILY_PRIZE = 50;

export type Entry = { u: string; score: number; at: number; replay?: string };
type Board = { id: string; entries: Entry[]; paid?: boolean };

/** Identifiant de semaine ISO, ex. 2026-W40. */
export function weekId(d = new Date()) {
  const t = new Date(Date.UTC(d.getUTCFullYear(), d.getUTCMonth(), d.getUTCDate()));
  const day = t.getUTCDay() || 7; t.setUTCDate(t.getUTCDate() + 4 - day);
  const y0 = new Date(Date.UTC(t.getUTCFullYear(), 0, 1));
  const w = Math.ceil(((t.getTime() - y0.getTime()) / 86400000 + 1) / 7);
  return `${t.getUTCFullYear()}-W${String(w).padStart(2, "0")}`;
}
export const dayId = (d = new Date()) => d.toISOString().slice(0, 10);
function hash(s: string) { let h = 2166136261; for (const c of s) { h ^= c.charCodeAt(0); h = Math.imul(h, 16777619); } return h >>> 0; }

/** Le défi du jour : même jeu et même graine pour tout le monde. */
export function dailyChallenge(d = new Date()) {
  const id = dayId(d);
  const g = ARCADE_GAMES[hash("defi:" + id) % ARCADE_GAMES.length];
  return { day: id, seed: hash("seed:" + id), ...g };
}

const keyOf = (scope: "week" | "all" | "daily" | "map", game: string, id: string) => `board:${scope}:${game}:${id}`;

async function put(key: string, e: Entry) {
  let rank = 0, improved = false;
  await updateJSON<Board>(STORE, key, (b) => {
    const d = b || { id: key, entries: [] };
    const i = d.entries.findIndex((x) => x.u.toLowerCase() === e.u.toLowerCase());
    if (i >= 0) { if (d.entries[i].score >= e.score) { rank = rankIn(d.entries, e.u); return d; } d.entries[i] = { ...d.entries[i], ...e }; }
    else d.entries.push(e);
    improved = true;
    d.entries.sort((a, b) => b.score - a.score || a.at - b.at);
    d.entries = d.entries.slice(0, 200);
    rank = rankIn(d.entries, e.u);
    return d;
  });
  return { rank, improved };
}
const rankIn = (list: Entry[], u: string) => list.findIndex((x) => x.u.toLowerCase() === u.toLowerCase()) + 1;

export async function board(scope: "week" | "all" | "daily" | "map", game: string, id = "") {
  const b = await getJSON<Board>(STORE, keyOf(scope, game, id || (scope === "week" ? weekId() : scope === "daily" ? dayId() : "x")));
  return b?.entries || [];
}

export async function submitScore(u: string, gameId: string, score: number, opts: { daily?: boolean; mapId?: string; replay?: string } = {}) {
  await settleWeek();
  const e: Entry = { u, score: Math.floor(score), at: Date.now(), ...(opts.replay ? { replay: opts.replay } : {}) };
  if (opts.mapId) return { map: await put(keyOf("map", "custom", opts.mapId), e) };
  const week = await put(keyOf("week", gameId, weekId()), e);
  const all = await put(keyOf("all", gameId, "x"), e);
  let daily: { rank: number; improved: boolean } | undefined;
  if (opts.daily && dailyChallenge().id === gameId) daily = await put(keyOf("daily", "defi", dayId()), e);
  return { week, all, daily };
}

/** Récompense lazily les N°1 de la semaine précédente et du défi d'hier. */
export async function settleWeek() {
  const prevW = weekId(new Date(Date.now() - 7 * 86400000));
  const flag = await getJSON<{ done: boolean }>(STORE, `settled:${prevW}`);
  if (!flag) {
    await setJSON(STORE, `settled:${prevW}`, { done: true });
    for (const g of ARCADE_GAMES) {
      const top = (await getJSON<Board>(STORE, keyOf("week", g.id, prevW)))?.entries?.[0];
      if (top) { try { await credit(top.u, WEEKLY_PRIZE, "system", `N°1 de la semaine sur ${g.title}`, "quest"); await grantBadge(top.u, "weekly"); } catch { /* ignore */ } }
    }
  }
  const yday = dayId(new Date(Date.now() - 86400000));
  const f2 = await getJSON<{ done: boolean }>(STORE, `settled-daily:${yday}`);
  if (!f2) {
    await setJSON(STORE, `settled-daily:${yday}`, { done: true });
    const top = (await getJSON<Board>(STORE, keyOf("daily", "defi", yday)))?.entries?.[0];
    if (top) { try { await credit(top.u, DAILY_PRIZE, "system", "N°1 du défi du jour", "quest"); await grantBadge(top.u, "daily"); } catch { /* ignore */ } }
  }
}

/** Meilleurs scores d'un joueur (pour son profil). */
export async function bestsOf(u: string) {
  const out: { game: string; title: string; score: number; rank: number }[] = [];
  for (const g of ARCADE_GAMES) {
    const list = await board("all", g.id);
    const r = rankIn(list, u);
    if (r) out.push({ game: g.id, title: g.title, score: list[r - 1].score, rank: r });
  }
  return out.sort((a, b) => a.rank - b.rank);
}

// ————— Rediffusions (vidéo WebM de la partie) —————
export type Replay = { id: string; u: string; gameId: string; title: string; score: number; at: number; mime: string; data: string };
const RSTORE = "steamblox-replays";
export async function saveReplay(r: Omit<Replay, "id" | "at">) {
  const id = `${Date.now().toString(36)}${Math.random().toString(36).slice(2, 7)}`;
  const rep: Replay = { ...r, id, at: Date.now() };
  // Chaque rediffusion a son propre fichier/blob pour ne pas alourdir les autres.
  await setJSON(`${RSTORE}-${id}`, "replay", rep);
  await setJSON(RSTORE, `meta:${id}`, { id, u: r.u, gameId: r.gameId, title: r.title, score: r.score, at: rep.at });
  return rep;
}
export async function getReplay(id: string) {
  if (!/^[a-z0-9]{6,20}$/.test(id)) return null;
  return getJSON<Replay>(`${RSTORE}-${id}`, "replay");
}
export async function replaysOf(u: string) {
  return (await listJSON<Omit<Replay, "data" | "mime">>(RSTORE, "meta:")).filter((r) => r.u.toLowerCase() === u.toLowerCase()).sort((a, b) => b.at - a.at).slice(0, 12);
}
