import { getJSON, listJSON, setJSON } from "./data-store";
import { getUser, hasGameAccess } from "./store";
import { credit, spend } from "./bobux";
import { ARCADE_GAMES } from "./leaderboard";
import { serial, singleWriter } from "./feature-lock";
import { randomUUID } from "node:crypto";
export type Duel = {
  id: string;
  from: string;
  to: string;
  gameId: string;
  stake: number;
  status: "pending" | "active" | "finished" | "cancelled";
  expiresAt: number;
  acceptedAt?: number;
  scores: Record<string, number>;
  runs: Record<string, { token: string; at: number; used: boolean }>;
  winner?: string;
  draw?: boolean;
  paid?: boolean;
};
const STORE = "tcb-duels",
  low = (s: string) => s.toLowerCase();
async function refund(d: Duel) {
  await credit(
    d.from,
    d.stake,
    "Duel",
    "Mise rendue",
    "bank",
    `duel:${d.id}:refund:${low(d.from)}`,
  );
  if (d.acceptedAt)
    await credit(
      d.to,
      d.stake,
      "Duel",
      "Mise rendue",
      "bank",
      `duel:${d.id}:refund:${low(d.to)}`,
    );
  d.paid = true;
  await setJSON(STORE, `duel:${d.id}`, d);
}
async function expire() {
  for (const d of await listJSON<Duel>(STORE, "duel:"))
    if (["pending", "active"].includes(d.status) && d.expiresAt <= Date.now()) {
      d.status = "cancelled";
      await setJSON(STORE, `duel:${d.id}`, d);
      await refund(d);
    }
}
export async function duelsFor(username: string) {
  singleWriter();
  return serial("duels", async () => {
    await expire();
    for (const d of await listJSON<Duel>(STORE, "duel:"))
      if (!d.paid) {
        if (d.status === "cancelled" || (d.status === "finished" && d.draw))
          await refund(d);
        else if (d.status === "finished" && d.winner) {
          await credit(
            d.winner,
            d.stake * 2,
            "Duel",
            `Victoire duel ${d.id}`,
            "bank",
            `duel:${d.id}:prize`,
          );
          d.paid = true;
          await setJSON(STORE, `duel:${d.id}`, d);
        }
      }
    return (await listJSON<Duel>(STORE, "duel:"))
      .filter((d) => [low(d.from), low(d.to)].includes(low(username)))
      .map((d) => {
        const { runs, ...v } = d;
        return v;
      });
  });
}
export async function duelAction(username: string, b: Record<string, unknown>) {
  singleWriter();
  return serial("duels", async () => {
    await expire();
    if (b.action === "create") {
      const me = await getUser(username),
        to = await getUser(String(b.to)),
        stake = Number(b.stake),
        gameId = String(b.gameId);
      if (
        !to ||
        to.banned ||
        !me?.friends?.some((f) => low(f) === low(to.username))
      )
        throw new Error("Défie un ami de ta liste.");
      if (
        !ARCADE_GAMES.some(
          (g) => g.id === gameId && g.id !== "blocus-simulator",
        ) ||
        !Number.isInteger(stake) ||
        stake < 1 ||
        stake > 10000
      )
        throw new Error("Jeu ou mise invalide (1–10 000 Bobux).");
      if (!hasGameAccess(me!, gameId) || !hasGameAccess(to, gameId))
        throw new Error(
          "Les deux joueurs doivent avoir accès à ce jeu avant de miser.",
        );
      if (
        (await listJSON<Duel>(STORE, "duel:")).filter(
          (d) =>
            low(d.from) === low(username) &&
            ["pending", "active"].includes(d.status),
        ).length >= 5
      )
        throw new Error("Maximum 5 duels en cours.");
      await spend(username, stake, `Mise duel contre ${to.username}`);
      const d: Duel = {
        id: randomUUID(),
        from: username,
        to: to.username,
        gameId,
        stake,
        status: "pending",
        expiresAt: Date.now() + 86400000,
        scores: {},
        runs: {},
      };
      await setJSON(STORE, `duel:${d.id}`, d);
      return { message: "Défi envoyé. Ta mise est réservée." };
    }
    const key = `duel:${String(b.id)}`,
      d = await getJSON<Duel>(STORE, key);
    if (!d || ![low(d.from), low(d.to)].includes(low(username)))
      throw new Error("Duel inaccessible.");
    if (b.action === "accept") {
      if (d.status !== "pending" || low(d.to) !== low(username))
        throw new Error("Duel non disponible.");
      await spend(username, d.stake, `Mise duel ${d.id}`);
      d.status = "active";
      d.acceptedAt = Date.now();
      d.expiresAt = Date.now() + 30 * 60000;
    } else if (b.action === "decline") {
      if (d.status !== "pending") throw new Error("Duel déjà commencé.");
      d.status = "cancelled";
      await setJSON(STORE, key, d);
      await refund(d);
    } else if (b.action === "run") {
      if (
        d.status !== "active" ||
        d.scores[low(username)] !== undefined ||
        d.runs[low(username)]
      )
        throw new Error("Tu disposes d'une seule partie par duel.");
      const token = randomUUID();
      d.runs[low(username)] = { token, at: Date.now(), used: false };
      await setJSON(STORE, key, d);
      return { url: `/games/${d.gameId}?duel=${d.id}&duelToken=${token}` };
    } else throw new Error("Action inconnue.");
    await setJSON(STORE, key, d);
    return { message: "Duel mis à jour." };
  });
}
export async function scoreDuel(
  username: string,
  id: string,
  token: string,
  gameId: string,
  score: number,
  duration: number,
) {
  singleWriter();
  return serial("duels", async () => {
    const key = `duel:${id}`,
      d = await getJSON<Duel>(STORE, key),
      run = d?.runs[low(username)];
    if (
      !d ||
      d.status !== "active" ||
      d.expiresAt <= Date.now() ||
      d.gameId !== gameId ||
      !run ||
      run.used ||
      run.token !== token ||
      duration < 3 ||
      duration > 1800 ||
      (Date.now() - run.at) / 1000 < duration - 2
    )
      throw new Error("Partie de duel invalide.");
    run.used = true;
    d.scores[low(username)] = score;
    if (
      d.scores[low(d.from)] !== undefined &&
      d.scores[low(d.to)] !== undefined
    ) {
      const a = d.scores[low(d.from)],
        b = d.scores[low(d.to)];
      d.status = "finished";
      d.draw = a === b;
      d.winner = a > b ? d.from : b > a ? d.to : undefined;
      await setJSON(STORE, key, d);
      if (d.draw) await refund(d);
      else
        await credit(
          d.winner!,
          d.stake * 2,
          "Duel",
          `Victoire duel ${d.id}`,
          "bank",
          `duel:${d.id}:prize`,
        );
      d.paid = true;
    }
    await setJSON(STORE, key, d);
    return { status: d.status, winner: d.winner, draw: d.draw };
  });
}
