import { getJSON, setJSON, listJSON } from "./data-store";
import { getUser } from "./store";
import { credit, spend } from "./bobux";
import { serial, singleWriter } from "./feature-lock";
import { randomInt, randomUUID } from "node:crypto";
export type RiskDuel = {
  id: string;
  from: string;
  to: string;
  stake: number;
  status: "pending" | "active" | "finished" | "cancelled";
  turn: string;
  trap: number;
  position: number;
  accepted: boolean;
  expiresAt: number;
  winner?: string;
  eliminated?: string;
  paid?: boolean;
  moves: { user: string; position: number; safe: boolean }[];
};
const STORE = "tcb-risk-duels",
  low = (s: string) => s.toLowerCase();
function publicDuel(d: RiskDuel) {
  const { trap, ...v } = d;
  return v;
}
async function refund(d: RiskDuel) {
  await credit(
    d.from,
    d.stake,
    "Duel roulette russe",
    "Mise rendue",
    "bank",
    `risk:${d.id}:refund:${low(d.from)}`,
  );
  if (d.accepted)
    await credit(
      d.to,
      d.stake,
      "Duel roulette russe",
      "Mise rendue",
      "bank",
      `risk:${d.id}:refund:${low(d.to)}`,
    );
  d.paid = true;
  await setJSON(STORE, `duel:${d.id}`, d);
}
async function expire() {
  for (const d of await listJSON<RiskDuel>(STORE, "duel:"))
    if (["active", "pending"].includes(d.status) && d.expiresAt <= Date.now()) {
      d.status = "cancelled";
      await setJSON(STORE, `duel:${d.id}`, d);
      await refund(d);
    }
}
export async function riskDuelsFor(username: string) {
  singleWriter();
  return serial("risk-duels", async () => {
    await expire();
    for (const d of await listJSON<RiskDuel>(STORE, "duel:")) {
      if (d.status === "finished" && d.winner && !d.paid) {
        await credit(
          d.winner,
          d.stake * 2,
          "Roulette russe",
          `Victoire duel ${d.id}`,
          "bank",
          `risk:${d.id}:prize`,
        );
        d.paid = true;
        await setJSON(STORE, `duel:${d.id}`, d);
      }
      if (d.status === "cancelled" && !d.paid) await refund(d);
    }
    return (await listJSON<RiskDuel>(STORE, "duel:"))
      .filter((d) => [low(d.from), low(d.to)].includes(low(username)))
      .map(publicDuel);
  });
}
export async function riskAction(username: string, b: Record<string, unknown>) {
  singleWriter();
  return serial("risk-duels", async () => {
    await expire();
    if (b.action === "create") {
      const me = await getUser(username),
        to = await getUser(String(b.to)),
        stake = Number(b.stake);
      if (
        !to ||
        to.banned ||
        !me?.friends?.some((f) => low(f) === low(to.username))
      )
        throw new Error("Choisis un ami de ta liste.");
      if (!Number.isInteger(stake) || stake < 1 || stake > 10000)
        throw new Error("Mise de 1 à 10 000 Bobux.");
      if (
        (await listJSON<RiskDuel>(STORE, "duel:")).filter(
          (d) =>
            low(d.from) === low(username) &&
            ["active", "pending"].includes(d.status),
        ).length >= 5
      )
        throw new Error("Maximum cinq duels en cours.");
      await spend(username, stake, `Mise roulette russe contre ${to.username}`);
      const d: RiskDuel = {
        id: randomUUID(),
        from: username,
        to: to.username,
        stake,
        status: "pending",
        turn: username,
        trap: randomInt(6),
        position: 0,
        accepted: false,
        expiresAt: Date.now() + 86400000,
        moves: [],
      };
      await setJSON(STORE, `duel:${d.id}`, d);
      return {
        message: "Invitation envoyée. Ta mise est réservée.",
        duel: publicDuel(d),
      };
    }
    const key = `duel:${String(b.id)}`,
      d = await getJSON<RiskDuel>(STORE, key);
    if (!d || ![low(d.from), low(d.to)].includes(low(username)))
      throw new Error("Duel inaccessible.");
    if (b.action === "accept") {
      if (d.status !== "pending" || low(d.to) !== low(username))
        throw new Error("Invitation déjà traitée.");
      await spend(username, d.stake, `Mise roulette russe ${d.id}`);
      d.accepted = true;
      d.status = "active";
      d.expiresAt = Date.now() + 15 * 60000;
      d.turn = randomInt(2) ? d.from : d.to;
    } else if (b.action === "cancel") {
      if (d.status !== "pending") throw new Error("Le duel a déjà commencé.");
      d.status = "cancelled";
      await setJSON(STORE, key, d);
      await refund(d);
    } else if (b.action === "play") {
      if (d.status !== "active" || low(d.turn) !== low(username))
        throw new Error("Ce n'est pas ton tour.");
      if (Number(b.position) !== d.position)
        throw new Error("Ce tour a déjà été joué. Actualise le duel.");
      const safe = d.position !== d.trap;
      d.moves.push({ user: username, position: d.position, safe });
      d.position++;
      if (!safe) {
        d.status = "finished";
        d.eliminated = username;
        d.winner = low(username) === low(d.from) ? d.to : d.from;
        await setJSON(STORE, key, d);
        await credit(
          d.winner,
          d.stake * 2,
          "Roulette russe",
          `Victoire duel ${d.id}`,
          "bank",
          `risk:${d.id}:prize`,
        );
        d.paid = true;
      } else d.turn = low(username) === low(d.from) ? d.to : d.from;
    } else throw new Error("Action inconnue.");
    await setJSON(STORE, key, d);
    return {
      message: d.winner
        ? `${d.winner} remporte les deux mises (${d.stake * 2} Bobux).`
        : "Duel mis à jour.",
      duel: publicDuel(d),
    };
  });
}
