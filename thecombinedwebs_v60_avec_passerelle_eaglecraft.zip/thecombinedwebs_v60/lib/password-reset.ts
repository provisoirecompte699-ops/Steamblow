import { getUser } from "./store";
import { verifyPassword, hashLocalPassword } from "./passwords";
import { writeCredential } from "./credentials";
import { serial } from "./feature-lock";

export class PasswordResetError extends Error {
  constructor(message: string, public status: number) { super(message); }
}
const root = globalThis as typeof globalThis & { tcbResetAttempts?: Map<string, { count: number; until: number }> };
const attempts = root.tcbResetAttempts ||= new Map();

export async function resetMoustafaPassword(actorUsername: string, currentPassword: string, newPassword: string, confirmation: string) {
  const actor = await getUser(actorUsername);
  if (!actor || actor.banned || actor.role !== "creator") throw new PasswordResetError("Réservé au créateur.", 403);
  if (typeof currentPassword !== "string" || !currentPassword || currentPassword.length > 200 ||
      typeof newPassword !== "string" || newPassword.length < 12 || newPassword.length > 128 || !newPassword.trim())
    throw new PasswordResetError("Le nouveau mot de passe doit contenir entre 12 et 128 caractères.", 400);
  if (newPassword !== confirmation) throw new PasswordResetError("Les nouveaux mots de passe ne correspondent pas.", 400);
  const key = actor.username.toLowerCase();
  const limit = attempts.get(key);
  if (limit && limit.until > Date.now() && limit.count >= 5) throw new PasswordResetError("Trop de tentatives. Réessaie dans quinze minutes.", 429);
  if (!(await verifyPassword(currentPassword, actor.passwordHash))) {
    const entry = limit && limit.until > Date.now() ? limit : { count: 0, until: Date.now() + 900000 };
    entry.count++; attempts.set(key, entry);
    throw new PasswordResetError("Le mot de passe du créateur est incorrect.", 403);
  }
  const passwordHash = await hashLocalPassword(newPassword);
  return serial("credential-reset:moustafa", async () => {
    const freshActor=await getUser(actor.username);
    if(!freshActor||freshActor.banned||freshActor.role!=="creator"||freshActor.passwordHash!==actor.passwordHash)
      throw new PasswordResetError("La session créateur a changé. Reconnecte-toi.",403);
    const target = await getUser("Moustafa");
    if (!target || target.role !== "vice_creator" || target.username.toLowerCase() !== "moustafa")
      throw new PasswordResetError("Compte Moustafa vice-créateur introuvable.", 404);
    const changedAt = new Date().toISOString();
    await writeCredential(target.username, { passwordHash, changedAt, changedBy: actor.username });
    attempts.delete(key);
    return { username: target.username, changedAt };
  });
}
