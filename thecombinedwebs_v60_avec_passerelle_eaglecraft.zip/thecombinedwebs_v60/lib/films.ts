import { getJSON, listJSON, setJSON } from "./data-store";
import { createCashRequest, listCashRequests } from "./payments";
import { createFunnyRequest, listFunnyRequests } from "./funny-payment";
import type { User } from "./store";

/** Prix unique d'un film ou d'une série sur CinéStream / Vortex. */
export const FILM_PRICE = 2.99;
const KEY_RE = /^(m|tv)-\d{1,9}$/;

export const isFilmKey = (key: unknown): key is string => typeof key === "string" && KEY_RE.test(key);
export const filmGameId = (key: string) => `film:${key}`;
export const isFilmGameId = (id: string) => id.startsWith("film:");
export const isPrivileged = (u: Pick<User, "role">) => u.role === "creator" || u.role === "vice_creator";

type FilmTitle = { key: string; title: string };
export async function rememberFilmTitle(key: string, title: string) {
  const clean = String(title || "").replace(/\s+/g, " ").trim().slice(0, 120);
  if (clean) await setJSON<FilmTitle>("steamblox-films", `title:${key}`, { key, title: clean });
}
export async function filmTitles(): Promise<Record<string, string>> {
  const all = await listJSON<FilmTitle>("steamblox-films", "title:");
  return Object.fromEntries(all.filter(Boolean).map((t) => [filmGameId(t.key), t.title]));
}

export async function filmStatus(u: User) {
  const owned = u.owned.filter(isFilmGameId).map((id) => id.slice(5));
  const pending: Record<string, "cash" | "joke"> = {};
  const name = u.username.toLowerCase();
  for (const r of await listCashRequests()) if (r.status === "pending" && r.username.toLowerCase() === name && isFilmGameId(r.gameId)) pending[r.gameId.slice(5)] = "cash";
  for (const r of await listFunnyRequests()) if (r.status === "pending" && r.username.toLowerCase() === name && isFilmGameId(r.gameId)) pending[r.gameId.slice(5)] = "joke";
  return { owned, pending, privileged: isPrivileged(u), price: FILM_PRICE };
}

export async function buyFilm(u: User, key: string, title: string, method: "cash" | "joke", joke?: string) {
  const gid = filmGameId(key);
  if (u.owned.includes(gid)) throw new Error("Tu possèdes déjà ce film.");
  await rememberFilmTitle(key, title);
  if (method === "cash") {
    // createCashRequest n'utilise que id et price
    return createCashRequest(u.username, { id: gid, title, price: FILM_PRICE } as never);
  }
  const text = String(joke || "").trim();
  if (text.length < 8) throw new Error("Ta blague est un peu courte.");
  const pendingJoke = (await listFunnyRequests()).find((r) => r.status === "pending" && r.username.toLowerCase() === u.username.toLowerCase() && r.gameId === gid);
  if (pendingJoke) return pendingJoke;
  return createFunnyRequest(u.username, gid, text);
}

// ————— v52 : Ma liste, historique (reprendre), avis —————
import { getUser as _getUser, saveUser as _saveUser } from "./store";
import { listJSON as _listJSON, updateJSON as _updateJSON } from "./data-store";
export type FilmRef = { key: string; title: string; poster?: string; type?: string; cat?: string; season?: number; episode?: number };
export type Review = { u: string; key: string; title: string; rating: number; text: string; at: number };

export async function toggleList(username: string, f: FilmRef) {
  const u = await _getUser(username); if (!u) throw new Error("Compte introuvable");
  const list = u.filmList || [];
  const has = list.some((x) => x.key === f.key);
  u.filmList = has ? list.filter((x) => x.key !== f.key) : [{ key: f.key, title: String(f.title || "").slice(0, 120), poster: f.poster, type: f.type, at: Date.now() }, ...list].slice(0, 200);
  await _saveUser(u);
  return { inList: !has, list: u.filmList };
}
export async function recordWatch(username: string, f: FilmRef) {
  const u = await _getUser(username); if (!u) return null;
  const h = (u.filmHistory || []).filter((x) => x.key !== f.key);
  u.filmHistory = [{ key: f.key, title: String(f.title || "").slice(0, 120), poster: f.poster, type: f.type, cat: f.cat, season: f.season, episode: f.episode, at: Date.now() }, ...h].slice(0, 60);
  await _saveUser(u);
  return u.filmHistory;
}
export async function reviewsFor(key: string) {
  const d = await _listJSON<Review>("steamblox-reviews", `r:${key}:`);
  return d.sort((a, b) => b.at - a.at);
}
export async function reviewsBy(username: string) {
  return (await _listJSON<Review>("steamblox-reviews", "r:")).filter((r) => r.u.toLowerCase() === username.toLowerCase()).sort((a, b) => b.at - a.at);
}
export async function postReview(username: string, key: string, title: string, rating: number, text: string) {
  if (!isFilmKey(key)) throw new Error("Film inconnu");
  const r = Math.round(rating);
  if (r < 1 || r > 5) throw new Error("Note entre 1 et 5");
  const { cleanText } = await import("./discord");
  const rev: Review = { u: username, key, title: String(title || "").slice(0, 120), rating: r, text: cleanText(text).slice(0, 400), at: Date.now() };
  await _updateJSON<Review>("steamblox-reviews", `r:${key}:${username.toLowerCase()}`, () => rev);
  return rev;
}
