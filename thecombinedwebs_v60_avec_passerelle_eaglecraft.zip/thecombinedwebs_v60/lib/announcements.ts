import { onNetlify } from "./runtime";
import {getStore} from "@netlify/blobs";
import {promises as fs} from "node:fs";
import path from "node:path";
export type Announcement={id:string;author:string;message:string;createdAt:string};
const DB=path.join(process.cwd(),"data","announcements.json");
let memory:Announcement[]=[];
function remote(){try{return getStore({name:"steamblox-announcements",consistency:"strong"})}catch{return null}}
async function readFile(){if(onNetlify())return memory;try{return JSON.parse(await fs.readFile(DB,"utf8")) as Announcement[]}catch{return []}}
async function writeFile(items:Announcement[]){if(onNetlify()){memory=items;return}await fs.mkdir(path.dirname(DB),{recursive:true});await fs.writeFile(DB,JSON.stringify(items,null,2));}
export async function listAnnouncements(){const s=remote();if(s){try{const {blobs}=await s.list({prefix:"announcement:"});const out:Announcement[]=[];for(const b of blobs){const x=await s.get(b.key,{type:"json"}) as Announcement|null;if(x)out.push(x)}return out.sort((a,b)=>b.createdAt.localeCompare(a.createdAt)).slice(0,20)}catch{}}return (await readFile()).sort((a,b)=>b.createdAt.localeCompare(a.createdAt)).slice(0,20)}
export async function createAnnouncement(author:string,message:string){const clean=message.trim().slice(0,500);if(!clean)throw new Error("Annonce vide");const item:Announcement={id:`announcement_${crypto.randomUUID()}`,author,message:clean,createdAt:new Date().toISOString()};const s=remote();if(s){try{await s.setJSON(`announcement:${item.id}`,item);return item}catch{}}const items=await readFile();items.push(item);await writeFile(items.slice(-100));return item}
