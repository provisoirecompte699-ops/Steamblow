// Niveau de compte, passe de saison et boutique de cosmétiques.
import { getUser, saveUser, type User } from "./store";
import { credit, spend } from "./bobux";

// ————— Niveau —————
/** XP nécessaire pour passer du niveau L au niveau L+1. */
export const xpForLevel = (L: number) => 120 + (L - 1) * 60;
export function levelInfo(xp: number) {
  let L = 1, rest = Math.max(0, Math.floor(xp || 0));
  while (rest >= xpForLevel(L) && L < 500) { rest -= xpForLevel(L); L++; }
  return { level: L, into: rest, need: xpForLevel(L), total: Math.floor(xp || 0) };
}

// ————— Saison —————
export const SEASON_TIERS = 30;
export const XP_PER_TIER = 300;
export function seasonId(d = new Date()) { return `${d.getUTCFullYear()}-${String(d.getUTCMonth() + 1).padStart(2, "0")}`; }
export function seasonName(id = seasonId()) {
  const [y, m] = id.split("-").map(Number);
  const mois = ["Janvier", "Février", "Mars", "Avril", "Mai", "Juin", "Juillet", "Août", "Septembre", "Octobre", "Novembre", "Décembre"][m - 1];
  return `Saison ${mois} ${y}`;
}
export function seasonEnds(id = seasonId()) { const [y, m] = id.split("-").map(Number); return Date.UTC(y, m, 1); }

export type Reward = { kind: "bobux"; amount: number } | { kind: "cosmetic"; id: string } | { kind: "xpboost"; amount: number };
export function tierReward(t: number): Reward {
  const cosmetics: Record<number, string> = { 5: "border-aurora", 10: "name-glow", 15: "sound-chime", 20: "border-flame", 25: "name-rainbow", 30: "border-season" };
  if (cosmetics[t]) return { kind: "cosmetic", id: cosmetics[t] };
  return { kind: "bobux", amount: t % 3 === 0 ? 60 : 25 };
}

// ————— Cosmétiques —————
export type Cosmetic = { id: string; type: "border" | "name" | "sound"; name: string; price: number; pass?: boolean; desc: string };
export const COSMETICS: Cosmetic[] = [
  { id: "border-neon", type: "border", name: "Bordure Néon", price: 120, desc: "Un contour cyan lumineux" },
  { id: "border-gold", type: "border", name: "Bordure Or", price: 260, desc: "Pour les vrais VIP" },
  { id: "border-pixel", type: "border", name: "Bordure Pixel", price: 90, desc: "Carrée, façon 8-bit" },
  { id: "border-aurora", type: "border", name: "Bordure Aurore", price: 0, pass: true, desc: "Palier 5 du passe" },
  { id: "border-flame", type: "border", name: "Bordure Flammes", price: 0, pass: true, desc: "Palier 20 du passe" },
  { id: "border-season", type: "border", name: "Bordure de saison", price: 0, pass: true, desc: "Palier 30 du passe" },
  { id: "name-gold", type: "name", name: "Pseudo doré", price: 150, desc: "Ton nom en or dans le chat" },
  { id: "name-glitch", type: "name", name: "Pseudo glitch", price: 180, desc: "Un effet numérique animé" },
  { id: "name-glow", type: "name", name: "Pseudo lumineux", price: 0, pass: true, desc: "Palier 10 du passe" },
  { id: "name-rainbow", type: "name", name: "Pseudo arc-en-ciel", price: 0, pass: true, desc: "Palier 25 du passe" },
  { id: "sound-laser", type: "sound", name: "Arrivée laser", price: 80, desc: "Son quand tu rejoins un vocal" },
  { id: "sound-8bit", type: "sound", name: "Arrivée 8-bit", price: 80, desc: "Son rétro quand tu rejoins un vocal" },
  { id: "sound-drum", type: "sound", name: "Arrivée tambour", price: 100, desc: "Roulement de tambour" },
  { id: "sound-chime", type: "sound", name: "Arrivée carillon", price: 0, pass: true, desc: "Palier 15 du passe" },
];
export type Equip = { border?: string; name?: string; sound?: string };
export const equipOf = (u: Pick<User, "cosmetics">): Equip => ({ border: u.cosmetics?.border, name: u.cosmetics?.name, sound: u.cosmetics?.sound });

// ————— Badges —————
export type Badge = { id: string; label: string; icon: string };
export function badgesOf(u: User): Badge[] {
  const b: Badge[] = [];
  if (u.role === "creator") b.push({ id: "founder", label: "Fondateur", icon: "👑" });
  if (u.role === "vice_creator") b.push({ id: "cofounder", label: "Co-fondateur", icon: "💎" });
  if (u.role === "moderator") b.push({ id: "mod", label: "Modérateur", icon: "🛡️" });
  if (u.username.toLowerCase() === "walid" || (u.friends || []).some((f) => f.toLowerCase() === "walid")) b.push({ id: "walid", label: "Ami de Walid", icon: "⭐" });
  for (const x of u.badges || []) if (!b.some((y) => y.id === x)) {
    const known: Record<string, Badge> = { champion: { id: "champion", label: "Champion de tournoi", icon: "🏆" }, weekly: { id: "weekly", label: "N°1 de la semaine", icon: "🥇" }, daily: { id: "daily", label: "Héros du défi", icon: "🎯" }, critic: { id: "critic", label: "Critique ciné", icon: "🎬" }, creator: { id: "creator", label: "Créateur de niveaux", icon: "🧱" } };
    if (known[x]) b.push(known[x]);
  }
  const L = levelInfo(u.xp || 0).level;
  if (L >= 10) b.push({ id: "lvl10", label: "Niveau 10+", icon: "🔥" });
  if (L >= 25) b.push({ id: "lvl25", label: "Niveau 25+", icon: "⚡" });
  return b;
}
export async function grantBadge(username: string, id: string) {
  const u = await getUser(username); if (!u) return;
  if ((u.badges || []).includes(id)) return;
  u.badges = [...(u.badges || []), id]; await saveUser(u);
}

// ————— Gain d'XP —————
const today = () => new Date().toISOString().slice(0, 10);
/** Ajoute de l'XP (niveau + saison). `cap` limite ce type de gain par jour. */
export async function awardXp(username: string, amount: number, kind: string, cap?: number) {
  const u = await getUser(username);
  if (!u || u.banned) return null;
  const d = today();
  const daily = u.xpDaily?.date === d ? u.xpDaily : { date: d, by: {} as Record<string, number> };
  let gain = Math.max(0, Math.floor(amount));
  if (cap != null) gain = Math.max(0, Math.min(gain, cap - (daily.by[kind] || 0)));
  if (!gain) return { gained: 0, ...levelInfo(u.xp || 0), levelUp: false };
  daily.by[kind] = (daily.by[kind] || 0) + gain;
  const before = levelInfo(u.xp || 0).level;
  u.xp = (u.xp || 0) + gain;
  const sid = seasonId();
  if (u.season?.id !== sid) u.season = { id: sid, xp: 0, claimed: [] };
  u.season.xp += gain;
  u.xpDaily = daily;
  await saveUser(u);
  const after = levelInfo(u.xp);
  if (after.level > before) { try { await credit(u.username, 20 * (after.level - before), "system", `Niveau ${after.level} atteint`, "quest"); } catch { /* ignore */ } }
  return { gained: gain, ...after, levelUp: after.level > before };
}

export function seasonOf(u: User) {
  const sid = seasonId();
  const s = u.season?.id === sid ? u.season : { id: sid, xp: 0, claimed: [] as number[] };
  const tier = Math.min(SEASON_TIERS, Math.floor(s.xp / XP_PER_TIER));
  return { id: sid, name: seasonName(sid), xp: s.xp, tier, into: s.xp - tier * XP_PER_TIER, claimed: s.claimed, endsAt: seasonEnds(sid) };
}

export async function claimTier(username: string, t: number) {
  const u = await getUser(username);
  if (!u) throw new Error("Compte introuvable");
  const s = seasonOf(u);
  if (!Number.isInteger(t) || t < 1 || t > SEASON_TIERS) throw new Error("Palier invalide");
  if (t > s.tier) throw new Error("Palier pas encore atteint");
  if (s.claimed.includes(t)) throw new Error("Déjà récupéré");
  const r = tierReward(t);
  u.season = { id: s.id, xp: s.xp, claimed: [...s.claimed, t] };
  if (r.kind === "cosmetic") u.cosmetics = { ...(u.cosmetics || {}), owned: Array.from(new Set([...(u.cosmetics?.owned || []), r.id])) };
  await saveUser(u);
  if (r.kind === "bobux") await credit(u.username, r.amount, "system", `Passe de saison · palier ${t}`, "quest");
  return r;
}

export async function buyCosmetic(username: string, id: string) {
  const item = COSMETICS.find((c) => c.id === id);
  if (!item || item.pass) throw new Error("Objet indisponible à l'achat");
  const u = await getUser(username);
  if (!u) throw new Error("Compte introuvable");
  if (u.cosmetics?.owned?.includes(id)) throw new Error("Tu as déjà cet objet");
  await spend(u.username, item.price, `Boutique · ${item.name}`);
  const fresh = (await getUser(username))!;
  fresh.cosmetics = { ...(fresh.cosmetics || {}), owned: Array.from(new Set([...(fresh.cosmetics?.owned || []), id])) };
  await saveUser(fresh);
  return fresh.cosmetics;
}

export async function equipCosmetic(username: string, type: Cosmetic["type"], id: string | null) {
  const u = await getUser(username);
  if (!u) throw new Error("Compte introuvable");
  if (id) { const item = COSMETICS.find((c) => c.id === id && c.type === type); if (!item || !u.cosmetics?.owned?.includes(id)) throw new Error("Objet non possédé"); }
  u.cosmetics = { ...(u.cosmetics || { owned: [] }), owned: u.cosmetics?.owned || [], [type]: id || undefined };
  await saveUser(u);
  return u.cosmetics;
}

/** Cosmétiques équipés de plusieurs joueurs (pour l'affichage dans Discord). */
export async function equipMap(names: string[]) {
  const out: Record<string, Equip> = {};
  for (const n of Array.from(new Set(names.map((x) => x.toLowerCase()))).slice(0, 60)) {
    const u = await getUser(n);
    if (u?.cosmetics && (u.cosmetics.border || u.cosmetics.name || u.cosmetics.sound)) out[n] = equipOf(u);
  }
  return out;
}
