// TheCombinedWebs Discord — salons texte, messages privés, salons vocaux et appels entre amis.
// Tout passe par l'API Next (aucun serveur externe requis) : la voix est en WebRTC pair-à-pair,
// la signalisation (offres/réponses SDP) transite par de petites boîtes aux lettres côté serveur.
import { delJSON, getJSON, listJSON, setJSON, updateJSON } from "./data-store";
import { getUser, type Role, type User } from "./store";

const STORE = "steamblox-discord";
const MAX_MESSAGES = 200;
const VOICE_TTL = 9000; // un membre sans battement depuis 9 s quitte le salon
const ONLINE_TTL = 70000;
export const VOICE_MAX = 8;
export const REACTIONS = ["👍", "😂", "❤️", "🔥", "😮", "🎮"];

export type Channel = { id: string; name: string; topic: string; icon: string; readOnly?: boolean };
export const TEXT_CHANNELS: Channel[] = [
  { id: "annonces", name: "annonces", topic: "Les nouveautés de l'écosystème TheCombinedWebs", icon: "📣", readOnly: true },
  { id: "general", name: "général", topic: "Discute de tout avec la communauté", icon: "#" },
  { id: "jeux", name: "jeux", topic: "Scores, astuces et parties à organiser", icon: "#" },
  { id: "films", name: "films-et-séries", topic: "Recommandations CinéStream et Vortex", icon: "#" },
  { id: "entraide", name: "entraide", topic: "Une question ? Demande ici", icon: "#" },
  { id: "memes", name: "memes", topic: "Les meilleures blagues (gratuites, celles-là)", icon: "#" },
];
export const VOICE_ROOMS = [
  { id: "vc-general", name: "Salon général" },
  { id: "vc-jeux", name: "Gaming" },
  { id: "vc-cine", name: "Ciné-club" },
  { id: "vc-chill", name: "Chill" },
];

export type Msg = { id: string; at: number; author: string; text: string; reactions?: Record<string, string[]>; edited?: number; replyTo?: { id: string; author: string; text: string } };
type ChanDoc = { id: string; rev: number; messages: Msg[] };
type VoiceMember = { u: string; at: number; joinedAt: number; muted?: boolean; deaf?: boolean; speaking?: boolean };
type VoiceDoc = { room: string; members: Record<string, VoiceMember> };
type Presence = { u: string; at: number; where?: string; voice?: string | null };
export type Signal = { id: string; from: string; to: string; room: string; kind: "offer" | "answer" | "bye"; sdp?: unknown; at: number };
export type Call = { from: string; room: string; at: number };

const low = (u: string) => u.toLowerCase();
export const staff = (r: Role) => r === "creator" || r === "vice_creator" || r === "moderator";
export const dmId = (a: string, b: string) => "dm~" + [low(a), low(b)].sort().join("~");
const rid = () => `${Date.now().toString(36)}${Math.random().toString(36).slice(2, 8)}`;

export function isFriend(me: User, other: string) {
  return (me.friends || []).some((f) => low(f) === low(other));
}

/** Vérifie qu'un utilisateur peut lire/écrire dans un salon (texte ou vocal). */
export function canAccess(me: User, id: string) {
  if (TEXT_CHANNELS.some((c) => c.id === id) || VOICE_ROOMS.some((r) => r.id === id)) return true;
  // Salon de clan (texte « clan~ID », vocal « clanvc~ID ») : réservé aux membres
  if (id.startsWith("clan~") || id.startsWith("clanvc~")) return !!me.clan && id.split("~")[1] === me.clan;
  // Soirée ciné : l'appartenance est vérifiée côté route (asynchrone)
  if (/^party~[A-Z0-9]{6}$/.test(id)) return true;
  // Actual asynchronous membership check is required in all API routes.
  if (/^group(?:vc)?~[a-z-]+$/.test(id)) return true;
  if (id.startsWith("dm~")) {
    const parts = id.split("~").slice(1);
    if (parts.length !== 2 || !parts.includes(low(me.username))) return false;
    const other = parts.find((p) => p !== low(me.username)) || parts[0];
    return isFriend(me, other) || me.role === "creator" || me.role === "vice_creator";
  }
  return false;
}

// ————— Messages —————
export async function getChannel(id: string): Promise<ChanDoc> {
  return (await getJSON<ChanDoc>(STORE, `chan:${id}`)) || { id, rev: 0, messages: [] };
}

const lastSend = new Map<string, number>();
const BAD = /\b(connard|connasse|salope|encul[ée]|fdp|pute|ntm|nique ta m[eè]re|batard|bâtard)\b/gi;
export function cleanText(t: string) {
  return String(t || "").replace(/\r/g, "").replace(/\n{4,}/g, "\n\n\n").trim().slice(0, 1200).replace(BAD, (m) => "•".repeat(m.length));
}

export async function sendMessage(me: User, channel: string, text: string, replyTo?: string) {
  const ch = TEXT_CHANNELS.find((c) => c.id === channel);
  if (ch?.readOnly && me.role !== "creator" && me.role !== "vice_creator") throw new Error("Seuls Younes et Moustafa peuvent écrire ici.");
  const clean = cleanText(text);
  if (!clean) throw new Error("Message vide");
  const now = Date.now();
  if (now - (lastSend.get(low(me.username)) || 0) < 600) throw new Error("Doucement, tu écris trop vite.");
  lastSend.set(low(me.username), now);
  let created: Msg | null = null;
  await updateJSON<ChanDoc>(STORE, `chan:${channel}`, (doc) => {
    const d = doc || { id: channel, rev: 0, messages: [] };
    const parent = replyTo ? d.messages.find((m) => m.id === replyTo) : undefined;
    created = { id: rid(), at: now, author: me.username, text: clean, ...(parent ? { replyTo: { id: parent.id, author: parent.author, text: parent.text.slice(0, 120) } } : {}) };
    d.messages = [...d.messages, created].slice(-MAX_MESSAGES);
    d.rev = (d.rev || 0) + 1;
    return d;
  });
  return created as Msg | null;
}

export async function editMessage(me: User, channel: string, id: string, action: "delete" | "edit" | "react", value?: string) {
  let ok = false;
  await updateJSON<ChanDoc>(STORE, `chan:${channel}`, (doc) => {
    if (!doc) return doc;
    const i = doc.messages.findIndex((m) => m.id === id);
    if (i < 0) return doc;
    const m = doc.messages[i];
    const mine = low(m.author) === low(me.username);
    if (action === "delete") {
      if (!mine && !staff(me.role)) return doc;
      doc.messages.splice(i, 1);
    } else if (action === "edit") {
      const t = cleanText(value || "");
      if (!mine || !t) return doc;
      m.text = t; m.edited = Date.now();
    } else {
      if (!REACTIONS.includes(value || "")) return doc;
      const r = (m.reactions ||= {});
      const list = r[value!] || [];
      r[value!] = list.some((u) => low(u) === low(me.username)) ? list.filter((u) => low(u) !== low(me.username)) : [...list, me.username];
      if (!r[value!].length) delete r[value!];
    }
    doc.rev = (doc.rev || 0) + 1;
    ok = true;
    return doc;
  });
  return ok;
}

// ————— Lu / non lu —————
type ReadDoc = Record<string, number>;
export async function markRead(u: string, channel: string, at: number) {
  await updateJSON<ReadDoc>(STORE, `read:${low(u)}`, (d) => ({ ...(d || {}), [channel]: Math.max(at, d?.[channel] || 0) }));
}
export async function getRead(u: string) {
  return (await getJSON<ReadDoc>(STORE, `read:${low(u)}`)) || {};
}

// ————— Présence —————
export async function touchPresence(u: string, where?: string, voice?: string | null) {
  if(voice?.startsWith("groupvc~")){const {groupAccess}=await import("./tcb");if(!(await groupAccess(u,voice)))voice=null;}
  const prev = await getJSON<Presence>(STORE, `presence:${low(u)}`);
  const now = Date.now();
  // Évite d'écrire à chaque requête : une fois toutes les 15 s suffit, sauf si l'activité change.
  if (prev && now - prev.at < 15000 && prev.where === (where ?? prev.where) && (voice === undefined || prev.voice === voice)) return;
  await setJSON<Presence>(STORE, `presence:${low(u)}`, { u, at: now, where: where ?? prev?.where, voice: voice === undefined ? prev?.voice ?? null : voice });
  if (where?.startsWith("Joue à ") && where !== prev?.where && (!prev || now-prev.at > 60000 || !prev.where?.startsWith("Joue à "))) {
    const { notifyFriendPlaying } = await import("./push");
    await notifyFriendPlaying(u,where).catch(()=>{});
  }
}
export async function friendsPresence(me: User) {
  const friends = me.friends || [];
  const now = Date.now();
  return Promise.all(
    friends.map(async (f) => {
      const p = await getJSON<Presence>(STORE, `presence:${low(f)}`);
      const online = !!p && now - p.at < ONLINE_TTL;
      return { username: f, online, where: online ? p?.where || "" : "", voice: online ? p?.voice || null : null, lastSeen: p?.at || 0 };
    }),
  );
}

// ————— Vocal —————
function prune(doc: VoiceDoc | null, room: string): VoiceDoc {
  const d = doc || { room, members: {} };
  const now = Date.now();
  for (const [k, m] of Object.entries(d.members)) if (now - m.at > VOICE_TTL) delete d.members[k];
  return d;
}
export async function voiceMembers(room: string) {
  const d = prune(await getJSON<VoiceDoc>(STORE, `voice:${room}`), room);
  return Object.values(d.members).sort((a, b) => a.joinedAt - b.joinedAt);
}
export async function voiceBeat(me: User, room: string, state: { muted?: boolean; deaf?: boolean; speaking?: boolean }, join = false) {
  let full = false;
  const doc = await updateJSON<VoiceDoc>(STORE, `voice:${room}`, (cur) => {
    const d = prune(cur, room);
    const k = low(me.username);
    if (!d.members[k] && Object.keys(d.members).length >= VOICE_MAX) { full = true; return d; }
    if (!d.members[k] && !join) return d; // un battement après un « leave » ne doit pas re-rejoindre
    d.members[k] = { u: me.username, at: Date.now(), joinedAt: d.members[k]?.joinedAt || Date.now(), muted: !!state.muted, deaf: !!state.deaf, speaking: !!state.speaking };
    return d;
  });
  if (full) throw new Error(`Salon complet (${VOICE_MAX} personnes max).`);
  return Object.values(doc?.members || {}).sort((a, b) => a.joinedAt - b.joinedAt);
}
export async function voiceLeave(me: User, room: string) {
  await updateJSON<VoiceDoc>(STORE, `voice:${room}`, (cur) => {
    const d = prune(cur, room);
    delete d.members[low(me.username)];
    return d;
  });
}

export async function pushSignal(from: string, room: string, s: { to: string; kind: Signal["kind"]; sdp?: unknown }) {
  const sig: Signal = { id: rid(), from, to: s.to, room, kind: s.kind, sdp: s.sdp, at: Date.now() };
  await setJSON(STORE, `sig:${low(s.to)}:${sig.id}`, sig);
}
export async function takeSignals(u: string) {
  const list = await listJSON<Signal>(STORE, `sig:${low(u)}:`);
  await Promise.all(list.map((s) => delJSON(STORE, `sig:${low(u)}:${s.id}`)));
  const now = Date.now();
  return list.filter((s) => now - s.at < 30000).sort((a, b) => a.at - b.at);
}

// ————— Appels privés —————
export async function ring(me: User, to: string) {
  const other = await getUser(to);
  if (!other || other.banned) throw new Error("Utilisateur introuvable");
  if (!isFriend(me, other.username)) throw new Error("Vous devez être amis pour vous appeler.");
  const room = dmId(me.username, other.username);
  await setJSON<Call>(STORE, `call:${low(other.username)}`, { from: me.username, room, at: Date.now() });
  return room;
}
export async function getCall(u: string) {
  const c = await getJSON<Call>(STORE, `call:${low(u)}`);
  if (!c || Date.now() - c.at > 45000) return null;
  return c;
}
export async function clearCall(u: string) {
  await delJSON(STORE, `call:${low(u)}`);
}

/** Nombre de messages privés non lus (pour les notifications globales). */
export async function unreadDMs(me: User) {
  const read = await getRead(me.username);
  const out: { from: string; channel: string; at: number; text: string }[] = [];
  for (const f of me.friends || []) {
    const id = dmId(me.username, f);
    const doc = await getJSON<ChanDoc>(STORE, `chan:${id}`);
    const last = doc?.messages[doc.messages.length - 1];
    if (last && low(last.author) !== low(me.username) && last.at > (read[id] || 0)) out.push({ from: last.author, channel: id, at: last.at, text: last.text.slice(0, 90) });
  }
  return out;
}

// ————— Signalements —————
export type Report = { id: string; by: string; channel: string; msgId: string; author: string; text: string; reason: string; at: number; status: "open" | "done" };
export async function reportMessage(me: User, channel: string, msgId: string, reason: string) {
  const ch = await getChannel(channel);
  const m = ch.messages.find((x) => x.id === msgId);
  if (!m) throw new Error("Message introuvable");
  if (low(m.author) === low(me.username)) throw new Error("Tu ne peux pas signaler ton propre message");
  const r: Report = { id: rid(), by: me.username, channel, msgId, author: m.author, text: m.text.slice(0, 500), reason: cleanText(reason).slice(0, 200) || "Non précisé", at: Date.now(), status: "open" };
  await setJSON(STORE, `report:${r.id}`, r);
  return r;
}
export async function listReports() {
  return (await listJSON<Report>(STORE, "report:")).filter((r) => r.status === "open").sort((a, b) => b.at - a.at);
}
export async function closeReport(id: string, removeMessage: boolean, actor: User) {
  const r = await getJSON<Report>(STORE, `report:${id}`);
  if (!r) return null;
  if (removeMessage) await editMessage(actor, r.channel, r.msgId, "delete");
  r.status = "done";
  await setJSON(STORE, `report:${id}`, r);
  return r;
}
