import { onNetlify } from "./runtime";
import { randomBytes, createHash } from "node:crypto";
import { promises as fs } from "node:fs";
import path from "node:path";
import { getStore } from "@netlify/blobs";

type Session = { username: string; expiresAt: number; credentialVersion?: string };
export const credentialVersion = (passwordHash: string) => createHash("sha256").update("password-version\0" + passwordHash).digest("hex");
export function sessionMatchesCredential(session: Session, user: { passwordHash: string; passwordResetAt?: string }) {
  return session.credentialVersion ? session.credentialVersion === credentialVersion(user.passwordHash) : !user.passwordResetAt;
}
const valid = (token: string) => /^[A-Za-z0-9_-]{43}$/.test(token);
const key = (token: string) => createHash("sha256").update(token).digest("hex");
const directory = () => path.join(process.env.TCB_DATA_DIR || path.join(process.cwd(), "data"), "sessions");
const remote = () => getStore({ name: "steamblox-sessions", consistency: "strong" });

export async function newSession(username: string, version?: string) {
  const token = randomBytes(32).toString("base64url");
  const record: Session = { username, expiresAt: Date.now() + 604800000, credentialVersion: version };
  if (onNetlify()) {
    // Do not silently fall back to an instance-local key or cookie on failure.
    await remote().setJSON(key(token), record);
  } else {
    await fs.mkdir(directory(), { recursive: true, mode: 0o700 });
    await fs.writeFile(path.join(directory(), key(token) + ".json"), JSON.stringify(record), { flag: "wx", mode: 0o600 });
  }
  return token;
}

export async function revokeSession(token: string) {
  if (!valid(token)) return;
  if (onNetlify()) await remote().delete(key(token));
  else await fs.rm(path.join(directory(), key(token) + ".json"), { force: true });
}

export async function readSession(token: string): Promise<Session | null> {
  if (!valid(token)) return null;
  let record: Session | null;
  if (onNetlify()) record = await remote().get(key(token), { type: "json" }) as Session | null;
  else {
    try { record = JSON.parse(await fs.readFile(path.join(directory(), key(token) + ".json"), "utf8")); }
    catch (error) { if ((error as NodeJS.ErrnoException).code === "ENOENT") return null; throw error; }
  }
  if (!record || typeof record.username !== "string" || !Number.isFinite(record.expiresAt) || record.expiresAt <= Date.now()) {
    if (record) await revokeSession(token);
    return null;
  }
  return record;
}
