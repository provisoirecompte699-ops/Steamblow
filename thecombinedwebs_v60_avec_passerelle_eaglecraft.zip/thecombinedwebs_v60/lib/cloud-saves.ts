import { getJSON, setJSON } from "./data-store";
import { catalog, getUser, saveUser } from "./store";
import { serial } from "./feature-lock";
export type CloudSave = {
  version: number;
  updatedAt: number;
  data: { bestScore: number; achievements: string[]; difficulty: string };
};
const STORE = "tcb-cloud-saves";
export function localGame(id: string) {
  return (
    !["snokido", "gta-web"].includes(id) &&
    catalog.some((g) => g.id === id && !g.externalUrl && g.playable)
  );
}
export async function cloudSave(username: string, gameId: string) {
  if (!localGame(gameId)) throw new Error("Jeu local inconnu.");
  return (
    (await getJSON<CloudSave>(
      STORE,
      `save:${username.toLowerCase()}:${gameId}`,
    )) || {
      version: 0,
      updatedAt: 0,
      data: { bestScore: 0, achievements: [], difficulty: "normal" },
    }
  );
}
export class SaveConflict extends Error {}
export async function writeCloudSave(
  username: string,
  gameId: string,
  raw: unknown,
  baseVersion: number,
) {
  if (!localGame(gameId))
    throw new Error("Les sauvegardes sont réservées aux jeux locaux.");
  const b = raw as CloudSave["data"];
  if (
    !b ||
    !Number.isInteger(b.bestScore) ||
    b.bestScore < 0 ||
    b.bestScore > 2000000 ||
    !Array.isArray(b.achievements) ||
    b.achievements.length > 100 ||
    b.achievements.some(
      (x) => typeof x !== "string" || !/^[a-z0-9_-]{1,60}$/.test(x),
    ) ||
    !["easy", "normal", "hard"].includes(b.difficulty)
  )
    throw new Error("Sauvegarde invalide.");
  return serial(`save:${username.toLowerCase()}:${gameId}`, async () => {
    const current = await cloudSave(username, gameId);
    if (current.version !== baseVersion)
      throw new SaveConflict(
        "Une autre session a modifié la sauvegarde. Recharge la sauvegarde cloud.",
      );
    const s: CloudSave = {
      version: current.version + 1,
      updatedAt: Date.now(),
      data: {
        bestScore: Math.max(b.bestScore, current.data.bestScore),
        achievements: [
          ...new Set([...current.data.achievements, ...b.achievements]),
        ].slice(0, 100),
        difficulty: b.difficulty,
      },
    };
    await setJSON(STORE, `save:${username.toLowerCase()}:${gameId}`, s);
    return s;
  });
}
