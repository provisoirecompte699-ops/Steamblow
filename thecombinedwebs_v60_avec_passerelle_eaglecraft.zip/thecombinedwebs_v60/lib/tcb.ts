import {getJSON,listJSON,setJSON,updateJSON} from "./data-store";
import {getUser,catalog,type User} from "./store";
import {credit} from "./bobux";
import {isSubscriber} from "./tcb-bank";
import crypto from "node:crypto";

const DAY=86400000;
const low=(s:string)=>s.toLowerCase();
const clean=(s:unknown,n:number)=>String(s??"").replace(/[<>]/g,"").trim().slice(0,n);
export const today=()=>new Date().toISOString().slice(0,10);
export const isStaff=(u:Pick<User,"role">)=>u.role==="moderator"||u.role==="vice_creator"||u.role==="creator";

/* ---------- Jeu du jour ---------- */
export function gameOfDay(date=today()){
  const ids=catalog.filter(g=>g.playable&&g.status==="available").map(g=>g.id);
  let h=0;for(const c of date)h=(h*31+c.charCodeAt(0))>>>0;
  return ids[h%ids.length];
}
export async function claimDaily(me:string){
  const u=await getUser(me);if(!u)return {error:"Utilisateur introuvable"};
  if(!((u.xpDaily?.date===today())&&(u.xpDaily.by.arcade||0)>0))return {error:"Joue d’abord une partie arcade aujourd’hui."};
  const key=`claim:${low(me)}:${today()}`;
  if(await getJSON("tcb-daily",key))return {error:"Déjà récupéré aujourd’hui."};
  await setJSON("tcb-daily",key,{at:Date.now()});
  const amount=(await isSubscriber(me))?50:25;
  await credit(me,amount,"TCB","Jeu du jour","quest");
  return {ok:true,amount};
}

/* ---------- Badges & titres ---------- */
export type Title={id:string;label:string;icon:string;need:string;ok:boolean};
export async function titlesFor(u:User):Promise<Title[]>{
  const refs=(await getJSON<{n:number}>("tcb-referral",`count:${low(u.username)}`))?.n??0;
  const rules:[string,string,string,string,boolean][]=[
    ["rookie","Recrue","🌱","Créer un compte",true],
    ["marathon","Marathonien","⏱️","10 h de jeu",(u.playTimeMinutes||0)>=600],
    ["streak","Assidu","🔥","Série de 7 jours",(u.loginStreak||0)>=7],
    ["social","Sociable","🤝","5 amis",(u.friends?.length||0)>=5],
    ["collector","Collectionneur","🏅","10 succès",(u.achievements?.length||0)>=10],
    ["rich","Riche en Bobux","💰","1000 Bobux",(u.bobux||0)>=1000],
    ["xp","Vétéran","⭐","5000 XP",(u.xp||0)>=5000],
    ["recruiter","Recruteur","📣","Parrainer 3 amis",refs>=3],
    ["premium","Premium","💎","S’abonner à TCB Premium",await isSubscriber(u.username)],
  ];
  return rules.map(([id,label,icon,need,ok])=>({id,label,icon,need,ok}));
}
export async function setTitle(me:string,id:string){
  const u=await getUser(me);if(!u)return {error:"Introuvable"};
  const t=(await titlesFor(u)).find(x=>x.id===id);
  if(!t||!t.ok)return {error:"Titre non débloqué"};
  await setJSON("tcb-profile",`title:${low(me)}`,{id});return {ok:true};
}
export async function activeTitle(me:string){return (await getJSON<{id:string}>("tcb-profile",`title:${low(me)}`))?.id??null}

/* ---------- Stories éphémères (24 h) ---------- */
export type Story={id:string;author:string;text:string;emoji:string;gameId?:string;at:number};
export async function createStory(author:string,text:unknown,emoji:unknown,gameId?:unknown){
  const t=clean(text,140);if(!t)return {error:"Écris quelque chose."};
  const all=await listJSON<Story>("tcb-stories","story:");
  if(all.filter(s=>low(s.author)===low(author)&&Date.now()-s.at<DAY).length>=((await isSubscriber(author))?10:5))return {error:"Limite de stories atteinte pour 24 h."};
  const g=catalog.some(x=>x.id===gameId)?String(gameId):undefined;
  const s:Story={id:`story_${crypto.randomUUID()}`,author,text:t,emoji:clean(emoji,4)||"🎮",gameId:g,at:Date.now()};
  await setJSON("tcb-stories",`story:${s.id}`,s);return {ok:true,story:s};
}
export async function listStories(me:string){
  const u=await getUser(me);const ok=new Set([me,...(u?.friends||[])].map(low));
  const all=await listJSON<Story>("tcb-stories","story:");
  return all.filter(s=>Date.now()-s.at<DAY&&ok.has(low(s.author))).sort((a,b)=>b.at-a.at).slice(0,60);
}

/* ---------- Statut « en jeu » ---------- */
type Presence={user:string;gameId:string|null;at:number};
export async function setPresence(me:string,gameId:unknown){
  const g=catalog.some(x=>x.id===gameId)?String(gameId):null;
  await setJSON<Presence>("tcb-presence",`presence:${low(me)}`,{user:me,gameId:g,at:Date.now()});
}
export async function friendsPlaying(me:string){
  const u=await getUser(me);const fr=new Set((u?.friends||[]).map(low));
  const all=await listJSON<Presence>("tcb-presence","presence:");
  return all.filter(p=>fr.has(low(p.user))&&p.gameId&&Date.now()-p.at<150000).map(p=>({user:p.user,gameId:p.gameId}));
}

/* ---------- Parrainage ---------- */
export async function referralInfo(me:string){
  const n=(await getJSON<{n:number}>("tcb-referral",`count:${low(me)}`))?.n??0;
  const used=await getJSON<{by:string}>("tcb-referral",`used:${low(me)}`);
  return {code:me,count:n,usedCode:used?.by??null};
}
export async function redeemReferral(me:string,raw:unknown){
  const code=clean(raw,24);
  if(!code||low(code)===low(me))return {error:"Code invalide."};
  if(await getJSON("tcb-referral",`used:${low(me)}`))return {error:"Tu as déjà utilisé un code de parrainage."};
  const target=await getUser(code);if(!target||target.banned)return {error:"Aucun joueur avec ce code."};
  const cur=(await getJSON<{n:number}>("tcb-referral",`count:${low(target.username)}`))?.n??0;
  if(cur>=20)return {error:"Ce parrain a atteint la limite de 20 filleuls."};
  await setJSON("tcb-referral",`used:${low(me)}`,{by:target.username,at:Date.now()});
  await setJSON("tcb-referral",`count:${low(target.username)}`,{n:cur+1});
  await credit(me,100,target.username,"Parrainage (filleul)","gift");
  await credit(target.username,100,me,"Parrainage (parrain)","gift");
  return {ok:true,amount:100};
}

/* ---------- Groupes thématiques ---------- */
const GROUPS=[
  {slug:"speedrun",name:"Speedrun",icon:"⚡"},{slug:"cinema",name:"Cinéphiles",icon:"🍿"},
  {slug:"coop",name:"Coop & salons",icon:"🤝"},{slug:"arcade",name:"Arcade",icon:"🕹️"},
  {slug:"createurs",name:"Créateurs de niveaux",icon:"🧱"},
];
export async function listGroups(me:string){
  return Promise.all(GROUPS.map(async g=>{
    const r=await getJSON<{members:string[]}>("tcb-groups",`group:${g.slug}`);const m=r?.members||[];
    return {...g,count:m.length,joined:m.some(x=>low(x)===low(me))};
  }));
}
export async function toggleGroup(me:string,slug:unknown,join:boolean){
  if(!GROUPS.some(g=>g.slug===slug))return {error:"Groupe inconnu"};
  const key=`group:${slug}`;
  await updateJSON<{members:string[]}>("tcb-groups",key,v=>{const rest=(v?.members||[]).filter(x=>low(x)!==low(me));return {members:join?[...rest,me].slice(0,500):rest};});return {ok:true};
}
export async function groupAccess(username:string,channel:string) {
  if(!channel.startsWith("group~")&&!channel.startsWith("groupvc~"))return true;
  const slug=channel.split("~")[1];
  if(!GROUPS.some(g=>g.slug===slug))return false;
  const d=await getJSON<{members:string[]}>("tcb-groups",`group:${slug}`);
  return !!d?.members.some(u=>low(u)===low(username));
}

/* ---------- Signalements ---------- */
export type Report={id:string;reporter:string;target:string;reason:string;details:string;status:"open"|"actioned"|"dismissed";note?:string;decidedBy?:string;decidedAt?:number;at:number};
export const REASONS=["Triche","Harcèlement","Contenu inapproprié","Spam","Autre"];
export async function createReport(me:string,target:unknown,reason:unknown,details:unknown){
  const t=await getUser(clean(target,24));if(!t)return {error:"Joueur introuvable."};
  if(low(t.username)===low(me))return {error:"Tu ne peux pas te signaler toi-même."};
  const r=REASONS.includes(String(reason))?String(reason):"Autre";
  const all=await listJSON<Report>("tcb-reports","report:");
  if(all.filter(x=>low(x.reporter)===low(me)&&Date.now()-x.at<DAY).length>=5)return {error:"5 signalements maximum par jour."};
  const rep:Report={id:`report_${crypto.randomUUID()}`,reporter:me,target:t.username,reason:r,details:clean(details,500),status:"open",at:Date.now()};
  await setJSON("tcb-reports",`report:${rep.id}`,rep);return {ok:true};
}
export async function listReports(){
  return (await listJSON<Report>("tcb-reports","report:")).sort((a,b)=>(a.status==="open"?0:1)-(b.status==="open"?0:1)||b.at-a.at).slice(0,100);
}
export async function decideReport(by:string,id:unknown,status:unknown,note:unknown){
  const key=`report:${clean(id,80)}`;const r=await getJSON<Report>("tcb-reports",key);if(!r)return {error:"Introuvable"};
  if(status!=="actioned"&&status!=="dismissed"&&status!=="open")return {error:"Statut invalide"};
  await setJSON("tcb-reports",key,{...r,status,note:clean(note,300),decidedBy:by,decidedAt:Date.now()});return {ok:true};
}


/* ---------- Recherche globale ---------- */
export const PAGES=[
  {href:"/steamblox",label:"Accueil"},{href:"/discord",label:"Discord"},{href:"/cinestream",label:"CinéStream"},
  {href:"/vortex",label:"Vortex"},{href:"/tiktok",label:"TikTok"},{href:"/classements",label:"Classements"},
  {href:"/tournois",label:"Tournois"},{href:"/clans",label:"Clans"},{href:"/passe",label:"Passe & boutique"},
  {href:"/editeur",label:"Éditeur de niveaux"},{href:"/multiplayer",label:"Multijoueur"},{href:"/tcb",label:"TCB Plus"},
  {href:"/account",label:"Mon compte"},{href:"/credits",label:"Crédits"},{href:"/games/eaglecraft",label:"EagleCraft"},
];
