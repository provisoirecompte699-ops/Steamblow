export function sameRequestOrigin(req: Request) {
  const value=req.headers.get("origin");
  if(!value)return true; // authenticated server/API clients may omit Origin
  try {
    const origin=new URL(value);
    const host=(req.headers.get("x-forwarded-host")?.split(",")[0].trim()||req.headers.get("host")||new URL(req.url).host).toLowerCase();
    const protocol=(req.headers.get("x-forwarded-proto")?.split(",")[0].trim()||new URL(req.url).protocol.replace(":",""))+":";
    return origin.host.toLowerCase()===host&&origin.protocol===protocol;
  } catch { return false; }
}
