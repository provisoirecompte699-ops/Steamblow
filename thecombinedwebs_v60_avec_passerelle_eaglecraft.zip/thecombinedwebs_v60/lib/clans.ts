// Clans : une équipe avec son logo, son salon privé (texte + vocal) et un classement.
import { getJSON, listJSON, setJSON, delJSON } from "./data-store";
import { getUser, saveUser } from "./store";
import { levelInfo } from "./progression";

const STORE = "steamblox-clans";
export const CLAN_MAX = 20;
export const CLAN_EMOJIS = ["🐺", "🦅", "🐉", "⚡", "🔥", "💀", "👾", "🚀", "🌙", "🍀", "🦊", "🛡️"];
export const CLAN_COLORS = ["#8b7cff", "#5ee7c4", "#ff6b6b", "#ffd43b", "#4dabf7", "#f783ac", "#69db7c", "#ff922b"];

export type Clan = { id: string; name: string; tag: string; emoji: string; color: string; motto: string; owner: string; members: string[]; createdAt: number; open: boolean };

const low = (s: string) => s.toLowerCase();
export const getClan = (id: string) => getJSON<Clan>(STORE, `clan:${id}`);
export async function listClans() { return listJSON<Clan>(STORE, "clan:"); }

export async function clanRanking() {
  const clans = await listClans();
  const out = [] as (Clan & { xp: number; avgLevel: number })[];
  for (const c of clans) {
    let xp = 0, lv = 0;
    for (const m of c.members) { const u = await getUser(m); xp += u?.xp || 0; lv += levelInfo(u?.xp || 0).level; }
    out.push({ ...c, xp, avgLevel: c.members.length ? Math.round(lv / c.members.length) : 0 });
  }
  return out.sort((a, b) => b.xp - a.xp);
}

export async function createClan(username: string, o: { name: string; tag: string; emoji: string; color: string; motto?: string; open?: boolean }) {
  const u = await getUser(username);
  if (!u) throw new Error("Compte introuvable");
  if (u.clan && (await getClan(u.clan))) throw new Error("Quitte ton clan actuel avant d'en créer un.");
  const name = String(o.name || "").replace(/\s+/g, " ").trim().slice(0, 28);
  const tag = String(o.tag || "").toUpperCase().replace(/[^A-Z0-9]/g, "").slice(0, 5);
  if (name.length < 3) throw new Error("Nom trop court (3 caractères minimum)");
  if (tag.length < 2) throw new Error("Tag trop court (2 à 5 lettres)");
  const all = await listClans();
  if (all.some((c) => low(c.name) === low(name) || c.tag === tag)) throw new Error("Ce nom ou ce tag est déjà pris");
  const id = Math.random().toString(36).slice(2, 8).toUpperCase();
  const clan: Clan = { id, name, tag, emoji: CLAN_EMOJIS.includes(o.emoji) ? o.emoji : "🐺", color: CLAN_COLORS.includes(o.color) ? o.color : CLAN_COLORS[0], motto: String(o.motto || "").slice(0, 80), owner: u.username, members: [u.username], createdAt: Date.now(), open: o.open !== false };
  await setJSON(STORE, `clan:${id}`, clan);
  u.clan = id; await saveUser(u);
  return clan;
}

export async function joinClan(username: string, id: string) {
  const u = await getUser(username);
  const c = await getClan(String(id || "").toUpperCase());
  if (!u || !c) throw new Error("Clan introuvable (vérifie le code)");
  if (u.clan === c.id) return c;
  if (u.clan && (await getClan(u.clan))) throw new Error("Quitte ton clan actuel d'abord.");
  if (c.members.length >= CLAN_MAX) throw new Error("Ce clan est complet");
  c.members = Array.from(new Set([...c.members, u.username]));
  await setJSON(STORE, `clan:${c.id}`, c);
  u.clan = c.id; await saveUser(u);
  return c;
}

export async function leaveClan(username: string) {
  const u = await getUser(username);
  if (!u?.clan) return null;
  const c = await getClan(u.clan);
  u.clan = undefined; await saveUser(u);
  if (!c) return null;
  c.members = c.members.filter((m) => low(m) !== low(username));
  if (!c.members.length) { await delJSON(STORE, `clan:${c.id}`); return null; }
  if (low(c.owner) === low(username)) c.owner = c.members[0];
  await setJSON(STORE, `clan:${c.id}`, c);
  return c;
}

export async function kickFromClan(owner: string, target: string) {
  const o = await getUser(owner);
  const c = o?.clan ? await getClan(o.clan) : null;
  if (!c || low(c.owner) !== low(owner)) throw new Error("Seul le chef du clan peut exclure");
  if (low(target) === low(owner)) throw new Error("Tu ne peux pas t'exclure toi-même");
  c.members = c.members.filter((m) => low(m) !== low(target));
  await setJSON(STORE, `clan:${c.id}`, c);
  const t = await getUser(target);
  if (t && t.clan === c.id) { t.clan = undefined; await saveUser(t); }
  return c;
}

export async function updateClan(owner: string, patch: { motto?: string; emoji?: string; color?: string; open?: boolean }) {
  const o = await getUser(owner);
  const c = o?.clan ? await getClan(o.clan) : null;
  if (!c || low(c.owner) !== low(owner)) throw new Error("Seul le chef du clan peut modifier");
  if (patch.motto !== undefined) c.motto = String(patch.motto).slice(0, 80);
  if (patch.emoji && CLAN_EMOJIS.includes(patch.emoji)) c.emoji = patch.emoji;
  if (patch.color && CLAN_COLORS.includes(patch.color)) c.color = patch.color;
  if (patch.open !== undefined) c.open = !!patch.open;
  await setJSON(STORE, `clan:${c.id}`, c);
  return c;
}
