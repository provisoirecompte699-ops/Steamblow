// Tournois à élimination directe : chaque match = les deux joueurs font une partie
// sur la même carte (graine commune), le meilleur score passe au tour suivant.
import { getJSON, listJSON, setJSON, updateJSON } from "./data-store";
import { credit } from "./bobux";
import { awardXp, grantBadge } from "./progression";
import { gameById } from "./leaderboard";

const STORE = "steamblox-tournaments";
export const TOURNEY_PRIZE = 200;

export type Match = { id: string; a: string | null; b: string | null; sa?: number; sb?: number; winner?: string | null };
export type Tournament = {
  id: string; name: string; gameId: string; size: 4 | 8; createdBy: string; createdAt: number; seed: number;
  players: string[]; status: "open" | "running" | "done"; rounds: Match[][]; champion?: string; clan?: string | null;
};

const rid = (n = 6) => Math.random().toString(36).slice(2, 2 + n).toUpperCase();
const low = (s: string | null | undefined) => (s || "").toLowerCase();

export async function listTournaments() {
  return (await listJSON<Tournament>(STORE, "t:")).sort((a, b) => b.createdAt - a.createdAt).slice(0, 40);
}
export const getTournament = (id: string) => getJSON<Tournament>(STORE, `t:${id}`);

export async function createTournament(u: string, name: string, gameId: string, size: number) {
  if (!gameById(gameId)) throw new Error("Jeu invalide");
  const clean = String(name || "").replace(/\s+/g, " ").trim().slice(0, 40) || `Tournoi de ${u}`;
  const t: Tournament = { id: rid(), name: clean, gameId, size: size === 8 ? 8 : 4, createdBy: u, createdAt: Date.now(), seed: Math.floor(Math.random() * 2 ** 31), players: [u], status: "open", rounds: [] };
  await setJSON(STORE, `t:${t.id}`, t);
  return t;
}

function shuffle<T>(a: T[]) { const b = [...a]; for (let i = b.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); [b[i], b[j]] = [b[j], b[i]]; } return b; }

function build(t: Tournament) {
  const seats: (string | null)[] = shuffle(t.players);
  while (seats.length < t.size) seats.push(null);
  const first: Match[] = [];
  for (let i = 0; i < t.size; i += 2) first.push({ id: `r0m${i / 2}`, a: seats[i], b: seats[i + 1] });
  t.rounds = [first];
  for (let r = 1, n = t.size / 4; n >= 1; r++, n /= 2) t.rounds.push(Array.from({ length: n }, (_, i) => ({ id: `r${r}m${i}`, a: null, b: null })));
  t.status = "running";
  advance(t);
}

/** Fait avancer les gagnants (et les « byes ») dans le tableau. */
function advance(t: Tournament) {
  for (let r = 0; r < t.rounds.length; r++) {
    for (let i = 0; i < t.rounds[r].length; i++) {
      const m = t.rounds[r][i];
      if (m.winner === undefined) {
        const prevDone = r === 0 || t.rounds[r - 1].slice(i * 2, i * 2 + 2).every((x) => x.winner !== undefined);
        if (!prevDone) continue;
        if (m.a && !m.b) m.winner = m.a;
        else if (!m.a && m.b) m.winner = m.b;
        else if (!m.a && !m.b) m.winner = null;
        else if (m.sa != null && m.sb != null) m.winner = m.sa >= m.sb ? m.a : m.b;
      }
      if (m.winner !== undefined && r + 1 < t.rounds.length) {
        const next = t.rounds[r + 1][Math.floor(i / 2)];
        if (i % 2 === 0) next.a = m.winner; else next.b = m.winner;
      }
    }
  }
  const final = t.rounds[t.rounds.length - 1]?.[0];
  if (final && final.winner !== undefined && t.status !== "done") { t.status = "done"; t.champion = final.winner || undefined; }
}

export async function joinTournament(u: string, id: string) {
  let err = "";
  const t = await updateJSON<Tournament>(STORE, `t:${id}`, (t) => {
    if (!t) { err = "Tournoi introuvable"; return t; }
    if (t.status !== "open") { err = "Les inscriptions sont fermées"; return t; }
    if (t.players.some((p) => low(p) === low(u))) return t;
    if (t.players.length >= t.size) { err = "Tournoi complet"; return t; }
    t.players.push(u);
    if (t.players.length === t.size) build(t);
    return t;
  });
  if (err) throw new Error(err);
  return t;
}
export async function leaveTournament(u: string, id: string) {
  return updateJSON<Tournament>(STORE, `t:${id}`, (t) => {
    if (!t || t.status !== "open") return t;
    t.players = t.players.filter((p) => low(p) !== low(u));
    return t.players.length ? t : null;
  });
}
export async function startTournament(u: string, id: string) {
  let err = "";
  const t = await updateJSON<Tournament>(STORE, `t:${id}`, (t) => {
    if (!t) { err = "Tournoi introuvable"; return t; }
    if (low(t.createdBy) !== low(u)) { err = "Seul l'organisateur peut lancer le tournoi"; return t; }
    if (t.status !== "open") return t;
    if (t.players.length < 2) { err = "Il faut au moins 2 joueurs"; return t; }
    if (t.players.length <= 4) t.size = 4;
    build(t);
    return t;
  });
  if (err) throw new Error(err);
  await rewardIfDone(t);
  return t;
}

/** Trouve le match en cours d'un joueur. */
export function currentMatch(t: Tournament, u: string) {
  for (const round of t.rounds) for (const m of round) {
    if (m.winner !== undefined) continue;
    if (low(m.a) === low(u) && m.sa == null && m.b) return m;
    if (low(m.b) === low(u) && m.sb == null && m.a) return m;
  }
  return null;
}

export async function reportMatch(u: string, id: string, matchId: string, score: number) {
  let done = false;
  const t = await updateJSON<Tournament>(STORE, `t:${id}`, (t) => {
    if (!t || t.status !== "running") return t;
    const m = t.rounds.flat().find((x) => x.id === matchId);
    if (!m || m.winner !== undefined) return t;
    if (low(m.a) === low(u) && m.sa == null) m.sa = Math.floor(score);
    else if (low(m.b) === low(u) && m.sb == null) m.sb = Math.floor(score);
    else return t;
    advance(t);
    done = (t.status as string) === "done";
    return t;
  });
  if (done) await rewardIfDone(t);
  return t;
}

async function rewardIfDone(t: Tournament | null) {
  if (!t || t.status !== "done" || !t.champion) return;
  const flag = await getJSON<{ ok: boolean }>(STORE, `paid:${t.id}`);
  if (flag) return;
  await setJSON(STORE, `paid:${t.id}`, { ok: true });
  try { await credit(t.champion, TOURNEY_PRIZE, "system", `Vainqueur du tournoi ${t.name}`, "quest"); } catch { /* ignore */ }
  await grantBadge(t.champion, "champion");
  await awardXp(t.champion, 300, "tournament");
}
