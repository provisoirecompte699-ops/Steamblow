import { io, type Socket } from "socket.io-client";

export type Multiplayer = { socket: Socket; roomId: string; close: () => void };

export function connectMultiplayer(roomId: string, username: string, game: string): Multiplayer | null {
  const url = process.env.NEXT_PUBLIC_MULTIPLAYER_SERVER_URL;
  if (!url || typeof window === "undefined") return null;
  const socket = io(url, {
    transports: ["websocket", "polling"],
    reconnection: true,
    reconnectionAttempts: Infinity,
    reconnectionDelay: 500,
    timeout: 5000,
    auth: { name: username.slice(0, 20), game: game.slice(0, 40) },
  });
  const join = () => socket.emit("room:join", { roomId, name: username, game });
  socket.on("connect", join);
  return { socket, roomId, close: () => { socket.off("connect", join); socket.disconnect(); } };
}

// ————— Types pour le multijoueur simple —————
export type PlayerInfo = { id: string; name: string; x: number; y: number; vx: number; vy: number; rotation: number; score: number; game: string; ready: boolean; team: number; troll?: boolean };
export type RoomMeta = { hostId: string | null; started: boolean; maxPlayers: number; players: PlayerInfo[]; hostOptions: Record<string, unknown>; hostEntities: HostEntity[] };
export type HostEntity = { type: string; x: number; y: number; count: number; id: string };
export type HostOptions = { difficulty?: string; speed?: number; gravity?: number; monsterRate?: number; chaos?: number; friendlyFire?: boolean; fog?: number; invincible?: boolean; oneHitKO?: boolean; slowMotion?: number; bigHead?: boolean; lowGravity?: boolean; explosions?: boolean; darkness?: boolean };

export const MONSTER_TYPES = [
  { type: "blob", label: "Blob", icon: "🟢", desc: "Monstre lent mais résistant" },
  { type: "fast", label: "Rapide", icon: "💨", desc: "Très rapide, peu de PV" },
  { type: "tank", label: "Tank", icon: "🛡️", desc: "Très résistant, lent" },
  { type: "swarm", label: "Essaim", icon: "🐝", desc: "5 monstres petits et rapides" },
  { type: "boss", label: "Boss", icon: "👹", desc: "Géant avec beaucoup de PV" },
  { type: "ghost", label: "Fantôme", icon: "👻", desc: "Invisible par moments" },
  { type: "spike", label: "Pic", icon: "🔺", desc: "Monstre qui charge" },
  { type: "explode", label: "Bombe", icon: "💣", desc: "Explose à proximité" },
];

export const HOST_ACTIONS = [
  { action: "heal", label: "Soigner tous", icon: "💚" },
  { action: "damage", label: "Dégâts à tous", icon: "💥" },
  { action: "reset", label: "Reset entités", icon: "🔄" },
  { action: "chaos", label: "Chaos total", icon: "🌪️" },
  { action: "freeze", label: "Geler tous", icon: "❄️" },
  { action: "speed", label: "Accélérer", icon: "⚡" },
  { action: "slow", label: "Ralentir", icon: "🐌" },
  { action: "rain", label: "Pluie de bonus", icon: "🌟" },
  { action: "jumpscare", label: "Jump-scare", icon: "😱" },
  { action: "party", label: "Mode fête", icon: "🎉" },
];
