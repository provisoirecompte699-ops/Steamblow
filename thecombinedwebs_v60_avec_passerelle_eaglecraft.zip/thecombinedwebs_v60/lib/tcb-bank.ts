import { getJSON, listJSON, setJSON, updateJSON, delJSON } from "./data-store";
import { BOBUX_MAX, getAllUsers, getUser, isMaxAccount, type User } from "./store";
import { credit, ledgerFor, spend } from "./bobux";
import crypto from "node:crypto";
import { isAdminAbuseActive } from "./admin-abuse";
import { serial } from "./feature-lock";

/**
 * TCB Banque v2 — réalisme renforcé :
 * compte courant, livrets multiples, virements (instant + planifiés),
 * cagnottes, découvert limité, score santé, carte virtuelle, catégories,
 * alertes, intérêts, taxe, Premium.
 */
const DAY = 86400000;
const low = (s: string) => s.toLowerCase();
const clean = (s: unknown, n: number) => String(s ?? "").replace(/[<>`]/g, "").trim().slice(0, n);
const day = () => new Date().toISOString().slice(0, 10);
export const PLAN = { id: "premium", name: "TCB Premium", price: 500, days: 30 };
export const LIMITS = {
  base: { rate: 0.005, cap: 5000, transfer: 500, overdraft: 100 },
  premium: { rate: 0.01, cap: 50000, transfer: 5000, overdraft: 500 },
};
/** Livrets disponibles */
export const LIVRETS = {
  classic: { id: "classic", name: "Livret Classique", rateMul: 1, capMul: 1 },
  projet: { id: "projet", name: "Livret Projet", rateMul: 0.8, capMul: 1.5 },
} as const;
const tier = (premium: boolean) => (premium ? LIMITS.premium : LIMITS.base);
const amountOf = (v: unknown) => { const n = Number(v); return Number.isInteger(n) && n > 0 && n <= 1_000_000_000 ? n : 0; };
const errMsg = (e: unknown) => (e instanceof Error ? e.message : "Erreur");

/* ---------- Types ---------- */
export type LivretBal = { balance: number; lastInterestAt: number };
export type Acct = {
  savings: number; // legacy = classic
  lastInterestAt: number;
  goal: { name: string; target: number } | null;
  taxDay?: string;
  livrets?: Record<string, LivretBal>;
  overdraftUsed?: number;
  debtSince?: number; // timestamp première dette non remboursée
  overdraftOperations?: Record<string,boolean>;
  interestHistory?: { date: string; amount: number; livret: string }[];
  hauntedUntil?: number; // mode compte hanté
  blocusCooldownUntil?: number;
};
export type Tx = { id: string; type: string; amount: number; note: string; at: number; category?: string };
export type Scheduled = {
  id: string; from: string; to: string; amount: number; note: string;
  nextAt: number; intervalDays: number; remaining: number; createdAt: number;
};
export type Pot = {
  id: string; name: string; owner: string; members: string[]; balance: number;
  goal?: number; createdAt: number; closed?: boolean;
};
export type Loan = {
  id: string; from: string; to: string; amount: number; remaining: number;
  interest: number; dueAt: number; status: "pending" | "active" | "repaid" | "defaulted";
  createdAt: number;
};
export type Insurance = { plan: string; endsAt: number; price: number };
export type Alert = { id: string; type: string; message: string; at: number; read: boolean };

const fresh = (): Acct => ({
  savings: 0, lastInterestAt: Date.now(), goal: null, taxDay: day(),
  livrets: { classic: { balance: 0, lastInterestAt: Date.now() }, projet: { balance: 0, lastInterestAt: Date.now() } },
  overdraftUsed: 0, interestHistory: [],
});
const akey = (u: string) => `acct:${low(u)}`;

export const accountNumber = (u: string) => {
  const h = crypto.createHash("sha256").update("tcb:" + low(u)).digest("hex").toUpperCase();
  return `TCB-${h.slice(0, 4)}-${h.slice(4, 8)}-${h.slice(8, 12)}`;
};
/** IBAN stylisé français (non réel) */
export const makeIban = (u: string) => {
  const h = crypto.createHash("sha256").update("iban:" + low(u)).digest("hex").toUpperCase();
  return `TCBB FR76 ${h.slice(0, 4)} ${h.slice(4, 8)} ${h.slice(8, 12)} ${h.slice(12, 16)} ${h.slice(16, 19)}`;
};
/** Numéro de carte virtuelle */
export const makeCard = (u: string) => {
  const h = crypto.createHash("sha256").update("card:" + low(u)).digest("hex").toUpperCase();
  return {
    number: `4532 ${h.slice(0, 4)} ${h.slice(4, 8)} ${h.slice(8, 12)}`,
    exp: `${String((new Date().getMonth() + 6) % 12 + 1).padStart(2, "0")}/${String(new Date().getFullYear() + 3).slice(2)}`,
    cvv: h.slice(20, 23),
    holder: u.toUpperCase().slice(0, 20),
  };
};

const CATEGORY_MAP: Record<string, string> = {
  interest: "Intérêts", deposit: "Épargne", withdraw: "Épargne", tax: "Taxe",
  subscription: "Abonnement", transfer: "Virement", gift: "Cadeau",
  pot: "Cagnotte", loan: "Prêt", insurance: "Assurance", scheduled: "Virement planifié",
  overdraft: "Découvert", shop: "Boutique", game: "Jeu", tournament: "Tournoi",
};

function catOf(type: string, note: string): string {
  if (CATEGORY_MAP[type]) return CATEGORY_MAP[type];
  const n = note.toLowerCase();
  if (n.includes("jeu") || n.includes("game")) return "Jeu";
  if (n.includes("tournoi") || n.includes("tournament")) return "Tournoi";
  if (n.includes("boutique") || n.includes("shop") || n.includes("skin")) return "Boutique";
  if (n.includes("virement")) return "Virement";
  if (n.includes("cadeau") || n.includes("gift")) return "Cadeau";
  return "Autre";
}

async function logTx(user: string, type: string, amount: number, note: string) {
  const at = Date.now(); const id = `${at}-${crypto.randomBytes(3).toString("hex")}`;
  const category = catOf(type, note);
  await setJSON<Tx>("tcb-bank", `tx:${low(user)}:${id}`, { id, type, amount, note: clean(note, 80), at, category });
}

async function pushAlert(user: string, type: string, message: string) {
  const id = `${Date.now()}-${crypto.randomBytes(2).toString("hex")}`;
  await setJSON<Alert>("tcb-bank", `alert:${low(user)}:${id}`, { id, type, message, at: Date.now(), read: false });
}

/* ---------- Abonnement ---------- */
export type Sub = { plan: string; startedAt: number; endsAt: number; autoRenew: boolean; price: number };
export async function getSub(user: string): Promise<Sub | null> {
  const account = await getUser(user);
  if (account && isMaxAccount(account)) return { plan: PLAN.id, startedAt: 0, endsAt: Number.MAX_SAFE_INTEGER, autoRenew: false, price: 0 };
  const key = `sub:${low(user)}`; let s = await getJSON<Sub>("tcb-bank", key); if (!s) return null;
  if (Date.now() >= s.endsAt && s.autoRenew) {
    try {
      await spend(user, s.price, "Abonnement TCB Premium (renouvellement)");
      s = { ...s, endsAt: Date.now() + PLAN.days * DAY }; await setJSON("tcb-bank", key, s);
      await logTx(user, "subscription", -s.price, "Renouvellement TCB Premium");
    } catch { s = { ...s, autoRenew: false }; await setJSON("tcb-bank", key, s); }
  }
  return s;
}
export async function isSubscriber(user: string) {
  const me = await getUser(user); if (me && isMaxAccount(me)) return true;
  const s = await getSub(user); return !!s && s.endsAt > Date.now();
}
export async function subscribe(user: string) {
  const me = await getUser(user); if (me && isMaxAccount(me)) return { ok: true, unlimited: true };
  if (await isSubscriber(user)) return { error: "Tu es déjà abonné." };
  try { await spend(user, PLAN.price, "Abonnement TCB Premium"); } catch (e) { return { error: errMsg(e) }; }
  const now = Date.now();
  await setJSON<Sub>("tcb-bank", `sub:${low(user)}`, { plan: PLAN.id, startedAt: now, endsAt: now + PLAN.days * DAY, autoRenew: true, price: PLAN.price });
  await logTx(user, "subscription", -PLAN.price, "Abonnement TCB Premium");
  await pushAlert(user, "premium", "Bienvenue dans TCB Premium ! Avantages activés.");
  return { ok: true };
}
export async function setAutoRenew(user: string, value: boolean) {
  const me = await getUser(user); if (me && isMaxAccount(me)) return { error: "Le Premium du créateur est illimité." };
  const s = await getSub(user); if (!s || s.endsAt <= Date.now()) return { error: "Aucun abonnement actif." };
  await setJSON("tcb-bank", `sub:${low(user)}`, { ...s, autoRenew: value }); return { ok: true };
}

/* ---------- Migration legacy → livrets ---------- */
async function ensureLivrets(user: string): Promise<Acct> {
  let a = await getJSON<Acct>("tcb-bank", akey(user));
  if (!a) { a = fresh(); await setJSON("tcb-bank", akey(user), a); return a; }
  if (!a.livrets) {
    a = {
      ...a,
      livrets: {
        classic: { balance: a.savings || 0, lastInterestAt: a.lastInterestAt || Date.now() },
        projet: { balance: 0, lastInterestAt: Date.now() },
      },
      overdraftUsed: a.overdraftUsed ?? 0,
      interestHistory: a.interestHistory ?? [],
    };
    await setJSON("tcb-bank", akey(user), a);
  }
  return a;
}

/* ---------- Intérêts multi-livrets ---------- */
async function accrue(user: string, premium: boolean) {
  const now = Date.now(); const t = tier(premium);
  let totalGained = 0;
  await updateJSON<Acct>("tcb-bank", akey(user), (v) => {
    const c = v ?? fresh();
    if (!c.livrets) {
      c.livrets = {
        classic: { balance: c.savings || 0, lastInterestAt: c.lastInterestAt || now },
        projet: { balance: 0, lastInterestAt: now },
      };
    }
    const hist = c.interestHistory ?? [];
    for (const [lid, def] of Object.entries(LIVRETS)) {
      const L = c.livrets[lid] ?? { balance: 0, lastInterestAt: now };
      const total = Math.floor((now - L.lastInterestAt) / DAY);
      if (total <= 0 || L.balance <= 0) {
        if (total > 0) L.lastInterestAt = L.lastInterestAt + total * DAY;
        c.livrets[lid] = L; continue;
      }
      const rate = t.rate * def.rateMul;
      const cap = Math.floor(t.cap * def.capMul);
      let s = L.balance;
      for (let i = 0; i < Math.min(30, total); i++) s += Math.floor(Math.min(s, cap) * rate);
      s = Math.min(BOBUX_MAX, s);
      const gained = s - L.balance;
      if (gained > 0) {
        totalGained += gained;
        hist.push({ date: day(), amount: gained, livret: def.name });
      }
      L.balance = s;
      L.lastInterestAt = L.lastInterestAt + total * DAY;
      c.livrets[lid] = L;
    }
    // sync legacy field
    c.savings = c.livrets.classic?.balance ?? 0;
    c.lastInterestAt = c.livrets.classic?.lastInterestAt ?? now;
    c.interestHistory = hist.slice(-60);
    return c;
  });
  if (totalGained > 0) {
    await logTx(user, "interest", totalGained, `Intérêts livrets`);
    await pushAlert(user, "interest", `+${totalGained.toLocaleString("fr-FR")} Bobux d’intérêts versés sur tes livrets.`);
  }
}
export const getAcct = async (u: string) => ensureLivrets(u);

/* ---------- Dépôt / retrait multi-livrets ---------- */
export async function deposit(user: string, raw: unknown, livretId: unknown = "classic") {
  const amt = amountOf(raw); if (!amt) return { error: "Montant invalide." };
  const lid = String(livretId || "classic");
  if (!LIVRETS[lid as keyof typeof LIVRETS]) return { error: "Livret inconnu." };
  const def = LIVRETS[lid as keyof typeof LIVRETS];
  const premium = await isSubscriber(user); const t = tier(premium);
  await accrue(user, premium);
  const a = await getAcct(user);
  const cur = a.livrets?.[lid]?.balance ?? 0;
  const cap = Math.floor(t.cap * def.capMul);
  if (cur + amt > cap) return { error: `Plafond du ${def.name} : ${cap.toLocaleString("fr-FR")} Bobux.` };
  try { await spend(user, amt, `Épargne : dépôt ${def.name}`); } catch (e) { return { error: errMsg(e) }; }
  let ok = true;
  await updateJSON<Acct>("tcb-bank", akey(user), (v) => {
    const c = v ?? fresh();
    if (!c.livrets) c.livrets = { classic: { balance: 0, lastInterestAt: Date.now() }, projet: { balance: 0, lastInterestAt: Date.now() } };
    const L = c.livrets[lid] ?? { balance: 0, lastInterestAt: Date.now() };
    if (L.balance + amt > cap) { ok = false; return c; }
    L.balance += amt;
    if (L.balance === amt) L.lastInterestAt = Date.now();
    c.livrets[lid] = L;
    c.savings = c.livrets.classic?.balance ?? 0;
    return c;
  });
  if (!ok) { await credit(user, amt, "TCB Banque", "Épargne : remboursement", "bank"); return { error: "Plafond d’épargne atteint." }; }
  await logTx(user, "deposit", amt, `Dépôt ${def.name}`);
  return { ok: true };
}

export async function withdraw(user: string, raw: unknown, livretId: unknown = "classic") {
  const amt = amountOf(raw); if (!amt) return { error: "Montant invalide." };
  const lid = String(livretId || "classic");
  if (!LIVRETS[lid as keyof typeof LIVRETS]) return { error: "Livret inconnu." };
  const def = LIVRETS[lid as keyof typeof LIVRETS];
  await accrue(user, await isSubscriber(user));
  let ok = false;
  await updateJSON<Acct>("tcb-bank", akey(user), (v) => {
    const c = v ?? fresh();
    if (!c.livrets) c.livrets = { classic: { balance: c.savings || 0, lastInterestAt: Date.now() }, projet: { balance: 0, lastInterestAt: Date.now() } };
    const L = c.livrets[lid] ?? { balance: 0, lastInterestAt: Date.now() };
    if (L.balance >= amt) { ok = true; L.balance -= amt; c.livrets[lid] = L; c.savings = c.livrets.classic?.balance ?? 0; }
    return c;
  });
  if (!ok) return { error: "Solde du livret insuffisant." };
  try { await credit(user, amt, "TCB Banque", `Épargne : retrait ${def.name}`, "bank"); }
  catch (e) {
    await updateJSON<Acct>("tcb-bank", akey(user), (v) => {
      const c = v ?? fresh();
      if (!c.livrets) return c;
      const L = c.livrets[lid] ?? { balance: 0, lastInterestAt: Date.now() };
      L.balance += amt; c.livrets[lid] = L; c.savings = c.livrets.classic?.balance ?? 0;
      return c;
    });
    return { error: errMsg(e) };
  }
  await logTx(user, "withdraw", -amt, `Retrait ${def.name}`);
  return { ok: true };
}

export async function setGoal(user: string, name: unknown, target: unknown) {
  const n = clean(name, 40), t = amountOf(target);
  await updateJSON<Acct>("tcb-bank", akey(user), (v) => ({ ...(v ?? fresh()), goal: n && t ? { name: n, target: t } : null }));
  return { ok: true };
}

/* ---------- Découvert ---------- */
async function applyOverdraft(user: string, needed: number, force = false): Promise<{ ok: boolean; used: number }> {
  const premium = await isSubscriber(user);
  const maxOd = force ? 10_000 : tier(premium).overdraft; // malus mystère peut endetter au-delà du plafond soft
  const a = await getAcct(user);
  const already = a.overdraftUsed ?? 0;
  const room = maxOd - already;
  if (needed > room) return { ok: false, used: 0 };
  await updateJSON<Acct>("tcb-bank", akey(user), (v) => {
    const c = v ?? fresh();
    const next = (c.overdraftUsed ?? 0) + needed;
    return {
      ...c,
      overdraftUsed: next,
      debtSince: c.debtSince && (c.overdraftUsed ?? 0) > 0 ? c.debtSince : Date.now(),
    };
  });
  await logTx(user, "overdraft", -needed, force ? "Dette Guichet Mystère" : "Utilisation du découvert");
  return { ok: true, used: needed };
}

/** Prélève un montant : solde d’abord, puis dette (négatif). Retourne ce qui a été réellement pris. */
async function chargeOrDebt(user: string, amount: number, reason: string): Promise<{ taken: number; debt: number }> {
  const me = await getUser(user);
  const bal = me?.bobux ?? 0;
  let taken = 0;
  let debt = 0;
  if (bal > 0) {
    const fromBal = Math.min(bal, amount);
    try {
      await spend(user, fromBal, reason);
      taken = fromBal;
    } catch { /* solde modifié entre-temps */ }
  }
  const rest = amount - taken;
  if (rest > 0) {
    const od = await applyOverdraft(user, rest, true);
    if (od.ok) debt = od.used;
  }
  return { taken: taken + debt, debt };
}

/** Rembourse automatiquement la dette dès que le compte courant a des Bobux. */
export async function repayDebt(user: string): Promise<number> {
  return serial(`bank-debt:${low(user)}`,async()=>repayDebtUnlocked(user));
}
async function repayDebtUnlocked(user: string): Promise<number> {
  const a = await getAcct(user);
  const debt = a.overdraftUsed ?? 0;
  if (debt <= 0) return 0;
  const me = await getUser(user);
  const bal = me?.bobux ?? 0;
  if (bal <= 0) return 0;
  const pay = Math.min(bal, debt);
  try { await spend(user, pay, "Remboursement dette / découvert"); } catch { return 0; }
  const remaining = debt - pay;
  await updateJSON<Acct>("tcb-bank", akey(user), (v) => {
    const c = v ?? fresh();
    return {
      ...c,
      overdraftUsed: Math.max(0, remaining),
      debtSince: remaining > 0 ? (c.debtSince ?? Date.now()) : undefined,
      hauntedUntil: remaining > 0 ? c.hauntedUntil : undefined,
    };
  });
  await logTx(user, "overdraft", pay, "Remboursement dette");
  await pushAlert(user, "debt", `Dette remboursée : −${pay.toLocaleString("fr-FR")} Bobux. Reste dû : ${Math.max(0, remaining).toLocaleString("fr-FR")}.`);
  return pay;
}

/* ---------- Virements ---------- */
export async function transfer(from: string, toRaw: unknown, raw: unknown, note: unknown) {
  const amt = amountOf(raw); if (!amt) return { error: "Montant invalide." };
  const to = await getUser(clean(toRaw, 24)); if (!to || to.banned) return { error: "Destinataire introuvable." };
  if (low(to.username) === low(from)) return { error: "Tu ne peux pas te faire un virement à toi-même." };
  const limit = tier(await isSubscriber(from)).transfer;
  const key = `xfer:${low(from)}:${day()}`;
  const used = (await getJSON<{ n: number }>("tcb-bank", key))?.n ?? 0;
  if (used + amt > limit) return { error: `Limite de virement quotidienne : ${limit.toLocaleString("fr-FR")} Bobux (il te reste ${Math.max(0, limit - used)}).` };
  const memo = clean(note, 30); const label = memo ? ` : ${memo}` : "";
  const me = await getUser(from);
  const bal = me?.bobux ?? 0;
  if (bal < amt) {
    // tenter découvert
    const need = amt - bal;
    const od = await applyOverdraft(from, need);
    if (!od.ok) return { error: "Solde Bobux insuffisant (découvert max atteint)." };
  }
  try { await spend(from, Math.min(amt, bal > 0 ? bal : amt), `Virement à ${to.username}${label}`.slice(0, 80)); }
  catch (e) {
    // si solde 0 et découvert déjà pris, on force via credit négatif simulé
    if ((me?.bobux ?? 0) === 0) { /* already handled via overdraft tracking */ }
    else return { error: errMsg(e) };
  }
  // si on a utilisé le découvert, le spend partiel a déjà eu lieu ; on crédite le destinataire
  try { await credit(to.username, amt, from, `Virement de ${from}${label}`.slice(0, 80), "gift"); }
  catch {
    await credit(from, amt, "TCB Banque", "Virement annulé", "bank");
    // rollback overdraft
    await updateJSON<Acct>("tcb-bank", akey(from), (v) => {
      const c = v ?? fresh();
      return { ...c, overdraftUsed: Math.max(0, (c.overdraftUsed ?? 0) - (amt - bal)) };
    });
    return { error: "Virement impossible." };
  }
  await setJSON("tcb-bank", key, { n: used + amt });
  await logTx(from, "transfer", -amt, `Virement à ${to.username}${label}`);
  await pushAlert(to.username, "transfer_in", `Tu as reçu ${amt.toLocaleString("fr-FR")} Bobux de ${from}${label}`);
  await pushAlert(from, "transfer_out", `Virement de ${amt.toLocaleString("fr-FR")} Bobux envoyé à ${to.username}`);
  return { ok: true };
}

/* ---------- Virements planifiés ---------- */
export async function scheduleTransfer(from: string, toRaw: unknown, raw: unknown, note: unknown, intervalDays: unknown, count: unknown) {
  const amt = amountOf(raw); if (!amt) return { error: "Montant invalide." };
  const to = await getUser(clean(toRaw, 24)); if (!to || to.banned) return { error: "Destinataire introuvable." };
  if (low(to.username) === low(from)) return { error: "Impossible." };
  const days = Math.min(30, Math.max(1, Number(intervalDays) || 7));
  const remaining = Math.min(12, Math.max(1, Number(count) || 1));
  const id = `${Date.now()}-${crypto.randomBytes(3).toString("hex")}`;
  const s: Scheduled = {
    id, from: low(from), to: to.username, amount: amt, note: clean(note, 30),
    nextAt: Date.now() + days * DAY, intervalDays: days, remaining, createdAt: Date.now(),
  };
  await setJSON("tcb-bank", `sched:${low(from)}:${id}`, s);
  await pushAlert(from, "scheduled", `Virement planifié : ${amt} Bobux → ${to.username} tous les ${days} j (${remaining} fois)`);
  return { ok: true, id };
}

export async function cancelScheduled(user: string, id: unknown) {
  const key = `sched:${low(user)}:${clean(id, 40)}`;
  const s = await getJSON<Scheduled>("tcb-bank", key);
  if (!s) return { error: "Virement planifié introuvable." };
  await delJSON("tcb-bank", key);
  return { ok: true };
}

/** Exécute les virements planifiés dus (appelé à l’overview) */
async function processScheduled(user: string) {
  const list = await listJSON<Scheduled>("tcb-bank", `sched:${low(user)}:`);
  const now = Date.now();
  for (const s of list) {
    if (s.nextAt > now || s.remaining <= 0) continue;
    const r = await transfer(user, s.to, s.amount, s.note || "Virement planifié");
    if (!r.error) {
      s.remaining -= 1;
      s.nextAt = now + s.intervalDays * DAY;
      if (s.remaining <= 0) await delJSON("tcb-bank", `sched:${low(user)}:${s.id}`);
      else await setJSON("tcb-bank", `sched:${low(user)}:${s.id}`, s);
    }
  }
}

/* ---------- Cagnottes ---------- */
export async function createPot(user: string, name: unknown, goal: unknown) {
  const n = clean(name, 40); if (!n) return { error: "Nom requis." };
  const id = `${Date.now()}-${crypto.randomBytes(3).toString("hex")}`;
  const pot: Pot = {
    id, name: n, owner: low(user), members: [low(user)], balance: 0,
    goal: amountOf(goal) || undefined, createdAt: Date.now(),
  };
  await setJSON("tcb-bank", `pot:${id}`, pot);
  await setJSON("tcb-bank", `potmember:${low(user)}:${id}`, { potId: id });
  return { ok: true, id };
}

export async function joinPot(user: string, potId: unknown) {
  const id = clean(potId, 40);
  const pot = await getJSON<Pot>("tcb-bank", `pot:${id}`);
  if (!pot || pot.closed) return { error: "Cagnotte introuvable." };
  if (pot.members.includes(low(user))) return { error: "Tu es déjà membre." };
  pot.members.push(low(user));
  await setJSON("tcb-bank", `pot:${id}`, pot);
  await setJSON("tcb-bank", `potmember:${low(user)}:${id}`, { potId: id });
  await pushAlert(pot.owner, "pot", `${user} a rejoint la cagnotte « ${pot.name} »`);
  return { ok: true };
}

export async function contributePot(user: string, potId: unknown, raw: unknown) {
  const amt = amountOf(raw); if (!amt) return { error: "Montant invalide." };
  const id = clean(potId, 40);
  const pot = await getJSON<Pot>("tcb-bank", `pot:${id}`);
  if (!pot || pot.closed) return { error: "Cagnotte introuvable." };
  if (!pot.members.includes(low(user))) return { error: "Tu n’es pas membre." };
  try { await spend(user, amt, `Cagnotte : ${pot.name}`); } catch (e) { return { error: errMsg(e) }; }
  pot.balance += amt;
  await setJSON("tcb-bank", `pot:${id}`, pot);
  await logTx(user, "pot", -amt, `Cagnotte « ${pot.name} »`);
  for (const m of pot.members) {
    if (m !== low(user)) await pushAlert(m, "pot", `${user} a ajouté ${amt.toLocaleString("fr-FR")} Bobux à « ${pot.name} »`);
  }
  return { ok: true };
}

export async function withdrawPot(user: string, potId: unknown, raw: unknown) {
  const amt = amountOf(raw); if (!amt) return { error: "Montant invalide." };
  const id = clean(potId, 40);
  const pot = await getJSON<Pot>("tcb-bank", `pot:${id}`);
  if (!pot || pot.closed) return { error: "Cagnotte introuvable." };
  if (low(user) !== pot.owner) return { error: "Seul le créateur peut retirer." };
  if (pot.balance < amt) return { error: "Solde de la cagnotte insuffisant." };
  pot.balance -= amt;
  await setJSON("tcb-bank", `pot:${id}`, pot);
  try { await credit(user, amt, "TCB Banque", `Cagnotte : retrait ${pot.name}`, "bank"); }
  catch (e) { pot.balance += amt; await setJSON("tcb-bank", `pot:${id}`, pot); return { error: errMsg(e) }; }
  await logTx(user, "pot", amt, `Retrait cagnotte « ${pot.name} »`);
  return { ok: true };
}

/* ---------- Prêts P2P ---------- */
export async function requestLoan(from: string, toRaw: unknown, raw: unknown, days: unknown) {
  const amt = amountOf(raw); if (!amt) return { error: "Montant invalide." };
  const to = await getUser(clean(toRaw, 24)); if (!to || to.banned) return { error: "Prêteur introuvable." };
  if (low(to.username) === low(from)) return { error: "Impossible." };
  const d = Math.min(30, Math.max(3, Number(days) || 7));
  const id = `${Date.now()}-${crypto.randomBytes(3).toString("hex")}`;
  const loan: Loan = {
    id, from: low(from), to: to.username, amount: amt, remaining: amt,
    interest: Math.floor(amt * 0.05), dueAt: Date.now() + d * DAY,
    status: "pending", createdAt: Date.now(),
  };
  await setJSON("tcb-bank", `loan:${id}`, loan);
  await pushAlert(to.username, "loan", `${from} te demande un prêt de ${amt.toLocaleString("fr-FR")} Bobux (${d} jours, +5 %)`);
  return { ok: true, id };
}

export async function acceptLoan(user: string, loanId: unknown) {
  const id = clean(loanId, 40);
  const loan = await getJSON<Loan>("tcb-bank", `loan:${id}`);
  if (!loan || loan.status !== "pending") return { error: "Prêt introuvable." };
  if (low(user) !== low(loan.to)) return { error: "Ce n’est pas toi le prêteur." };
  try { await spend(user, loan.amount, `Prêt à ${loan.from}`); } catch (e) { return { error: errMsg(e) }; }
  try { await credit(loan.from, loan.amount, user, `Prêt de ${user}`, "gift"); }
  catch (e) { await credit(user, loan.amount, "TCB Banque", "Prêt annulé", "bank"); return { error: errMsg(e) }; }
  loan.status = "active";
  await setJSON("tcb-bank", `loan:${id}`, loan);
  await logTx(user, "loan", -loan.amount, `Prêt accordé à ${loan.from}`);
  await logTx(loan.from, "loan", loan.amount, `Prêt reçu de ${user}`);
  await pushAlert(loan.from, "loan", `${user} a accepté ton prêt de ${loan.amount.toLocaleString("fr-FR")} Bobux`);
  return { ok: true };
}

export async function repayLoan(user: string, loanId: unknown, raw: unknown) {
  const amt = amountOf(raw); if (!amt) return { error: "Montant invalide." };
  const id = clean(loanId, 40);
  const loan = await getJSON<Loan>("tcb-bank", `loan:${id}`);
  if (!loan || loan.status !== "active") return { error: "Prêt introuvable." };
  if (low(user) !== low(loan.from)) return { error: "Ce n’est pas ton prêt." };
  const due = loan.remaining + (loan.remaining === loan.amount ? loan.interest : 0);
  const pay = Math.min(amt, due);
  try { await spend(user, pay, `Remboursement prêt ${loan.to}`); } catch (e) { return { error: errMsg(e) }; }
  try { await credit(loan.to, pay, user, `Remboursement de ${user}`, "gift"); }
  catch (e) { await credit(user, pay, "TCB Banque", "Remboursement annulé", "bank"); return { error: errMsg(e) }; }
  loan.remaining = Math.max(0, loan.remaining - pay);
  if (loan.remaining <= 0) loan.status = "repaid";
  await setJSON("tcb-bank", `loan:${id}`, loan);
  await logTx(user, "loan", -pay, `Remboursement prêt`);
  await pushAlert(loan.to, "loan", `${user} a remboursé ${pay.toLocaleString("fr-FR")} Bobux`);
  return { ok: true };
}

/* ---------- Assurance ---------- */
export async function buyInsurance(user: string) {
  const price = 150;
  if (await getJSON<Insurance>("tcb-bank", `ins:${low(user)}`)) {
    const ins = await getJSON<Insurance>("tcb-bank", `ins:${low(user)}`);
    if (ins && ins.endsAt > Date.now()) return { error: "Tu as déjà une assurance active." };
  }
  try { await spend(user, price, "Assurance TCB Protection"); } catch (e) { return { error: errMsg(e) }; }
  await setJSON<Insurance>("tcb-bank", `ins:${low(user)}`, { plan: "protection", endsAt: Date.now() + 30 * DAY, price });
  await logTx(user, "insurance", -price, "Assurance TCB Protection (30 j)");
  await pushAlert(user, "insurance", "Assurance TCB Protection activée pour 30 jours.");
  return { ok: true };
}


/* ---------- Guichet Mystère (farfelu) ---------- */
const MYSTERY_COST = 25;
const MYSTERY_EVENTS = [
  { w: 18, id: "lucky", run: async (user: string) => {
    const gain = 50 + Math.floor(Math.random() * 151);
    await credit(user, gain, "Guichet Mystère", "Le guichet a craché des Bobux", "bank");
    await logTx(user, "mystery", gain, "Guichet Mystère : jackpot mineur");
    return { title: "💰 Jackpot mineur !", text: `Le guichet s’est mis à tousser et a craché ${gain.toLocaleString("fr-FR")} Bobux. Personne ne sait pourquoi.` };
  }},
  { w: 12, id: "tax_refund", run: async (user: string) => {
    const gain = 10 + Math.floor(Math.random() * 40);
    await credit(user, gain, "Guichet Mystère", "Remboursement fiscal absurde", "bank");
    await logTx(user, "mystery", gain, "Guichet Mystère : remboursement fiscal");
    return { title: "🧾 Erreur fiscale en ta faveur", text: `Un stagiaire a inversé deux colonnes. Tu récupères ${gain.toLocaleString("fr-FR")} Bobux. Ne le dis à personne.` };
  }},
  { w: 15, id: "curse", run: async (user: string) => {
    const loss = 15 + Math.floor(Math.random() * 35);
    const { taken, debt } = await chargeOrDebt(user, loss, "Guichet Mystère : malédiction");
    await logTx(user, "mystery", -taken, "Guichet Mystère : malédiction du guichet");
    if (debt > 0) {
      return { title: "👻 Malédiction — tu es en négatif !", text: `L’agent spectral a prélevé ${taken.toLocaleString("fr-FR")} Bobux. Tu n’avais pas assez : tu dois maintenant ${debt.toLocaleString("fr-FR")} Bobux à la banque. Tes prochains gains rembourseront automatiquement la dette.` };
    }
    return { title: "👻 Malédiction du guichet", text: `Un agent spectral a prélevé ${taken.toLocaleString("fr-FR")} Bobux « pour les frais d’outre-tombe ».` };
  }},
  { w: 10, id: "interest_boost", run: async (user: string) => {
    await updateJSON<Acct>("tcb-bank", akey(user), (v) => {
      const c = v ?? fresh();
      if (!c.livrets) return c;
      for (const lid of Object.keys(c.livrets)) {
        const L = c.livrets[lid];
        const bonus = Math.floor(L.balance * 0.02);
        if (bonus > 0) { L.balance = Math.min(BOBUX_MAX, L.balance + bonus); }
      }
      c.savings = c.livrets.classic?.balance ?? c.savings;
      return c;
    });
    await logTx(user, "mystery", 0, "Guichet Mystère : bénédiction d’intérêts");
    return { title: "✨ Bénédiction des intérêts", text: "Un moine bancaire a murmuré une formule. Tes livrets gagnent +2 % instantanés." };
  }},
  { w: 10, id: "title", run: async (user: string) => {
    const titles = ["Baron du Découvert", "Comte des Cagnottes", "Duc du Guichet", "Marquis des Intérêts Composés", "Chevalier du Relevé Mensuel", "Archiduc du Bobux Perdu"];
    const t = titles[Math.floor(Math.random() * titles.length)];
    await setJSON("tcb-bank", `title:${low(user)}`, { title: t, until: Date.now() + 7 * DAY });
    await logTx(user, "mystery", 0, `Titre honorifique : ${t}`);
    return { title: "👑 Titre honorifique", text: `La Banque te nomme officiellement « ${t} » pour 7 jours. Ça ne sert à rien. C’est magnifique.` };
  }},
  { w: 8, id: "audit", run: async (user: string) => {
    await pushAlert(user, "mystery", "⚠️ Audit surprise : tout est en règle (on a inventé les chiffres).");
    return { title: "🕵️ Audit surprise", text: "Trois agents en costard-cravate ont fouillé ton compte pendant 0,3 seconde. Verdict : « Bof, ça passe. »" };
  }},
  { w: 7, id: "pigeon", run: async (user: string) => {
    const gain = 1;
    await credit(user, gain, "Guichet Mystère", "Un pigeon a apporté 1 Bobux", "bank");
    await logTx(user, "mystery", gain, "Guichet Mystère : pigeon voyageur");
    return { title: "🐦 Pigeon voyageur", text: "Un pigeon est entré par la fenêtre du serveur et a déposé 1 Bobux sur ton compte avant de repartir. On ne pose pas de questions." };
  }},
  { w: 8, id: "double_or_nothing", run: async (user: string) => {
    const me = await getUser(user);
    const bal = me?.bobux ?? 0;
    if (bal < 10) return { title: "🎲 Double ou rien… vide", text: "Le guichet voulait jouer, mais ton solde est trop bas. Il a hausé les épaules (métaphoriquement)." };
    const stake = Math.min(100, Math.floor(bal * 0.1));
    if (Math.random() < 0.45) {
      await credit(user, stake, "Guichet Mystère", "Double ou rien gagné", "bank");
      await logTx(user, "mystery", stake, "Guichet Mystère : double ou rien GAGNÉ");
      return { title: "🎲 Double ou rien — GAGNÉ", text: `Le guichet a lancé une pièce spectral. Tu gagnes ${stake.toLocaleString("fr-FR")} Bobux. Chanceux.` };
    }
    const { taken, debt } = await chargeOrDebt(user, stake, "Guichet Mystère : double ou rien perdu");
    await logTx(user, "mystery", -taken, "Guichet Mystère : double ou rien PERDU");
    if (debt > 0) {
      return { title: "🎲 Double ou rien — PERDU (endeté)", text: `La pièce est tombée du mauvais côté. −${taken.toLocaleString("fr-FR")} Bobux dont ${debt.toLocaleString("fr-FR")} en dette. Tu dois de l’argent à la banque jusqu’au remboursement.` };
    }
    return { title: "🎲 Double ou rien — PERDU", text: `La pièce est tombée du mauvais côté. −${taken.toLocaleString("fr-FR")} Bobux. Le guichet te fait un clin d’œil ironique.` };
  }},
  { w: 6, id: "void", run: async (_user: string) => {
    return { title: "🌀 Le Vide Bancaire", text: "Tu as contemplé le néant du système monétaire. Rien ne s’est passé. Et pourtant… quelque chose a changé en toi. (Rien n’a changé.)" };
  }},
  { w: 6, id: "prophecy", run: async (user: string) => {
    const props = [
      "Aujourd’hui, un ami te devra des Bobux. Ou pas.",
      "Méfie-toi des virements après minuit UTC.",
      "Tes intérêts composeront… émotionnellement.",
      "Un grand cagnotte se profile à l’horizon.",
      "Le créateur Younes a pensé à toi pendant 0,02 seconde.",
    ];
    const p = props[Math.floor(Math.random() * props.length)];
    await pushAlert(user, "mystery", `🔮 Prophétie : ${p}`);
    return { title: "🔮 Prophétie du guichet", text: p };
  }},
];

function pickMystery() {
  const total = MYSTERY_EVENTS.reduce((s, e) => s + e.w, 0);
  let r = Math.random() * total;
  for (const e of MYSTERY_EVENTS) { r -= e.w; if (r <= 0) return e; }
  return MYSTERY_EVENTS[0];
}

export async function pullMystery(user: string) {
  const key = `mystery:${low(user)}:${day()}`;
  const used = (await getJSON<{ n: number }>("tcb-bank", key))?.n ?? 0;
  if (used >= 5) return { error: "Le Guichet Mystère est fatigué (5 tirages max par jour). Reviens demain." };
  try { await spend(user, MYSTERY_COST, "Guichet Mystère"); } catch (e) { return { error: errMsg(e) }; }
  await logTx(user, "mystery", -MYSTERY_COST, "Tirage Guichet Mystère");
  await setJSON("tcb-bank", key, { n: used + 1 });
  const event = pickMystery();
  const result = await event.run(user);
  await pushAlert(user, "mystery", `${result.title} — ${result.text}`);
  return { ok: true, ...result, remaining: 4 - used };
}

/* ---------- Taxe ---------- */
export const TAX = { rate: 0.001, premiumRate: 0.0005, threshold: 1000, cap: 100, maxCatchUpDays: 7 };
const taxFor = (wealth: number, premium: boolean) => Math.min(TAX.cap, Math.floor(Math.max(0, wealth - TAX.threshold) * (premium ? TAX.premiumRate : TAX.rate)));
export async function addTreasury(amount: number,operationId?:string) {
  await updateJSON<{ total: number;operations?:Record<string,boolean> }>("tcb-bank", "treasury:total", (v) => operationId&&v?.operations?.[operationId]?v:({ total: (v?.total ?? 0) + amount,operations:operationId?{...v?.operations,[operationId]:true}:v?.operations }));
  await updateJSON<{ total: number; payers: number;operations?:Record<string,boolean> }>("tcb-bank", `treasury:day:${day()}`, (v) => operationId&&v?.operations?.[operationId]?v:({ total: (v?.total ?? 0) + amount, payers: (v?.payers ?? 0) + 1,operations:operationId?{...v?.operations,[operationId]:true}:v?.operations }));
}
export async function settleTax(user: string) {
  const me = await getUser(user); if (!me || me.banned || isMaxAccount(me)) return 0;
  if (await isAdminAbuseActive()) return 0;
  const today = day(); let days = 0;
  await updateJSON<Acct>("tcb-bank", akey(user), (v) => {
    const c = v ?? fresh(); if (!c.taxDay) return { ...c, taxDay: today }; if (c.taxDay >= today) return c;
    days = Math.min(TAX.maxCatchUpDays, Math.round((Date.parse(today) - Date.parse(c.taxDay)) / DAY)); return { ...c, taxDay: today };
  });
  if (days <= 0) return 0;
  const a = await getAcct(user);
  const totalSavings = Object.values(a.livrets || {}).reduce((s, L) => s + (L.balance || 0), 0);
  const checking = me.bobux ?? 0;
  const total = taxFor(checking + totalSavings, await isSubscriber(user)) * days;
  if (total <= 0) return 0;
  let paid = 0;
  const fromChecking = Math.min(total, checking);
  if (fromChecking > 0) { try { await spend(user, fromChecking, "Taxe journalière (reversée au créateur)"); paid += fromChecking; } catch { /* */ } }
  let rest = total - paid;
  if (rest > 0 && a.livrets) {
    for (const lid of Object.keys(a.livrets)) {
      if (rest <= 0) break;
      const L = a.livrets[lid];
      const take = Math.min(rest, L.balance);
      if (take > 0) {
        let ok = false;
        await updateJSON<Acct>("tcb-bank", akey(user), (v) => {
          const c = v ?? fresh();
          if (!c.livrets?.[lid]) return c;
          if (c.livrets[lid].balance >= take) { ok = true; c.livrets[lid].balance -= take; c.savings = c.livrets.classic?.balance ?? 0; }
          return c;
        });
        if (ok) { paid += take; rest -= take; }
      }
    }
  }
  if (paid > 0) {
    await addTreasury(paid);
    await logTx(user, "tax", -paid, `Taxe journalière (${days} j)`);
    await pushAlert(user, "tax", `Taxe journalière prélevée : −${paid.toLocaleString("fr-FR")} Bobux`);
  }
  return paid;
}
export async function collectDailyTax(budgetMs = 8000) {
  const start = Date.now(); const key = `taxrun:${day()}`;
  if (await isAdminAbuseActive()) return { done: false, paused: true, reason: "Admin Abuse actif : taxes suspendues." };
  const run = (await getJSON<{ i: number; done: boolean }>("tcb-bank", key)) ?? { i: 0, done: false }; if (run.done) return { done: true };
  const users = (await getAllUsers()).filter((u) => !u.banned).sort((a, b) => a.username.localeCompare(b.username)); let i = run.i;
  while (i < users.length && Date.now() - start < budgetMs) { await settleTax(users[i].username).catch(() => 0); i++; }
  const done = i >= users.length; await setJSON("tcb-bank", key, { i, done }); return { done, processed: i, total: users.length };
}
export async function treasuryView() {
  const total = (await getJSON<{ total: number }>("tcb-bank", "treasury:total"))?.total ?? 0;
  const all: { date: string; total: number; payers: number }[] = [];
  for (let k = 0; k < 14; k++) {
    const d = new Date(Date.now() - k * DAY).toISOString().slice(0, 10);
    const r = await getJSON<{ total: number; payers: number }>("tcb-bank", `treasury:day:${d}`);
    if (r) all.push({ date: d, ...r });
  }
  return { total, today: all.find((x) => x.date === day())?.total ?? 0, days: all };
}

/* ---------- Score santé financière ---------- */
function healthScore(checking: number, savings: number, txs: Tx[], overdraftUsed: number, premium: boolean): { score: number; tips: string[] } {
  let score = 50;
  const tips: string[] = [];
  const total = checking + savings;
  if (savings > 0 && total > 0) {
    const ratio = savings / total;
    if (ratio >= 0.4) score += 20;
    else if (ratio >= 0.2) score += 10;
    else { score -= 5; tips.push("Essaie d’épargner au moins 20 % de ton patrimoine."); }
  } else { score -= 10; tips.push("Commence à épargner pour améliorer ton score."); }
  if (overdraftUsed > 0) { score -= 15; tips.push("Tu es à découvert : rembourse dès que possible."); }
  const recent = txs.filter((t) => t.at > Date.now() - 7 * DAY);
  const out = recent.filter((t) => t.amount < 0).reduce((s, t) => s + Math.abs(t.amount), 0);
  const inn = recent.filter((t) => t.amount > 0).reduce((s, t) => s + t.amount, 0);
  if (inn > out) score += 10;
  else if (out > inn * 1.5) { score -= 10; tips.push("Tes dépenses dépassent nettement tes entrées cette semaine."); }
  if (premium) score += 5;
  if (checking < 100 && total < 200) { score -= 10; tips.push("Solde très bas : fais attention aux dépenses."); }
  score = Math.max(0, Math.min(100, score));
  if (score >= 80) tips.unshift("Excellent ! Ta gestion est saine.");
  else if (score >= 50) tips.unshift("Correct. Quelques ajustements et tu seras au top.");
  else tips.unshift("Attention, ta santé financière est fragile.");
  return { score, tips: tips.slice(0, 4) };
}

/* ---------- Alertes ---------- */
export async function markAlertsRead(user: string) {
  const list = await listJSON<Alert>("tcb-bank", `alert:${low(user)}:`);
  for (const a of list) {
    if (!a.read) {
      a.read = true;
      await setJSON("tcb-bank", `alert:${low(user)}:${a.id}`, a);
    }
  }
  return { ok: true };
}


/* ---------- Compte hanté + Blocus Simulator ---------- */
const HAUNT_DAYS = 5;
const BLOCUS_COOLDOWN_MS = 6 * 60 * 60 * 1000; // 6 h entre deux parties

async function checkHaunted(user: string) {
  const a = await getAcct(user);
  const debt = a.overdraftUsed ?? 0;
  if (debt <= 0) {
    if (a.hauntedUntil) {
      await updateJSON<Acct>("tcb-bank", akey(user), (v) => {
        const c = v ?? fresh();
        const { hauntedUntil, ...rest } = c as Acct & { hauntedUntil?: number };
        return { ...rest, hauntedUntil: undefined };
      });
    }
    return { haunted: false, daysLeft: HAUNT_DAYS, debtDays: 0 };
  }
  const since = a.debtSince ?? Date.now();
  const days = Math.floor((Date.now() - since) / DAY);
  if (days >= HAUNT_DAYS && !(a.hauntedUntil && a.hauntedUntil > Date.now())) {
    await updateJSON<Acct>("tcb-bank", akey(user), (v) => {
      const c = v ?? fresh();
      return { ...c, hauntedUntil: Date.now() + 3 * DAY };
    });
    await pushAlert(user, "haunt", "💀 Ton compte est HANTÉ : dette impayée depuis 5 jours. Intérêts suspendus, virements limités. Joue à Blocus Simulator pour réduire ta dette !");
  }
  const haunted = !!(a.hauntedUntil && a.hauntedUntil > Date.now()) || days >= HAUNT_DAYS;
  return { haunted, daysLeft: Math.max(0, HAUNT_DAYS - days), debtDays: days };
}

/** Récompense / pénalité après une partie de Blocus Simulator */
export async function blocusResult(user: string, won: boolean, score: number) {
  const a = await getAcct(user);
  const debt = a.overdraftUsed ?? 0;
  if (debt <= 0) return { error: "Tu n’as pas de dette à réduire." };
  const cd = a.blocusCooldownUntil ?? 0;
  if (Date.now() < cd) {
    const min = Math.ceil((cd - Date.now()) / 60000);
    return { error: `Blocus Simulator en cooldown (${min} min restantes).` };
  }
  await updateJSON<Acct>("tcb-bank", akey(user), (v) => {
    const c = v ?? fresh();
    return { ...c, blocusCooldownUntil: Date.now() + BLOCUS_COOLDOWN_MS };
  });

  if (won) {
    // Efface 20–50 % de la dette selon le score (score 0–100)
    const pct = 0.20 + Math.min(0.30, (Math.max(0, Math.min(100, score)) / 100) * 0.30);
    const forgiven = Math.max(1, Math.floor(debt * pct));
    await updateJSON<Acct>("tcb-bank", akey(user), (v) => {
      const c = v ?? fresh();
      const next = Math.max(0, (c.overdraftUsed ?? 0) - forgiven);
      return {
        ...c,
        overdraftUsed: next,
        debtSince: next > 0 ? (c.debtSince ?? Date.now()) : undefined,
        hauntedUntil: next > 0 ? c.hauntedUntil : undefined,
      };
    });
    await logTx(user, "blocus", forgiven, `Blocus Simulator : fuite réussie (−${forgiven} dette)`);
    await pushAlert(user, "blocus", `🚨 Tu as échappé au blocus ! Dette réduite de ${forgiven.toLocaleString("fr-FR")} Bobux.`);
    return { ok: true, won: true, forgiven, remaining: Math.max(0, debt - forgiven) };
  }

  // Échec : +10 % de dette (max +200)
  const penalty = Math.min(200, Math.max(10, Math.floor(debt * 0.10)));
  await updateJSON<Acct>("tcb-bank", akey(user), (v) => {
    const c = v ?? fresh();
    return {
      ...c,
      overdraftUsed: (c.overdraftUsed ?? 0) + penalty,
      debtSince: c.debtSince ?? Date.now(),
    };
  });
  await logTx(user, "blocus", -penalty, "Blocus Simulator : attrapé (+dette)");
  await pushAlert(user, "blocus", `💥 Flashball ! Tu t’es fait rattraper. Dette +${penalty.toLocaleString("fr-FR")} Bobux. Pas de ban — juste la honte et les intérêts de la peur.`);
  return { ok: true, won: false, penalty, remaining: debt + penalty };
}

/* ---------- Vue d'ensemble ---------- */
export async function overview(me: User) {
  const sub = await getSub(me.username);
  const premium = !!sub && sub.endsAt > Date.now();
  const t = tier(premium);
  await settleTax(me.username);
  await repayDebt(me.username);
  const hauntInfo = await checkHaunted(me.username);
  if (!hauntInfo.haunted) await accrue(me.username, premium);
  await processScheduled(me.username);
  const a = await getAcct(me.username);
  const used = (await getJSON<{ n: number }>("tcb-bank", `xfer:${low(me.username)}:${day()}`))?.n ?? 0;
  const txs = (await listJSON<Tx>("tcb-bank", `tx:${low(me.username)}:`)).sort((x, y) => y.at - x.at).slice(0, 50);
  const ledger = (await ledgerFor(me.username)).slice(0, 40).map((e) => ({
    at: Date.parse(e.createdAt), label: e.reason, amount: e.amount, category: catOf(e.kind, e.reason),
  }));
  const fresh_me = (await getUser(me.username)) ?? me;
  const checking = fresh_me.bobux ?? 0;
  const livrets = a.livrets || { classic: { balance: a.savings, lastInterestAt: a.lastInterestAt }, projet: { balance: 0, lastInterestAt: Date.now() } };
  const totalSavings = Object.values(livrets).reduce((s, L) => s + (L.balance || 0), 0);

  // scheduled
  const scheduled = (await listJSON<Scheduled>("tcb-bank", `sched:${low(me.username)}:`)).filter((s) => s.remaining > 0);

  // pots
  const potLinks = await listJSON<{ potId: string }>("tcb-bank", `potmember:${low(me.username)}:`);
  const pots: Pot[] = [];
  for (const pl of potLinks) {
    const p = await getJSON<Pot>("tcb-bank", `pot:${pl.potId}`);
    if (p && !p.closed) pots.push(p);
  }

  // loans
  const allLoans = await listJSON<Loan>("tcb-bank", "loan:");
  const loans = allLoans.filter((l) => (low(l.from) === low(me.username) || low(l.to) === low(me.username)) && l.status !== "repaid");

  // insurance
  const ins = await getJSON<Insurance>("tcb-bank", `ins:${low(me.username)}`);
  const insurance = ins && ins.endsAt > Date.now() ? ins : null;

  // alerts
  const alerts = (await listJSON<Alert>("tcb-bank", `alert:${low(me.username)}:`)).sort((a, b) => b.at - a.at).slice(0, 15);

  // categories breakdown (last 30 days)
  const recent = [...txs, ...ledger.map((e) => ({ ...e, type: "ledger", note: e.label, id: String(e.at), category: e.category }))];
  const catMap: Record<string, number> = {};
  for (const tx of recent.filter((x) => x.amount < 0 && x.at > Date.now() - 30 * DAY)) {
    const c = (tx as any).category || "Autre";
    catMap[c] = (catMap[c] || 0) + Math.abs(tx.amount);
  }
  const categories = Object.entries(catMap).map(([name, total]) => ({ name, total })).sort((a, b) => b.total - a.total);

  const health = healthScore(checking, totalSavings, txs, a.overdraftUsed ?? 0, premium);

  return {
    account: {
      number: accountNumber(me.username),
      iban: makeIban(me.username),
      card: makeCard(me.username),
      checking,
      savings: totalSavings,
      livrets: Object.fromEntries(Object.entries(LIVRETS).map(([id, def]) => [id, {
        name: def.name,
        balance: livrets[id]?.balance ?? 0,
        rate: t.rate * def.rateMul,
        cap: Math.floor(t.cap * def.capMul),
      }])),
      goal: a.goal,
      rate: t.rate,
      cap: t.cap,
      transferLimit: t.transfer,
      transferUsed: used,
      overdraftLimit: t.overdraft,
      overdraftUsed: a.overdraftUsed ?? 0,
      interestHistory: (a.interestHistory ?? []).slice(-14).reverse(),
    },
    subscription: {
      active: premium, endsAt: sub?.endsAt ?? 0, autoRenew: !!sub?.autoRenew && premium,
      price: PLAN.price, days: PLAN.days, name: PLAN.name, creatorUnlimited: isMaxAccount(me),
    },
    tax: {
      rate: premium ? TAX.premiumRate : TAX.rate, threshold: TAX.threshold, cap: TAX.cap,
      estimate: isMaxAccount(me) || await isAdminAbuseActive() ? 0 : taxFor(checking + totalSavings, premium),
      exempt: isMaxAccount(me) || await isAdminAbuseActive(),
      adminAbuse: await isAdminAbuseActive(),
    },
    treasury: isMaxAccount(me) ? await treasuryView() : null,
    statement: ledger,
    savingsTx: txs,
    scheduled,
    pots,
    loans,
    insurance,
    alerts,
    categories,
    health,
    mystery: await (async () => {
      const used = (await getJSON<{ n: number }>("tcb-bank", `mystery:${low(me.username)}:${day()}`))?.n ?? 0;
      const tit = await getJSON<{ title: string; until: number }>("tcb-bank", `title:${low(me.username)}`);
      return {
        cost: MYSTERY_COST,
        remaining: Math.max(0, 5 - used),
        title: tit && tit.until > Date.now() ? tit.title : null,
      };
    })(),
    haunted: hauntInfo,
    blocus: {
      available: (a.overdraftUsed ?? 0) > 0 && Date.now() >= (a.blocusCooldownUntil ?? 0),
      cooldownUntil: a.blocusCooldownUntil ?? 0,
      debt: a.overdraftUsed ?? 0,
    },
  };
}
