import {getUser,saveUser} from "./store";
import {credit} from "./bobux";
export const QUESTS=[
 {id:"play",title:"Jouer à un jeu",desc:"Joue réellement pendant 5 minutes.",target:300,reward:80},
 {id:"launch",title:"Découvrir un jeu",desc:"Lance une expérience de ta bibliothèque.",target:1,reward:30},
 {id:"favorite",title:"Faire un favori",desc:"Ajoute un jeu à tes favoris.",target:1,reward:40},
 {id:"algebre",title:"Réviser l'algèbre",desc:"Fais un exercice sur Algèbre Facile.",target:1,reward:50},
] as const;
export const WEEKLY_QUESTS=[
 {id:"w_play",title:"Marathon gamer",desc:"Joue 30 minutes cette semaine.",target:1800,reward:300},
 {id:"w_algebre",title:"Mathématicien",desc:"Résous 20 exercices d'algèbre.",target:20,reward:250},
 {id:"w_games",title:"Explorateur",desc:"Joue à 5 jeux différents.",target:5,reward:200},
 {id:"w_cine",title:"Cinéphile",desc:"Regarde 3 films sur CinéStream.",target:3,reward:150},
] as const;
function day(){return new Date().toISOString().slice(0,10)}
export async function state(username:string){const u=await getUser(username);if(!u)throw new Error("Utilisateur introuvable");const d=day();if(!u.dailyQuests||u.dailyQuests.date!==d)u.dailyQuests={date:d,claimed:[],progress:{}};await saveUser(u);return u.dailyQuests}
export async function progress(username:string,id:string,value:number){const u=await getUser(username);if(!u)throw new Error("Utilisateur introuvable");const d=day();if(!u.dailyQuests||u.dailyQuests.date!==d)u.dailyQuests={date:d,claimed:[],progress:{}};const q=QUESTS.find(x=>x.id===id);if(!q)throw new Error("Quête inconnue");u.dailyQuests.progress[id]=Math.max(u.dailyQuests.progress[id]||0,Math.min(q.target,value));await saveUser(u);return u.dailyQuests}
export async function claim(username:string,id:string){const u=await getUser(username);if(!u)throw new Error("Utilisateur introuvable");const d=day();if(!u.dailyQuests||u.dailyQuests.date!==d)throw new Error("Quête non terminée");const q=QUESTS.find(x=>x.id===id);if(!q)throw new Error("Quête inconnue");if(u.dailyQuests.claimed.includes(id))throw new Error("Déjà récupérée");if((u.dailyQuests.progress[id]||0)<q.target)throw new Error("Quête pas encore terminée");u.dailyQuests.claimed.push(id);await saveUser(u);await credit(username,q.reward,"TheCombinedWebs",`Quête : ${q.title}`,"quest");return {state:u.dailyQuests,reward:q.reward,bobux:(await getUser(username))?.bobux||0}}

// ————— Quêtes hebdomadaires —————
function weekNum(){const d=new Date();const y=d.getFullYear();const onejan=new Date(y,0,1);const wk=Math.ceil(((d.getTime()-onejan.getTime())/86400000+onejan.getDay()+1)/7);return `${y}-W${wk}`}
export async function weeklyState(username:string){const u=await getUser(username);if(!u)throw new Error("Utilisateur introuvable");const w=weekNum();if(!u.weeklyQuests||u.weeklyQuests.week!==w)u.weeklyQuests={week:w,claimed:[],progress:{}};await saveUser(u);return u.weeklyQuests}
export async function weeklyProgress(username:string,id:string,value:number){const u=await getUser(username);if(!u)throw new Error("Utilisateur introuvable");const w=weekNum();if(!u.weeklyQuests||u.weeklyQuests.week!==w)u.weeklyQuests={week:w,claimed:[],progress:{}};const q=WEEKLY_QUESTS.find(x=>x.id===id);if(!q)throw new Error("Quête hebdo inconnue");u.weeklyQuests.progress[id]=Math.max(u.weeklyQuests.progress[id]||0,Math.min(q.target,value));await saveUser(u);return u.weeklyQuests}
export async function weeklyClaim(username:string,id:string){const u=await getUser(username);if(!u)throw new Error("Utilisateur introuvable");const w=weekNum();if(!u.weeklyQuests||u.weeklyQuests.week!==w)throw new Error("Quête hebdo expirée");const q=WEEKLY_QUESTS.find(x=>x.id===id);if(!q)throw new Error("Quête hebdo inconnue");if(u.weeklyQuests.claimed.includes(id))throw new Error("Déjà récupérée");if((u.weeklyQuests.progress[id]||0)<q.target)throw new Error("Quête pas encore terminée");u.weeklyQuests.claimed.push(id);await saveUser(u);await credit(username,q.reward,"TheCombinedWebs",`Quête hebdo : ${q.title}`,"quest");return {state:u.weeklyQuests,reward:q.reward,bobux:(await getUser(username))?.bobux||0}}
