const ALLOWED_NEXT = ["/steamblox", "/portails", "/evenements", "/economie", "/social", "/cinestream", "/vortex", "/games/", "/account", "/credits", "/multiplayer"];
export function safeNext(next: unknown, fallback = "/steamblox") {
  const v = typeof next === "string" ? next : "";
  if (!v.startsWith("/") || v.startsWith("//") || v.includes("\\")) return fallback;
  return ALLOWED_NEXT.some((p) => v === p || v.startsWith(p.endsWith("/") ? p : p + "/") || v.startsWith(p + "?")) ? v : fallback;
}
