import { onNetlify } from "./runtime";
import { getStore } from "@netlify/blobs";
import { promises as fs } from "node:fs";
import path from "node:path";
import { serial } from "./feature-lock";
import {readCredential} from "./credentials";

export type Role = "user" | "moderator" | "vice_creator" | "creator";
export type User = {
  username: string;
  passwordHash: string;
  passwordResetAt?: string;
  role: Role;
  owned: string[];
  friends?: string[];
  banned?: boolean;
  banReason?: string;
  coins?: number;
  bobux?: number;
  bobuxReceipts?: Record<string,{amount:number;at:string}>;
  favorites?: string[];
  dailyQuests?: {date:string;claimed:string[];progress:Record<string,number>};
  weeklyQuests?: {week:string;claimed:string[];progress:Record<string,number>};
  activeGame?: {gameId:string;startedAt:string;elapsedSeconds?:number};
  achievements?: string[];
  playTimeMinutes?: number;
  loginStreak?: number;
  lastLoginDate?: string;
  avatarHat?: string;
  avatarShirt?: string;
  ownedHats?: string[];
  ownedShirts?: string[];
  aiConversations?: AIConversation[];
  // v52 — progression, social, films
  xp?: number;
  xpDaily?: { date: string; by: Record<string, number> };
  season?: { id: string; xp: number; claimed: number[] };
  cosmetics?: { owned: string[]; border?: string; name?: string; sound?: string };
  badges?: string[];
  status?: string;
  bio?: string;
  favoriteGame?: string;
  showcasedAchievements?: string[];
  clan?: string;
  theme?: string;
  filmList?: { key: string; title: string; poster?: string; type?: string; at: number }[];
  filmHistory?: { key: string; title: string; poster?: string; type?: string; cat?: string; season?: number; episode?: number; at: number }[];
};

export type AIMessage = { role: "user" | "assistant"; content: string; createdAt: string };
export type AIConversation = { id: string; title: string; createdAt: string; updatedAt: string; messages: AIMessage[] };

export function hasGameAccess(user: Pick<User,"role"|"owned">, gameId: string) {
  const game = catalog.find((item) => item.id === gameId);
  // v53 : tous les jeux sont gratuits
  return !!game || user.role === "creator" || user.role === "vice_creator" || user.owned.includes(gameId);
}

export type Game = {
  id: string;
  title: string;
  price: number;
  status: "available" | "coming-soon";
  playable: boolean;
  description: string;
  kind: "original" | "licensed";
  multiplayer: boolean;
  is3D?: boolean;
  externalUrl?: string;
};

export const catalog: Game[] = [
  { id: "infinite-ascent", title: "Infinite Ascent", price: 0, status: "available", playable: true, description: "Plateforme infinie procédurale : grimpe, évite les pièges et bats ton record. Difficulté progressive.", kind: "original", multiplayer: true },
  { id: "blocus-simulator", title: "Blocus Simulator", price: 0, status: "available", playable: true, description: "Fuite pixel-art : esquive flashballs, fumigènes et CRS. Dash, combos, kits de soin. Survive jusqu'à l'extraction.", kind: "original", multiplayer: false },
  { id: "snokido", title: "Snokido", price: 0, status: "available", playable: true, description: "Portail de jeux Snokido (snokido.fr), affiché via le proxy TCB. Gratuit.", kind: "licensed", multiplayer: false, is3D: false, externalUrl: "https://snokido.fr" },
  { id: "gta-web", title: "GTA Web", price: 0, status: "available", playable: true, description: "GTA jouable dans le navigateur (hébergé sur gta.deloskiyt.pl). Story Mode et Sandbox. Gratuit.", kind: "licensed", multiplayer: false, is3D: true, externalUrl: "https://gta.deloskiyt.pl" },
  { id: "sky-jump", title: "Sky Jump 3D", price: 0, status: "available", playable: true, description: "Plateformes en 3D perspective, défis de saut et multijoueur à distance.", kind: "original", multiplayer: true, is3D: true },
  { id: "turbo-kart", title: "Turbo Kart 3D", price: 0, status: "available", playable: true, description: "Courses de kart en 3D perspective avec pilotes et multijoueur à distance.", kind: "original", multiplayer: true, is3D: true },
  { id: "neon-drift-3d", title: "Neon Drift 3D", price: 0, status: "available", playable: true, description: "Conduite futuriste 3D, checkpoints et meilleurs temps.", kind: "original", multiplayer: true, is3D: true },
  { id: "mystic-mines", title: "Mystic Mines", price: 0, status: "available", playable: true, description: "Exploration dans le noir : lanterne, pioche, chauves-souris et cristaux cachés. Galeries générées à chaque partie.", kind: "original", multiplayer: true },
  { id: "block-brawl", title: "Block Brawl", price: 0, status: "available", playable: true, description: "Combat en vagues : enchaîne les coups, casse les caisses et repousse des blocs de plus en plus coriaces.", kind: "original", multiplayer: true },
  { id: "pixel-heist", title: "Pixel Heist", price: 0, status: "available", playable: true, description: "Infiltration : évite les cônes de vision des gardes, utilise des leurres et vole tout le butin.", kind: "original", multiplayer: true },
  { id: "neon-arena", title: "Neon Arena", price: 0, status: "available", playable: true, description: "Boss rush néon : esquive les salves de noyaux géants, frôle les projectiles et riposte.", kind: "original", multiplayer: true },
  { id: "rooftop-rivals", title: "Rooftop Rivals", price: 0, status: "available", playable: true, description: "Course sur les toits contre deux rivaux : saute entre les immeubles et capture 5 zones.", kind: "original", multiplayer: true, is3D: true },
  { id: "party-pals", title: "Party Pals", price: 0, status: "available", playable: true, description: "4 mini-jeux contre 3 adversaires : pièces, sol qui s’effondre, roi de la colline et patate chaude.", kind: "original", multiplayer: true },
  { id: "cyber-siege", title: "Cyber Siege", price: 0, status: "available", playable: true, description: "Tir en arène : drones, tourelles et tanks, bonus de tir rapide et triple, vagues infinies.", kind: "original", multiplayer: true },
  { id: "crystal-rush", title: "Crystal Rush", price: 0, status: "available", playable: true, description: "Contre la montre : ramasse tous les cristaux, évite les drones et enchaîne les niveaux.", kind: "original", multiplayer: true },
  { id: "hello-neighbor-prealpha", title: "Hello Neighbor: Pre-Alpha", price: 0, status: "available", playable: true, description: "Intégration TheCombinedWebs de la pré-alpha. Le jeu reste dans TheCombinedWebs et se lance via un build web autorisé.", kind: "licensed", multiplayer: true, is3D: true },
  { id: "baldi-basics-3d", title: "Baldi's Basics 3D", price: 0, status: "available", playable: true, description: "Version 3D améliorée intégrée à l’écosystème TheCombinedWebs : explore l’école, ramasse les carnets et échappe à Baldi. Crédits : Walid.", kind: "licensed", multiplayer: true, is3D: true },
  { id: "endacopia", title: "Endacopia", price: 0, status: "coming-soon", playable: false, description: "Emplacement d’intégration soumis à autorisation et distribution officielle.", kind: "licensed", multiplayer: false },
  { id: "ultrakill-local", title: "ULTRAKILL", price: 0, status: "available", playable: false, description: "Jeu PC externe : associe ton exemplaire local depuis TheCombinedWebs. Aucun exécutable n’est hébergé par la plateforme.", kind: "licensed", multiplayer: true, is3D: true },
  { id: "meteor-mayhem", title: "Meteor Mayhem", price: 0, status: "available", playable: true, description: "Survie arcade : esquive la pluie de météores, ramasse les étoiles et active ton bouclier.", kind: "original", multiplayer: true },
  { id: "neon-tag", title: "Neon Tag", price: 0, status: "available", playable: true, description: "Chat perché néon contre 4 adversaires : passe le moins de temps possible dans le rôle du chat.", kind: "original", multiplayer: true },
  { id: "castle-clash", title: "Castle Clash", price: 0, status: "available", playable: true, description: "Contrôle de zone médiéval : tiens le cercle central face aux chevaliers et aux archers.", kind: "original", multiplayer: true },
  { id: "algebra-arena", title: "Algèbre Arena", price: 0, status: "available", playable: true, description: "Révisions ludiques : des équations tombent, touche les vraies, évite les fausses. Combo et vies.", kind: "original", multiplayer: true },
  { id: "mental-math", title: "Calcul Mental", price: 0, status: "available", playable: true, description: "30 secondes pour faire le maximum d'opérations. Additions, soustractions, multiplications.", kind: "original", multiplayer: true },
  { id: "fraction-rush", title: "Fraction Rush", price: 0, status: "available", playable: true, description: "Compare des fractions le plus vite possible. Gauche, droite ou égal ? 30 secondes.", kind: "original", multiplayer: true },
  { id: "algebra-duel", title: "Algebra Duel", price: 0, status: "available", playable: true, description: "Duel temps réel contre l'IA : premier à 5 bonnes réponses. Équations de plus en plus dures.", kind: "original", multiplayer: true },
];

const LOCAL_DB = path.join(process.env.TCB_DATA_DIR || path.join(process.cwd(), "data"), "users.json");
const USE_FILE_FALLBACK = !onNetlify();


async function readLocalUsers() {
  if(!USE_FILE_FALLBACK) return {} as Record<string,User>;
  try { return JSON.parse(await fs.readFile(LOCAL_DB,"utf8")) as Record<string,User>; } catch { return {} as Record<string,User>; }
}

async function writeLocalUsers(users:Record<string,User>) {
  if(!USE_FILE_FALLBACK) return;
  const dir=path.dirname(LOCAL_DB); await fs.mkdir(dir,{recursive:true});
  const tmp=LOCAL_DB+".tmp"; await fs.writeFile(tmp,JSON.stringify(users,null,2),"utf8"); await fs.rename(tmp,LOCAL_DB);
}

async function localGetUser(username:string) {
  const users=await readLocalUsers(); return users[username.trim().toLowerCase()]??null;
}
async function localSaveUser(user:User) {
  await serial("users-file",async()=>{const users=await readLocalUsers(); users[user.username.toLowerCase()]=user; await writeLocalUsers(users);});
}
async function localGetAllUsers() { return Object.values(await readLocalUsers()); }

async function fallbackGetUser(username:string) {
  if(!USE_FILE_FALLBACK) throw new Error("Stockage des comptes indisponible.");
  return localGetUser(username);
}
async function fallbackGetAllUsers() {
  if(!USE_FILE_FALLBACK) throw new Error("Stockage des comptes indisponible.");
  return localGetAllUsers();
}
async function fallbackSave(user:User) {
  if(!USE_FILE_FALLBACK) throw new Error("Stockage des comptes indisponible.");
  await localSaveUser(user);
}

function netlifyStore() {
  try {
    return getStore({ name: "steamblox", consistency: "strong" });
  } catch {
    return null;
  }
}

async function withStore<T>(work: (store: ReturnType<typeof getStore>) => Promise<T>, fallback: () => Promise<T>) {
  const remote = netlifyStore();
  if (!remote) return fallback();
  try {
    return await work(remote);
  } catch {
    return fallback();
  }
}

export const BOBUX_MAX = 999_999_999;
export const isMaxAccount = (u: { username: string; role: string }) => u.role === "creator" && u.username.toLowerCase() === "younes";
function maxed<T extends { username: string; role: string; bobux?: number }>(u: T | null): T | null {
  return u && isMaxAccount(u) && u.bobux !== BOBUX_MAX ? { ...u, bobux: BOBUX_MAX } : u;
}

export async function getUser(username: string) {
  const user=maxed(await getUserRaw(username));
  if(!user)return null;
  const credential=await readCredential(user.username);
  return credential ? {...user,passwordHash:credential.passwordHash,passwordResetAt:credential.changedAt} : user;
}
async function getUserRaw(username: string) {
  const key = `user:${username.toLowerCase()}`;
  return withStore(
    async remote => (await remote.get(key, { type: "json" })) as User | null,
    async () => fallbackGetUser(username)
  );
}

export async function saveUser(user: User, options?: {balanceWrite?:boolean}) {
  return serial(`user-save:${user.username.toLowerCase()}`,async()=>saveUserUnlocked(user,options));
}
async function saveUserUnlocked(user:User,options?:{balanceWrite?:boolean}){
  const existing=await getUserRaw(user.username);
  // Credential changes live separately and cannot be reverted by profile saves.
  if(existing){user={...user,passwordHash:existing.passwordHash,passwordResetAt:existing.passwordResetAt};}
  if(existing&&!options?.balanceWrite){user.bobux=existing.bobux;user.bobuxReceipts=existing.bobuxReceipts;}
  if (isMaxAccount(user)) user = { ...user, bobux: BOBUX_MAX };
  const key = `user:${user.username.toLowerCase()}`;
  return withStore(
    async remote => { await remote.setJSON(key, user); },
    async () => { await fallbackSave(user); }
  );
}

export async function getAllUsers() {
  return (await getAllUsersRaw()).map(u => maxed(u)!);
}
async function getAllUsersRaw() {
  return withStore(
    async remote => {
      const { blobs } = await remote.list({ prefix: "user:" });
      const users: User[] = [];
      for (const blob of blobs) {
        const user = (await remote.get(blob.key, { type: "json" })) as User | null;
        if (user) users.push(user);
      }
      return users;
    },
    fallbackGetAllUsers
  );
}

export async function ensureSeeded() {
  const bcrypt = await import("bcryptjs");
  const base = { owned: catalog.map(g => g.id), friends: [], coins: 0, bobux: 0, favorites: [], dailyQuests: undefined, activeGame: undefined, achievements: [], playTimeMinutes: 0, avatarHat: "none", avatarShirt: "blue", aiConversations: [], ownedHats: ["none", "cap"], ownedShirts: ["blue", "black"] };
  const seeded = [
    { username: "Younes", passwordHash: "$pbkdf2-sha256$120000$e57ad288a07da9c1e2ce6ce8a694b579$04acd56d16f4151fa86b6132c0188486dc317bc0b22291609cf91ad94bb6bf5b", role: "creator" as Role },
    { username: "Moustafa", passwordHash: "$pbkdf2-sha256$120000$2602ecc0e8e301d2707889b18c75b108$d23ba9acbc356ed32669fdba3ac47dfe51eafbb05eb6f5f601ded3395877949e", role: "vice_creator" as Role }
  ];
  for (const account of seeded) {
    if (!(await getUser(account.username))) await saveUser({ ...base, ...account });
  }
  if (process.env.ISSAMNPC_PASSWORD && !(await getUser("Issamnpc"))) {
    await saveUser({ ...base, owned: [], username: "Issamnpc", passwordHash: await bcrypt.hash(process.env.ISSAMNPC_PASSWORD, 12), role: "user" });
  }
}
