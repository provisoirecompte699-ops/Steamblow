// Soirées ciné : un hôte choisit le film, tout le monde l'ouvre en même temps,
// compte à rebours commun, chat et vocal (salon « party~CODE »).
import { getJSON, updateJSON } from "./data-store";
import { cleanText } from "./discord";

const STORE = "steamblox-parties";
const TTL = 20000;
export type PartyFilm = { key: string; title: string; tmdbId?: number; type?: string; season?: number; episode?: number; poster?: string };
export type Party = {
  id: string; host: string; createdAt: number; members: Record<string, { u: string; at: number; ready?: boolean }>;
  film: PartyFilm | null; filmAt: number; countdown: number | null; chat: { id: string; u: string; text: string; at: number }[];
  /** Synchronisation fine (lecteur vidéo direct uniquement) */
  play?: { playing: boolean; t: number; at: number } | null;
};
const low = (s: string) => s.toLowerCase();
const prune = (p: Party) => { const now = Date.now(); for (const [k, m] of Object.entries(p.members)) if (now - m.at > TTL) delete p.members[k]; return p; };

export const getParty = async (id: string) => { const p = await getJSON<Party>(STORE, `p:${id}`); return p ? prune(p) : null; };
export async function isPartyMember(u: string, id: string) { const p = await getParty(id); return !!p && !!p.members[low(u)]; }

export async function createParty(u: string) {
  const id = Math.random().toString(36).slice(2, 8).toUpperCase();
  const p: Party = { id, host: u, createdAt: Date.now(), members: { [low(u)]: { u, at: Date.now() } }, film: null, filmAt: 0, countdown: null, chat: [], play: null };
  await updateJSON<Party>(STORE, `p:${id}`, () => p);
  return p;
}

export async function partyAction(u: string, id: string, a: { action: string; film?: PartyFilm; text?: string; play?: { playing: boolean; t: number }; ready?: boolean }) {
  let err = "";
  const p = await updateJSON<Party>(STORE, `p:${String(id).toUpperCase()}`, (cur) => {
    if (!cur) { err = "Soirée introuvable (vérifie le code)"; return cur; }
    const p = prune(cur);
    const k = low(u), isHost = low(p.host) === k;
    if (a.action === "leave") {
      delete p.members[k];
      const left = Object.values(p.members);
      if (!left.length) return null;
      if (isHost) p.host = left[0].u;
      return p;
    }
    if (!p.members[k] && Object.keys(p.members).length >= 12) { err = "Soirée complète (12 max)"; return p; }
    p.members[k] = { u, at: Date.now(), ready: a.ready ?? p.members[k]?.ready };
    if (a.action === "film") {
      if (!isHost) { err = "Seul l'hôte choisit le film"; return p; }
      if (a.film && /^(m|tv)-\d{1,9}$/.test(a.film.key)) { p.film = { ...a.film, title: String(a.film.title || "").slice(0, 120) }; p.filmAt = Date.now(); p.countdown = null; p.play = null; for (const m of Object.values(p.members)) m.ready = false; }
    } else if (a.action === "countdown") {
      if (!isHost) { err = "Seul l'hôte lance la lecture"; return p; }
      p.countdown = Date.now() + 5000;
    } else if (a.action === "play") {
      if (!isHost) return p;
      if (a.play) p.play = { playing: !!a.play.playing, t: Math.max(0, Number(a.play.t) || 0), at: Date.now() };
    } else if (a.action === "chat") {
      const text = cleanText(a.text || "").slice(0, 300);
      if (text) p.chat = [...p.chat, { id: Date.now().toString(36) + Math.random().toString(36).slice(2, 5), u, text, at: Date.now() }].slice(-80);
    } else if (a.action === "host") {
      if (!isHost) return p;
    }
    return p;
  });
  if (err) throw new Error(err);
  return p;
}
