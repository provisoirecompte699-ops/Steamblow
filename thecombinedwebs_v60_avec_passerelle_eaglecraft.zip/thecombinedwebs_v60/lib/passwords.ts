import bcrypt from "bcryptjs";
import {pbkdf2, timingSafeEqual, randomBytes} from "node:crypto";

function parsePbkdf2(value:string){
  const m=/^\$pbkdf2-sha256\$(\d+)\$([0-9a-f]+)\$([0-9a-f]+)$/.exec(value);
  if(!m)return null;
  return {iterations:Number(m[1]),salt:m[2],hash:m[3]};
}

export async function verifyPassword(password:string, stored:string){
  const parsed=parsePbkdf2(stored);
  if(!parsed)return bcrypt.compare(password,stored);
  return await new Promise<boolean>((resolve,reject)=>{
    pbkdf2(password,Buffer.from(parsed.salt,"hex"),parsed.iterations,parsed.hash.length/2,"sha256",(err,key)=>{
      if(err)return reject(err);
      const expected=Buffer.from(parsed.hash,"hex");
      resolve(key.length===expected.length && timingSafeEqual(key,expected));
    });
  });
}

export async function hashLocalPassword(password:string){
  const iterations=120000;
  const salt=randomBytes(16).toString("hex");
  const hash=await new Promise<string>((resolve,reject)=>pbkdf2(password,Buffer.from(salt,"hex"),iterations,32,"sha256",(err,key)=>err?reject(err):resolve(key.toString("hex"))));
  return `$pbkdf2-sha256$${iterations}$${salt}$${hash}`;
}
