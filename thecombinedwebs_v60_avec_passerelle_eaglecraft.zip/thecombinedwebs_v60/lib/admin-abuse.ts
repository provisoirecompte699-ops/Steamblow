import { getJSON, setJSON, updateJSON, listJSON } from "./data-store";
import { getUser } from "./store";
import { credit } from "./bobux";
import crypto from "node:crypto";

const STORE = "tcb-admin-abuse";
const EVENT_KEY = "event:active";
const DAY_MS = 86400000;
const day = () => new Date().toISOString().slice(0, 10);
const low = (s: string) => s.toLowerCase();
export type AdminAbuseEvent = { id: string; startedAt: number; endsAt: number; startedBy: string; date: string };
export async function getAdminAbuseEvent(): Promise<AdminAbuseEvent | null> {
  const e = await getJSON<AdminAbuseEvent>(STORE, EVENT_KEY);
  if (!e || e.endsAt <= Date.now()) return null;
  return e;
}
export async function isAdminAbuseActive() { return !!(await getAdminAbuseEvent()); }
export async function startAdminAbuse(username: string) {
  const u = await getUser(username);
  if (!u || (u.role !== "creator" && u.role !== "vice_creator")) return { error: "Réservé au créateur et au vice-créateur." };
  const current = await getAdminAbuseEvent();
  if (current) return { error: `Admin Abuse déjà actif jusqu’à ${new Date(current.endsAt).toLocaleTimeString("fr-FR", { hour: "2-digit", minute: "2-digit" })}.` };
  const now = Date.now();
  const event: AdminAbuseEvent = { id: crypto.randomUUID(), startedAt: now, endsAt: now + 15 * 60 * 1000, startedBy: u.username, date: day() };
  await setJSON(STORE, EVENT_KEY, event);
  return { ok: true, event };
}
export async function stopAdminAbuse(username: string) {
  const u = await getUser(username);
  if (!u || (u.role !== "creator" && u.role !== "vice_creator")) return { error: "Réservé au créateur et au vice-créateur." };
  await setJSON<AdminAbuseEvent | null>(STORE, EVENT_KEY, null);
  return { ok: true };
}
export async function adminAbuseStatus(username: string) {
  const u = await getUser(username); const event = await getAdminAbuseEvent();
  const played = await getJSON<{ date: string; runId: string }>(STORE, `played:${low(username)}:${day()}`);
  const scores = (await listJSON<{ username: string; score: number; reward: number; date: string; at: number }>(STORE, `score:${day()}:`)).sort((a,b) => b.score-a.score).slice(0,10);
  return { active: !!event, event, canControl: !!u && (u.role === "creator" || u.role === "vice_creator"), playedToday: !!played, scores };
}
export async function startAdminAbuseRun(username: string) {
  if (!(await getAdminAbuseEvent())) return { error: "L’Admin Abuse n’est pas actif. Attends qu’un admin le lance." };
  const key = `played:${low(username)}:${day()}`;
  if (await getJSON(STORE, key)) return { error: "Tu as déjà participé aujourd’hui. Reviens demain." };
  const runId = crypto.randomUUID();
  await setJSON(STORE, `run:${runId}`, { username: low(username), startedAt: Date.now(), used: false, eventId: (await getAdminAbuseEvent())?.id });
  await setJSON(STORE, key, { date: day(), runId });
  return { ok: true, runId, seconds: 30 };
}
export async function finishAdminAbuseRun(username: string, runIdRaw: unknown, scoreRaw: unknown) {
  const runId = String(runIdRaw || "").slice(0, 80);
  const key = `run:${runId}`;
  const run = await getJSON<{ username: string; startedAt: number; used: boolean; eventId: string }>(STORE, key);
  if (!run || run.username !== low(username) || run.used) return { error: "Partie invalide ou déjà comptée." };
  const elapsed = (Date.now() - run.startedAt) / 1000;
  if (elapsed < 20 || elapsed > 75) return { error: "Durée de partie invalide." };
  await setJSON(STORE, key, { ...run, used: true });
  const score = Math.max(0, Math.min(150, Math.floor(Number(scoreRaw) || 0)));
  const reward = Math.min(300, score * 2);
  if (reward > 0) await credit(username, reward, "Admin Abuse", "Récompense Admin Abuse quotidien", "quest");
  const row = { username, score, reward, date: day(), at: Date.now() };
  await setJSON(STORE, `score:${day()}:${low(username)}`, row);
  return { ok: true, score, reward, balance: (await getUser(username))?.bobux ?? 0 };
}
