import { getJSON, setJSON, updateJSON } from "./data-store";
import { getUser, type User } from "./store";
import { credit, spend } from "./bobux";
import { serial } from "./feature-lock";
import {TROLL_PRICES} from "./troll-prices";
export {TROLL_PRICES} from "./troll-prices";
import crypto from "node:crypto";

const low = (s: string) => s.toLowerCase();
const isStaffRole = (u: Pick<User, "role">) => u.role === "moderator" || u.role === "vice_creator" || u.role === "creator";

/* ---------- Système de troll (effets visuels inoffensifs, avec désactivation) ---------- */
export const EFFECTS = ["flip", "mirror", "shake", "spin", "rainbow", "zoom", "confetti", "fakecrash"] as const;
type Troll = { id: string; from: string; effect: string; at: number };
export async function sendTroll(me: User, target: unknown, effect: unknown) {
  return serial(`troll:${low(me.username)}`,()=>sendTrollUnlocked(me,target,effect));
}
async function sendTrollUnlocked(me: User,target:unknown,effect:unknown) {
  if (!EFFECTS.includes(effect as any)) return { error: "Effet inconnu." };
  const t = await getUser(String(target || "").trim().slice(0, 24)); if (!t || t.banned) return { error: "Joueur introuvable." };
  if (low(t.username) === low(me.username)) return { error: "Tu ne peux pas te troller toi-même." };
  const staff = isStaffRole(me);
  if (!staff && !(me.friends || []).some((f) => low(f) === low(t.username))) return { error: "Tu ne peux troller que tes amis." };
  if ((await getJSON<{ v: boolean }>("tcb-troll", `optout:${low(t.username)}`))?.v) return { error: `${t.username} a désactivé les trolls.` };
  const last = await getJSON<{ at: number }>("tcb-troll", `last:${low(me.username)}`); const gap = staff ? 5000 : 60000;
  if (last && Date.now() - last.at < gap) return { error: `Attends ${Math.ceil((gap - (Date.now() - last.at)) / 1000)} s avant le prochain troll.` };
  try { await spend(me.username,TROLL_PRICES[String(effect)],`Boutique troll ${String(effect)} sur ${t.username}`); } catch(e) { return {error:e instanceof Error?e.message:"Solde insuffisant."}; }
  await setJSON("tcb-troll", `last:${low(me.username)}`, { at: Date.now() });
  await updateJSON<Troll[]>("tcb-troll", `inbox:${low(t.username)}`, (cur) => [...(cur || []).filter((x) => Date.now() - x.at < 120000), { id: crypto.randomUUID(), from: me.username, effect: String(effect), at: Date.now() }].slice(-5));
  return { ok: true, price:TROLL_PRICES[String(effect)] };
}
export async function takeTrolls(me: string) {
  if ((await getJSON<{ v: boolean }>("tcb-troll", `optout:${low(me)}`))?.v) return [];
  const inbox = (await getJSON<Troll[]>("tcb-troll", `inbox:${low(me)}`)) || [];
  const fresh = inbox.filter((x) => Date.now() - x.at < 120000);
  if (inbox.length) await setJSON("tcb-troll", `inbox:${low(me)}`, []);
  return fresh.slice(0, 3);
}
export const setOptOut = (me: string, v: boolean) => setJSON("tcb-troll", `optout:${low(me)}`, { v });
export async function getOptOut(me: string) { return !!(await getJSON<{ v: boolean }>("tcb-troll", `optout:${low(me)}`))?.v; }

/* ---------- Easter egg BOBUXTIME : mini-jeu d'attrape-Bobux ---------- */
export const GAME_SECONDS = 30, DAILY_RUNS = 5, MAX_PER_RUN = 80;
const day = () => new Date().toISOString().slice(0, 10);
export async function startBobuxRun(me: string, code: unknown) {
  const expected = (process.env.TCB_EASTER_CODE || "BOBUXTIME").toUpperCase();
  if (String(code || "").trim().toUpperCase() !== expected) return { error: "Code incorrect." };
  const key = `runs:${low(me)}:${day()}`; const n = (await getJSON<{ n: number }>("tcb-bobuxgame", key))?.n ?? 0;
  if (n >= DAILY_RUNS) return { error: `Reviens demain : ${DAILY_RUNS} parties par jour maximum.` };
  await setJSON("tcb-bobuxgame", key, { n: n + 1 });
  const id = crypto.randomUUID(); await setJSON("tcb-bobuxgame", `run:${id}`, { user: low(me), startedAt: Date.now(), used: false });
  return { ok: true, id, seconds: GAME_SECONDS, runsLeft: DAILY_RUNS - n - 1 };
}
export async function finishBobuxRun(me: string, id: unknown, caught: unknown) {
  const key = `run:${String(id || "").slice(0, 60)}`; const r = await getJSON<{ user: string; startedAt: number; used: boolean }>("tcb-bobuxgame", key);
  if (!r || r.user !== low(me) || r.used) return { error: "Partie invalide." };
  const secs = (Date.now() - r.startedAt) / 1000;
  if (secs < 8 || secs > GAME_SECONDS + 25) return { error: "Partie invalide." };
  await setJSON("tcb-bobuxgame", key, { ...r, used: true });
  const amount = Math.max(0, Math.min(MAX_PER_RUN, Math.floor(secs * 3), Math.floor(Number(caught) || 0)));
  if (amount > 0) await credit(me, amount, "TCB", "Mini-jeu BOBUXTIME", "quest");
  return { ok: true, amount, balance: (await getUser(me))?.bobux ?? 0 };
}
