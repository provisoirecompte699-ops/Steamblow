import webpush from "web-push";
import { getJSON, setJSON, delJSON, listJSON } from "./data-store";
import { getAllUsers } from "./store";
import { createHash } from "node:crypto";
import type { LiveEvent } from "./live-events";
type Subscription = {
  username: string;
  subscription: webpush.PushSubscription;
  events: boolean;
  friends: boolean;
};
const STORE = "tcb-push";
export function pushConfigured() {
  return !!(
    process.env.NEXT_PUBLIC_VAPID_PUBLIC_KEY &&
    process.env.VAPID_PRIVATE_KEY &&
    process.env.VAPID_SUBJECT
  );
}
export async function subscribePush(
  username: string,
  raw: unknown,
  events: boolean,
  friends: boolean,
) {
  if (!pushConfigured())
    throw new Error("Notifications push non configurées sur le serveur.");
  const s = raw as webpush.PushSubscription;
  const u = new URL(s.endpoint);
  if (
    u.protocol !== "https:" ||
    u.username ||
    u.password ||
    u.port ||
    !(
      [
        "fcm.googleapis.com",
        "updates.push.services.mozilla.com",
        "web.push.apple.com",
      ].includes(u.hostname) || u.hostname.endsWith(".notify.windows.com")
    )
  )
    throw new Error("Service push non autorisé.");
  if (
    !s.keys?.auth ||
    !s.keys?.p256dh ||
    s.keys.auth.length > 200 ||
    s.keys.p256dh.length > 300
  )
    throw new Error("Abonnement invalide.");
  const id = createHash("sha256").update(s.endpoint).digest("hex");
  await setJSON<Subscription>(STORE, `sub:${id}`, {
    username,
    subscription: s,
    events,
    friends,
  });
}
export async function unsubscribePush(username: string, endpoint: string) {
  const key = `sub:${createHash("sha256").update(endpoint).digest("hex")}`;
  const s = await getJSON<Subscription>(STORE, key);
  if (s?.username.toLowerCase() === username.toLowerCase())
    await delJSON(STORE, key);
}
async function send(s: Subscription, payload: Record<string, string>) {
  if (!pushConfigured()) return;
  try {
    await webpush.sendNotification(s.subscription, JSON.stringify(payload), {
      TTL: 3600,
      vapidDetails: {
        subject: process.env.VAPID_SUBJECT!,
        publicKey: process.env.NEXT_PUBLIC_VAPID_PUBLIC_KEY!,
        privateKey: process.env.VAPID_PRIVATE_KEY!,
      },
    });
  } catch (e) {
    if ([404, 410].includes((e as { statusCode?: number }).statusCode || 0))
      await unsubscribePush(s.username, s.subscription.endpoint);
  }
}
export async function notifyEvent(e: LiveEvent) {
  const subs = await listJSON<Subscription>(STORE, "sub:");
  // Bounded concurrency, no private game activity in broadcast.
  for (let i = 0; i < subs.length; i += 10)
    await Promise.all(
      subs
        .slice(i, i + 10)
        .filter((s) => s.events)
        .map((s) =>
          send(s, {
            title: e.title,
            body: "Un événement vient de commencer sur TheCombinedWebs.",
            url: "/evenements",
            tag: `event-${e.id}`,
          }),
        ),
    );
}
export async function notifyFriendPlaying(username: string, where: string) {
  const friends = new Set(
    (await getAllUsers())
      .filter(
        (u) =>
          !u.banned &&
          u.friends?.some((f) => f.toLowerCase() === username.toLowerCase()),
      )
      .map((u) => u.username.toLowerCase()),
  );
  const subs = (await listJSON<Subscription>(STORE, "sub:")).filter(
    (s) => s.friends && friends.has(s.username.toLowerCase()),
  );
  for (let i = 0; i < subs.length; i += 10)
    await Promise.all(
      subs
        .slice(i, i + 10)
        .map((s) =>
          send(s, {
            title: `${username} est en jeu`,
            body: where,
            url: `/u/${encodeURIComponent(username)}`,
            tag: `friend-${username}`,
          }),
        ),
    );
}
