import bcrypt from "bcryptjs";
import { ensureSeeded, getUser, saveUser, type User } from "./store";
import { verifyPassword } from "./passwords";
import { createSession } from "./auth";
import { credit } from "./bobux";

/**
 * Connexion partagée par tout l'écosystème TheCombinedWebs
 * (TheCombinedWebs, Vortex, CinéStream, Baldi's Basics 3D).
 * Une seule session : le cookie HttpOnly `steamblox_session`.
 */

function dayKey(date = new Date()) { return date.toISOString().slice(0, 10); }
function previousDay(key: string) {
  const d = new Date(`${key}T00:00:00Z`);
  d.setUTCDate(d.getUTCDate() - 1);
  return dayKey(d);
}

// Limitation simple des tentatives (par instance serveur).
const attempts = new Map<string, { count: number; until: number }>();
export function tooManyAttempts(key: string) {
  const now = Date.now();
  const a = attempts.get(key);
  if (!a || a.until < now) return false;
  return a.count >= 8;
}
function recordFailure(key: string) {
  const now = Date.now();
  const a = attempts.get(key);
  if (!a || a.until < now) attempts.set(key, { count: 1, until: now + 60_000 });
  else a.count += 1;
}
function clearFailures(key: string) { attempts.delete(key); }

export type LoginResult =
  | { ok: true; user: User; reward: number; streak: number; token: string }
  | { ok: false; error: "invalid" | "rate_limited" };

export async function loginWithPassword(usernameRaw: string, password: string): Promise<LoginResult> {
  await ensureSeeded();
  const username = usernameRaw.trim();
  const key = username.toLowerCase();
  if (tooManyAttempts(key)) return { ok: false, error: "rate_limited" };
  const u = username ? await getUser(username) : null;
  if (!u || u.banned || !(await verifyPassword(password, u.passwordHash))) {
    recordFailure(key);
    return { ok: false, error: "invalid" };
  }
  clearFailures(key);

  const today = dayKey();
  const last = u.lastLoginDate;
  let streak = u.loginStreak || 0;
  if (last === today) {
    // Reconnexion le même jour : pas de récompense supplémentaire.
  } else if (last === previousDay(today)) {
    streak += 1;
  } else {
    streak = 1;
  }
  u.lastLoginDate = today;
  u.loginStreak = streak;

  let reward = 0;
  if (last !== today) {
    reward = 100 + Math.min(200, Math.max(0, streak - 1) * 10);
  }
  // Confirm persistent session storage before changing login rewards or metadata.
  const token = await createSession(u.username,u.passwordHash);
  await saveUser(u);
  if (reward) { const entry = await credit(u.username, reward, "TheCombinedWebs", "Connexion quotidienne", "daily"); reward = entry.amount; u.bobux = (await getUser(u.username))?.bobux; }
  return { ok: true, user: u, reward, streak, token };
}

export type RegisterResult = { ok: true; user: User } | { ok: false; error: "username" | "password" | "exists" };

export async function registerAccount(usernameRaw: string, password: string): Promise<RegisterResult> {
  await ensureSeeded();
  const username = usernameRaw.trim();
  if (!/^[A-Za-z0-9_]{3,20}$/.test(username)) return { ok: false, error: "username" };
  if (password.length < 6) return { ok: false, error: "password" };
  if (await getUser(username)) return { ok: false, error: "exists" };
  const user: User = { username, passwordHash: await bcrypt.hash(password, 12), role: "user", owned: [], friends: [], coins: 0, bobux: 0, favorites: [], achievements: [], playTimeMinutes: 0, avatarHat: "none", avatarShirt: "blue", ownedHats: ["none", "cap"], ownedShirts: ["blue", "black"] };
  await saveUser(user);
  await createSession(username);
  return { ok: true, user };
}

/** Redirection interne sûre après connexion (évite les redirections ouvertes). */
export { safeNext } from "./login-redirect";
