export const TROLL_PRICES:Record<string,number>={flip:30,mirror:30,shake:20,spin:40,rainbow:25,zoom:20,confetti:15,fakecrash:60};
