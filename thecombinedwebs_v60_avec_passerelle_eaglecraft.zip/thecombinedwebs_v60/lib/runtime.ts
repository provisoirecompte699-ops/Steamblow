/**
 * Détecte l'exécution sur Netlify.
 * `NETLIFY=true` n'existe que pendant le BUILD ; dans les fonctions (runtime),
 * Netlify ne le définit pas. On détecte donc aussi le runtime des fonctions
 * (AWS Lambda) et le contexte Blobs. `NETLIFY=false` force le mode local (tests).
 */
export function onNetlify(): boolean {
  const e = process.env;
  if (e.NETLIFY === "false") return false;
  if (e.NETLIFY === "true") return true;
  return Boolean(e.NETLIFY_BLOBS_CONTEXT || e.AWS_LAMBDA_FUNCTION_NAME || e.LAMBDA_TASK_ROOT);
}
