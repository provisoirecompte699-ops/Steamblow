// Éditeur de niveaux : cartes personnalisées pour les jeux arcade.
import { getJSON, listJSON, setJSON, updateJSON, delJSON } from "./data-store";
import { grantBadge } from "./progression";

const STORE = "steamblox-maps";
/** Modes compatibles avec les cartes personnalisées. */
export const MAP_MODES: { mode: string; gameId: string; title: string }[] = [
  { mode: "meteor", gameId: "meteor-mayhem", title: "Meteor Mayhem" },
  { mode: "tag", gameId: "neon-tag", title: "Neon Tag" },
  { mode: "crystal", gameId: "crystal-rush", title: "Crystal Rush" },
  { mode: "brawl", gameId: "block-brawl", title: "Block Brawl" },
  { mode: "cyber", gameId: "cyber-siege", title: "Cyber Siege" },
  { mode: "arena", gameId: "neon-arena", title: "Neon Arena" },
];
export type CustomMap = { id: string; name: string; author: string; mode: string; cols: number; rows: number; grid: string; spawn: { x: number; y: number }; at: number; plays: number; likes: string[] };
export type MapMeta = Omit<CustomMap, "grid">;

export async function saveMap(author: string, m: { id?: string; name: string; mode: string; cols: number; rows: number; grid: string; spawn: { x: number; y: number } }) {
  if (!MAP_MODES.some((x) => x.mode === m.mode)) throw new Error("Mode incompatible");
  const cols = Math.round(m.cols), rows = Math.round(m.rows);
  if (cols < 12 || cols > 40 || rows < 9 || rows > 28) throw new Error("Taille invalide");
  const grid = String(m.grid || "");
  if (grid.length !== cols * rows || !/^[0-3]+$/.test(grid)) throw new Error("Carte invalide");
  const open = grid.split("").filter((c) => c === "0").length;
  if (open < cols * rows * 0.35) throw new Error("La carte doit avoir au moins 35 % de sol libre");
  const sx = Math.round(m.spawn?.x), sy = Math.round(m.spawn?.y);
  if (!(sx > 0 && sy > 0 && sx < cols - 1 && sy < rows - 1) || grid[sy * cols + sx] !== "0") throw new Error("Place le point de départ sur du sol");
  const name = String(m.name || "").replace(/\s+/g, " ").trim().slice(0, 32) || "Carte sans nom";
  if (m.id) {
    const old = await getJSON<CustomMap>(STORE, `map:${m.id}`);
    if (!old || old.author.toLowerCase() !== author.toLowerCase()) throw new Error("Tu ne peux modifier que tes cartes");
    const next = { ...old, name, mode: m.mode, cols, rows, grid, spawn: { x: sx, y: sy } };
    await setJSON(STORE, `map:${m.id}`, next);
    return next;
  }
  const map: CustomMap = { id: Math.random().toString(36).slice(2, 9), name, author, mode: m.mode, cols, rows, grid, spawn: { x: sx, y: sy }, at: Date.now(), plays: 0, likes: [] };
  await setJSON(STORE, `map:${map.id}`, map);
  if ((await listMaps()).filter((x) => x.author.toLowerCase() === author.toLowerCase()).length >= 3) await grantBadge(author, "creator");
  return map;
}
export const getMap = (id: string) => getJSON<CustomMap>(STORE, `map:${id}`);
export async function listMaps(): Promise<MapMeta[]> {
  return (await listJSON<CustomMap>(STORE, "map:")).map(({ grid: _g, ...rest }) => rest).sort((a, b) => b.likes.length - a.likes.length || b.at - a.at);
}
export async function likeMap(u: string, id: string) {
  return updateJSON<CustomMap>(STORE, `map:${id}`, (m) => { if (!m) return m; m.likes = m.likes.some((x) => x.toLowerCase() === u.toLowerCase()) ? m.likes.filter((x) => x.toLowerCase() !== u.toLowerCase()) : [...m.likes, u]; return m; });
}
export async function countPlay(id: string) { await updateJSON<CustomMap>(STORE, `map:${id}`, (m) => (m ? { ...m, plays: (m.plays || 0) + 1 } : m)); }
export async function deleteMap(u: string, id: string, staff: boolean) {
  const m = await getMap(id);
  if (!m) return false;
  if (!staff && m.author.toLowerCase() !== u.toLowerCase()) return false;
  await delJSON(STORE, `map:${id}`);
  return true;
}
