// Invitation entre amis : lien du type  /games/xxx?room=CODE
export function cleanRoomCode(v: string) { return String(v || "").toUpperCase().replace(/[^A-Z0-9_-]/g, "").slice(0, 20); }
export function roomFromUrl(): string {
  if (typeof window === "undefined") return "";
  try { return cleanRoomCode(new URLSearchParams(window.location.search).get("room") || ""); } catch { return ""; }
}
export function inviteLink(room: string): string {
  const u = new URL(window.location.href); u.search = ""; u.hash = ""; u.searchParams.set("room", room); return u.toString();
}
export async function copyInvite(room: string): Promise<boolean> {
  if (!room) return false;
  const link = inviteLink(room);
  try { if (navigator.share && /Mobi|Android/i.test(navigator.userAgent)) { await navigator.share({ title: "Rejoins ma partie TheCombinedWebs", url: link }); return true; } } catch {}
  try { await navigator.clipboard.writeText(link); return true; } catch {}
  try { window.prompt("Copie ce lien et envoie-le à tes amis :", link); return true; } catch { return false; }
}
