import { getJSON, setJSON, updateJSON } from "./data-store";
import { catalog, getUser, saveUser } from "./store";
import { load } from "cheerio";
import { createHash } from "node:crypto";
import { lookup } from "node:dns/promises";
import https from "node:https";
import { isIP } from "node:net";
import { serial } from "./feature-lock";
export type PortalGame = {
  id: string;
  title: string;
  url: string;
  portalId: string;
  category?: string;
};
export type Portal = {
  id: string;
  name: string;
  url: string;
  hosts: string[];
  enabled: boolean;
  isolated: boolean;
  selector: string;
  games: PortalGame[];
  indexedAt?: number;
  indexError?: string;
};
export type Library = {
  favorites: string[];
  recent: { id: string; at: number }[];
};
const STORE = "tcb-portals";
const defaults: Portal[] = [
  {
    id: "snokido",
    name: "Snokido",
    url: "https://snokido.fr/",
    hosts: ["snokido.fr", "*.snokido.fr"],
    enabled: true,
    isolated: false,
    selector: 'a[href*="/jeu/"],a[href*="/game/"]',
    games: [
      {
        id: "snokido",
        portalId: "snokido",
        title: "Snokido",
        url: "https://snokido.fr/",
      },
    ],
  },
  {
    id: "gta",
    name: "GTA Web",
    url: "https://gta.deloskiyt.pl/",
    hosts: ["gta.deloskiyt.pl"],
    enabled: true,
    isolated: true,
    selector: "",
    games: [
      {
        id: "gta-web",
        portalId: "gta",
        title: "GTA Web",
        url: "https://gta.deloskiyt.pl/",
      },
    ],
  },
];
export function validHost(raw: string) {
  const h = raw.trim().toLowerCase();
  const base = h.replace(/^\*\./, "");
  if (
    isIP(base) ||
    !/^(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z]{2,63}$/.test(base) ||
    /(?:^|\.)(?:localhost|local|internal|test|invalid|example)$/.test(base)
  )
    throw new Error("Hôte public invalide : " + raw);
  return h;
}
export function hostMatches(host: string, hosts: string[]) {
  return hosts.some((h) =>
    h.startsWith("*.")
      ? host === h.slice(2) || host.endsWith(h.slice(1))
      : host === h,
  );
}
export function portalUrl(raw: string, hosts: string[]) {
  const u = new URL(raw);
  if (
    u.protocol !== "https:" ||
    u.username ||
    u.password ||
    (u.port && u.port !== "443") ||
    !hostMatches(u.hostname, hosts)
  )
    throw new Error("URL HTTPS hors des hôtes autorisés.");
  validHost(u.hostname);
  return u;
}
export function publicAddress(ip: string) {
  if (isIP(ip) === 6)
    return (
      !/^(::|fc|fd|fe[89ab]|ff|2001:db8)/i.test(ip) &&
      !ip.toLowerCase().includes("ffff:")
    );
  const [a, b] = ip.split(".").map(Number);
  return (
    isIP(ip) === 4 &&
    a > 0 &&
    a !== 10 &&
    a !== 127 &&
    a < 224 &&
    !(a === 169 && b === 254) &&
    !(a === 172 && b >= 16 && b <= 31) &&
    !(a === 192 && (b === 168 || b === 0)) &&
    !(a === 100 && b >= 64 && b <= 127) &&
    !(a === 198 && (b === 18 || b === 19))
  );
}
// Pin a validated DNS address, revalidate every redirect, bound bytes and time.
async function safeText(
  url: URL,
  hosts: string[],
  redirects = 0,
): Promise<string> {
  portalUrl(url.href, hosts);
  const addresses = await lookup(url.hostname, { all: true });
  if (!addresses.length || addresses.some((a) => !publicAddress(a.address)))
    throw new Error("Adresse réseau privée ou réservée refusée.");
  const address = addresses[0];
  return new Promise((resolve, reject) => {
    const req = https.get(
      url,
      {
        lookup: (_h, _o, cb) => cb(null, address.address, address.family),
        timeout: 12000,
        headers: {
          "user-agent": "TCB-Catalog/60.0",
          accept: "text/html,application/json",
        },
      },
      (res) => {
        if (
          res.statusCode &&
          res.statusCode >= 300 &&
          res.statusCode < 400 &&
          res.headers.location
        ) {
          res.resume();
          if (redirects >= 3) return reject(new Error("Trop de redirections."));
          safeText(
            new URL(res.headers.location, url),
            hosts,
            redirects + 1,
          ).then(resolve, reject);
          return;
        }
        if (res.statusCode !== 200) {
          res.resume();
          reject(new Error(`Catalogue inaccessible (${res.statusCode}).`));
          return;
        }
        let size = 0;
        const parts: Buffer[] = [];
        res.on("data", (c: Buffer) => {
          size += c.length;
          if (size > 3_000_000) {
            req.destroy(new Error("Catalogue trop volumineux."));
            return;
          }
          parts.push(c);
        });
        res.on("end", () => resolve(Buffer.concat(parts).toString("utf8")));
        res.on("error", reject);
      },
    );
    req.on("timeout", () => req.destroy(new Error("Délai dépassé.")));
    req.on("error", reject);
  });
}
export async function listPortals() {
  return (await getJSON<Portal[]>(STORE, "sites")) || defaults;
}
export async function savePortal(body: Record<string, unknown>) {
  const name = String(body.name || "")
    .trim()
    .slice(0, 60);
  const id = String(
    body.id ||
      name
        .toLowerCase()
        .normalize("NFD")
        .replace(/[\u0300-\u036f]/g, "")
        .replace(/[^a-z0-9]+/g, "-"),
  ).slice(0, 60);
  if (!name || !/^[a-z0-9][a-z0-9-]*$/.test(id))
    throw new Error("Nom et identifiant requis.");
  const hosts = [
    ...new Set(
      String(body.hosts || "")
        .split(/[\s,]+/)
        .filter(Boolean)
        .map(validHost),
    ),
  ];
  if (!hosts.length || hosts.length > 30)
    throw new Error("Indique de 1 à 30 hôtes.");
  const url = portalUrl(String(body.url || ""), hosts).href;
  const old = (await listPortals()).find((p) => p.id === id);
  const p: Portal = {
    id,
    name,
    url,
    hosts,
    enabled: body.enabled !== false,
    isolated: !!body.isolated,
    selector: String(
      body.selector || 'a[href*="/game/"],a[href*="/jeu/"]',
    ).slice(0, 300),
    games:
      old?.games.filter((g) => {
        try {
          portalUrl(g.url, hosts);
          return true;
        } catch {
          return false;
        }
      }) || [],
    indexedAt: old?.indexedAt,
  };
  await updateJSON<Portal[]>(STORE, "sites", (v) => [
    ...(v || defaults).filter((x) => x.id !== id),
    p,
  ]);
  return p;
}
export async function indexPortal(id: string, imported?: unknown) {
  const p = (await listPortals()).find((x) => x.id === id);
  if (!p) throw new Error("Portail inconnu.");
  let rows: { title: string; url: string; category?: string }[] = [];
  if (imported !== undefined) {
    if (!Array.isArray(imported) || imported.length > 5000)
      throw new Error("Import JSON : tableau de 5 000 jeux maximum.");
    rows = imported;
  } else {
    const $ = load(await safeText(new URL(p.url), p.hosts));
    if (!p.selector)
      throw new Error(
        "Configure un sélecteur de liens ou importe le catalogue JSON.",
      );
    $(p.selector).each((_i, el) => {
      const a = $(el);
      const raw = a.attr("href");
      const title =
        a.attr("title") || a.find("img").attr("alt") || a.text().trim();
      if (raw && title) rows.push({ title, url: new URL(raw, p.url).href });
    });
    if (!rows.length)
      throw new Error(
        "Aucun jeu trouvé : vérifie le sélecteur ou importe un catalogue JSON.",
      );
  }
  const seen = new Set<string>();
  const games: PortalGame[] = [];
  for (const row of rows) {
    if (!row || typeof row.title !== "string" || typeof row.url !== "string")
      throw new Error("Chaque jeu doit avoir title et url.");
    const u = portalUrl(new URL(row.url, p.url).href, p.hosts);
    u.hash = "";
    if (seen.has(u.href)) continue;
    seen.add(u.href);
    games.push({
      id: `portal:${id}:${createHash("sha256").update(u.href).digest("hex").slice(0, 16)}`,
      portalId: id,
      title: row.title.trim().slice(0, 100),
      url: u.href,
      category: String(row.category || "").slice(0, 40),
    });
  }
  p.games = games;
  p.indexedAt = Date.now();
  p.indexError = undefined;
  await updateJSON<Portal[]>(STORE, "sites", (v) =>
    (v || defaults).map((x) => (x.id === id ? p : x)),
  );
  return p;
}
export async function allGames() {
  return [
    ...catalog
      .filter((g) => g.playable && !["snokido", "gta-web"].includes(g.id))
      .map((g) => ({
        id: g.id,
        title: g.title,
        url: `/games/${g.id}`,
        portalId: "local",
        category: g.is3D ? "3D" : "Arcade",
      })),
    ...(await listPortals()).filter((p) => p.enabled).flatMap((p) => p.games),
  ];
}
export async function library(username: string) {
  const d = (await getJSON<Library>(
    STORE,
    `library:${username.toLowerCase()}`,
  )) || { favorites: [], recent: [] };
  const u = await getUser(username);
  d.favorites = [...new Set([...(u?.favorites || []), ...d.favorites])];
  return d;
}
export async function libraryAction(
  username: string,
  id: string,
  action: string,
) {
  return serial(`library:${username.toLowerCase()}`, async () =>
    libraryActionUnlocked(username, id, action),
  );
}
async function libraryActionUnlocked(
  username: string,
  id: string,
  action: string,
) {
  if (!(await allGames()).some((g) => g.id === id))
    throw new Error("Jeu inconnu.");
  if (!["favorite", "recent"].includes(action))
    throw new Error("Action inconnue.");
  const current = await library(username);
  const result = await updateJSON<Library>(
    STORE,
    `library:${username.toLowerCase()}`,
    (v) => {
      const d = v || current;
      d.favorites = [...new Set([...d.favorites, ...current.favorites])];
      if (action === "favorite")
        d.favorites = d.favorites.includes(id)
          ? d.favorites.filter((x) => x !== id)
          : [...d.favorites, id].slice(-500);
      else
        d.recent = [
          { id, at: Date.now() },
          ...d.recent.filter((x) => x.id !== id),
        ].slice(0, 50);
      return d;
    },
  );
  if (result && action === "favorite" && !id.startsWith("portal:")) {
    const u = await getUser(username);
    if (u) {
      u.favorites = result.favorites.filter((x) => !x.startsWith("portal:"));
      await saveUser(u);
    }
  }
  return result;
}
