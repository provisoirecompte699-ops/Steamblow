import { onNetlify } from "./runtime";
import { promises as fs } from "node:fs";
import path from "node:path";
import { createHash, randomUUID } from "node:crypto";
import { getStore } from "@netlify/blobs";

export type Credential = { passwordHash: string; changedAt: string; changedBy: string };
const key = (username: string) => createHash("sha256").update(username.toLowerCase()).digest("hex");
const directory = () => path.join(process.env.TCB_DATA_DIR || path.join(process.cwd(), "data"), "credentials");
const remote = () => getStore({ name: "steamblox-credentials", consistency: "strong" });
export async function readCredential(username: string): Promise<Credential | null> {
  let value: Credential | null;
  if (onNetlify()) value = await remote().get(key(username), { type: "json" }) as Credential | null;
  else {
    try { value = JSON.parse(await fs.readFile(path.join(directory(), key(username) + ".json"), "utf8")); }
    catch (error) { if ((error as NodeJS.ErrnoException).code === "ENOENT") return null; throw error; }
  }
  if (value && (typeof value.passwordHash !== "string" || !value.passwordHash || typeof value.changedAt !== "string")) throw new Error("Données d'authentification invalides.");
  return value;
}
export async function writeCredential(username: string, value: Credential) {
  if (onNetlify()) { await remote().setJSON(key(username), value); return; }
  await fs.mkdir(directory(), { recursive: true, mode: 0o700 });
  const file = path.join(directory(), key(username) + ".json");
  const temporary = file + "." + randomUUID() + ".tmp";
  try {
    await fs.writeFile(temporary, JSON.stringify(value), { mode: 0o600, flag: "wx" });
    await fs.rename(temporary, file);
  } finally { await fs.rm(temporary, { force: true }); }
}
