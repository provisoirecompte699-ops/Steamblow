export type NetPlayer = {
  id: string; name: string; x: number; y: number; vx?: number; vy?: number;
  rotation?: number; score?: number; ping?: number;
};

export class RealtimeClient {
  private ws: WebSocket | null = null;
  private retry = 0;
  private timer: ReturnType<typeof setTimeout> | null = null;
  private listeners = new Map<string, Set<(data:any)=>void>>();

  constructor(private url: string) {}

  on(event:string, fn:(data:any)=>void) {
    if (!this.listeners.has(event)) this.listeners.set(event,new Set());
    this.listeners.get(event)!.add(fn);
    return () => this.listeners.get(event)?.delete(fn);
  }

  private emit(event:string,data:any) {
    this.listeners.get(event)?.forEach(fn => fn(data));
  }

  connect(room:string, name:string) {
    const target = `${this.url.replace(/^http/,"ws")}/?room=${encodeURIComponent(room)}&name=${encodeURIComponent(name)}`;
    this.ws = new WebSocket(target);
    this.ws.onopen = () => { this.retry=0; this.emit("connected",{}); };
    this.ws.onmessage = e => {
      try { const msg=JSON.parse(e.data); this.emit(msg.type,msg.data); } catch {}
    };
    this.ws.onclose = () => {
      this.emit("disconnected",{});
      const delay=Math.min(8000,500*Math.pow(2,this.retry++));
      this.timer=setTimeout(()=>this.connect(room,name),delay);
    };
    this.ws.onerror = () => this.ws?.close();
  }

  send(type:string,data:any) {
    if (this.ws?.readyState===WebSocket.OPEN) this.ws.send(JSON.stringify({type,data}));
  }

  close() {
    if (this.timer) clearTimeout(this.timer);
    this.ws?.close();
    this.ws=null;
  }
}
