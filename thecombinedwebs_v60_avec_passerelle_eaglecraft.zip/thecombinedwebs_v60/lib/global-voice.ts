import { createHmac, timingSafeEqual } from "node:crypto";

// Service-to-service signing, independent from login sessions.
function secret() {
  const s = process.env.REALTIME_SECRET?.trim();
  if (!s) throw new Error("Signature temps réel indisponible : configure REALTIME_SECRET sur les deux services.");
  return s;
}

type VoicePayload = { u: string; s: boolean; t: number };

const sign = (body: string) => createHmac("sha256", secret()).update(body).digest("hex");

/** Le droit de parler (s) est signé dans le token : le client ne peut pas se l'attribuer. */
export function issueGlobalVoiceToken(username: string, canSpeak = false) {
  const body = Buffer.from(JSON.stringify({ u: username, s: canSpeak, t: Date.now() } satisfies VoicePayload)).toString("base64url");
  return `${body}.${sign(body)}`;
}

export function verifyGlobalVoiceToken(token: string, username: string) {
  try {
    const [body, sig] = String(token || "").split(".");
    if (!body || !sig) return null;
    const a = Buffer.from(sig), b = Buffer.from(sign(body));
    if (a.length !== b.length || !timingSafeEqual(a, b)) return null;
    const p = JSON.parse(Buffer.from(body, "base64url").toString("utf8")) as VoicePayload;
    const age = Date.now() - p.t;
    if (p.u !== username || !Number.isFinite(age) || age < 0 || age > 5 * 60 * 1000) return null;
    return { username: p.u, canSpeak: !!p.s };
  } catch {
    return null;
  }
}
