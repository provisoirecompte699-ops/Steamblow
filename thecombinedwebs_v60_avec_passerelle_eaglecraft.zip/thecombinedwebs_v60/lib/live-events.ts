import { onNetlify } from "./runtime";
import { getJSON, setJSON, listJSON } from "./data-store";
import { serial, singleWriter } from "./feature-lock";
import { credit } from "./bobux";
import { randomUUID, randomBytes, createHmac } from "node:crypto";
export type LiveEvent = {
  id: string;
  type: "golden" | "treasure" | "boss";
  title: string;
  startsAt: number;
  endsAt: number;
  author: string;
  reward: number;
  page?: string;
  spot?: number;
  winner?: string;
  hp?: number;
  maxHp?: number;
  damage?: Record<string, number>;
  attacks?: Record<string, number>;
  paid?: boolean;
  secret?: string;
};
const STORE = "tcb-live-events";
export async function liveEvents() {
  return serial("events", async () => {
    const events = await listJSON<LiveEvent>(STORE, "event:");
    if (
      !onNetlify() ||
      process.env.TCB_SINGLE_WRITER === "true"
    )
      for (const e of events)
        if (e.winner && !e.paid) {
          await credit(
            e.winner,
            e.reward,
            e.type === "boss" ? "Boss" : "Trésor",
            `Récompense : ${e.title}`,
            "quest",
            `event:${e.id}:prize`,
          );
          e.paid = true;
          await setJSON(STORE, `event:${e.id}`, e);
        }
    return events
      .filter((e) => e.endsAt > Date.now())
      .sort((a, b) => b.startsAt - a.startsAt);
  });
}
export async function goldenMultiplier() {
  return (await listJSON<LiveEvent>(STORE, "event:")).some(
    (e) => e.type === "golden" && e.endsAt > Date.now(),
  )
    ? 2
    : 1;
}
export async function startEvent(author: string, b: Record<string, unknown>) {
  singleWriter();
  return serial("events", async () => {
    const type = String(b.type);
    if (!["golden", "treasure", "boss"].includes(type))
      throw new Error("Événement inconnu.");
    if (
      (await listJSON<LiveEvent>(STORE, "event:")).some(
        (e) => e.type === type && e.endsAt > Date.now(),
      )
    )
      throw new Error("Cet événement est déjà actif.");
    const minutes = Number(b.minutes ?? 30),
      reward = Number(b.reward ?? 500),
      hp = Number(b.hp ?? 10000);
    if (
      !Number.isInteger(minutes) ||
      minutes < 1 ||
      minutes > 1440 ||
      !Number.isInteger(reward) ||
      reward < 1 ||
      reward > 100000 ||
      !Number.isInteger(hp) ||
      hp < 100 ||
      hp > 1000000
    )
      throw new Error("Paramètres hors limites.");
    const page = String(b.page || "/portails");
    if (
      ![
        "/portails",
        "/steamblox",
        "/evenements",
        "/social",
        "/economie",
      ].includes(page)
    )
      throw new Error("Page de chasse invalide.");
    const e: LiveEvent = {
      id: randomUUID(),
      type: type as LiveEvent["type"],
      title: String(
        b.title ||
          (
            {
              golden: "Heure dorée",
              treasure: "Chasse au trésor",
              boss: "Boss du serveur",
            } as Record<string, string>
          )[type],
      ).slice(0, 80),
      startsAt: Date.now(),
      endsAt: Date.now() + minutes * 60000,
      author,
      secret: randomBytes(32).toString("hex"),
      reward,
      ...(type === "boss" ? { hp, maxHp: hp, damage: {}, attacks: {} } : {}),
      ...(type === "treasure"
        ? { page, spot: Math.floor(Math.random() * 4) }
        : {}),
    };
    await setJSON(STORE, `event:${e.id}`, e);
    return e;
  });
}
export async function eventAction(
  username: string,
  id: string,
  action: string,
  token?: string,
) {
  singleWriter();
  return serial("events", async () => {
    const e = await getJSON<LiveEvent>(STORE, `event:${id}`);
    if (!e || e.endsAt <= Date.now()) throw new Error("Événement terminé.");
    if (action === "find") {
      if (
        e.type !== "treasure" ||
        !e.secret ||
        e.winner ||
        token !== treasureToken(e, username)
      )
        throw new Error("Trésor introuvable ou déjà remporté.");
      e.winner = username;
      await setJSON(STORE, `event:${id}`, e);
      await credit(
        username,
        e.reward,
        "Trésor",
        `Premier au trésor : ${e.title}`,
        "quest",
        `event:${e.id}:prize`,
      );
      e.paid = true;
      await setJSON(STORE, `event:${id}`, e);
    } else if (action === "attack") {
      if (e.type !== "boss" || !e.hp)
        throw new Error("Le boss est déjà vaincu.");
      const u = username.toLowerCase(),
        now = Date.now();
      if (now - (e.attacks?.[u] || 0) < 800)
        throw new Error("Attends avant la prochaine attaque.");
      const damage = Math.min(25, e.hp);
      e.hp -= damage;
      e.attacks ||= {};
      e.damage ||= {};
      e.attacks[u] = now;
      e.damage[u] = (e.damage[u] || 0) + damage;
      // Only the finishing player gets the jackpot; all attacks are server-computed.
      if (!e.hp) e.winner = username;
      await setJSON(STORE, `event:${id}`, e);
      if (e.winner && !e.paid) {
        await credit(
          username,
          e.reward,
          "Boss",
          `Coup final : ${e.title}`,
          "quest",
          `event:${e.id}:prize`,
        );
        e.paid = true;
        await setJSON(STORE, `event:${id}`, e);
      }
    } else throw new Error("Action inconnue.");
    return e;
  });
}
export function treasureToken(e: LiveEvent, username: string) {
  if (!e.secret) return "";
  return createHmac(
    "sha256",
    e.secret,
  )
    .update(`${e.id}:${username.toLowerCase()}:${e.page}`)
    .digest("hex");
}
export function publicEvent(e: LiveEvent) {
  const { page, spot, attacks, secret, ...v } = e;
  return v;
}
