import {cookies,headers} from "next/headers";
import {getUser} from "./store";
import {newSession,readSession,revokeSession,credentialVersion,sessionMatchesCredential} from "./session-store";

export async function createSession(username:string,verifiedPasswordHash?:string){
  const user=await getUser(username);
  if(!user)throw new Error("Compte introuvable.");
  if(verifiedPasswordHash&&verifiedPasswordHash!==user.passwordHash)throw new Error("Le mot de passe a changé. Reconnecte-toi.");
  const t=await newSession(username,credentialVersion(user.passwordHash));
  (await cookies()).set("steamblox_session",t,{httpOnly:true,sameSite:"lax",secure:process.env.NODE_ENV==="production",path:"/",maxAge:604800});
  return t;
}

export async function sessionUser(){
  const bearer=(await headers()).get("authorization")?.match(/^Bearer (.+)$/)?.[1];
  const t=bearer||(await cookies()).get("steamblox_session")?.value;
  if(!t)return null;
  try{
    const session=await readSession(t);
    if(!session)return null;
    const user=await getUser(session.username);
    return user&&sessionMatchesCredential(session,user) ? user : null;
  }catch{
    // An invalid or unavailable session must not crash a normal page visit.
    return null;
  }
}

export async function currentUser(){const u=await sessionUser();if(!u||u.banned)return null;return u}
export async function clearSession(){
  const jar=await cookies();
  const token=jar.get("steamblox_session")?.value;
  const h=await headers();
  const bearer=h.get("authorization")?.match(/^Bearer (.+)$/i)?.[1];
  for(const value of new Set([token,bearer].filter((v):v is string=>!!v)))await revokeSession(value);
  jar.delete("steamblox_session");
}
