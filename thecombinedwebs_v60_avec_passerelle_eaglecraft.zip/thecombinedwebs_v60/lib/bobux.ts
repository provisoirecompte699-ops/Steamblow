import { getJSON, listJSON, setJSON } from "./data-store";
import { getUser, saveUser, BOBUX_MAX } from "./store";
import { goldenMultiplier } from "./live-events";
import { serial } from "./feature-lock";
import { createHash } from "node:crypto";
export type BobuxLedger = {
  id: string;
  to: string;
  from: string;
  amount: number;
  kind: "daily" | "quest" | "gift" | "spend" | "bank";
  reason: string;
  createdAt: string;
};
export async function balance(username: string) {
  return (await getUser(username))?.bobux ?? 0;
}
export async function credit(
  to: string,
  amount: number,
  from: string,
  reason: string,
  kind: BobuxLedger["kind"],
  operationId?: string,
) {
  if (!Number.isInteger(amount) || amount <= 0)
    throw new Error("Montant invalide");
  const multiplier =
    kind === "daily" || kind === "quest" ? await goldenMultiplier() : 1;
  return serial(`wallet:${to.toLowerCase()}`, async () => {
    const u = await getUser(to);
    if (!u || u.banned) throw new Error("Utilisateur invalide");
    const id = operationId
      ? `bobux_${createHash("sha256").update(operationId).digest("hex")}`
      : `bobux_${crypto.randomUUID()}`;
    const receipt = u.bobuxReceipts?.[id];
    if (receipt) {
      const e: BobuxLedger = {
        id,
        to,
        from,
        amount: receipt.amount,
        kind,
        reason,
        createdAt: receipt.at,
      };
      await setJSON("steamblox-bobux", `ledger:${id}`, e);
      return e;
    }
    const before = u.bobux ?? 0;
    u.bobux = Math.min(BOBUX_MAX, before + amount * multiplier);
    const at = new Date().toISOString();
    if (operationId) {
      u.bobuxReceipts ||= {};
      u.bobuxReceipts[id] = { amount: u.bobux - before, at };
    }
    await saveUser(u, { balanceWrite: true });
    const e: BobuxLedger = {
      id,
      to,
      from,
      amount: u.bobux - before,
      kind,
      reason: reason + (multiplier === 2 ? " (Heure dorée ×2)" : ""),
      createdAt: at,
    };
    await setJSON("steamblox-bobux", `ledger:${e.id}`, e);
    return e;
  });
}
export async function spend(
  username: string,
  amount: number,
  reason: string,
  operationId?: string,
) {
  if (!Number.isInteger(amount) || amount <= 0)
    throw new Error("Montant invalide");
  return serial(`wallet:${username.toLowerCase()}`, async () => {
    const u = await getUser(username);
    if (!u || u.banned) throw new Error("Utilisateur invalide");
    const id = operationId
      ? `bobux_${createHash("sha256").update(operationId).digest("hex")}`
      : `bobux_${crypto.randomUUID()}`;
    const receipt = u.bobuxReceipts?.[id];
    if (receipt) {
      const e: BobuxLedger = {
        id,
        to: username,
        from: username,
        amount: receipt.amount,
        kind: "spend",
        reason,
        createdAt: receipt.at,
      };
      await setJSON("steamblox-bobux", `ledger:${id}`, e);
      return e;
    }
    if ((u.bobux ?? 0) < amount) throw new Error("Solde Bobux insuffisant");
    u.bobux = (u.bobux ?? 0) - amount;
    const at = new Date().toISOString();
    if (operationId) {
      u.bobuxReceipts ||= {};
      u.bobuxReceipts[id] = { amount: -amount, at };
    }
    await saveUser(u, { balanceWrite: true });
    const e: BobuxLedger = {
      id,
      to: username,
      from: username,
      amount: -amount,
      kind: "spend",
      reason,
      createdAt: at,
    };
    await setJSON("steamblox-bobux", `ledger:${e.id}`, e);
    return e;
  });
}
export async function ledgerFor(username: string) {
  const out = await listJSON<BobuxLedger>("steamblox-bobux", "ledger:");
  return out
    .filter((e) => e.to.toLowerCase() === username.toLowerCase())
    .sort((a, b) => b.createdAt.localeCompare(a.createdAt))
    .slice(0, 100);
}
