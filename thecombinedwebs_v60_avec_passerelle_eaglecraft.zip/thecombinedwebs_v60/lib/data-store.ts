import { onNetlify } from "./runtime";
import {getStore} from "@netlify/blobs";
import {serial} from "./feature-lock";
import {promises as fs} from "node:fs";import path from "node:path";
const BASE=process.env.TCB_DATA_DIR||path.join(process.cwd(),"data");
const useFile=!onNetlify();
function remote(name:string){try{return getStore({name,consistency:"strong"})}catch{return null}}
async function read(name:string):Promise<Record<string,any>>{if(!useFile)return {};try{return JSON.parse(await fs.readFile(path.join(BASE,`${name}.json`),"utf8"))}catch{return {}}}
async function write(name:string,data:Record<string,any>){if(!useFile)return;await fs.mkdir(BASE,{recursive:true});const p=path.join(BASE,`${name}.json`),tmp=p+".tmp";await fs.writeFile(tmp,JSON.stringify(data,null,2),"utf8");await fs.rename(tmp,p)}
// Verrou par fichier : évite de perdre des écritures quand plusieurs requêtes écrivent en même temps.
const locks=new Map<string,Promise<unknown>>();
function locked<T>(name:string,fn:()=>Promise<T>):Promise<T>{return serial(`file:${name}`,fn)}
export async function delJSON(name:string,key:string){const s=remote(name);if(s){try{await s.delete(key);return}catch{}}return locked(name,async()=>{const d=await read(name);if(key in d){delete d[key];await write(name,d)}})}
/** Lecture-modification-écriture atomique (en local) d'une clé. */
export async function updateJSON<T>(name:string,key:string,fn:(v:T|null)=>T|null):Promise<T|null>{const s=remote(name);if(s){let cur:T|null=null;try{cur=await s.get(key,{type:"json"}) as T|null}catch{}const v=fn(cur);if(v===null){try{await s.delete(key)}catch{}}else{try{await s.setJSON(key,v)}catch{}}return v}return locked(name,async()=>{const d=await read(name);const v=fn((d[key]??null) as T|null);if(v===null)delete d[key];else d[key]=v;await write(name,d);return v})}
export async function getJSON<T>(name:string,key:string){const s=remote(name);if(s){try{return await s.get(key,{type:"json"}) as T|null}catch{}}const d=await read(name);return (d[key]??null) as T|null}
export async function setJSON<T>(name:string,key:string,value:T){const s=remote(name);if(s){try{await s.setJSON(key,value);return}catch{}}return locked(name,async()=>{const d=await read(name);d[key]=value;await write(name,d)})}
export async function listJSON<T>(name:string,prefix:string){const s=remote(name);if(s){try{const {blobs}=await s.list({prefix});const out:T[]=[];for(const b of blobs){const v=await s.get(b.key,{type:"json"}) as T|null;if(v)out.push(v)}return out}catch{}}const d=await read(name);return Object.entries(d).filter(([k])=>k.startsWith(prefix)).map(([,v])=>v as T)}
