import { createHmac } from "node:crypto";

// Même secret de service que le serveur proxy. Ticket stable 7 à 14 jours : l'URL ne change pas
// d'une visite à l'autre, donc le cache du navigateur garde les gros fichiers de jeu.
const secret = () => {
  const value = process.env.PROXY_SECRET?.trim();
  if (!value) throw new Error("Signature proxy indisponible : configure PROXY_SECRET sur les deux services.");
  return value;
};
export function issueProxyTicket(username: string, hosts?: string[]) {
  const body = Buffer.from(JSON.stringify(hosts ? { u: username, hosts, exp: Date.now() + 15 * 60_000 } : { u: username, b: Math.floor(Date.now() / (7 * 864e5)) })).toString("base64url");
  return `${body}.${createHmac("sha256", secret()).update(body).digest("hex")}`;
}
export const PROXY_SITES = {
  gta: { host: "gta.deloskiyt.pl", path: "/", game: "gta-web", isolated: true },
  snokido: { host: "snokido.fr", path: "/", game: "snokido", isolated: false },
} as const;
export type ProxySite = keyof typeof PROXY_SITES;
