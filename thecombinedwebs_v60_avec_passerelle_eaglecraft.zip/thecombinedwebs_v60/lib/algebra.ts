// Moteur d'algèbre d'Algèbre Facile : calcul exact en fractions, analyse d'expressions
// (développement, réduction), résolution détaillée des équations du 1er et du 2nd degré
// et des systèmes 2×2, génération d'exercices.

/* ------------------------------------------------------------------ */
/* Fractions exactes                                                   */
/* ------------------------------------------------------------------ */
function gcd(a: number, b: number): number { a = Math.abs(a); b = Math.abs(b); while (b) { [a, b] = [b, a % b]; } return a || 1; }

export class Frac {
  readonly n: number; readonly d: number;
  constructor(n: number, d = 1) {
    if (d === 0) throw new AlgebraError("Division par zéro.");
    if (!Number.isFinite(n) || !Number.isFinite(d)) throw new AlgebraError("Nombre trop grand.");
    if (!Number.isInteger(n) || !Number.isInteger(d)) { const f = Frac.fromDecimal(n / d); n = f.n; d = f.d; }
    const g = gcd(n, d); const s = d < 0 ? -1 : 1;
    this.n = (s * n) / g; this.d = (s * d) / g;
    if (Math.abs(this.n) > 1e12 || this.d > 1e12) throw new AlgebraError("Nombres trop grands pour un calcul exact.");
  }
  static of(v: number | Frac) { return v instanceof Frac ? v : new Frac(v); }
  static fromDecimal(x: number) {
    if (Number.isInteger(x)) return new Frac(x);
    const s = String(x); if (s.includes("e")) throw new AlgebraError("Nombre trop petit ou trop grand.");
    const dec = (s.split(".")[1] || "").length; const d = 10 ** Math.min(dec, 9);
    return new Frac(Math.round(x * d), d);
  }
  static parse(raw: string): Frac {
    const t = raw.trim().replace(/\s+/g, "").replace(/,/g, ".").replace(/[−–]/g, "-");
    if (!t) throw new AlgebraError("Valeur vide.");
    const m = t.match(/^([+-]?\d+(?:\.\d+)?)(?:\/([+-]?\d+(?:\.\d+)?))?$/);
    if (!m) throw new AlgebraError(`« ${raw} » n'est pas un nombre (exemples : 3 ; -2,5 ; 7/4).`);
    const a = Frac.fromDecimal(parseFloat(m[1]));
    return m[2] ? a.div(Frac.fromDecimal(parseFloat(m[2]))) : a;
  }
  add(o: Frac | number) { const b = Frac.of(o); return new Frac(this.n * b.d + b.n * this.d, this.d * b.d); }
  sub(o: Frac | number) { const b = Frac.of(o); return new Frac(this.n * b.d - b.n * this.d, this.d * b.d); }
  mul(o: Frac | number) { const b = Frac.of(o); return new Frac(this.n * b.n, this.d * b.d); }
  div(o: Frac | number) { const b = Frac.of(o); if (b.n === 0) throw new AlgebraError("Division par zéro."); return new Frac(this.n * b.d, this.d * b.n); }
  neg() { return new Frac(-this.n, this.d); }
  isZero() { return this.n === 0; }
  isOne() { return this.n === 1 && this.d === 1; }
  isInt() { return this.d === 1; }
  sign() { return Math.sign(this.n); }
  eq(o: Frac | number) { const b = Frac.of(o); return this.n === b.n && this.d === b.d; }
  value() { return this.n / this.d; }
  toString() { const t = this.d === 1 ? String(Math.abs(this.n)) : `${Math.abs(this.n)}/${this.d}`; return this.n < 0 ? `−${t}` : t; }
  /** Écriture avec parenthèses si négatif (pour les substitutions). */
  paren() { return this.n < 0 || this.d !== 1 ? `(${this.toString()})` : this.toString(); }
  /** Valeur approchée lisible en français. */
  approx(digits = 4) { return this.d === 1 ? String(this.n) : fmtDec(this.value(), digits); }
}

export class AlgebraError extends Error {}

export function fmtDec(x: number, digits = 4) {
  return Number(x.toFixed(digits)).toString().replace(".", ",").replace("-", "−");
}

/* ------------------------------------------------------------------ */
/* Polynômes de degré ≤ 2 en x                                          */
/* ------------------------------------------------------------------ */
export type Poly = Frac[]; // [c0, c1, c2]
const Z = () => new Frac(0);
function poly(c0: Frac | number = 0, c1: Frac | number = 0, c2: Frac | number = 0): Poly { return [Frac.of(c0), Frac.of(c1), Frac.of(c2)]; }
function padd(a: Poly, b: Poly): Poly { return [0, 1, 2].map(i => (a[i] || Z()).add(b[i] || Z())); }
function pneg(a: Poly): Poly { return a.map(c => c.neg()); }
function psub(a: Poly, b: Poly) { return padd(a, pneg(b)); }
function pdeg(a: Poly) { return !a[2].isZero() ? 2 : !a[1].isZero() ? 1 : 0; }
function pmul(a: Poly, b: Poly): Poly {
  const r = [Z(), Z(), Z(), Z(), Z()];
  for (let i = 0; i < 3; i++) for (let j = 0; j < 3; j++) r[i + j] = r[i + j].add(a[i].mul(b[j]));
  if (!r[3].isZero() || !r[4].isZero()) throw new AlgebraError("Degré supérieur à 2 : Algèbre Facile traite les expressions jusqu'au second degré.");
  return [r[0], r[1], r[2]];
}
/** Forme factorisée a(x − r₁)(x − r₂) avec racines rationnelles, en absorbant les dénominateurs. */
export function factorText(a: Frac, r1: Frac, r2: Frac) {
  if (r1.eq(r2)) { const lead = a.div(r1.d * r1.d); return `${lead.isOne() ? "" : lead.eq(-1) ? "−" : lead.toString()}(${pformat(poly(-r1.n, r1.d))})²`; }
  const lead = a.div(r1.d * r2.d);
  const f = (r: Frac) => `(${pformat(poly(-r.n, r.d))})`;
  return `${lead.isOne() ? "" : lead.eq(-1) ? "−" : lead.toString()}${f(r1)}${f(r2)}`;
}
export function pevaluate(a: Poly, x: Frac) { return a[0].add(a[1].mul(x)).add(a[2].mul(x).mul(x)); }

/** Mise en forme : 3x² − 2x + 1/2 */
export function pformat(a: Poly, v = "x"): string {
  const parts: string[] = [];
  for (const i of [2, 1, 0]) {
    const c = a[i]; if (c.isZero()) continue;
    const abs = c.sign() < 0 ? c.neg() : c;
    const lit = i === 2 ? `${v}²` : i === 1 ? v : "";
    const body = lit && abs.isOne() ? lit : abs.d === 1 ? `${abs.n}${lit}` : lit ? `${abs.n === 1 ? "" : abs.n}${lit}/${abs.d}` : abs.toString();
    parts.push(parts.length === 0 ? (c.sign() < 0 ? `−${body}` : body) : `${c.sign() < 0 ? "−" : "+"} ${body}`);
  }
  return parts.length ? parts.join(" ") : "0";
}

/* ------------------------------------------------------------------ */
/* Analyse syntaxique                                                  */
/* ------------------------------------------------------------------ */
type Tok = { t: "num"; v: Frac } | { t: "x" } | { t: "op"; v: string } | { t: "(" } | { t: ")" } | { t: "^"; };

function normalize(s: string) {
  return s.replace(/[−–]/g, "-").replace(/[×·*]/g, "*").replace(/÷|:/g, "/").replace(/²/g, "^2").replace(/,/g, ".").replace(/\s+/g, "").toLowerCase();
}

function tokenize(src: string): Tok[] {
  const s = normalize(src); const out: Tok[] = []; let i = 0;
  while (i < s.length) {
    const ch = s[i];
    if (/[0-9.]/.test(ch)) { let j = i; while (j < s.length && /[0-9.]/.test(s[j])) j++; const lit = s.slice(i, j); if ((lit.match(/\./g) || []).length > 1) throw new AlgebraError(`Nombre mal écrit : « ${lit} ».`); out.push({ t: "num", v: Frac.fromDecimal(parseFloat(lit)) }); i = j; continue; }
    if (ch === "x") { out.push({ t: "x" }); i++; continue; }
    if ("+-*/".includes(ch)) { out.push({ t: "op", v: ch }); i++; continue; }
    if (ch === "(" || ch === "[") { out.push({ t: "(" }); i++; continue; }
    if (ch === ")" || ch === "]") { out.push({ t: ")" }); i++; continue; }
    if (ch === "^") { out.push({ t: "^" }); i++; continue; }
    throw new AlgebraError(`Caractère non reconnu : « ${ch} ». Utilise x comme inconnue.`);
  }
  return out;
}

class Parser {
  private i = 0; usedParens = false;
  constructor(private toks: Tok[]) {}
  private peek() { return this.toks[this.i]; }
  private next() { return this.toks[this.i++]; }
  parse(): Poly { if (!this.toks.length) throw new AlgebraError("Expression vide."); const p = this.expr(); if (this.i < this.toks.length) throw new AlgebraError("Expression incomplète ou parenthèse en trop."); return p; }
  private expr(): Poly {
    let p = this.term();
    for (let k = this.peek(); k && k.t === "op" && (k.v === "+" || k.v === "-"); k = this.peek()) { this.next(); const q = this.term(); p = k.v === "+" ? padd(p, q) : psub(p, q); }
    return p;
  }
  private startsFactor(k?: Tok) { return !!k && (k.t === "num" || k.t === "x" || k.t === "("); }
  private term(): Poly {
    let p = this.unary();
    for (;;) {
      const k = this.peek();
      if (k && k.t === "op" && (k.v === "*" || k.v === "/")) {
        this.next(); const q = this.unary();
        if (k.v === "*") p = pmul(p, q);
        else { if (pdeg(q) > 0) throw new AlgebraError("Division par une expression contenant x : non prise en charge."); if (q[0].isZero()) throw new AlgebraError("Division par zéro."); p = p.map(c => c.div(q[0])); }
      } else if (this.startsFactor(k)) { p = pmul(p, this.power()); } // multiplication implicite : 2x, 3(x+1), (x+1)(x-2)
      else return p;
    }
  }
  private unary(): Poly { const k = this.peek(); if (k && k.t === "op" && (k.v === "-" || k.v === "+")) { this.next(); const p = this.unary(); return k.v === "-" ? pneg(p) : p; } return this.power(); }
  private power(): Poly {
    const base = this.primary();
    if (this.peek()?.t === "^") { this.next(); const e = this.next(); if (!e || e.t !== "num" || !e.v.isInt() || e.v.n < 0 || e.v.n > 2) throw new AlgebraError("Exposant accepté : 0, 1 ou 2."); return e.v.n === 0 ? poly(1) : e.v.n === 1 ? base : pmul(base, base); }
    return base;
  }
  private primary(): Poly {
    const k = this.next();
    if (!k) throw new AlgebraError("Expression incomplète.");
    if (k.t === "num") return poly(k.v);
    if (k.t === "x") return poly(0, 1);
    if (k.t === "(") { this.usedParens = true; const p = this.expr(); if (this.next()?.t !== ")") throw new AlgebraError("Parenthèse non fermée."); return p; }
    throw new AlgebraError("Expression mal formée.");
  }
}

export function parseExpr(src: string) { const p = new Parser(tokenize(src)); const r = p.parse(); return { poly: r, usedParens: p.usedParens }; }

/* ------------------------------------------------------------------ */
/* Résolution détaillée                                                */
/* ------------------------------------------------------------------ */
export type Step = { title: string; math: string; note?: string };
export type Solution = { steps: Step[]; solutions: Frac[] | "all" | "none"; summary: string; exactText?: string[] };

function sqrtFrac(f: Frac): Frac | null { if (f.sign() < 0) return null; const a = Math.round(Math.sqrt(f.n)), b = Math.round(Math.sqrt(f.d)); return a * a === f.n && b * b === f.d ? new Frac(a, b) : null; }
/** √n = k√m */
function simplifySqrt(n: number) { let k = 1, m = n; for (let p = 2; p * p <= m; p++) while (m % (p * p) === 0) { m /= p * p; k *= p; } return { k, m }; }

const canon = (s: string) => s.replace(/\s/g, "").replace(/[-–]/g, "−").replace(/\^2/g, "²").replace(/\*/g, "").replace(/,/g, ".").toLowerCase();
export function solveEquation(src: string): Solution {
  const clean = src.replace(/≠/g, "");
  const sides = clean.split("=");
  if (sides.length !== 2 || !sides[0].trim() || !sides[1].trim()) throw new AlgebraError("Écris une équation avec un seul signe « = », par exemple 3(x − 2) + 5 = 2x + 7.");
  const L = parseExpr(sides[0]), R = parseExpr(sides[1]);
  const steps: Step[] = [{ title: "Équation de départ", math: `${sides[0].trim()} = ${sides[1].trim()}` }];
  const reduced = `${pformat(L.poly)} = ${pformat(R.poly)}`;
  if (L.usedParens || R.usedParens) steps.push({ title: "Développer et réduire chaque membre", math: reduced, note: "On applique la distributivité k(a + b) = ka + kb, puis on regroupe les termes semblables." });
  else if (canon(reduced) !== canon(`${sides[0]}=${sides[1]}`)) steps.push({ title: "Réduire chaque membre", math: reduced });

  const diff = psub(L.poly, R.poly);
  const deg = pdeg(diff);
  if (deg === 2) return solveQuadraticPoly(diff, steps);

  const a = L.poly[1].sub(R.poly[1]); const b = R.poly[0].sub(L.poly[0]);
  if (!R.poly[1].isZero() || !L.poly[0].isZero()) {
    const moves: string[] = [];
    if (!R.poly[1].isZero()) moves.push(`on ${R.poly[1].sign() > 0 ? "soustrait" : "ajoute"} ${pformat(poly(0, R.poly[1].sign() > 0 ? R.poly[1] : R.poly[1].neg()))} aux deux membres`);
    if (!L.poly[0].isZero()) moves.push(`on ${L.poly[0].sign() > 0 ? "soustrait" : "ajoute"} ${(L.poly[0].sign() > 0 ? L.poly[0] : L.poly[0].neg()).toString()} aux deux membres`);
    steps.push({ title: "Regrouper les x à gauche, les nombres à droite", math: `${pformat(poly(0, a))} = ${b.toString().replace("-", "−")}`, note: `Pour garder l'égalité vraie, ${moves.join(" et ")}.` });
  }
  if (a.isZero()) {
    if (b.isZero()) { steps.push({ title: "Conclusion", math: "0 = 0", note: "L'égalité est vraie pour toute valeur de x." }); return { steps, solutions: "all", summary: "Tous les nombres réels sont solutions." }; }
    steps.push({ title: "Conclusion", math: `0 = ${b.toString()}`, note: "Cette égalité est fausse, quelle que soit la valeur de x." });
    return { steps, solutions: "none", summary: "L'équation n'a aucune solution." };
  }
  const x = b.div(a);
  if (!a.isOne()) steps.push({ title: `Diviser les deux membres par ${a.toString()}`, math: `x = ${b.toString()} ÷ ${a.paren()} = ${x.toString().replace("-", "−")}`, note: x.isInt() ? undefined : `Valeur approchée : x ≈ ${x.approx()}` });
  const lv = pevaluate(L.poly, x), rv = pevaluate(R.poly, x);
  steps.push({ title: "Vérification", math: `Membre de gauche : ${lv.toString()}   ·   Membre de droite : ${rv.toString()}`, note: lv.eq(rv) ? "Les deux membres sont égaux : la solution est correcte. ✓" : "Écart détecté." });
  return { steps, solutions: [x], summary: `La solution est x = ${x.toString().replace("-", "−")}.` };
}

function solveQuadraticPoly(p: Poly, steps: Step[]): Solution {
  const [c, b, a] = p;
  const last = steps[steps.length - 1].math;
  if (canon(last) !== canon(`${pformat(p)} = 0`)) steps.push({ title: "Tout ramener dans le membre de gauche", math: `${pformat(p)} = 0` });
  steps.push({ title: "Identifier les coefficients", math: `a = ${a}   ·   b = ${b}   ·   c = ${c}`, note: "C'est une équation du second degré de la forme ax² + bx + c = 0." });
  if (c.isZero()) {
    const x2 = b.neg().div(a);
    steps.push({ title: "Factoriser par x", math: `x(${pformat(poly(b, a))}) = 0`, note: "Un produit est nul si et seulement si l'un de ses facteurs est nul." });
    steps.push({ title: "Équation produit nul", math: `x = 0   ou   ${pformat(poly(b, a))} = 0  ⇔  x = ${x2}` });
    const sols = [new Frac(0), x2].sort((u, v) => u.value() - v.value()).filter((v, i, arr) => i === 0 || !v.eq(arr[i - 1]));
    return { steps, solutions: sols, summary: `Solutions : ${sols.map(s => `x = ${s}`).join(" ; ")}.` };
  }
  const delta = b.mul(b).sub(new Frac(4).mul(a).mul(c));
  steps.push({ title: "Calculer le discriminant", math: `Δ = b² − 4ac = ${b.paren()}² − 4 × ${a.paren()} × ${c.paren()} = ${delta}` });
  if (delta.sign() < 0) { steps.push({ title: "Conclusion", math: "Δ < 0", note: "Un carré ne peut pas être négatif : pas de solution réelle." }); return { steps, solutions: "none", summary: "Aucune solution réelle (Δ < 0)." }; }
  if (delta.isZero()) {
    const x0 = b.neg().div(a.mul(2));
    steps.push({ title: "Δ = 0 : une solution double", math: `x₀ = −b / (2a) = ${b.neg()} / ${a.mul(2).paren()} = ${x0}` });
    steps.push({ title: "Forme factorisée", math: `${factorText(a, x0, x0)} = 0` });
    return { steps, solutions: [x0], summary: `Une solution double : x = ${x0}.` };
  }
  const r = sqrtFrac(delta);
  if (r) {
    const x1 = b.neg().sub(r).div(a.mul(2)), x2 = b.neg().add(r).div(a.mul(2));
    const [lo, hi] = x1.value() < x2.value() ? [x1, x2] : [x2, x1];
    steps.push({ title: "Δ > 0 : deux solutions", math: `√Δ = ${r}\nx₁ = (−b − √Δ) / (2a) = (${b.neg()} − ${r}) / ${a.mul(2).paren()} = ${x1}\nx₂ = (−b + √Δ) / (2a) = (${b.neg()} + ${r}) / ${a.mul(2).paren()} = ${x2}` });
    steps.push({ title: "Forme factorisée", math: `${factorText(a, lo, hi)} = 0` });
    steps.push({ title: "Vérification", math: `P(${lo}) = ${pevaluate(p, lo)}   ·   P(${hi}) = ${pevaluate(p, hi)}`, note: "Les deux valeurs annulent le polynôme. ✓" });
    return { steps, solutions: [lo, hi], summary: `Deux solutions : x = ${lo} ; x = ${hi}.` };
  }
  // Racines irrationnelles : forme exacte avec radical simplifié quand c'est possible
  const dv = delta.value(); const s = Math.sqrt(dv);
  const r1 = (-b.value() - s) / (2 * a.value()), r2 = (-b.value() + s) / (2 * a.value());
  const [lo, hi] = r1 < r2 ? [r1, r2] : [r2, r1];
  let exact: string[] | undefined;
  if (delta.isInt() && a.isInt() && b.isInt()) {
    const { k, m } = simplifySqrt(delta.n); const g = gcd(gcd(b.n, k), 2 * a.n) * (a.n < 0 ? -1 : 1);
    const B = -b.n / g, K = k / g, D = (2 * a.n) / g;
    const rad = `${K === 1 ? "" : K}√${m}`;
    const top = (sg: string) => `${B === 0 ? (sg === "−" ? "−" : "") : `${String(B).replace("-", "−")} ${sg} `}${rad}`;
    exact = D === 1 ? [top("−"), top("+")] : [`(${top("−")}) / ${D}`, `(${top("+")}) / ${D}`];
    steps.push({ title: "Δ > 0 : deux solutions", math: `√Δ = √${delta.n}${k > 1 ? ` = ${k}√${m}` : ""}\nx₁ = ${exact[0]} ≈ ${fmtDec(lo)}\nx₂ = ${exact[1]} ≈ ${fmtDec(hi)}`, note: "Valeurs exactes avec la racine simplifiée, puis valeurs approchées." });
  } else steps.push({ title: "Δ > 0 : deux solutions", math: `x₁ = (−b − √Δ) / (2a) ≈ ${fmtDec(lo)}\nx₂ = (−b + √Δ) / (2a) ≈ ${fmtDec(hi)}` });
  return { steps, solutions: [], summary: exact ? `Deux solutions : x = ${exact[0]} ; x = ${exact[1]}.` : `Deux solutions : x ≈ ${fmtDec(lo)} ; x ≈ ${fmtDec(hi)}.`, exactText: exact };
}

export function simplifyExpression(src: string) {
  const { poly: p, usedParens } = parseExpr(src);
  const steps: Step[] = [{ title: "Expression", math: src.trim() }];
  if (usedParens) steps.push({ title: "Développer", math: pformat(p), note: "Distributivité simple et double, puis réduction des termes semblables." });
  else steps.push({ title: "Réduire", math: pformat(p), note: "On additionne les termes de même degré." });
  if (pdeg(p) === 2) {
    const [c, b, a] = p; const delta = b.mul(b).sub(new Frac(4).mul(a).mul(c)); const r = sqrtFrac(delta);
    if (r && !c.isZero()) { const x1 = b.neg().sub(r).div(a.mul(2)), x2 = b.neg().add(r).div(a.mul(2)); steps.push({ title: "Forme factorisée", math: factorText(a, x1, x2) }); }
    else if (c.isZero()) steps.push({ title: "Forme factorisée", math: `x(${pformat(poly(b, a))})` });
  } else if (pdeg(p) === 1 && !p[0].isZero()) {
    const g = gcd(p[0].n * p[1].d, p[1].n * p[0].d); const den = p[0].d * p[1].d;
    const k = new Frac(g, den); if (!k.isOne() && p[0].isInt() && p[1].isInt() && g > 1) steps.push({ title: "Facteur commun", math: `${k}(${pformat(p.map(c => c.div(k)))})` });
  }
  return steps;
}

export function solveSystem(a1: Frac, b1: Frac, c1: Frac, a2: Frac, b2: Frac, c2: Frac): Solution {
  const eq = (a: Frac, b: Frac, c: Frac) => `${pformat(poly(0, a), "x")}${b.isZero() ? "" : ` ${b.sign() < 0 ? "−" : "+"} ${b.sign() < 0 ? (b.neg().isOne() ? "" : b.neg()) : (b.isOne() ? "" : b)}y`} = ${c}`;
  const steps: Step[] = [{ title: "Système", math: `{ ${eq(a1, b1, c1)}\n{ ${eq(a2, b2, c2)}` }];
  const det = a1.mul(b2).sub(a2.mul(b1));
  steps.push({ title: "Déterminant", math: `D = a₁b₂ − a₂b₁ = ${a1.paren()}×${b2.paren()} − ${a2.paren()}×${b1.paren()} = ${det}`, note: "Si D ≠ 0, le système a une unique solution." });
  if (det.isZero()) {
    const prop = a1.mul(c2).sub(a2.mul(c1)).isZero() && b1.mul(c2).sub(b2.mul(c1)).isZero();
    steps.push({ title: "Conclusion", math: "D = 0", note: prop ? "Les deux équations sont proportionnelles : infinité de solutions (droites confondues)." : "Les équations sont incompatibles : aucune solution (droites parallèles)." });
    return { steps, solutions: prop ? "all" : "none", summary: prop ? "Infinité de solutions." : "Aucune solution." };
  }
  const x = c1.mul(b2).sub(c2.mul(b1)).div(det), y = a1.mul(c2).sub(a2.mul(c1)).div(det);
  steps.push({ title: "Calcul de x", math: `x = (c₁b₂ − c₂b₁) / D = (${c1.paren()}×${b2.paren()} − ${c2.paren()}×${b1.paren()}) / ${det.paren()} = ${x}` });
  steps.push({ title: "Calcul de y", math: `y = (a₁c₂ − a₂c₁) / D = (${a1.paren()}×${c2.paren()} − ${a2.paren()}×${c1.paren()}) / ${det.paren()} = ${y}` });
  steps.push({ title: "Vérification", math: `${a1.paren()}×${x.paren()} + ${b1.paren()}×${y.paren()} = ${a1.mul(x).add(b1.mul(y))}\n${a2.paren()}×${x.paren()} + ${b2.paren()}×${y.paren()} = ${a2.mul(x).add(b2.mul(y))}`, note: "On retrouve bien c₁ et c₂. ✓" });
  return { steps, solutions: [x, y], summary: `Solution : (x ; y) = (${x} ; ${y}).` };
}

/* ------------------------------------------------------------------ */
/* Inéquations du premier degré                                        */
/* ------------------------------------------------------------------ */
export type IneqSolution = { steps: Step[]; interval: string; summary: string; varName: string };
export function solveInequality(src: string): IneqSolution {
  const ops = ["≤", "≥", "<", ">"];
  let op = "";
  for (const o of ops) { if (src.includes(o)) { op = o; break; } }
  if (!op) throw new AlgebraError("Écris une inéquation avec ≤, ≥, < ou >, par exemple 3x − 7 ≤ 5.");
  const [leftRaw, rightRaw] = src.split(op);
  if (!leftRaw?.trim() || !rightRaw?.trim()) throw new AlgebraError("Inéquation incomplète.");
  const L = parseExpr(leftRaw), R = parseExpr(rightRaw);
  const steps: Step[] = [{ title: "Inéquation de départ", math: `${leftRaw.trim()} ${op} ${rightRaw.trim()}` }];
  const reduced = `${pformat(L.poly)} ${op} ${pformat(R.poly)}`;
  if (L.usedParens || R.usedParens) steps.push({ title: "Développer et réduire chaque membre", math: reduced, note: "On applique la distributivité, puis on regroupe les termes semblables." });
  else if (canon(reduced) !== canon(`${leftRaw}${op}${rightRaw}`)) steps.push({ title: "Réduire chaque membre", math: reduced });
  const diff = psub(L.poly, R.poly);
  // Comme dans solveEquation : a = coefficient de x (gauche - droite), b = terme constant (droite - gauche)
  const a = L.poly[1].sub(R.poly[1]);
  const b = R.poly[0].sub(L.poly[0]);
  if (!R.poly[1].isZero() || !L.poly[0].isZero()) {
    const moves: string[] = [];
    if (!R.poly[1].isZero()) moves.push(`on ${R.poly[1].sign() > 0 ? "soustrait" : "ajoute"} ${pformat(poly(0, R.poly[1].sign() > 0 ? R.poly[1] : R.poly[1].neg()))} aux deux membres`);
    if (!L.poly[0].isZero()) moves.push(`on ${L.poly[0].sign() > 0 ? "soustrait" : "ajoute"} ${(L.poly[0].sign() > 0 ? L.poly[0] : L.poly[0].neg()).toString()} aux deux membres`);
    steps.push({ title: "Regrouper les x à gauche, les nombres à droite", math: `${pformat(poly(0, a))} ${op} ${b.toString().replace("-", "−")}`, note: `Pour garder l'inégalité vraie, ${moves.join(" et ")}.` });
  }
  if (a.isZero()) {
    if (b.isZero()) { steps.push({ title: "Conclusion", math: `0 ${op} 0`, note: op === "<" || op === ">" ? "L'inégalité est fausse pour tout x : aucune solution." : "L'inégalité est vraie pour tout x." }); return { steps, interval: op === "<" || op === ">" ? "∅" : "ℝ", summary: op === "<" || op === ">" ? "Aucune solution." : "Tous les nombres réels sont solutions.", varName: "x" }; }
    steps.push({ title: "Conclusion", math: `0 ${op} ${b.toString()}`, note: "Cette inégalité est soit toujours vraie, soit toujours fausse, quelle que soit la valeur de x." });
    const alwaysTrue = op === "≤" ? b.sign() >= 0 : op === "<" ? b.sign() > 0 : op === "≥" ? b.sign() <= 0 : b.sign() < 0;
    return { steps, interval: alwaysTrue ? "ℝ" : "∅", summary: alwaysTrue ? "Tous les nombres réels sont solutions." : "Aucune solution.", varName: "x" };
  }
  const x = b.div(a);
  let finalOp = op;
  if (a.sign() < 0) {
    const flipped: Record<string, string> = { "≤": "≥", "≥": "≤", "<": ">", ">": "<" };
    finalOp = flipped[op];
    steps.push({ title: "Diviser par un nombre négatif", math: `x ${finalOp} ${x.toString().replace("-", "−")}`, note: `On divise par ${a.toString()} qui est négatif : le sens de l'inégalité s'inverse (${op} devient ${finalOp}).` });
  } else if (!a.isOne()) {
    steps.push({ title: `Diviser les deux membres par ${a.toString()}`, math: `x ${finalOp} ${x.toString().replace("-", "−")}`, note: x.isInt() ? undefined : `Valeur approchée : x ≈ ${x.approx()}` });
  } else {
    steps.push({ title: "Conclusion", math: `x ${finalOp} ${x.toString().replace("-", "−")}` });
  }
  const lo = Math.min(x.value(), x.value()), hi = Math.max(x.value(), x.value());
  let interval: string;
  if (finalOp === "≤" || finalOp === "<") interval = finalOp === "≤" ? `]−∞ ; ${x.toString().replace("-", "−")}]` : `]−∞ ; ${x.toString().replace("-", "−")}[`;
  else interval = finalOp === "≥" ? `[${x.toString().replace("-", "−")} ; +∞[` : `]${x.toString().replace("-", "−")} ; +∞[`;
  steps.push({ title: "Ensemble des solutions", math: `S = ${interval}`, note: `Les solutions sont tous les nombres ${finalOp === "≤" || finalOp === "<" ? "inférieurs" : "supérieurs"} ${finalOp === "≤" || finalOp === "≥" ? "ou égaux" : "strictement"} à ${x.toString().replace("-", "−")}.` });
  return { steps, interval, summary: `S = ${interval}.`, varName: "x" };
}

/* ------------------------------------------------------------------ */
/* Étude de fonctions (affines et du second degré)                     */
/* ------------------------------------------------------------------ */
export type FuncStudy = { steps: Step[]; summary: string; type: "affine" | "quadratic"; canonical?: string; vertex?: string; axis?: string; signTable?: { rows: { label: string; cells: string[] }[]; cols: string[] } };
export function studyFunction(src: string): FuncStudy {
  const { poly: p, usedParens } = parseExpr(src);
  const steps: Step[] = [{ title: "Fonction", math: `f(x) = ${src.trim()}` }];
  if (usedParens) steps.push({ title: "Forme développée", math: `f(x) = ${pformat(p)}`, note: "On développe et réduit pour obtenir la forme standard." });
  else if (canon(pformat(p)) !== canon(src)) steps.push({ title: "Forme réduite", math: `f(x) = ${pformat(p)}` });
  const deg = pdeg(p);
  if (deg === 0) { const v = p[0]; steps.push({ title: "Fonction constante", math: `f(x) = ${v}`, note: v.isZero() ? "La fonction est nulle : son image est toujours 0." : `La fonction est constante : son image est toujours ${v}.` }); return { steps, summary: `Fonction constante : f(x) = ${v} pour tout x.`, type: "affine" }; }
  if (deg === 1) return studyAffine(p, steps);
  if (deg === 2) return studyQuadraticFunc(p, steps);
  throw new AlgebraError("Étude de fonction : degré 0, 1 ou 2 uniquement.");
}
function studyAffine(p: Poly, steps: Step[]): FuncStudy {
  const a = p[1], b = p[0];
  steps.push({ title: "Type de fonction", math: `f(x) = ${pformat(p)}`, note: `Fonction affine de coefficient directeur a = ${a} et d'ordonnée à l'origine b = ${b}.` });
  steps.push({ title: "Image d'une valeur", math: `f(k) = ${a} × k + ${b}`, note: "Pour calculer l'image d'un nombre k, on remplace x par k et on calcule." });
  if (!a.isZero()) {
    const root = b.neg().div(a);
    steps.push({ title: "Racine (antécédent de 0)", math: `${a}x + ${b} = 0  ⇔  x = ${root.toString().replace("-", "−")}`, note: root.isInt() ? undefined : `Valeur approchée : x ≈ ${root.approx()}` });
  }
  // Tableau de signes
  if (!a.isZero()) {
    const root = b.neg().div(a);
    const rootStr = root.toString().replace("-", "−");
    const leftSign = a.sign() > 0 ? "−" : "+";
    const rightSign = a.sign() > 0 ? "+" : "−";
    const cols = ["−∞", rootStr, "+∞"];
    const rows = [
      { label: "x", cells: ["", rootStr, ""] },
      { label: `f(x) = ${pformat(p)}`, cells: [leftSign, "0", rightSign] },
    ];
    steps.push({ title: "Tableau de signes", math: `${leftSign}        0        ${rightSign}\n     ${rootStr}`, note: a.sign() > 0 ? "Le coefficient directeur est positif : la fonction est croissante." : "Le coefficient directeur est négatif : la fonction est décroissante." });
    return { steps, summary: `Fonction affine : racine en x = ${rootStr}, ${a.sign() > 0 ? "croissante" : "décroissante"}.`, type: "affine", signTable: { cols, rows } };
  }
  return { steps, summary: `Fonction constante : f(x) = ${b} pour tout x.`, type: "affine" };
}
function studyQuadraticFunc(p: Poly, steps: Step[]): FuncStudy {
  const [c, b, a] = p;
  steps.push({ title: "Type de fonction", math: `f(x) = ${pformat(p)}`, note: `Fonction du second degré avec a = ${a}, b = ${b}, c = ${c}.` });
  // Forme canonique : f(x) = a(x − α)² + β
  const alpha = b.neg().div(a.mul(2));
  const beta = c.sub(b.mul(b).div(a.mul(4)));
  const absAlpha = alpha.sign() < 0 ? alpha.neg() : alpha;
  const absBeta = beta.sign() < 0 ? beta.neg() : beta;
  const canonStr = `${a.isOne() ? "" : a.eq(-1) ? "−" : a.toString()}(x ${alpha.sign() < 0 ? "+" : "−"} ${absAlpha.toString()})² ${beta.sign() < 0 ? "−" : "+"} ${absBeta.toString()}`;
  steps.push({ title: "Forme canonique", math: `f(x) = ${canonStr}`, note: `Le sommet de la parabole est S(${alpha.toString().replace("-", "−")} ; ${beta.toString().replace("-", "−")}).` });
  steps.push({ title: "Axe de symétrie", math: `x = ${alpha.toString().replace("-", "−")}`, note: "La parabole est symétrique par rapport à la droite verticale passant par le sommet." });
  // Sens de variation
  if (a.sign() > 0) steps.push({ title: "Variations", math: "Décroissante sur ]−∞ ; α], croissante sur [α ; +∞[", note: `a > 0 : la parabole est orientée vers le haut, le minimum est atteint au sommet.` });
  else steps.push({ title: "Variations", math: "Croissante sur ]−∞ ; α], décroissante sur [α ; +∞[", note: `a < 0 : la parabole est orientée vers le bas, le maximum est atteint au sommet.` });
  // Racines
  const delta = b.mul(b).sub(new Frac(4).mul(a).mul(c));
  let roots: Frac[] = [];
  if (delta.sign() < 0) { steps.push({ title: "Racines", math: `Δ = ${delta} < 0`, note: "Δ < 0 : la fonction ne s'annule pas, elle garde un signe constant." }); }
  else if (delta.isZero()) { const x0 = b.neg().div(a.mul(2)); roots = [x0]; steps.push({ title: "Racine double", math: `Δ = 0, x₀ = ${x0.toString().replace("-", "−")}` }); }
  else {
    const r = sqrtFrac(delta);
    if (r) { const x1 = b.neg().sub(r).div(a.mul(2)), x2 = b.neg().add(r).div(a.mul(2)); roots = x1.value() < x2.value() ? [x1, x2] : [x2, x1]; steps.push({ title: "Racines", math: `x₁ = ${roots[0].toString().replace("-", "−")} ; x₂ = ${roots[1].toString().replace("-", "−")}` }); }
    else { const dv = delta.value(); const s = Math.sqrt(dv); const r1 = (-b.value() - s) / (2 * a.value()), r2 = (-b.value() + s) / (2 * a.value()); const [lo, hi] = r1 < r2 ? [r1, r2] : [r2, r1]; steps.push({ title: "Racines (irrationnelles)", math: `x₁ ≈ ${fmtDec(lo)} ; x₂ ≈ ${fmtDec(hi)}` }); roots = [new Frac(Math.round(lo * 1e6), 1e6), new Frac(Math.round(hi * 1e6), 1e6)]; }
  }
  // Tableau de signes
  const aSign = a.sign() > 0 ? "+" : "−";
  const outerSign = aSign;
  const innerSign = aSign === "+" ? "−" : "+";
  if (roots.length === 0) { steps.push({ title: "Signe", math: `f(x) ${outerSign === "+" ? "> 0" : "< 0"} pour tout x ∈ ℝ`, note: `a ${aSign} 0 et Δ < 0 : la fonction est toujours ${outerSign === "+" ? "positive" : "négative"}.` }); }
  else if (roots.length === 1) { const r = roots[0].toString().replace("-", "−"); steps.push({ title: "Signe", math: `${outerSign}        0        ${outerSign}\n          ${r}`, note: `La fonction touche 0 en x = ${r} sans changer de signe.` }); }
  else { const r1 = roots[0].toString().replace("-", "−"), r2 = roots[1].toString().replace("-", "−"); steps.push({ title: "Signe", math: `${outerSign}   0   ${innerSign}   0   ${outerSign}\n     ${r1}         ${r2}`, note: `La fonction s'annule en ${r1} et ${r2} et change de signe entre les deux racines.` }); }
  return { steps, summary: `Fonction du second degré : sommet (${alpha.toString().replace("-", "−")} ; ${beta.toString().replace("-", "−")}), ${a.sign() > 0 ? "parabole vers le haut" : "parabole vers le bas"}.`, type: "quadratic", canonical: canonStr, vertex: `(${alpha.toString().replace("-", "−")} ; ${beta.toString().replace("-", "−")})`, axis: `x = ${alpha.toString().replace("-", "−")}` };
}

/* ------------------------------------------------------------------ */
/* Exercices                                                           */
/* ------------------------------------------------------------------ */
export type Level = 1 | 2 | 3 | 4 | 5 | 6 | 7;
export const LEVELS: { id: Level; label: string; hint: string }[] = [
  { id: 1, label: "Niveau 1 · ax + b = c", hint: "4e" },
  { id: 2, label: "Niveau 2 · x des deux côtés", hint: "4e – 3e" },
  { id: 3, label: "Niveau 3 · avec parenthèses", hint: "3e" },
  { id: 4, label: "Niveau 4 · second degré", hint: "1re" },
  { id: 5, label: "Niveau 5 · fractions & décimaux", hint: "4e – 3e" },
  { id: 6, label: "Niveau 6 · produit nul", hint: "3e – 2nde" },
  { id: 7, label: "Niveau 7 · problèmes concrets", hint: "3e – 2nde" },
];
const rnd = (a: number, b: number) => Math.floor(Math.random() * (b - a + 1)) + a;
const nz = (a: number, b: number) => { let v = 0; while (v === 0) v = rnd(a, b); return v; };
const sgn = (v: number) => (v < 0 ? `− ${-v}` : `+ ${v}`);
const coef = (v: number) => (v === 1 ? "" : v === -1 ? "−" : String(v).replace("-", "−"));

export type Exercise = { level: Level; text: string; answers: Frac[]; multi: boolean };

export function generateExercise(level: Level): Exercise {
  const ex = makeExercise(level); return { ...ex, text: ex.text.replace(/-/g, "−") };
}
function makeExercise(level: Level): Exercise {
  if (level === 1) { const x = rnd(-9, 12), a = nz(2, 9), b = nz(-15, 15); return { level, text: `${coef(a)}x ${sgn(b)} = ${a * x + b}`, answers: [new Frac(x)], multi: false }; }
  if (level === 2) { const x = rnd(-8, 10); let a = nz(-7, 9), c = nz(-6, 8); while (a === c) c = nz(-6, 8); const b = nz(-12, 12); const d = a * x + b - c * x; return { level, text: `${coef(a)}x ${sgn(b)} = ${coef(c)}x ${sgn(d)}`, answers: [new Frac(x)], multi: false }; }
  if (level === 3) {
    const x = rnd(-6, 8), k = nz(2, 6), m = nz(-7, 7), c = nz(-9, 9); let d = nz(-5, 6); while (d === k) d = nz(-5, 6);
    const e = k * (x + m) + c - d * x;
    return { level, text: `${k}(x ${sgn(m)}) ${sgn(c)} = ${coef(d)}x ${sgn(e)}`, answers: [new Frac(x)], multi: false };
  }
  if (level === 4) {
    let r1 = rnd(-7, 7), r2 = rnd(-7, 7); if (r1 === r2) r2 = r1 + rnd(1, 4);
    const a = Math.random() < 0.7 ? 1 : nz(2, 3);
    const b = -a * (r1 + r2), c = a * r1 * r2;
    const text = `${coef(a)}x² ${b === 0 ? "" : `${b < 0 ? "−" : "+"} ${Math.abs(b) === 1 ? "" : Math.abs(b)}x `}${c === 0 ? "" : `${sgn(c)} `}= 0`.replace(/\s+/g, " ");
    return { level, text, answers: [new Frac(Math.min(r1, r2)), new Frac(Math.max(r1, r2))], multi: true };
  }
  if (level === 7) {
    // Problèmes concrets : géométrie, finances, physique
    const types = ["geo", "finance", "physique"];
    const t = types[rnd(0, 2)];
    const x = rnd(-10, 15);
    if (t === "geo") {
      const l = rnd(3, 12), w = x; const perim = 2 * (l + w); const text = `Un rectangle a une longueur de ${l} cm et un périmètre de ${perim} cm. Quelle est sa largeur x ?`;
      return { level, text, answers: [new Frac(x)], multi: false };
    } else if (t === "finance") {
      const prix = rnd(5, 50), n = x; const total = prix * n; const text = `J'achète ${n} articles identiques pour un total de ${total} €. Quel est le prix unitaire x ?`;
      return { level, text, answers: [new Frac(prix)], multi: false };
    } else {
      const v0 = rnd(10, 30), t2 = rnd(2, 8); const d = v0 * t2; const text = `Un objet avance à vitesse constante. En ${t2} s, il parcourt ${d} m. Quelle est sa vitesse x (en m/s) ?`;
      return { level, text, answers: [new Frac(v0)], multi: false };
    }
  }
  if (level === 5) {
    // Équations avec fractions et décimaux
    const useFrac = Math.random() < 0.5;
    if (useFrac) {
      const x = rnd(-6, 10); const den = nz(2, 8); const num = nz(-5, 6);
      const a = new Frac(num, den); const b = nz(-12, 12);
      const rhs = a.mul(x).add(b);
      return { level, text: `${a}x ${sgn(b)} = ${rhs}`, answers: [new Frac(x)], multi: false };
    } else {
      const x = rnd(-8, 10); const da = [2, 5, 10][rnd(0, 2)]; const numA = nz(-7, 9); const a = new Frac(numA, da); const numB = nz(-15, 15); const b = new Frac(numB, [2, 5, 10][rnd(0, 2)]);
      const rhs = a.mul(x).add(b);
      const absB = b.sign() < 0 ? b.neg() : b;
      return { level, text: `${a}x ${b.sign() < 0 ? "−" : "+"} ${absB.toString()} = ${rhs}`, answers: [new Frac(x)], multi: false };
    }
  }
  // Niveau 6 : équations produit nul (x − a)(x − b) = 0
  let r1 = rnd(-9, 9), r2 = rnd(-9, 9); if (r1 === r2) r2 = r1 + rnd(1, 5);
  const f = (r: number) => r >= 0 ? `x − ${r}` : `x + ${-r}`;
  const text = `(${f(r1)})(${f(r2)}) = 0`;
  return { level, text, answers: [new Frac(Math.min(r1, r2)), new Frac(Math.max(r1, r2))], multi: true };
}

/** Compare la réponse de l'élève (une ou plusieurs valeurs séparées par « ; ») aux solutions attendues. */
export function checkAnswer(ex: Exercise, raw: string): { ok: boolean; error?: string } {
  try {
    const vals = raw.split(/[;|]|\bou\b|\bet\b/).map(s => s.replace(/^\s*x\s*[₁₂12]?\s*=\s*/i, "").trim()).filter(Boolean).map(Frac.parse);
    if (!vals.length) return { ok: false, error: "Entre une valeur." };
    const uniq = vals.filter((v, i) => vals.findIndex(w => w.eq(v)) === i);
    if (ex.multi && uniq.length < ex.answers.length) return { ok: false, error: `Il y a ${ex.answers.length} solutions : sépare-les par « ; ».` };
    const ok = uniq.length === ex.answers.length && ex.answers.every(a => uniq.some(v => v.eq(a)));
    return { ok };
  } catch (e) { return { ok: false, error: e instanceof Error ? e.message : "Réponse illisible." }; }
}
