import { onNetlify } from "./runtime";
import { getJSON, setJSON, listJSON } from "./data-store";
import { credit, spend, ledgerFor, balance } from "./bobux";
import { getUser, saveUser } from "./store";
import { COSMETICS } from "./progression";
import { serial, singleWriter } from "./feature-lock";
import { randomInt, randomUUID, createHash } from "node:crypto";
import {
  addTreasury,
  treasuryView,
  repayDebt,
  getAcct,
  type Acct,
} from "./tcb-bank";
import { TROLL_PRICES, sendTroll, getOptOut } from "./tcb-fun";
import { updateJSON } from "./data-store";
export const parisDay = (now = Date.now()) =>
  new Intl.DateTimeFormat("en-CA", {
    timeZone: "Europe/Paris",
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
  }).format(now);
function parisTime(y: number, m: number, d: number, hour: number) {
  const utc = Date.UTC(y, m - 1, d, hour);
  const parts = new Intl.DateTimeFormat("en-GB", {
    timeZone: "Europe/Paris",
    hourCycle: "h23",
    hour: "numeric",
    timeZoneName: "shortOffset",
  }).formatToParts(utc);
  const offset = Number(
    parts.find((p) => p.type === "timeZoneName")?.value.replace("GMT", "") || 0,
  );
  return utc - offset * 3600000;
}
export function nextMidnight(now = Date.now()) {
  const [y, m, d] = parisDay(now).split("-").map(Number);
  const t = new Date(Date.UTC(y, m - 1, d + 1));
  return parisTime(t.getUTCFullYear(), t.getUTCMonth() + 1, t.getUTCDate(), 0);
}
export function lotteryPeriod(now = Date.now()) {
  const [y, m, d] = parisDay(now).split("-").map(Number);
  const t = new Date(Date.UTC(y, m - 1, d));
  t.setUTCDate(t.getUTCDate() + ((7 - t.getUTCDay()) % 7));
  let end = parisTime(
    t.getUTCFullYear(),
    t.getUTCMonth() + 1,
    t.getUTCDate(),
    20,
  );
  if (end <= now) {
    t.setUTCDate(t.getUTCDate() + 7);
    end = parisTime(
      t.getUTCFullYear(),
      t.getUTCMonth() + 1,
      t.getUTCDate(),
      20,
    );
  }
  return { id: t.toISOString().slice(0, 10), endsAt: end };
}
export function dailyShop(now = Date.now()) {
  const day = parisDay(now);
  const sorted = COSMETICS.filter((c) => !c.pass && c.price > 0)
    .map((c) => ({
      c,
      rank: createHash("sha256").update(`${day}:${c.id}`).digest("hex"),
    }))
    .sort((a, b) => a.rank.localeCompare(b.rank));
  return {
    day,
    endsAt: nextMidnight(now),
    items: sorted.slice(0, 4).map((x) => x.c),
  };
}
type Chest = {
  day: string;
  playTier: number;
  rewards: {
    at: number;
    amount: number;
    kind: string;
    id?: string;
    paid?: boolean;
  }[];
};
export type Loan = {
  id: string;
  lender: string;
  borrower: string;
  principal: number;
  rate: number;
  days: number;
  total: number;
  remaining: number;
  dueAt: number;
  status: "pending" | "active" | "paid" | "declined";
  createdAt: number;
};
type Lottery = {
  id: string;
  endsAt: number;
  tickets: { id: string; user: string }[];
  drawn: boolean;
  winner?: string;
  prize?: number;
  treasury?: number;
  drawnAt?: number;
  paid?: boolean;
};
type RouletteEntry = {
  username: string;
  requestId: string;
  at: number;
  stake: number;
  choice: string;
  result: string;
  won: boolean;
  payout: number;
  borrowed: number;
  cashDebit: number;
  settled: boolean;
  message: string;
};
const STORE = "tcb-economy";
async function settleSpin(entry: RouletteEntry) {
  if (entry.settled) return entry;
  const op = `roulette:${entry.username.toLowerCase()}:${entry.requestId}`,
    account = await getAcct(entry.username);
  if (entry.cashDebit)
    await spend(
      entry.username,
      entry.cashDebit,
      `Roulette : mise ${entry.stake} sur ${entry.choice === "red" ? "rouge" : "noir"}`,
      `${op}:stake`,
    );
  if (entry.borrowed)
    await updateJSON<Acct>(
      "tcb-bank",
      `acct:${entry.username.toLowerCase()}`,
      (a) => {
        const current = a || account;
        if (current.overdraftOperations?.[op]) return current;
        return {
          ...current,
          overdraftUsed: (current.overdraftUsed || 0) + entry.borrowed,
          debtSince: current.debtSince || Date.now(),
          overdraftOperations: { ...current.overdraftOperations, [op]: true },
        };
      },
    );
  if (entry.payout)
    await credit(
      entry.username,
      entry.payout,
      "Roulette",
      `Roulette : mise doublée (${entry.stake} × 2)`,
      "bank",
      `${op}:prize`,
    );
  if (entry.won) await repayDebt(entry.username);
  entry.settled = true;
  await setJSON(STORE, op, entry);
  return entry;
}
export async function myLoans(username: string) {
  return (await listJSON<Loan>(STORE, "loan:"))
    .filter((l) =>
      [l.lender.toLowerCase(), l.borrower.toLowerCase()].includes(
        username.toLowerCase(),
      ),
    )
    .sort((a, b) => b.createdAt - a.createdAt);
}
export async function settleLottery(now = Date.now()) {
  singleWriter();
  return serial("economy", async () => {
    for (const l of (await listJSON<Lottery>(STORE, "lottery:")).filter(
      (l) => !l.paid && l.endsAt <= now,
    )) {
      if (!l.drawn) {
        l.drawn = true;
        l.drawnAt = now;
        if (l.tickets.length) {
          l.winner = l.tickets[randomInt(l.tickets.length)].user;
          l.treasury = Math.floor(l.tickets.length * 10 * 0.1);
          l.prize = l.tickets.length * 10 - l.treasury;
        }
        await setJSON(STORE, `lottery:${l.id}`, l);
      }
      if (l.winner && l.prize)
        await credit(
          l.winner,
          l.prize,
          "Loterie",
          `Tirage du ${l.id}`,
          "bank",
          `lottery:${l.id}:prize`,
        );
      if (l.treasury) await addTreasury(l.treasury, `lottery:${l.id}:treasury`);
      l.paid = true;
      await setJSON(STORE, `lottery:${l.id}`, l);
    }
  });
}
export async function economyState(username?: string) {
  if (
    !onNetlify() ||
    process.env.TCB_SINGLE_WRITER === "true"
  )
    await settleLottery();
  if (username)
    await serial("economy", async () => {
      for (const entry of await listJSON<RouletteEntry>(
        STORE,
        `roulette:${username.toLowerCase()}:`,
      ))
        if (!entry.settled) await settleSpin(entry);
    });
  const period = lotteryPeriod();
  const l = await getJSON<Lottery>(STORE, `lottery:${period.id}`);
  const last = (await listJSON<Lottery>(STORE, "lottery:"))
    .filter((l) => l.drawn)
    .sort((a, b) => b.endsAt - a.endsAt)[0];
  const u = username ? await getUser(username) : null;
  const account = username ? await getAcct(username) : null;
  const chest = username
    ? await serial("economy", async () => {
        const current = await getJSON<Chest>(
          STORE,
          `chest:${username.toLowerCase()}`,
        );
        if (!current) return null;
        let changed = false;
        for (const reward of current.rewards)
          if (reward.id && !reward.paid) {
            await credit(
              username,
              reward.amount,
              "Coffre",
              "Récompense de coffre",
              "quest",
              `chest:${reward.id}`,
            );
            reward.paid = true;
            changed = true;
          }
        if (changed)
          await setJSON(STORE, `chest:${username.toLowerCase()}`, current);
        return current;
      })
    : null;
  return {
    shop: { ...dailyShop(), owned: u?.cosmetics?.owned || [] },
    balance: u?.bobux || 0,
    chest: {
      dailyReady: !!u && chest?.day !== parisDay(),
      playReady:
        !!u &&
        Math.floor((u.playTimeMinutes || 0) / 60) > (chest?.playTier || 0),
      nextPlayMinutes: ((chest?.playTier || 0) + 1) * 60,
      rewards: chest?.rewards || [],
      endsAt: nextMidnight(),
    },
    lottery: {
      ...period,
      tickets: l?.tickets.length || 0,
      myTickets:
        l?.tickets.filter(
          (t) => t.user.toLowerCase() === username?.toLowerCase(),
        ).length || 0,
      pot: (l?.tickets.length || 0) * 10,
      treasuryPercent: 10,
      price: 10,
      last: last
        ? {
            id: last.id,
            winner: last.winner,
            prize: last.prize,
            treasury: last.treasury,
          }
        : null,
    },
    loans: username ? await myLoans(username) : [],
    ledger: username ? await ledgerFor(username) : [],
    treasury: (await treasuryView()).total,
    friends: u?.friends || [],
    debt: account?.overdraftUsed || 0,
    netBalance: (u?.bobux || 0) - (account?.overdraftUsed || 0),
    trolls: Object.entries(TROLL_PRICES).map(([id, price]) => ({ id, price })),
    trollOptout: username ? await getOptOut(username) : false,
    rouletteHistory: username
      ? (
          await listJSON<{
            username: string;
            at: number;
            stake: number;
            choice: string;
            result: string;
            won: boolean;
            payout: number;
            borrowed: number;
          }>(STORE, `roulette:${username.toLowerCase()}:`)
        )
          .sort((a, b) => b.at - a.at)
          .slice(0, 20)
      : [],
  };
}
export async function economyAction(
  username: string,
  b: Record<string, unknown>,
) {
  singleWriter();
  await settleLottery();
  return serial("economy", async () => {
    const user = await getUser(username);
    if (!user || user.banned) throw new Error("Compte indisponible.");
    switch (b.action) {
      case "roulette": {
        const stake = Number(b.stake),
          choice = String(b.choice),
          requestId = String(b.requestId || "");
        if (
          !Number.isSafeInteger(stake) ||
          stake < 1 ||
          stake > 100000 ||
          !["red", "black"].includes(choice) ||
          !/^[a-z0-9-]{16,60}$/i.test(requestId)
        )
          throw new Error("Mise de 1 à 100 000 Bobux, rouge ou noir.");
        const key = `roulette:${username.toLowerCase()}:${requestId}`,
          old = await getJSON<RouletteEntry>(STORE, key);
        if (old) return settleSpin(old);
        const cash = user.bobux || 0,
          borrowed = Math.max(0, stake - cash),
          account = await getAcct(username);
        if (borrowed && b.acceptDebt !== true)
          throw new Error(
            `Cette mise crée ${borrowed} Bobux de dette. Confirme le découvert.`,
          );
        if ((account.overdraftUsed || 0) + borrowed > 999999999)
          throw new Error("Limite technique de dette atteinte.");
        const result = randomInt(2) === 0 ? "red" : "black",
          won = choice === result,
          payout = won ? stake * 2 : 0;
        const entry: RouletteEntry = {
          username,
          requestId,
          at: Date.now(),
          stake,
          choice,
          result,
          won,
          payout,
          borrowed,
          cashDebit: Math.min(cash, stake),
          settled: false,
          message: won
            ? `Boule ${result === "red" ? "rouge" : "noire"} : ${payout} Bobux crédités, dette remboursée en priorité.`
            : `Boule ${result === "red" ? "rouge" : "noire"} : mise perdue${borrowed ? `, ${borrowed} Bobux ajoutés à ta dette bancaire` : ""}.`,
        };
        await setJSON(STORE, key, entry);
        return settleSpin(entry);
      }
      case "troll": {
        const r = await sendTroll(user, b.target, b.effect);
        if (r.error) throw new Error(r.error);
        return { message: `Troll envoyé pour ${r.price} Bobux.` };
      }
      case "repay-debt": {
        const amount = await repayDebt(username);
        return { message: `${amount} Bobux de dette remboursés.` };
      }
      case "buy": {
        const c = dailyShop().items.find((c) => c.id === b.id);
        if (!c)
          throw new Error("Cet objet n'est pas dans la boutique du jour.");
        if (user.cosmetics?.owned?.includes(c.id))
          throw new Error("Objet déjà possédé.");
        await spend(
          username,
          c.price,
          `Boutique quotidienne : ${c.name}`,
          `cosmetic:${username.toLowerCase()}:${c.id}`,
        );
        const fresh = (await getUser(username))!;
        fresh.cosmetics ||= { owned: [] };
        fresh.cosmetics.owned = [...new Set([...fresh.cosmetics.owned, c.id])];
        await saveUser(fresh);
        return { message: `${c.name} ajouté à ta collection.` };
      }
      case "chest": {
        const key = `chest:${username.toLowerCase()}`,
          c = (await getJSON<Chest>(STORE, key)) || {
            day: "",
            playTier: 0,
            rewards: [],
          };
        if (b.kind === "daily") {
          if (c.day === parisDay())
            throw new Error("Coffre du jour déjà ouvert.");
          c.day = parisDay();
        } else if (b.kind === "play") {
          if (Math.floor((user.playTimeMinutes || 0) / 60) <= c.playTier)
            throw new Error("Palier de temps de jeu non atteint.");
          c.playTier++;
        } else throw new Error("Type de coffre invalide.");
        const r = randomInt(100),
          amount = r < 60 ? 20 : r < 85 ? 50 : r < 97 ? 100 : 500;
        const id = randomUUID();
        c.rewards = [
          { at: Date.now(), amount, kind: String(b.kind), id, paid: false },
          ...c.rewards,
        ].slice(0, 30);
        await setJSON(STORE, key, c);
        const e = await credit(
          username,
          amount,
          "Coffre",
          "Récompense de coffre",
          "quest",
          `chest:${id}`,
        );
        c.rewards[0].paid = true;
        await setJSON(STORE, key, c);
        return {
          message: `Coffre ouvert : ${e.amount} Bobux !`,
          reward: e.amount,
        };
      }
      case "ticket": {
        const period = lotteryPeriod(),
          key = `lottery:${period.id}`;
        const l = (await getJSON<Lottery>(STORE, key)) || {
          ...period,
          tickets: [],
          drawn: false,
        };
        if (l.drawn || l.endsAt <= Date.now()) throw new Error("Tirage fermé.");
        if (
          l.tickets.filter(
            (t) => t.user.toLowerCase() === username.toLowerCase(),
          ).length >= 100
        )
          throw new Error("Limite de 100 tickets par semaine.");
        await spend(username, 10, `Ticket de loterie ${period.id}`);
        l.tickets.push({ id: randomUUID(), user: username });
        await setJSON(STORE, key, l);
        return {
          message: "Ticket enregistré. Tirage dimanche à 20 h, heure de Paris.",
        };
      }
      case "offer-loan": {
        const borrower = await getUser(String(b.borrower));
        if (
          !borrower ||
          borrower.banned ||
          !user.friends?.some(
            (f) => f.toLowerCase() === borrower.username.toLowerCase(),
          )
        )
          throw new Error("Le bénéficiaire doit être un ami.");
        const principal = Number(b.amount),
          rate = Number(b.rate),
          days = Number(b.days);
        if (
          !Number.isInteger(principal) ||
          principal < 10 ||
          principal > 100000 ||
          !Number.isInteger(rate) ||
          rate < 0 ||
          rate > 20 ||
          !Number.isInteger(days) ||
          days < 1 ||
          days > 90
        )
          throw new Error(
            "Montant 10–100 000, intérêt 0–20 %, échéance 1–90 jours.",
          );
        if (
          (await myLoans(username)).filter((l) => l.status === "pending")
            .length >= 20
        )
          throw new Error("Trop de propositions en attente.");
        if ((await balance(username)) < principal)
          throw new Error("Solde insuffisant.");
        const total = principal + Math.floor((principal * rate) / 100);
        const loan: Loan = {
          id: randomUUID(),
          lender: username,
          borrower: borrower.username,
          principal,
          rate,
          days,
          total,
          remaining: total,
          dueAt: Date.now() + days * 86400000,
          status: "pending",
          createdAt: Date.now(),
        };
        await setJSON(STORE, `loan:${loan.id}`, loan);
        return {
          message:
            "Conditions envoyées à ton ami. Le débit aura lieu à son acceptation.",
        };
      }
      case "accept-loan":
      case "decline-loan":
      case "repay-loan": {
        const key = `loan:${String(b.id)}`,
          l = await getJSON<Loan>(STORE, key);
        if (!l || l.borrower.toLowerCase() !== username.toLowerCase())
          throw new Error("Prêt inaccessible.");
        if (b.action === "decline-loan") {
          if (l.status !== "pending")
            throw new Error("Proposition déjà traitée.");
          l.status = "declined";
        } else if (b.action === "accept-loan") {
          if (l.status !== "pending")
            throw new Error("Proposition déjà traitée.");
          if (Date.now() - l.createdAt > 7 * 86400000)
            throw new Error("Proposition expirée.");
          await spend(
            l.lender,
            l.principal,
            `Prêt ${l.id} à ${username}, ${l.rate} %, ${l.days} jours`,
          );
          try {
            await credit(
              username,
              l.principal,
              l.lender,
              `Prêt ${l.id} reçu`,
              "gift",
            );
          } catch (e) {
            await credit(
              l.lender,
              l.principal,
              "Banque",
              "Annulation prêt",
              "bank",
            );
            throw e;
          }
          l.status = "active";
          l.dueAt = Date.now() + l.days * 86400000;
        } else {
          if (l.status !== "active") throw new Error("Prêt non actif.");
          const amount = Number(b.amount);
          if (!Number.isInteger(amount) || amount < 1 || amount > l.remaining)
            throw new Error("Remboursement invalide.");
          await spend(username, amount, `Remboursement prêt ${l.id}`);
          try {
            await credit(
              l.lender,
              amount,
              username,
              `Remboursement prêt ${l.id}`,
              "gift",
            );
          } catch (e) {
            await credit(
              username,
              amount,
              "Banque",
              "Remboursement annulé",
              "bank",
            );
            throw e;
          }
          l.remaining -= amount;
          if (!l.remaining) l.status = "paid";
        }
        await setJSON(STORE, key, l);
        return { message: "Prêt mis à jour." };
      }
      default:
        throw new Error("Action inconnue.");
    }
  });
}
