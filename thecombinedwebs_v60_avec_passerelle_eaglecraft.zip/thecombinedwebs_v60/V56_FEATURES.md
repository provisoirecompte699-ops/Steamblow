# TheCombinedWebs v56 — Mega mise à jour

## Algèbre Facile
- **Examen blanc** : 15 questions mixtes (niveaux 1-4), note sur 20, corrigé détaillé avec revue question par question.
- **Mode histoire** : 6 boss mathématiques à vaincre (Gardien des Équations, Maître des Parenthèses, Seigneur du Second Degré, Dragon des Fractions, Sorcier du Produit Nul, Titan des Problèmes). 5 questions par boss, 3 vies, difficulté croissante, progression sauvegardée.
- **Problèmes concrets (niveau 7)** : exercices avec contexte réel — géométrie (périmètre), finances (prix unitaire), physique (vitesse).
- **7 niveaux d'exercices** au total.
- **5 modes** dans l'ExerciseTrainer : Entraînement, Chrono, Examen blanc, Mode histoire, Statistiques.
- **Progression du mode histoire** visible dans l'arbre de compétences.

## Jeux
- **Calcul Mental** : nouveau mini-jeu. 30 secondes pour faire le maximum d'opérations (additions, soustractions, multiplications). Combo croissant.
- **Fraction Rush** : nouveau mini-jeu. Compare des fractions le plus vite possible (gauche, droite ou égal). 30 secondes.
- 15 jeux au catalogue (11 arcade + 3 pédagogiques + Baldi 3D).

## Communauté
- **Notation des jeux** : note les jeux de 1 à 5 étoiles, laisse un avis. Stockage local.
- **Classement entre amis** : ton rang parmi tes amis pour chaque jeu, pas seulement mondial.
- **Tutoriel interactif** : guide de 8 étapes pour les nouveaux joueurs, affiché à la première connexion. Passable.
- **Statistiques de compte enrichies** : temps de jeu, jeux possédés, films débloqués, amis, succès, score arcade cumulé, exercices algèbre, progression mode histoire — tout sur une page.

## Dashboard
- Bannière v56 présentant les 9 nouvelles fonctionnalités.
- Nouvelle section « Mon profil » avec AccountStats.
- FriendLeaderboard ajouté à la section « Activité et amis ».
- Tutoriel affiché automatiquement pour les nouveaux utilisateurs.
