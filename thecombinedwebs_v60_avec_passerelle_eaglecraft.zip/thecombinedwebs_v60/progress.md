Original prompt: étendre thecombinedwebs_v59_proxy.zip avec portails/proxy administrables, recherche et favoris globaux, TV/manette, notifications PWA, cloud local, événements, vocal de groupes, duels et profils ; compléter avec boutique quotidienne, prêts, coffres, loterie, boutique sur l'accueil, trolls payants, roulette rouge/noir avec dette bancaire et roulette russe entre amis.

# Progression v60

## Implémentation

- Projet Next.js existant conservé ; nouvelles pages `/portails`, `/evenements`, `/social`, `/economie`.
- Comptes et solde de TCB Banque utilisés ; pas de monnaie parallèle.
- API serveur et contrôles d'accès pour les nouvelles fonctionnalités.
- Aperçu React des nouvelles pages, avec jetons de session en mémoire et données de test séparées des données fournies.
- Verrous mono-écrivain, crédits idempotents et reprise de roulette/loterie ; restriction explicite des opérations sensibles en serverless multi-écrivain.
- Mini-jeu de roulette russe abstrait et non graphique, jamais une instruction réelle.

## Validation

- Tests fonctionnels serveur et compilation TypeScript.
- Build Next.js de production.
- Vérifications navigateur sur ordinateur, mobile et thèmes.
- Scénarios à deux joueurs avec comptes isolés.

## Configuration et suivi

- Voir `NOTES_V60.md` pour les variables, le proxy, le push et l'ordonnanceur de loterie.
- Push hors application, vocal entre réseaux et manette physique à vérifier sur les appareils réels.
- Une base transactionnelle sera nécessaire avant une mise à l'échelle multi-instance de l'économie.
- Les scores des jeux navigateur ne sont pas validés par une simulation serveur complète.
- Le cloud conserve la progression prise en charge par les moteurs, pas les parties physiques en cours ni les sauvegardes des sites externes.
