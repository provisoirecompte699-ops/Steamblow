# TheCombinedWebs v60.0.3 : réinitialisation du compte Moustafa

Le créateur peut choisir un nouveau mot de passe pour Moustafa depuis le Centre de contrôle. Le ZIP n'applique pas de nouveau mot de passe au compte réel : l'action est effectuée uniquement lorsque le créateur valide le formulaire sur le site redéployé.

## Utilisation

Connecte-toi au compte créateur, ouvre `/admin`, puis utilise « Réinitialiser le mot de passe de Moustafa ». Saisis ton mot de passe créateur, le nouveau mot de passe de Moustafa et sa confirmation ; coche ensuite la confirmation et valide.

Le nouveau mot de passe doit contenir de 12 à 128 caractères. Il n'est jamais affiché dans les réponses API ni enregistré en clair. Transmets-le à Moustafa par un moyen privé après validation.

## Protections

- **Autorisation** : rôle créateur vérifié côté serveur et au moment de la réauthentification. Un joueur, modérateur ou vice-créateur ne peut pas utiliser cette action.
- **Cible** : uniquement le compte Moustafa possédant le rôle vice-créateur. L'API ne permet pas de choisir arbitrairement un autre compte.
- **Confirmation** : mot de passe créateur obligatoire, confirmation du nouveau mot de passe et cinq échecs maximum par période de quinze minutes par instance serveur. Cette limitation n'est pas une limite globale distribuée.
- **Sessions** : les jetons sont liés à la version du mot de passe. Les anciennes sessions de Moustafa ne sont plus authentifiées après le changement, y compris les sessions v60.0.2 sans version. Les sessions du créateur restent valides.
- **Données** : aucune modification du solde, des jeux, des succès ou de la progression. Les mots de passe réinitialisés sont stockés séparément des profils ; une sauvegarde de profil ancienne ne restaure pas le mot de passe précédent.
- **Stockage** : Netlify Blobs en lecture fortement cohérente, ou `data/credentials/` sur un volume Node persistant. Conserver ce stockage dans les sauvegardes privées de production ; ne pas l'exposer ni le publier. Les données d'authentification de test ne sont pas incluses dans le ZIP.

Les sessions de connexion n'utilisent toujours aucune clé de signature manuelle. Les configurations de services proxy et temps réel sont indépendantes.

## Tests

```sh
npm run test:password-reset
npm run test:login
npm run test:features
npm run smoke
npm run build
```
