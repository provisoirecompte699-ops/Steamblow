# TheCombinedWebs Écosystème v50

## Jeux
- Nouveau moteur arcade (`app/games/_components/arcade/`) : collisions, IA, particules, éclairage, sons WebAudio, thèmes graphiques pseudo-3D.
- 11 jeux réécrits et jouables : Mystic Mines, Block Brawl, Pixel Heist, Castle Clash, Meteor Mayhem, Neon Tag, Crystal Rush, Cyber Siege, Neon Arena, Party Pals, Rooftop Rivals.
- Neon Drift 3D : bouton « Jouer en solo » (plus besoin de serveur multijoueur) et correction du plantage au chargement.
- Sky Jump / Turbo Kart : correction d'une erreur de rendu serveur.

## Mode mobile
- Joystick tactile, boutons Dash / action, tir automatique, mode plein écran immersif, mise à l'échelle portrait et paysage.

## Films payants (CinéStream et Vortex)
- Chaque film ou série coûte 2,99 € (tous les épisodes inclus pour une série).
- Écran de paiement avec deux choix : espèces remises à Younes ou Moustafa, ou une blague jugée par eux.
- Les demandes apparaissent dans /admin (« Paiements en espèces » et « Jeux et films offerts pour une bonne blague »). La validation débloque le film sur le compte TheCombinedWebs.
- Les créateurs (creator / vice_creator) ont accès à tout. Les fichiers vidéo locaux restent gratuits.
- Code : `lib/films.ts`, `app/api/films/`, `public/eco/paywall.js`.

Crédits : Walid.
