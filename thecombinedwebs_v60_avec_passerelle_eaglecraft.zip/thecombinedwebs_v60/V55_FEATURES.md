# TheCombinedWebs v55 — Mega mise à jour

## Algèbre Facile
- **Défi chronométré** : 10 équations en 60 secondes, suivi du meilleur temps.
- **Statistiques détaillées** : exercices par niveau, taux de réussite, meilleur chrono, niveaux maîtrisés.
- **Arbre de compétences** : 6 niveaux visuels avec progression (🔒 → 📖 → ⭐).
- **3 modes** dans l'ExerciseTrainer : Entraînement, Défi chronométré, Statistiques.

## Jeux
- **Algèbre Arena** : nouveau jeu dans le catalogue. Des équations tombent, touche les vraies, évite les fausses. 3 vies, combo croissant.
- Succès et options de jeu v54 toujours présents.

## CinéStream
- **Quiz cinéma** : 10 questions de culture ciné qui apparaissent pendant les soirées. Réponses partagées dans le chat.
- Réactions, messages rapides et statut « prêt » v54 toujours présents.

## Communauté
- **Boss hebdomadaire** : un boss communautaire avec barre de vie partagée (50 000 PV). Les scores arcade infligent des dégâts. Récompense de 200 Bobux.
- **Événements quotidiens** : un événement spécial chaque jour (défi doublé, tournoi flash, soirée ciné, marathon arcade, clan wars…).
- **Quêtes hebdomadaires** : 4 objectifs de semaine avec grosses récompenses (150-300 Bobux). API dédiée avec `weeklyState`, `weeklyProgress`, `weeklyClaim`.
- **Hall of Fame** : records top 1 par jeu, affichés sur le dashboard.
- **Défis entre amis** : lance un défi à un ami pour battre ton record sur un jeu précis. Statut en attente / gagné / perdu.
- **Messagerie privée** : conversations directes entre amis, stockage local, 100 messages par conversation.
- **Mur d'activités** : fil d'activité local avec les exploits récents (jeux, exercices, succès).

## Dashboard
- Bannière v55 présentant les 9 nouvelles fonctionnalités.
- Nouvelles sections : Communauté v55 (Boss, Événements, Hall of Fame) et Activité et amis (Mur d'activités, Défis, Messagerie).
- Accès rapide à Algèbre Facile.
