# TheCombinedWebs v60 : fonctionnalités et mise en service

Cette version étend le projet `thecombinedwebs_v59_proxy.zip`, sans remplacer les jeux ni les services existants. La boutique, les trolls, les prêts, les mises et les récompenses utilisent le solde Bobux du compte courant existant ; il n'y a pas de portefeuille économique parallèle.

## Boutique et jeux bancaires

- **Boutique sur l'accueil** : quatre cosmétiques disponibles chaque jour, compte à rebours et achat depuis le compte courant. Les objets restent dans la collection déjà utilisée par Passe & boutique.
- **Trolls payants** : prix affiché pour chaque effet, destinataires amis, effets temporaires et possibilité de désactiver leur réception. Les règles existantes de protection, d'accès et de délai sont conservées.
- **Roulette rouge/noir** : tirage serveur à chances égales ; le versement brut d'une victoire est deux fois la mise. Une défaite perd toute la mise.
- **Endettement** : une mise peut dépasser le solde disponible. La différence est enregistrée dans `Acct.overdraftUsed`, la dette déjà gérée par TCB Banque. Le solde net, la dette et le montant emprunté sont affichés avant la mise ; une confirmation explicite est nécessaire. Les gains remboursent la dette en priorité.
- **Roulette russe entre amis** : invitation, acceptation des deux mises, premier joueur choisi par le serveur, six cases dont une fatale et tours alternés. L'élimination est exclusivement virtuelle, sans représentation graphique de blessures ni arme utilisable. Le gagnant reçoit les deux mises ; une invitation refusée ou un duel expiré restitue les mises.
- **Limites affichées** : 1 à 100 000 Bobux par tour rouge/noir ; 1 à 10 000 Bobux par joueur en duel. Les duels ne créent pas de dette : seul le rouge/noir permet une mise à découvert.

### Exemple de mise à découvert

Avec 50 Bobux disponibles et une mise de 100 :

- **Défaite** : compte courant à 0, dette bancaire de 50.
- **Victoire** : versement brut de 200, remboursement des 50 empruntés, compte courant à 150 et dette liée à ce tour à 0.

Une dette antérieure est également remboursée en priorité lorsque le gain le permet. Les taux, plafonds et intérêts bancaires déjà présents dans la v59 restent ceux de TCB Banque.

## Économie complémentaire

- **Prêts à conditions libres** : un joueur propose à un ami un montant, un taux de 0 à 20 % et une durée de 1 à 90 jours. Aucun transfert avant l'acceptation du bénéficiaire ; le solde restant inclut les intérêts convenus et les remboursements partiels sont suivis.
- **Coffres** : un quotidien et un par tranche de 60 minutes de jeu cumulées. Tirage serveur : 20 Bobux à 60 %, 50 à 25 %, 100 à 12 %, 500 à 3 %.
- **Loterie** : ticket de 10 Bobux, jusqu'à 100 tickets par joueur et par semaine. Tirage dimanche à 20 h, Europe/Paris ; 90 % au gagnant, 10 % au Trésor existant du créateur.
- **Relevé** : débits et crédits passent par le registre Bobux existant. Les nouveaux prêts à conditions libres se consultent dans Boutique & banque ; les anciens contrats du service bancaire restent conservés dans leur interface d'origine.

## Portails et proxy

- **Gestion créateur** : ajout et édition de portails, URL HTTPS, hôtes autorisés et sélecteur de liens depuis `/portails`.
- **Catalogue** : import JSON complet ou indexation des liens de la page configurée. Format : `[{"title":"Mon jeu","url":"https://jeux.domaine.fr/game/mon-jeu","category":"Arcade"}]`.
- **Recherche globale** : jeux locaux et jeux indexés des portails actifs sont recherchés dans la même page. L'ajout d'un domaine ne rend pas automatiquement son catalogue externe complet disponible : il faut l'indexer ou importer sa liste de jeux.
- **Favoris et récents** : liés au compte, communs aux portails, avec conservation des favoris locaux déjà présents.
- **Proxy dynamique** : les hôtes sont inclus dans des tickets signés valables 15 minutes. Il faut mettre à jour le serveur proxy fourni avec cette version, mais ajouter ensuite un portail ne demande pas de changement de code.
- **Sécurité réseau** : refus des adresses privées, validation des hôtes et du DNS, résolution épinglée pendant la connexion, redirections de catalogue revérifiées et taille/délai limités.

Les restrictions techniques des sites externes restent applicables. L'indexeur ne lit pas les catalogues rendus exclusivement par JavaScript ; utiliser alors l'import JSON. Les hôtes d'assets nécessaires à un portail doivent être explicitement autorisés par le créateur.

## Événements et social

- **Heure dorée** : lancée par le créateur depuis `/evenements`, elle double les récompenses marquées comme quotidiennes ou de quête. Les transferts, remboursements, mises restituées et gains de roulette/loterie ne sont pas multipliés.
- **Chasse au trésor** : objet sur une page choisie, contrôle côté serveur et un seul gagnant. Le gros lot passe par le compte courant.
- **Boss du serveur** : points de vie partagés, dégâts fixés à 25 par attaque et cadence limitée côté serveur. Le coup final reçoit le gros lot. L'interface se synchronise toutes les 1,2 seconde.
- **Groupes** : chat et salons vocaux dédiés, avec vérification de l'adhésion sur les API de texte, de voix et de synchronisation.
- **Duels de scores** : partie unique par joueur sur un jeu accessible aux deux participants, mise réservée pour chacun et règlement après comparaison des scores. Égalité ou expiration : remboursement.
- **Profils publics** : titre existant, jeu favori, vitrine de six succès déjà acquis, favoris multiportails et statistiques. Les comptes bannis ne sont pas exposés.

Les scores d'arcade restent produits par le moteur côté navigateur, comme dans la v59. Les jetons de partie, contrôles de durée et limites de score réduisent les rejouements, mais ne constituent pas un moteur anti-triche autoritaire ; il faudra une validation serveur du gameplay pour des compétitions à enjeux élevés.

## Confort, installation et sauvegardes

- **TV et manette** : navigation au pad standard, croix ou stick gauche, A pour valider, B pour revenir, Start pour basculer le mode TV. Les formulaires disposent d'un clavier virtuel, avec chiffres et majuscules. Les jeux externes conservent leurs propres contrôles.
- **PWA** : le manifeste, l'installation et le service worker existants sont conservés ; le service worker reçoit désormais les notifications Web Push.
- **Notifications** : abonnement explicite pour les événements et les amis en jeu ; suppression des abonnements devenus invalides. Le push hors application exige les clés VAPID et HTTPS.
- **Cloud de progression** : stockage côté serveur par compte et par jeu, avec numéro de version et refus d'écrasement concurrent. Les moteurs arcade partagés sauvegardent records, succès et difficulté ; des adaptateurs enregistrent les records des jeux mathématiques, d'Infinite Ascent, Sky Jump, Neon Drift et les paliers de tours de Turbo Kart.

Le cloud ne reprend pas une partie au milieu d'un niveau et ne peut pas accéder aux sauvegardes privées de Snokido ou de GTA Web. Il conserve les éléments de progression implémentés par chaque moteur local ; il ne prétend pas sérialiser tous les états physiques des jeux.

## Mise en service

### Hébergement et données

Les nouvelles opérations économiques exigent **un seul serveur Node faisant autorité**, avec un volume persistant pour les données et des sauvegardes régulières. Les verrous de cette version sont partagés entre les routes d'un processus Node, pas entre plusieurs machines.

La v59 proposait un stockage de repli par fichiers et un stockage Netlify Blobs. Cette version ne prétend pas rendre des transferts multi-comptes atomiques sur plusieurs fonctions serverless : les nouvelles mutations sensibles sont bloquées sur Netlify lorsque ce mode mono-écrivain n'est pas explicitement établi. Pour plusieurs instances, migrer l'économie vers une base transactionnelle avant activation.

Ne pas définir `TCB_SINGLE_WRITER=true` sur des fonctions serverless indépendantes pour contourner cette protection. Cette variable ne convient que lorsque l'architecture garantit réellement un seul écrivain.

### Variables

| Variable | Usage |
|---|---|
| Sessions | Aucune clé manuelle ; sessions opaques persistées côté serveur. |
| `REALTIME_SECRET` | Signature des tickets multijoueur/vocal ; identique sur le site et le serveur temps réel. Sans lien avec les sessions de connexion. |
| `PROXY_SECRET` | Même secret de signature sur le projet et le serveur proxy. |
| `NEXT_PUBLIC_PROXY_URL` | URL HTTPS du proxy mis à jour. |
| `TCB_DATA_DIR` | Dossier persistant pour les utilisateurs et le stockage local ; sinon `data/`. |
| `NEXT_PUBLIC_VAPID_PUBLIC_KEY` | Clé publique Web Push. |
| `VAPID_PRIVATE_KEY` | Clé privée Web Push, seulement sur le serveur. |
| `VAPID_SUBJECT` | Identité VAPID, par exemple un contact `mailto:` valide. |
| `TCB_CRON_SECRET` | Secret pour l'appel authentifié au tirage automatique. |

Les clés et les identifiants de services ne sont pas inclus dans les livrables.

### Tirage hebdomadaire

Configurer un ordonnanceur pour appeler `POST /api/economy/draw`, avec `Authorization: Bearer <TCB_CRON_SECRET>`, chaque dimanche à 20 h Europe/Paris. Un appel fréquent, par exemple toutes les minutes, est également possible : le serveur ne règle que les tirages échus, avec des identifiants de crédit et de versement au Trésor idempotents.

Sans ordonnanceur, le tirage échu est réglé lors de la prochaine consultation de l'économie. Le résultat est unique, mais l'exécution ne sera pas ponctuelle à 20 h si aucun client ne consulte la page.

### Commandes

```sh
npm ci
npm run test:features
npm run smoke
npx tsc --noEmit
npm run build
npm start
```

Le serveur proxy se déploie séparément avec les fichiers de `proxy-server/`. Les données de comptes de l'archive ne doivent pas être intégrées à un aperçu partagé ni à un dépôt public.

## Vérifications

Les tests de `scripts/feature-test.ts` utilisent un répertoire temporaire isolé. Ils couvrent les crédits concurrents, la protection du solde contre un profil périmé, la boutique, les coffres, les prêts, l'Heure dorée, la roulette et sa reprise après interruption, le trésor, le boss, les portails, les favoris/récents, les sauvegardes, les deux duels et la répartition de la loterie.

Le build Next.js, la compilation TypeScript et les tests de structure sont également exécutés. Des parcours navigateur utilisent deux comptes de test distincts pour vérifier la recherche, les favoris, les thèmes, le boss, les mises et le duel de roulette russe.

La livraison inclut un aperçu des nouvelles pages branché sur les API du projet et des comptes isolés. Cet aperçu ne remplace pas le déploiement du projet Next.js complet ; les jeux, les profils complets, l'installation PWA, le proxy externe et le push hors application nécessitent l'hébergement et les réglages indiqués ci-dessus.

### Points à vérifier sur l'hébergement final

- **Vocal** : vérifier les microphones et les connexions entre deux réseaux réels ; prévoir TURN si nécessaire.
- **Manette physique** : tester les modèles de manettes réellement utilisés ; les contrôles de navigation standard sont implémentés.
- **Push et PWA** : vérifier installation, autorisations et réception application fermée sur les appareils visés.
- **Économie distribuée** : ne pas activer plusieurs écrivains sans base transactionnelle. Les opérations multi-enregistrements, notamment les prêts anciens et nouveaux, n'offrent pas toutes une transaction ACID lors d'une panne brutale.
- **Catalogue externe** : importer une liste complète de jeux si l'indexation d'une seule page ne suffit pas.
