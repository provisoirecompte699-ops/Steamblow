"use strict";
/**
 * TCB Proxy — proxy inverse personnalisé de TheCombinedWebs (zéro dépendance, Node 18+).
 *  • Liste blanche stricte d'hôtes (ce n'est PAS un proxy ouvert).
 *  • Ticket signé par le site (même PROXY_SECRET) : /s/<ticket>/<hôte>/<chemin>
 *  • Retire X-Frame-Options / CSP, réécrit les URL (HTML, CSS) et injecte un shim pour fetch / XHR / éléments dynamiques.
 *  • Pour les hôtes « isolés » (GTA) : COOP + COEP + CORP → crossOriginIsolated, donc SharedArrayBuffer et threads WASM.
 *  • Streaming (Range, gros fichiers WASM / données de jeu) sans limite de taille.
 */
const http = require("http");
const https = require("https");
const zlib = require("zlib");
const crypto = require("crypto");
const { AsyncLocalStorage } = require("async_hooks");
const dns = require("dns");
const net = require("net");
const scope = new AsyncLocalStorage();
const activeHosts = () => scope.getStore() || ALLOW;
function publicAddress(ip) {
  if (net.isIP(ip) === 6) return !/^(::|fc|fd|fe[89ab]|ff|2001:db8)/i.test(ip) && !ip.toLowerCase().includes("ffff:");
  const [a,b] = ip.split(".").map(Number);
  return net.isIP(ip) === 4 && a > 0 && a !== 10 && a !== 127 && a < 224 && !(a === 169 && b === 254) && !(a === 172 && b >= 16 && b <= 31) && !(a === 192 && (b === 168 || b === 0)) && !(a === 100 && b >= 64 && b <= 127) && !(a === 198 && (b === 18 || b === 19));
}
function safeLookup(host, options, cb) {
  dns.lookup(host, { all: true }, (err, addresses) => {
    if (err) return cb(err);
    if (!addresses.length || addresses.some(a => !publicAddress(a.address))) return cb(new Error("Adresse privée refusée"));
    cb(null, addresses[0].address, addresses[0].family);
  });
}

const PORT = Number(process.env.PORT) || 8080;
const csv = (v) => String(v || "").split(",").map((s) => s.trim().toLowerCase()).filter(Boolean);
const ALLOW = ["gta.deloskiyt.pl", "deloskiyt.pl", "*.deloskiyt.pl", "snokido.fr", "*.snokido.fr", ...csv(process.env.PROXY_ALLOW)];
const ISOLATE = new Set(["gta.deloskiyt.pl", ...csv(process.env.PROXY_ISOLATE)]);
const SITE_ORIGINS = csv(process.env.SITE_ORIGINS);
const TEST_UPSTREAM = process.env.PROXY_TEST_UPSTREAM || ""; // tests locaux uniquement (hôte:port en HTTP)
const MAX_TEXT = 12 * 1024 * 1024;
const secret = () => String(process.env.PROXY_SECRET || "");

/* ---------- Sécurité : hôtes et tickets ---------- */
function allowed(host) {
  host = String(host || "").toLowerCase();
  if (!/^[a-z0-9.-]+$/.test(host) || !host.includes(".") || /^[0-9.]+$/.test(host) || host === "localhost" || host.endsWith(".local") || host.endsWith(".internal")) return false;
  return activeHosts().some((a) => (a[0] === "*" ? host === a.slice(2) || host.endsWith(a.slice(1)) : host === a));
}
function verifyTicket(t) {
  try {
    if (!secret()) return false;
    const [body, sig] = String(t || "").split("."); if (!body || !sig) return false;
    const exp = crypto.createHmac("sha256", secret()).update(body).digest("hex");
    const a = Buffer.from(sig), b = Buffer.from(exp); if (a.length !== b.length || !crypto.timingSafeEqual(a, b)) return false;
    const p = JSON.parse(Buffer.from(body, "base64url").toString("utf8")); const now = Math.floor(Date.now() / (7 * 864e5));
    if (Array.isArray(p.hosts)) return typeof p.u === "string" && Number.isFinite(p.exp) && p.exp > Date.now() && p.exp <= Date.now() + 16 * 60_000 && p.hosts.length > 0 && p.hosts.length <= 30 && p.hosts.every(h => typeof h === "string" && /^(?:\*\.)?[a-z0-9.-]+$/.test(h));
    return p && (p.b === now || p.b === now - 1);
  } catch { return false; }
}

/* ---------- Réécriture ---------- */
function mapUrl(v, token, host) {
  const s = String(v || "").trim(); if (!s || /^(#|data:|blob:|javascript:|mailto:|tel:|about:)/i.test(s)) return v;
  try {
    if (s.startsWith("//") || /^https?:\/\//i.test(s)) { const a = new URL(s.startsWith("//") ? "https:" + s : s); return allowed(a.hostname) ? `/s/${token}/${a.hostname}${a.pathname}${a.search}${a.hash}` : v; }
    if (s[0] === "/") return `/s/${token}/${host}${s}`;
  } catch { /* URL invalide : laissée telle quelle */ }
  return v; // relative : se résout naturellement sous /s/<ticket>/<hôte>/…
}
function rewriteCss(css, token, host) {
  return css
    .replace(/url\(\s*(['"]?)([^'")]+)\1\s*\)/gi, (m, q, u) => `url(${q}${mapUrl(u, token, host)}${q})`)
    .replace(/@import\s+(['"])([^'"]+)\1/gi, (m, q, u) => `@import ${q}${mapUrl(u, token, host)}${q}`);
}
function shim(token, host) {
  const cfg = JSON.stringify({ t: token, h: host, a: activeHosts() });
  return `<script>(function(){var C=${cfg},T=C.t,AL=C.a,P="/s/"+T+"/";
function ok(h){h=String(h).toLowerCase();return AL.some(function(a){return a.charAt(0)==="*"?(h===a.slice(2)||h.slice(-(a.length-1))===a.slice(1)):h===a})}
var mm=/^\\/s\\/[^\\/]+\\/([^\\/]+)/.exec(location.pathname),CH=mm?decodeURIComponent(mm[1]):C.h;
function rw(u){try{if(u==null)return u;var s=String(u);if(!s||/^(#|data:|blob:|javascript:|mailto:|about:)/i.test(s)||s.indexOf(P)===0)return u;var a;
if(/^https?:\\/\\//i.test(s))a=new URL(s);else if(s.slice(0,2)==="//")a=new URL("https:"+s);else if(s.charAt(0)==="/")return P+CH+s;else return u;
if(a.origin===location.origin){return a.pathname.indexOf(P)===0?u:P+CH+a.pathname+a.search+a.hash}
if(ok(a.hostname))return P+a.hostname+a.pathname+a.search+a.hash;
try{console.warn("[TCB proxy] hote non autorise :",a.hostname)}catch(e){}return u}catch(e){return u}}
var of=window.fetch;if(of)window.fetch=function(i,o){try{if(typeof i==="string"||i instanceof URL)i=rw(i);else if(i&&i.url)i=new Request(rw(i.url),i)}catch(e){}return of.call(this,i,o)};
var ox=XMLHttpRequest.prototype.open;XMLHttpRequest.prototype.open=function(m,u){arguments[1]=rw(u);return ox.apply(this,arguments)};
function hook(p,k){var d=Object.getOwnPropertyDescriptor(p,k);if(!d||!d.set)return;Object.defineProperty(p,k,{get:d.get,set:function(v){d.set.call(this,rw(v))},configurable:true,enumerable:d.enumerable})}
[[HTMLScriptElement,"src"],[HTMLImageElement,"src"],[HTMLIFrameElement,"src"],[HTMLSourceElement,"src"],[HTMLMediaElement,"src"],[HTMLLinkElement,"href"],[HTMLAnchorElement,"href"],[HTMLEmbedElement,"src"],[HTMLObjectElement,"data"],[HTMLFormElement,"action"],[HTMLVideoElement,"poster"]].forEach(function(x){try{hook(x[0].prototype,x[1])}catch(e){}});
var sa=Element.prototype.setAttribute;Element.prototype.setAttribute=function(n,v){if(/^(src|href|action|poster|data|data-src)$/i.test(n))v=rw(v);return sa.call(this,n,v)};
var OW=window.Worker;if(OW){window.Worker=function(u,o){return new OW(rw(u),o)};window.Worker.prototype=OW.prototype}
if(navigator.sendBeacon){var sb=navigator.sendBeacon.bind(navigator);navigator.sendBeacon=function(u,d){return sb(rw(u),d)}}
var wo=window.open;window.open=function(u){if(u)arguments[0]=rw(u);return wo.apply(this,arguments)};
if(window.EventSource){var OE=window.EventSource;window.EventSource=function(u,o){return new OE(rw(u),o)};window.EventSource.prototype=OE.prototype}
["pushState","replaceState"].forEach(function(k){var o=history[k];history[k]=function(s,t,u){return o.call(this,s,t,u==null?u:rw(u))}});
if(navigator.serviceWorker)navigator.serviceWorker.register=function(){return Promise.reject(new Error("Service worker desactive par le proxy TCB"))};
})();</script>`;
}
function rewriteHtml(html, token, host) {
  let out = html
    .replace(/<meta[^>]+http-equiv\s*=\s*["']?content-security-policy[^>]*>/gi, "")
    .replace(/\sintegrity\s*=\s*(["']).*?\1/gi, "")
    .replace(/(\ssrcset\s*=\s*)(["'])(.*?)\2/gis, (m, a, q, v) => a + q + v.split(",").map((part) => { const p = part.trim().split(/\s+/); p[0] = mapUrl(p[0], token, host); return p.join(" "); }).join(", ") + q)
    .replace(/(\s(?:src|href|action|poster|formaction|data-src|data-href|data-url)\s*=\s*)(["'])(.*?)\2/gis, (m, a, q, v) => a + q + mapUrl(v, token, host) + q)
    .replace(/(<style[^>]*>)([\s\S]*?)(<\/style>)/gi, (m, a, css, b) => a + rewriteCss(css, token, host) + b);
  const s = shim(token, host);
  return /<head[^>]*>/i.test(out) ? out.replace(/<head[^>]*>/i, (m) => m + s) : s + out;
}

/* ---------- Proxy ---------- */
const SAFE = ["content-type", "content-length", "content-range", "accept-ranges", "etag", "last-modified", "content-encoding", "content-disposition", "cache-control", "vary", "expires"];
function outHeaders(h, host, extra) {
  const o = {}; for (const k of SAFE) if (h[k] != null) o[k] = h[k];
  o["cross-origin-resource-policy"] = "cross-origin";
  if (ISOLATE.has(host)) { o["cross-origin-embedder-policy"] = "require-corp"; o["cross-origin-opener-policy"] = "same-origin"; }
  o["content-security-policy"] = `frame-ancestors ${SITE_ORIGINS.length ? SITE_ORIGINS.join(" ") : "*"}`;
  o["referrer-policy"] = "no-referrer";
  return Object.assign(o, extra);
}
const plain = (res, code, msg) => { res.writeHead(code, { "content-type": "text/plain; charset=utf-8", "cache-control": "no-store", "cross-origin-resource-policy": "cross-origin" }); res.end(msg); };

function proxy(req, res, token, host, path, query) {
  const doc = /(^\/$)|(\.(html?|css)$)|(\/[^./]*$)/i.test(path); // documents / CSS : on demande du texte brut pour pouvoir le réécrire
  const headers = { host, "user-agent": req.headers["user-agent"] || "Mozilla/5.0", accept: req.headers.accept || "*/*", "accept-language": req.headers["accept-language"] || "fr,en;q=0.8", referer: `https://${host}/`, "accept-encoding": doc ? "identity" : (req.headers["accept-encoding"] || "identity") };
  for (const k of ["range", "if-none-match", "if-modified-since"]) if (req.headers[k]) headers[k] = req.headers[k];
  const [thost, tport] = TEST_UPSTREAM ? TEST_UPSTREAM.split(":") : [host, 443];
  const ureq = (TEST_UPSTREAM ? http : https).request({ hostname: thost, port: Number(tport), path: path + query, method: req.method, headers, servername: host, timeout: 30000, ...(TEST_UPSTREAM ? {} : { lookup: safeLookup }) }, (ur) => {
    const code = ur.statusCode || 502, h = ur.headers;
    if (code >= 300 && code < 400 && h.location) { // redirections : on reste dans le proxy
      ur.resume();
      try {
        const u = new URL(h.location, `https://${host}${path}`);
        if (!allowed(u.hostname)) { console.log("[bloqué] redirection vers", u.hostname); return plain(res, 502, "Redirection vers un hôte non autorisé : " + u.hostname); }
        res.writeHead(code, outHeaders({}, host, { location: `/s/${token}/${u.hostname}${u.pathname}${u.search}`, "cache-control": "no-store" })); return res.end();
      } catch { return plain(res, 502, "Redirection invalide"); }
    }
    const ctype = String(h["content-type"] || "").toLowerCase(); const isHtml = ctype.includes("text/html"), isCss = ctype.includes("text/css");
    if ((isHtml || isCss) && req.method !== "HEAD" && code === 200) {
      let stream = ur; const enc = String(h["content-encoding"] || "").toLowerCase();
      if (enc === "gzip") stream = ur.pipe(zlib.createGunzip()); else if (enc === "br") stream = ur.pipe(zlib.createBrotliDecompress()); else if (enc === "deflate") stream = ur.pipe(zlib.createInflate());
      const chunks = []; let size = 0;
      stream.on("data", (c) => { size += c.length; if (size > MAX_TEXT) { ureq.destroy(); return; } chunks.push(c); });
      stream.on("error", () => plain(res, 502, "Erreur de lecture amont"));
      stream.on("end", () => {
        if (size > MAX_TEXT) return plain(res, 502, "Document trop volumineux");
        const text = Buffer.concat(chunks).toString("utf8"); const body = Buffer.from(isHtml ? rewriteHtml(text, token, host) : rewriteCss(text, token, host));
        const oh = outHeaders(h, host, { "content-length": String(body.length), "cache-control": "no-store" }); delete oh["content-encoding"]; delete oh["etag"];
        res.writeHead(200, oh); res.end(body);
      });
      return;
    }
    const extra = {}; if (!h["cache-control"] && code === 200) extra["cache-control"] = "public, max-age=86400";
    res.writeHead(code, outHeaders(h, host, extra)); if (req.method === "HEAD") { ur.resume(); return res.end(); }
    ur.pipe(res); ur.on("error", () => res.destroy());
  });
  ureq.on("timeout", () => ureq.destroy(new Error("timeout")));
  ureq.on("error", (e) => { if (!res.headersSent) plain(res, 502, "Hôte injoignable : " + host + " (" + (e.code || e.message) + ")"); else res.destroy(); });
  req.on("close", () => ureq.destroy());
  ureq.end();
}

function handleScoped(req, res) {
  if (req.url === "/health") { res.writeHead(200, { "content-type": "application/json" }); return res.end(JSON.stringify({ ok: true, service: "tcb-proxy", hosts: ALLOW.length })); }
  const m = /^\/s\/([^/]+)\/([^/?#]+)(\/[^?#]*)?(\?[^#]*)?/.exec(req.url || "");
  if (!m) return plain(res, 404, "TCB Proxy");
  if (req.method !== "GET" && req.method !== "HEAD") return plain(res, 405, "Méthode non autorisée");
  if (!verifyTicket(m[1])) return plain(res, 401, "Ticket expiré ou invalide : recharge la page du site.");
  let host; try { host = decodeURIComponent(m[2]).toLowerCase(); } catch { return plain(res, 400, "Hôte invalide"); }
  if (!allowed(host)) { console.log("[bloqué]", host); return plain(res, 403, "Hôte non autorisé : " + host + " (ajoute-le dans PROXY_ALLOW)"); }
  proxy(req, res, m[1], host, m[3] || "/", m[4] || "");
}
function handler(req, res) {
  const m = /^\/s\/([^/]+)\//.exec(req.url || "");
  if (m && verifyTicket(m[1])) {
    const p = JSON.parse(Buffer.from(m[1].split(".")[0], "base64url").toString("utf8"));
    return scope.run(p.hosts || ALLOW, () => handleScoped(req, res));
  }
  return handleScoped(req, res);
}

module.exports = { allowed, verifyTicket, rewriteHtml, rewriteCss, mapUrl, handler };
if (require.main === module) http.createServer(handler).listen(PORT, () => console.log(`TCB Proxy sur :${PORT} · ${ALLOW.length} hôtes autorisés`));
