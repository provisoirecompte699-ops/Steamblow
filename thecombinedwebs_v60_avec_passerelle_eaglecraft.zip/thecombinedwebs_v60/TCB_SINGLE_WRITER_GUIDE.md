# TCB_SINGLE_WRITER — déploiement sûr

Les opérations économiques protégées par `lib/feature-lock.ts` demandent un processus Node unique qui est l’unique écrivain, avec stockage persistant. Les verrous en mémoire ne synchronisent pas plusieurs instances ou fonctions serverless.

## Netlify / fonctions serverless

- **Ne définis pas** `TCB_SINGLE_WRITER=true` dans les variables d’environnement Netlify.
- Ne l’ajoute pas à plusieurs fonctions indépendantes : cela ne crée pas un verrou global et ne rend pas les transactions atomiques.
- Les opérations concernées restent volontairement bloquées tant que l’application tourne dans cette architecture. Pour les activer sur plusieurs instances, migrer d’abord les mutations vers une base transactionnelle.

## Serveur Node dédié (une seule instance)

1. Déployer l’application Next.js sur un serveur que tu contrôles, avec un seul processus/une seule instance active.
2. Configurer un dossier de données persistant avec `TCB_DATA_DIR`. Sauvegarder ce dossier régulièrement.
3. Dans l’environnement **de ce serveur dédié uniquement**, définir `TCB_SINGLE_WRITER=true`. Ne pas mettre cette variable dans le dépôt Git.
4. Lancer l’application avec `npm run start` après `npm run build`. Ne pas lancer de deuxième instance, de worker d’écriture ou de fonction serverless qui modifie les mêmes données.
5. Si tu actives le scaling horizontal, retire cette variable et migre vers un stockage transactionnel partagé avant de réactiver ces opérations.

Cette variable est une déclaration d’architecture, pas un mécanisme qui transforme un déploiement multi-instance en serveur mono-écrivain.

Les fonctionnalités IA et le mode de maintenance automatique ont été retirés de cette archive.
