# TheCombinedWebs v52 — nouveautés

## Compétition
- **Classements** (`/classements`) : top par jeu, semaine (ISO) et depuis toujours, filtre « amis ». Le N°1 de chaque jeu reçoit **150 Bobux** et le badge « N°1 de la semaine » (versé automatiquement à la première visite de la semaine suivante).
- **Défi du jour** : un jeu arcade tiré chaque jour, même graine aléatoire pour tout le monde (`?daily=1`), jouable même sans posséder le jeu, +100 XP à la première partie, 50 Bobux au meilleur.
- **Tournois** (`/tournois`) : 4 ou 8 joueurs, tableau tiré au sort (byes automatiques), un match = une tentative chacun sur la même carte, bracket en direct, **200 Bobux** + badge Champion.
- **Rediffusions** : chaque partie arcade est enregistrée (WebM, 60 s max) → Revoir / Télécharger / Partager dans #jeux sur Discord (`/replay/<id>`, lecture directe dans le chat).
- **Éditeur de niveaux** (`/editeur`) : sol, murs, caisses, point de départ, symétrie, 3 tailles ; cartes jouables dans Meteor Mayhem, Neon Tag, Crystal Rush, Block Brawl, Cyber Siege, Neon Arena (`?map=<id>`), likes, compteur de parties, badge Créateur après 3 cartes.

## Social
- **Profils publics** (`/u/<pseudo>`) : avatar avec bordure, effet de pseudo, statut, bio, badges (Fondateur, Co-fondateur, Modérateur, Ami de Walid, Champion…), niveau, passe, meilleurs scores, rediffusions, avis ciné, bouton ami.
- **Clans** (`/clans`) : nom, tag, logo emoji, couleur, devise, public/privé (code), 20 membres, chef qui peut exclure, salon texte et vocal privés dans Discord, classement par XP cumulée.
- **Discord** : partage d’écran (ordinateur), cosmétiques visibles (bordures, pseudos, sons d’arrivée en vocal), liens vers les profils, bouton 🚩 Signaler → section « Signalements Discord » de la page admin (supprimer, demander un ban, ignorer), +2 XP par message (40/jour max).
- **Soirée ciné** (CinéStream) : créer/rejoindre avec un code ou un lien, l’hôte choisit le film, compte à rebours commun de 5 s, chat et salon vocal intégrés.

## Progression
- **Niveau et XP** : parties arcade, défi, tournoi, messages, films ouverts, avis. Chaque niveau = 20 Bobux.
- **Passe de saison** (`/passe`) mensuel, 30 paliers gratuits (Bobux, bonus XP, cosmétiques exclusifs).
- **Boutique de cosmétiques** en Bobux : bordures d’avatar, effets de pseudo, sons d’arrivée en vocal.
- **Thèmes** : Sombre, Néon, Minimal clair, Rétro pixel (appliqués partout, mémorisés).

## CinéStream
- Rangées **Reprendre** (série : saison/épisode exact), **Ma liste**, **Recommandé pour toi**.
- Dans la fiche : + Ma liste, note sur 5, avis, avis des amis en premier, moyenne.
- Reprise à la seconde près pour les fichiers vidéo locaux. Les lecteurs externes (iframes tierces) ne permettent pas de lire la position : la reprise se fait à l’épisode.

## Application
- **PWA** : `manifest.webmanifest`, icônes, bouton « Installer », raccourcis (Discord, CinéStream, Défi du jour), notifications système d’appel et de message quand l’onglet est en arrière-plan.
- **APK Android** (`android/`) : WebView plein écran avec micro (chat vocal), notifications d’appel/message, plein écran vidéo, envoi de fichiers, bouton retour, liens externes dans le navigateur, téléchargements.
  - Construire : `SITE_URL=https://ton-site.netlify.app ./android/build-apk.sh` (Android SDK build-tools 34 + JDK 17, sans Gradle).
  - Sans `SITE_URL`, l’app demande l’adresse du site au premier lancement (modifiable sur l’écran d’erreur).
  - L’APK fourni est signé avec une clé de test : pour le Play Store, signer avec ta propre clé (`KEYSTORE=… KS_PASS=…`).

## Limites connues
- Notifications quand l’application est complètement fermée : nécessiteraient un service push (Firebase Cloud Messaging / VAPID). Ici, elles arrivent tant que l’app ou l’onglet tourne en arrière-plan.
- Partage d’écran : ordinateur uniquement (Android/iOS ne le permettent pas dans un navigateur/WebView).
- Vocal sur réseaux très fermés : prévoir un serveur TURN (`NEXT_PUBLIC_TURN_URL`, voir README v51).
- Rediffusions : stockées en base64 (4 Mo max chacune) dans le stockage Netlify Blobs.
