# TheCombinedWebs Launcher Android

Cette version ajoute un launcher Android natif dans `android-launcher/`.

- Application ID : `com.steamblox.launcher`
- Nom : TheCombinedWebs
- URL chargée : `https://steambloxcommunity.netlify.app/steamblox`
- JavaScript, DOM storage et audio activés
- Navigation retour Android prise en charge
- Orientation libre téléphone/tablette

## APK

Le code source Android est prêt à être ouvert dans Android Studio. La compilation nécessite Android SDK 35 et Gradle/Android Studio. L'environnement de génération actuel ne contient pas le SDK Android, donc aucun faux `.apk` vide n'est fourni.
