# v58 — Renommage TheCombinedWebs

- Le site s'appelle désormais **TheCombinedWebs** (textes visibles, titres, pages d'erreur, connexion, inscription, CinéStream, Vortex, docs, app Android).
- Tous les logos affichent **TCB** (barre du hub, tableau de bord, Discord, sélecteur de plateforme, écran de chargement, icônes PWA et Android, bannière TV).
- Nom court de l'application installée : **TCB**.
- Conservés volontairement (pour ne pas casser les comptes et les données) : route `/steamblox`, clés `localStorage` `steamblox:*`, identifiant Android `com.steamblox.app`, nom du dépôt GitHub.

# v58 — TCB Plus (nouveau : page `/tcb`)

Ajouté (hors algèbre, comme demandé) :
- **Recherche globale** (`/` ou Ctrl+K) : jeux, joueurs, pages. **Raccourcis clavier** (`?` pour l'aide, `g` puis `j/d/c/t/p/a`), désactivés dans les jeux.
- **Jeu du jour** (+25 Bobux après une partie arcade), **badges & titres** à équiper.
- **Stories éphémères 24 h** visibles par toi et tes amis (5 max par jour).
- **Statut « en jeu »** : tes amis voient à quoi tu joues et peuvent rejoindre.
- **Groupes thématiques** (Speedrun, Cinéphiles, Coop, Arcade, Créateurs) avec lien vers Discord.
- **Parrainage** : code ou lien `?ref=Pseudo`, +100 Bobux pour les deux (20 filleuls max par parrain).
- **Sauvegarde / restauration** des réglages locaux en un fichier JSON.
- **Économie de données** (coupe animations et flous), **mode hors-ligne** (service worker v10 : réseau d'abord, cache en secours).
- **Contrôle parental** : PIN, limite quotidienne, jeux masqués.
- **Signalements** avec file de modération (statut, note, auteur de la décision).

Existait déjà et n'a pas été refait : thèmes (ThemeCustomizer), recommandations CinéStream, notifications, passe de saison, éditeur de niveaux, tournois, échanges de Bobux.

Pas encore fait (demande un vrai temps réel ou un travail dédié) : watch party synchronisée, matchmaking rapide, mode spectateur, boss coopératif, tournoi express, sous-titres/audio au choix, notation des niveaux de l'éditeur.

# v58 (suite) — Temps réel, IA de maintenance, troll, easter egg

## Temps réel (serveur `multiplayer-server`, socket.io)
Netlify ne gère pas les WebSockets : le temps réel passe par `multiplayer-server/` hébergé à part (Render, Fly, Railway…, voir DEPLOY_MULTIPLAYER.md).
Nouveautés côté serveur : `tcb:auth` (jeton HMAC de service, même `REALTIME_SECRET` que le site), **matchmaking** (`mm:*`), **salons de visionnage synchronisés** (`wp:*` : horloge commune, compte à rebours, chat), **mode spectateur** (`spec:*`, vue radar), compteur de joueurs en ligne.
Interface : TCB Plus → onglet **Temps réel**. Les lecteurs intégrés de CinéStream ne sont pas pilotables : le salon synchronise une horloge et un « GO » commun.

## Fonctionnalités retirées dans cette archive

L’IA et les cycles automatiques de maintenance décrits dans les versions historiques ne sont plus inclus dans cette version. La taxe journalière se règle lors des opérations bancaires des joueurs ; le balayage global planifié a été retiré avec l’ancien cycle IA.

## Troll
Effets visuels inoffensifs (écran retourné, miroir, secousse, rotation, arc-en-ciel, zoom, confettis, faux plantage qui se ferme seul). Amis uniquement (1/min) ; la modération peut cibler tout le monde (5 s). Désactivable par chaque joueur. Pas d'effet pendant une partie.

## Easter egg BOBUXTIME
10 clics rapides sur le logo TCB (bouton en bas à droite ou logo des barres) → « Donner un code » → `BOBUXTIME` (changeable via `TCB_EASTER_CODE`) → mini-jeu de 30 s. Gain vérifié côté serveur : 5 parties par jour, 80 Bobux max par partie.

## Bobux
Plafond de 999 999 999 pour tout le monde ; le compte créateur **Younes** est toujours à la valeur maximale.

# v58 (suite) — TCB Banque & abonnement Premium (TCB Plus → onglet « Banque »)

- **Compte courant** = ton solde de Bobux, avec numéro de compte `TCB-XXXX-XXXX-XXXX` et relevé des opérations.
- **Épargne** : dépôts et retraits, intérêts de 0,5 % par jour (1 % avec Premium) sur les 5 000 premiers Bobux (50 000 avec Premium), versés à la prochaine visite, 30 jours maximum à la fois. **Objectif d'épargne** avec barre de progression.
- **Virements** à n'importe quel joueur : 500 Bobux par jour (5 000 avec Premium), message optionnel, annulation automatique si le virement échoue.
- **Abonnement TCB Premium** : 500 Bobux pour 30 jours, renouvellement automatique annulable. Avantages : intérêts doublés, plafonds relevés, jeu du jour à 50 Bobux, 10 stories par jour, titre 💎 Premium. Le renouvellement est prélevé à la première visite après l'échéance ; si le solde est insuffisant, l'abonnement s'arrête sans frais.
- Monnaie virtuelle uniquement : aucun paiement en argent réel (un abonnement Stripe serait un autre chantier).
- Les plafonds et les taux se règlent dans `lib/tcb-bank.ts` (`LIMITS`, `PLAN`).

# v58 (suite) — Taxe journalière reversée au créateur

- Chaque jour, **0,2 %** des Bobux d'un joueur (compte courant + épargne) au-delà de **1 000** est prélevé, **200 Bobux maximum par jour** ; **0,1 %** avec Premium. Sous 1 000 Bobux : aucune taxe.
- Le prélèvement est pris d'abord sur le compte courant, puis sur l'épargne. Il apparaît dans le relevé.
- Tout revient au créateur **Younes**, qui est exempté. Son solde étant toujours au maximum, la taxe s'accumule dans un **Trésor du créateur** (total, gain du jour, détail sur 14 jours), visible dans TCB Plus → Banque.
- Application : à la première visite de chaque joueur chaque jour (rattrapage de 7 jours maximum) lors de ses visites (rattrapage de 7 jours maximum). Un joueur n'est jamais taxé deux fois le même jour.
- Réglages : `TAX` dans `lib/tcb-bank.ts`.

# v59 — Proxy TCB : Snokido + GTA Web
Voir `PROXY_SERVER.md`. Nouveau : `proxy-server/` (proxy personnalisé), page `/games/snokido`, GTA Web via le proxy avec isolation cross-origin, ticket signé `/api/proxy/ticket`. Taxe quotidienne : la fonction planifiée n'exige plus de `TCB_CRON_TOKEN` et chaque visite fait avancer le prélèvement.
