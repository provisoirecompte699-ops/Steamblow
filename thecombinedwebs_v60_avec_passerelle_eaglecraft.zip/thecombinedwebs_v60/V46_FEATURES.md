# TheCombinedWebs V46

- Mémoire liée au compte TheCombinedWebs via `User.aiConversations`; mémoire locale de secours sans compte.
- Historique : jusqu’à 20 conversations, 40 messages conservés par conversation.
- Suppression et effacement des conversations.
- Aucun quota de messages ajouté par TheCombinedWebs.
- Nouveau jeu original multijoueur **Rooftop Rivals**, avec salons privés et chat vocal.
- Optimisation majeure de Neon Arena : boucle graphique stable, joueurs en `ref`, réseau limité à ~30 Hz et affichage du score limité.
- Réduction de certains appels de surveillance en arrière-plan : session 30 s, annonces 20 s.
- Correction d’une erreur de syntaxe dans Crystal Rush qui bloquait le contrôle TypeScript.
