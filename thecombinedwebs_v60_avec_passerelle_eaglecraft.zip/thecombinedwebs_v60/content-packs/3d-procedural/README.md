# Procedural 3D asset pack

512 GLB content files are included as a large optional asset pack. The application does not load the entire pack at startup. Individual assets can be selected by a future content loader.
