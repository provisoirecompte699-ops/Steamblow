import assert from "node:assert/strict";
import { mkdtemp, readdir, readFile, writeFile, rm } from "node:fs/promises";
import os from "node:os";
import path from "node:path";
import { createHash } from "node:crypto";
import { newSession, readSession, revokeSession } from "../lib/session-store";
import { safeNext } from "../lib/login-redirect";

async function main() {
  const dir = await mkdtemp(path.join(os.tmpdir(), "tcb-session-test-"));
  const before = { ...process.env };
  try {
    process.env.TCB_DATA_DIR = dir;
    process.env.NETLIFY = "false";
    Object.assign(process.env, { NODE_ENV: "production" });
    const tokens = await Promise.all(Array.from({ length: 32 }, () => newSession("TestCreator")));
    assert.equal(new Set(tokens).size, 32);
    assert.ok(tokens.every((t) => /^[A-Za-z0-9_-]{43}$/.test(t)));
    const files = await readdir(path.join(dir, "sessions"));
    assert.equal(files.length, 32);
    assert.ok(files.every((file) => !tokens.some((t) => file.includes(t))));
    assert.equal((await readSession(tokens[0]))?.username, "TestCreator");
    assert.equal(await readSession(tokens[0].slice(0, -1)), null);
    assert.equal(await readSession("../users.json"), null);
    assert.equal(await readSession("x".repeat(43)), null);
    await revokeSession(tokens[0]);
    assert.equal(await readSession(tokens[0]), null);
    assert.equal((await readSession(tokens[1]))?.username, "TestCreator");
    await revokeSession(tokens[0]);
    const expiredFile = path.join(dir, "sessions", createHash("sha256").update(tokens[1]).digest("hex") + ".json");
    const expired = JSON.parse(await readFile(expiredFile, "utf8"));
    expired.expiresAt = Date.now() - 1000;
    await writeFile(expiredFile, JSON.stringify(expired));
    assert.equal(await readSession(tokens[1]), null);
    for (const bad of ["https://example.com", "//example.com", "/\\evil", "/login", null]) assert.equal(safeNext(bad), "/steamblox");
    assert.equal(safeNext("/portails"), "/portails");
    assert.equal(safeNext("/games/meteor-mayhem"), "/games/meteor-mayhem");
    console.log("PASS Production sans configuration de clé : 32 sessions aléatoires indépendantes, stockage par empreinte.");
    console.log("PASS Session invalide, altérée, inconnue, expirée ; révocation durable et indépendante.");
    console.log("PASS Redirections internes sûres.");
  } finally {
    for (const key of Object.keys(process.env)) if (!(key in before)) delete process.env[key];
    Object.assign(process.env, before);
    await rm(dir, { recursive: true, force: true });
  }
}
main().catch((error) => { console.error(error); process.exitCode = 1; });
