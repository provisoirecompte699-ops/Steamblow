// Browser QA fixture only: refuses to write to the original account directory.
import { promises as fs } from "node:fs";
import path from "node:path";
import { hashLocalPassword } from "../lib/passwords";
async function main() {
  const directory=process.env.TCB_DATA_DIR;
  if(!directory||!directory.endsWith("/reset-qa-data"))throw new Error("Dossier reset-qa-data isolé requis.");
  await fs.mkdir(directory,{recursive:true});
  const passwordHash=await hashLocalPassword("Reset-QA-Only-123!");
  const base={passwordHash,owned:["meteor-mayhem"],bobux:823,banned:false,achievements:["first_game"],playTimeMinutes:81,lastLoginDate:new Date().toISOString().slice(0,10),loginStreak:1};
  await fs.writeFile(path.join(directory,"users.json"),JSON.stringify({
    democreateur:{...base,username:"DemoCreateur",role:"creator"},
    moustafa:{...base,username:"Moustafa",role:"vice_creator"},
    demojoueur:{...base,username:"DemoJoueur",role:"user"},
  }));
  console.log("Comptes de contrôle isolés préparés.");
}
main().catch(error=>{console.error(error);process.exitCode=1;});
