import assert from "node:assert/strict";
import { spawnSync } from "node:child_process";
import { mkdtemp, readdir, readFile, rm } from "node:fs/promises";
import os from "node:os";
import path from "node:path";

const directory=await mkdtemp(path.join(os.tmpdir(),"tcb-netlify-build-"));
try {
  const env={...process.env};
  // The build must not require the runtime-only Netlify Blobs context.
  for(const key of Object.keys(env))if(key.startsWith("NETLIFY_"))delete env[key];
  Object.assign(env,{NETLIFY:"true",NODE_ENV:"production",TCB_DATA_DIR:directory,NEXT_DIST_DIR:".next-build",NEXT_TELEMETRY_DISABLED:"1"});
  const result=spawnSync(process.platform==="win32"?"npm.cmd":"npm",["run","build"],{env,stdio:"inherit"});
  if(result.error)throw result.error;
  assert.equal(result.status,0,"Le build Netlify sans stockage doit réussir.");
  const manifest=JSON.parse(await readFile(".next-build/prerender-manifest.json","utf8"));
  for(const route of ["/admin","/steamblox","/games/3d","/account","/login"])assert.equal(manifest.routes[route],undefined,`${route} ne doit pas être pré-rendue.`);
  assert.deepEqual(await readdir(directory),[],"Le build ne doit écrire aucun compte, session ou progression.");
  console.log("PASS Build NETLIFY=true sans contexte Blobs ; pages authentifiées non pré-rendues, aucune écriture de données.");
} finally {await rm(directory,{recursive:true,force:true});}
