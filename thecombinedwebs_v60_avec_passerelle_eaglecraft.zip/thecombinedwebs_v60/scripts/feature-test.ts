import assert from "node:assert/strict";
import { promises as fs } from "node:fs";
import os from "node:os";
import path from "node:path";
import { randomUUID } from "node:crypto";
async function main() {
  const dir = await fs.mkdtemp(path.join(os.tmpdir(), "tcb-v60-test-"));
  process.env.TCB_DATA_DIR = dir;
  process.env.NETLIFY = "false";
  const fixture = (username: string, role = "user") => ({
    username,
    role,
    passwordHash: "test-only",
    owned: ["meteor-mayhem"],
    banned: false,
    bobux: 10000,
    joinedAt: new Date().toISOString(),
    friends: ["Alpha", "Beta", "Gamma"].filter((x) => x !== username),
  });
  await fs.writeFile(
    path.join(dir, "users.json"),
    JSON.stringify({
      alpha: fixture("Alpha", "creator"),
      beta: fixture("Beta"),
      gamma: fixture("Gamma"),
    }),
  );
  const { getUser, saveUser } = await import("../lib/store");
  const { credit, spend, balance } = await import("../lib/bobux");
  const {
    economyAction,
    economyState,
    lotteryPeriod,
    dailyShop,
    settleLottery,
    nextMidnight,
  } = await import("../lib/economy");
  const { getJSON, setJSON } = await import("../lib/data-store");
  const { getAcct, treasuryView } = await import("../lib/tcb-bank");
  const { startEvent, eventAction, treasureToken } =
    await import("../lib/live-events");
  const { riskAction, riskDuelsFor } = await import("../lib/risk-duels");
  const { duelAction, duelsFor, scoreDuel } = await import("../lib/duels");
  const {
    savePortal,
    indexPortal,
    allGames,
    libraryAction,
    library,
    publicAddress,
    portalUrl,
  } = await import("../lib/portals");
  const { writeCloudSave, cloudSave } = await import("../lib/cloud-saves");
  const results: string[] = [];
  const pass = (s: string) => {
    results.push(s);
    console.log("PASS", s);
  };
  await Promise.all(
    Array.from({ length: 20 }, () =>
      credit("Beta", 10, "Test", "Concurrent", "gift"),
    ),
  );
  assert.equal(await balance("Beta"), 10200);
  pass("Crédits concurrents conservés");
  const before = await balance("Beta");
  await Promise.all([
    credit("Beta", 10, "Test", "Idempotent", "gift", "test-credit"),
    credit("Beta", 10, "Test", "Idempotent", "gift", "test-credit"),
  ]);
  assert.equal(await balance("Beta"), before + 10);
  pass("Crédit idempotent");
  const stale = (await getUser("Beta"))!;
  await credit("Beta", 10, "Test", "Concurrent profil", "gift");
  stale.bio = "test";
  await saveUser(stale);
  assert.equal(await balance("Beta"), before + 20);
  pass("Profil périmé ne réécrit pas le solde bancaire");
  assert.equal(dailyShop().items.length, 4);
  assert.deepEqual(dailyShop().items, dailyShop().items);
  assert.equal(
    nextMidnight(Date.parse("2026-10-24T23:30:00Z")),
    Date.parse("2026-10-25T23:00:00Z"),
  );
  pass("Boutique déterministe et minuit Paris au changement d'heure");
  const item = dailyShop().items[0];
  await economyAction("Beta", { action: "buy", id: item.id });
  assert.ok((await getUser("Beta"))?.cosmetics?.owned.includes(item.id));
  await assert.rejects(economyAction("Beta", { action: "buy", id: item.id }));
  pass("Achat cosmétique et rejet du double achat");
  await startEvent("Alpha", { type: "golden", minutes: 30 });
  const b = await balance("Beta");
  await credit("Beta", 10, "Test", "Quête", "quest");
  await credit("Beta", 10, "Alpha", "Transfert", "gift");
  assert.equal(await balance("Beta"), b + 30);
  pass("Heure dorée double les récompenses, pas les transferts");
  const chest = (await economyAction("Beta", {
    action: "chest",
    kind: "daily",
  })) as any;
  assert.ok([40, 100, 200, 1000].includes(chest.reward));
  await assert.rejects(
    economyAction("Beta", { action: "chest", kind: "daily" }),
  );
  pass("Coffre quotidien unique et récompense doublée");
  await economyAction("Alpha", {
    action: "offer-loan",
    borrower: "Beta",
    amount: 100,
    rate: 10,
    days: 7,
  });
  const loan = (await economyState("Beta")).loans[0];
  const lenderBefore = await balance("Alpha"),
    borrowerBefore = await balance("Beta");
  await economyAction("Beta", { action: "accept-loan", id: loan.id });
  assert.equal(await balance("Alpha"), lenderBefore - 100);
  assert.equal(await balance("Beta"), borrowerBefore + 100);
  await economyAction("Beta", {
    action: "repay-loan",
    id: loan.id,
    amount: 50,
  });
  assert.equal((await economyState("Beta")).loans[0].remaining, 60);
  await economyAction("Beta", {
    action: "repay-loan",
    id: loan.id,
    amount: 60,
  });
  assert.equal((await economyState("Beta")).loans[0].status, "paid");
  pass("Prêt consenti et remboursement partiel incluant les intérêts");
  const prior = await balance("Gamma"),
    amount = prior + 500;
  await assert.rejects(
    economyAction("Gamma", {
      action: "roulette",
      stake: amount,
      choice: "red",
      requestId: randomUUID(),
    }),
  );
  const rid = randomUUID();
  const spin = (await economyAction("Gamma", {
    action: "roulette",
    stake: amount,
    choice: "red",
    acceptDebt: true,
    requestId: rid,
  })) as any;
  assert.equal(spin.borrowed, 500);
  assert.equal((await getAcct("Gamma")).overdraftUsed, spin.won ? 0 : 500);
  assert.equal(await balance("Gamma"), spin.won ? amount * 2 - 500 : 0);
  const after = await balance("Gamma");
  await economyAction("Gamma", {
    action: "roulette",
    stake: amount,
    choice: "red",
    acceptDebt: true,
    requestId: rid,
  });
  assert.equal(await balance("Gamma"), after);
  pass(
    "Roulette, dette bancaire réelle, remboursement prioritaire et anti-rejeu",
  );
  await credit("Gamma",1000,"Test","Préparation reprise","gift");
  const recoveryId=randomUUID(),op=`roulette:gamma:${recoveryId}`,cash=await balance("Gamma"),debtBefore=(await getAcct("Gamma")).overdraftUsed||0;
  await spend("Gamma",cash,"Débit avant interruption",`${op}:stake`);
  await setJSON("tcb-economy",op,{username:"Gamma",requestId:recoveryId,at:Date.now(),stake:cash+50,choice:"red",result:"black",won:false,payout:0,borrowed:50,cashDebit:cash,settled:false,message:"Opération reprise"});
  await economyAction("Gamma",{action:"roulette",stake:cash+50,choice:"red",acceptDebt:true,requestId:recoveryId});
  assert.equal(await balance("Gamma"),0);assert.equal((await getAcct("Gamma")).overdraftUsed,debtBefore+50);
  pass("Reprise d'une roulette interrompue sans second débit");
  const treasure = await startEvent("Alpha", {
    type: "treasure",
    minutes: 30,
    reward: 100,
    page: "/portails",
  });
  const race = await Promise.allSettled([
    eventAction("Alpha", treasure.id, "find", treasureToken(treasure, "Alpha")),
    eventAction("Beta", treasure.id, "find", treasureToken(treasure, "Beta")),
  ]);
  assert.equal(race.filter((r) => r.status === "fulfilled").length, 1);
  pass("Un seul gagnant du trésor même en concurrence");
  const boss = await startEvent("Alpha", {
    type: "boss",
    minutes: 30,
    reward: 100,
    hp: 100,
  });
  await eventAction("Alpha", boss.id, "attack");
  await assert.rejects(eventAction("Alpha", boss.id, "attack"));
  const bb = await eventAction("Beta", boss.id, "attack");
  assert.equal(bb.hp, 50);
  pass("Boss commun et cadence d'attaque contrôlée côté serveur");
  await savePortal({
    id: "test",
    name: "Portail test",
    url: "https://games.example.org/",
    hosts: "games.example.org, *.example.org",
  });
  await indexPortal("test", [
    { title: "Mon jeu test", url: "https://games.example.org/game/one" },
  ]);
  const game = (await allGames()).find((g) => g.title === "Mon jeu test")!;
  await libraryAction("Beta", game.id, "favorite");
  await libraryAction("Beta", game.id, "recent");
  assert.ok((await library("Beta")).favorites.includes(game.id));
  assert.equal((await library("Beta")).recent[0].id, game.id);
  await assert.rejects(
    savePortal({ name: "Local", url: "https://127.0.0.1", hosts: "127.0.0.1" }),
  );
  assert.throws(() => portalUrl("https://evil.org", ["games.example.org"]));
  assert.equal(publicAddress("127.0.0.1"), false);
  assert.equal(publicAddress("::ffff:127.0.0.1"), false);
  pass("Portail sans code, index, favoris/récents et protection SSRF");
  await writeCloudSave(
    "Beta",
    "meteor-mayhem",
    { bestScore: 500, achievements: ["first_game"], difficulty: "hard" },
    0,
  );
  assert.equal((await cloudSave("Beta", "meteor-mayhem")).data.bestScore, 500);
  assert.equal((await cloudSave("Alpha", "meteor-mayhem")).version, 0);
  await assert.rejects(
    writeCloudSave(
      "Beta",
      "meteor-mayhem",
      { bestScore: 600, achievements: [], difficulty: "normal" },
      0,
    ),
  );
  pass("Cloud par compte et conflit de version");
  const r = (await riskAction("Alpha", {
    action: "create",
    to: "Beta",
    stake: 100,
  })) as any;
  assert.equal(r.duel.trap, undefined);
  await riskAction("Beta", { action: "accept", id: r.duel.id });
  let duel = (await riskDuelsFor("Alpha")).find((x) => x.id === r.duel.id)!;
  const initialTotal = (await balance("Alpha")) + (await balance("Beta"));
  while (duel.status === "active") {
    const actor = duel.turn,
      wrong = actor === "Alpha" ? "Beta" : "Alpha";
    await assert.rejects(
      riskAction(wrong, {
        action: "play",
        id: duel.id,
        position: duel.position,
      }),
    );
    const oldPosition = duel.position;
    const v = (await riskAction(actor, {
      action: "play",
      id: duel.id,
      position: oldPosition,
    })) as any;
    duel = v.duel;
    await assert.rejects(
      riskAction(actor, { action: "play", id: duel.id, position: oldPosition }),
    );
  }
  assert.equal(duel.status, "finished");
  assert.ok(duel.moves.length <= 6);
  assert.equal(
    (await balance("Alpha")) + (await balance("Beta")),
    initialTotal + 200,
  );
  await riskDuelsFor("Alpha");
  assert.equal(
    (await balance("Alpha")) + (await balance("Beta")),
    initialTotal + 200,
  );
  pass(
    "Roulette russe : tours, tirage caché, élimination virtuelle, cagnotte bancaire unique",
  );
  await duelAction("Alpha", {
    action: "create",
    to: "Beta",
    gameId: "meteor-mayhem",
    stake: 50,
  });
  const challenge = (await duelsFor("Alpha"))[0];
  await duelAction("Beta", { action: "accept", id: challenge.id });
  const ar = (await duelAction("Alpha", {
      action: "run",
      id: challenge.id,
    })) as any,
    br = (await duelAction("Beta", { action: "run", id: challenge.id })) as any;
  const da = await getJSON<any>("tcb-duels", `duel:${challenge.id}`);
  for (const run of Object.values(da.runs) as any[]) run.at -= 10000;
  await setJSON("tcb-duels", `duel:${challenge.id}`, da);
  await scoreDuel(
    "Alpha",
    challenge.id,
    new URL(ar.url, "https://test.fr").searchParams.get("duelToken")!,
    "meteor-mayhem",
    100,
    5,
  );
  await scoreDuel(
    "Beta",
    challenge.id,
    new URL(br.url, "https://test.fr").searchParams.get("duelToken")!,
    "meteor-mayhem",
    50,
    5,
  );
  assert.equal((await duelsFor("Alpha"))[0].winner, "Alpha");
  pass("Duel de score : partie unique et règlement des mises");
  await economyAction("Beta", { action: "ticket" });
  const period = lotteryPeriod(),
    lot = await getJSON<any>("tcb-economy", `lottery:${period.id}`);
  const cashBefore = await balance("Beta");
  await settleLottery(period.endsAt + 1);
  await settleLottery(period.endsAt + 1);
  assert.equal(await balance("Beta"), cashBefore + 9);
  assert.equal((await treasuryView()).total, 1);
  const settled=await getJSON<any>("tcb-economy",`lottery:${period.id}`);settled.paid=false;await setJSON("tcb-economy",`lottery:${period.id}`,settled);
  await settleLottery(period.endsAt+1);assert.equal(await balance("Beta"),cashBefore+9);assert.equal((await treasuryView()).total,1);
  pass(
    "Loterie dimanche : 90 % au gagnant, 10 % au Trésor, pas de double paiement",
  );
  console.log(
    `\n${results.length} scénarios v60 validés. Données de test isolées : ${dir}`,
  );
}
main().catch((e) => {
  console.error(e);
  process.exitCode = 1;
});
