import { build } from "esbuild";
import { mkdir, copyFile, readFile, writeFile, cp } from "node:fs/promises";
await mkdir("preview-dist", { recursive: true });
await build({
  entryPoints: ["preview/main.tsx"],
  bundle: true,
  outfile: "preview-dist/app.js",
  platform: "browser",
  format: "iife",
  jsx: "automatic",
  minify: true,
  inject: ["preview/storage.ts"],
  alias: {
    "next/link": "./preview/link.tsx",
    "next/navigation": "./preview/navigation.ts",
  },
  define: { "process.env.NODE_ENV": '"production"' },
});
await copyFile("preview/index.html", "preview-dist/index.html");
const tv = await readFile("public/eco/tv.js", "utf8");
await writeFile(
  "preview-dist/tv.js",
  "var tvMemory={getItem:function(){return null},setItem:function(){}};\n" +
    tv.replaceAll("localStorage", "tvMemory"),
);
await mkdir("public/preview-v60", { recursive: true });
await cp("preview-dist", "public/preview-v60", { recursive: true });
console.log("Aperçu React construit.");
