// Seed isolated preview ONLY. Never accepts the real data directory.
import { promises as fs } from "node:fs";
import path from "node:path";
import bcrypt from "bcryptjs";
import { catalog } from "../lib/store";
async function main() {
  const dir = process.env.TCB_DATA_DIR;
  if (!dir || !dir.endsWith("/qa-data"))
    throw new Error("Utiliser un dossier qa-data isolé.");
  await fs.mkdir(dir, { recursive: true });
  const base = {
    passwordHash: await bcrypt.hash("PreviewTCB60!", 12),
    owned: catalog.map((g) => g.id),
    banned: false,
    bobux: 1000,
    playTimeMinutes: 65,
    joinedAt: new Date().toISOString(),
    achievements: ["first_game", "score_100"],
    ownedHats: ["none"],
    ownedShirts: ["blue"],
  };
  await fs.writeFile(
    path.join(dir, "users.json"),
    JSON.stringify(
      {
        democreateur: {
          ...base,
          username: "DemoCreateur",
          role: "creator",
          friends: ["DemoAmi"],
        },
        demoami: {
          ...base,
          username: "DemoAmi",
          role: "user",
          friends: ["DemoCreateur"],
        },
      },
      null,
      2,
    ),
  );
  console.log(
    "Deux comptes de contrôle créés dans qa-data, aucun compte de l'archive modifié.",
  );
}
main();
