// Preview-only bridge. The Next.js application retains all authentication.
const http=require("node:http");
http.createServer((req,res)=>{
  if(!(req.url||"").startsWith("/api/")){res.writeHead(404);res.end("API uniquement");return;}
  const upstream=http.request({hostname:"127.0.0.1",port:3000,path:req.url,method:req.method,headers:{...req.headers,host:"127.0.0.1:3000"}},reply=>{
    res.writeHead(reply.statusCode||502,reply.headers);reply.pipe(res);
  });
  upstream.on("error",()=>{if(!res.headersSent)res.writeHead(503);res.end("Serveur de l'aperçu indisponible");});
  req.pipe(upstream);
}).listen(5000,"0.0.0.0",()=>console.log("Preview API bridge on 5000"));
