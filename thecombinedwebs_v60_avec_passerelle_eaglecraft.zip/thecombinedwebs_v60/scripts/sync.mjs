import {execFileSync} from 'node:child_process';
const run=(args)=>execFileSync('git',args,{stdio:'inherit'});
const out=(args)=>execFileSync('git',args,{encoding:'utf8'}).trim();
const branch=out(['branch','--show-current']);
if(!branch)throw new Error('Aucune branche Git active');
if(out(['status','--porcelain']))throw new Error('Travail local non sauvegardé. Commit tes changements avant la synchronisation.');
run(['fetch','origin']);
const remote=`origin/${branch}`;
try{run(['pull','--rebase','origin',branch])}catch{console.error(`Impossible de synchroniser ${remote}. Résous les conflits puis relance npm run sync.`);process.exit(1)}
console.log(`✓ TheCombinedWebs synchronisé sur ${remote}`);
