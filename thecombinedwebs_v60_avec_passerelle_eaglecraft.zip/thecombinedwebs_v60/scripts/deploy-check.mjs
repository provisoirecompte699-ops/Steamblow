import fs from 'node:fs';
import process from 'node:process';

const required = ['package.json', 'next.config.ts', 'app/page.tsx', 'app/login/page.tsx', 'app/register/page.tsx', 'lib/auth.ts', 'lib/store.ts'];
const missing = required.filter(file => !fs.existsSync(file));
if (missing.length) {
  console.error('Fichiers manquants:', missing.join(', '));
  process.exit(1);
}
console.log('Sessions côté serveur : aucune clé de connexion à configurer. Stockage persistant nécessaire.');
if (!process.env.MULTIPLAYER_SERVER_URL && !process.env.NEXT_PUBLIC_MULTIPLAYER_SERVER_URL) console.log('INFO: NEXT_PUBLIC_MULTIPLAYER_SERVER_URL absent. Le launcher reste utilisable, mais le multijoueur distant ne sera pas connecté.');
console.log('TheCombinedWebs deploy check: PASS');
