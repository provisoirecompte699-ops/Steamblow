import fs from 'node:fs';
import path from 'node:path';
const root=process.cwd();
const required=[
  'app/QuestGameTracker.tsx','app/GameTools.tsx','app/VoiceChat.tsx',
  'app/AvatarStudio.tsx','lib/auth.ts','lib/store.ts','lib/multiplayer.ts',
  'app/api/rooms/route.ts','scripts/smoke-test.mjs'
];
const missing=required.filter(f=>!fs.existsSync(path.join(root,f)));
if(missing.length){console.error('PRE-FLIGHT missing:',missing.join(', '));process.exit(1)}
for(const f of fs.readdirSync(path.join(root,'app/games'),{withFileTypes:true})){if(!f.isDirectory()||f.name.startsWith('_'))continue;const page=path.join(root,'app/games',f.name,'page.tsx');if(!fs.existsSync(page))continue;const s=fs.readFileSync(page,'utf8');if(s.includes('<QuestGameTracker')&&!s.includes('QuestGameTracker')){console.error('PRE-FLIGHT tracker import missing:',page);process.exit(1)}}
const env=fs.readFileSync(path.join(root,'.env.example'),'utf8');if(!env.includes('NEXT_PUBLIC_MULTIPLAYER_SERVER_URL'))console.warn('PRE-FLIGHT warning: NEXT_PUBLIC_MULTIPLAYER_SERVER_URL not documented in .env.example');
console.log('TheCombinedWebs pre-flight: PASS');
