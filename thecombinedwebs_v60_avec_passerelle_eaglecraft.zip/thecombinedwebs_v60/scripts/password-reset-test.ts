import assert from "node:assert/strict";
import { promises as fs } from "node:fs";
import os from "node:os";
import path from "node:path";
import { hashLocalPassword, verifyPassword } from "../lib/passwords";
import { newSession, readSession, credentialVersion, sessionMatchesCredential } from "../lib/session-store";
import {sameRequestOrigin} from "../lib/request-origin";

async function main() {
  const directory = await fs.mkdtemp(path.join(os.tmpdir(), "tcb-reset-test-"));
  process.env.TCB_DATA_DIR = directory;
  process.env.NETLIFY = "false";
  const creatorPassword = "Creator-Test-Only-123!";
  const oldPassword = "Old-Test-Only-123!";
  const newPassword = "New-Test-Only-456!";
  const creatorHash = await hashLocalPassword(creatorPassword);
  const targetHash = await hashLocalPassword(oldPassword);
  const users = {
    democreateur: { username: "DemoCreateur", role: "creator", passwordHash: creatorHash, owned: [], bobux: 200 },
    moustafa: { username: "Moustafa", role: "vice_creator", passwordHash: targetHash, owned: ["meteor-mayhem"], bobux: 823, achievements: ["first_game"], playTimeMinutes: 81, bio: "original" },
    regular: { username: "Regular", role: "user", passwordHash: creatorHash, owned: [], bobux: 12 },
    moderator: { username: "Moderator", role: "moderator", passwordHash: creatorHash, owned: [], bobux: 15 },
  };
  await fs.writeFile(path.join(directory, "users.json"), JSON.stringify(users));
  const { resetMoustafaPassword, PasswordResetError } = await import("../lib/password-reset");
  const { getUser, saveUser } = await import("../lib/store");
  const { readCredential } = await import("../lib/credentials");
  const expectFailure = async (username: string, password: string, next: string, confirm: string, status: number) =>
    assert.rejects(resetMoustafaPassword(username, password, next, confirm), (error) => error instanceof PasswordResetError && error.status === status);
  try {
    assert.equal(sameRequestOrigin(new Request("http://localhost:3211/api/reset",{headers:{host:"127.0.0.1:3211",origin:"http://127.0.0.1:3211"}})),true);
    assert.equal(sameRequestOrigin(new Request("http://localhost/api/reset",{headers:{"x-forwarded-host":"app.example.com","x-forwarded-proto":"https",origin:"https://app.example.com"}})),true);
    assert.equal(sameRequestOrigin(new Request("https://app.example.com/api/reset",{headers:{host:"app.example.com",origin:"https://evil.example"}})),false);
    assert.equal(sameRequestOrigin(new Request("https://app.example.com/api/reset",{headers:{host:"app.example.com",origin:"null"}})),false);
    const originalBytes = await fs.readFile(path.join(directory, "users.json"), "utf8");
    for (const role of ["Regular", "Moderator", "Moustafa", "Missing"]) await expectFailure(role, creatorPassword, newPassword, newPassword, 403);
    await expectFailure("DemoCreateur", "incorrect", newPassword, newPassword, 403);
    await expectFailure("DemoCreateur", creatorPassword, "short", "short", 400);
    await expectFailure("DemoCreateur", creatorPassword, newPassword, newPassword + "different", 400);
    assert.equal(await readCredential("Moustafa"), null);
    assert.equal(await fs.readFile(path.join(directory, "users.json"), "utf8"), originalBytes);
    const staleProfile = (await getUser("Moustafa"))!;
    const oldToken = await newSession("Moustafa", credentialVersion(targetHash));
    const legacyToken = await newSession("Moustafa");
    const creatorToken = await newSession("DemoCreateur", credentialVersion(creatorHash));
    const result = await resetMoustafaPassword("DemoCreateur", creatorPassword, newPassword, newPassword);
    assert.equal(result.username, "Moustafa");
    assert.ok(!JSON.stringify(result).includes(newPassword));
    const target = (await getUser("Moustafa"))!;
    assert.equal(await verifyPassword(oldPassword, target.passwordHash), false);
    assert.equal(await verifyPassword(newPassword, target.passwordHash), true);
    assert.equal(sessionMatchesCredential((await readSession(oldToken))!, target), false);
    assert.equal(sessionMatchesCredential((await readSession(legacyToken))!, target), false);
    const freshToken = await newSession("Moustafa", credentialVersion(target.passwordHash));
    assert.equal(sessionMatchesCredential((await readSession(freshToken))!, target), true);
    assert.equal(sessionMatchesCredential((await readSession(creatorToken))!, (await getUser("DemoCreateur"))!), true);
    assert.equal(await fs.readFile(path.join(directory, "users.json"), "utf8"), originalBytes);
    const stored = await readCredential("Moustafa");
    assert.equal(stored?.changedBy, "DemoCreateur");
    assert.ok(stored && !JSON.stringify(stored).includes(newPassword));
    staleProfile.bio = "Updated stale profile";
    await saveUser(staleProfile);
    const afterProfile = (await getUser("Moustafa"))!;
    assert.equal(await verifyPassword(newPassword, afterProfile.passwordHash), true);
    for (const field of ["bobux", "owned", "achievements", "playTimeMinutes"] as const) assert.deepEqual(afterProfile[field], users.moustafa[field]);
    for (let i = 0; i < 5; i++) await expectFailure("DemoCreateur", "incorrect", newPassword, newPassword, 403);
    await expectFailure("DemoCreateur", creatorPassword, newPassword, newPassword, 429);
    console.log("PASS Créateur uniquement, réauthentification, longueur, confirmation et limitation des tentatives.");
    console.log("PASS Nouveau mot de passe accepté, ancien refusé, sessions anciennes et héritées invalidées.");
    console.log("PASS Session créateur conservée, aucun secret retourné, soldes et progression inchangés.");
    console.log("PASS Profil périmé ne restaure pas l'ancien mot de passe.");
  } finally { await fs.rm(directory, { recursive: true, force: true }); }
}
main().catch((error) => { console.error(error); process.exitCode = 1; });
