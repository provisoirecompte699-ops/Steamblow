# Vortex intégré à TheCombinedWebs

- Route TheCombinedWebs : `/vortex` — page : `public/vortex/index.html`
- Films : `https://peachify.top/embed/movie/{tmdb_id}`
- Séries : `https://peachify.top/embed/tv/{tmdb_id}/{season}/{episode}`

## Vortex+ (`public/vortex/vortex-plus.js` / `.css`)
- 17 rangées TMDB supplémentaires (tendances, au cinéma, mieux notés, genres films & séries), chargées au scroll.
- Catalogue complet : Films/Séries, genre, tri, « Charger plus » (pagination TMDB).
- Recherche live sur tout TMDB (en plus de la base locale). « Tout voir » ouvre le catalogue sur la rangée.
- Notes ★, badge SÉRIE, squelettes de chargement, cartes/navbar/lecteur retravaillés, bouton retour en haut.
- Contenu adulte filtré (`include_adult=false` + filtre côté client).

## Sources de secours
- Peachify = source principale. D'autres lecteurs se déclarent dans `public/vortex/sources.config.js` (templates https avec `{id}`, `{season}`, `{episode}`).
- Le bouton « Source 1/N » du lecteur passe à la source suivante ; la bande-annonce YouTube reste en dernier recours. « Où regarder » liste les services officiels.
