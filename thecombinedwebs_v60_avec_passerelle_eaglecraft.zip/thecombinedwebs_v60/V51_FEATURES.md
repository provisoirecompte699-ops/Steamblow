# TheCombinedWebs Écosystème v51

## Discord TheCombinedWebs (`/discord`)
- Salons textuels : #annonces (écriture réservée à Younes et Moustafa), #général, #jeux, #films-et-séries, #entraide, #memes.
- Messages privés entre amis, avec indicateur de messages non lus.
- Messages : réponses, réactions (👍 😂 ❤️ 🔥 😮 🎮), modification (flèche du haut), suppression (auteur ou modération), mentions @pseudo surlignées, **gras**, `code`, liens cliquables, filtre anti-insultes, anti-spam.
- Salons vocaux publics (Salon général, Gaming, Ciné-club, Chill), jusqu'à 8 personnes chacun.
- Appels privés entre amis : « Appeler » dans une conversation, sonnerie, accepter / refuser.
- Vocal : coupure micro, sourdine casque, appui-pour-parler (touche V ou bouton), volume par personne, choix du micro, suppression du bruit, annulation d'écho, gain automatique, sensibilité réglable, anneau vert autour de la personne qui parle, sons d'arrivée et de départ.
- Onglet Amis : en ligne / tous / ajouter un ami / demandes reçues, et bouton « Rejoindre » quand un ami est dans un salon vocal.
- Interface adaptée au mobile : menu latéral escamotable, grandes zones tactiles, encoches iPhone prises en compte.

## Partout dans l'écosystème
- Statut d'activité visible par tes amis : « Joue à Neon Arena », « Regarde CinéStream », « En vocal »…
- Notifications globales : appel entrant (accepter depuis n'importe quelle page) et nouveaux messages privés.
- Liens Discord dans la barre de l'écosystème, le tableau de bord et la page Crédits.

## Qualité
- Stockage local : écritures sérialisées (plus de données perdues quand deux requêtes écrivent en même temps), nouvelles fonctions `updateJSON` / `delJSON`.
- Arcade mobile : le classement ne chevauche plus l'objectif en mode portrait.

## Technique du vocal
- WebRTC pair-à-pair en maillage. La signalisation passe par `/api/discord/voice` : aucun serveur externe n'est nécessaire.
- Réseaux très fermés (école, entreprise, certains réseaux 4G) : ajoute un relais TURN avec
  `NEXT_PUBLIC_TURN_URL` (ex. `turn:turn.example.com:3478`), `NEXT_PUBLIC_TURN_USERNAME`, `NEXT_PUBLIC_TURN_CREDENTIAL`.
- Le micro exige HTTPS (ou localhost).

Crédits : Walid.
