# CinéStream intégré à l'écosystème TheCombinedWebs (v48)

## Routes
- `/cinestream` → page Next.js qui affiche `public/cinestream/index.html`
- `/games/baldi-basics-3d` → Baldi's Basics 3D (`public/games/baldi-basics-3d/index.html`), ajouté au catalogue gratuit
- `/credits` → page de crédits de l'écosystème (Walid)

## Compte partagé TheCombinedWebs ↔ CinéStream
CinéStream est servi sur le **même domaine** que TheCombinedWebs, donc il lit le même cookie HttpOnly `steamblox_session`.

- Déjà connecté sur TheCombinedWebs → CinéStream s'ouvre directement, avec le pseudo affiché en haut à droite.
- Pas connecté → CinéStream affiche son écran « Connexion à CinéStream » qui accepte **les identifiants TheCombinedWebs**.
- Déconnexion depuis CinéStream = déconnexion de tout l'écosystème (une seule session).
- Comptes bannis : refusés partout (`/api/session` renvoie 403).

### Routes API
| Méthode | Route | Rôle |
|---|---|---|
| GET | `/api/session` | `{authenticated, username, role}` |
| POST | `/api/auth/login` | JSON `{username, password}` → crée la session (même bonus de connexion quotidien que TheCombinedWebs) |
| POST | `/api/auth/register` | JSON `{username, password}` → crée un compte TheCombinedWebs |
| POST | `/api/auth/logout` | ferme la session |

La logique de connexion est centralisée dans `lib/login.ts` (pages `/login`, `/register` et API JSON). Les tentatives ratées sont limitées (8 par minute et par pseudo). Le paramètre `?next=` des pages de connexion n'accepte que des chemins internes de l'écosystème.

## Contenu
Les contenus +18 (catégorie Hentai, sources associées, rangée et bouton de navigation) ont été retirés de CinéStream : 199 titres conservés.

## Crédits
Walid est crédité dans la barre d'écosystème, la page `/credits`, CinéStream (bandeau, écran de connexion, pied de page), Baldi's Basics 3D et les pages de connexion.
