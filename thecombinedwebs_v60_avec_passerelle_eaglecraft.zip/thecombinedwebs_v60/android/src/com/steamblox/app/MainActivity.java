package com.steamblox.app;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.DownloadManager;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.media.AudioManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.webkit.CookieManager;
import android.webkit.JavascriptInterface;
import android.webkit.PermissionRequest;
import android.webkit.URLUtil;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

/**
 * TheCombinedWebs pour Android : une WebView plein écran qui charge le site TheCombinedWebs
 * (jeux, Discord vocal, CinéStream, Vortex) avec micro, notifications et plein écran.
 */
public class MainActivity extends Activity {
    private static final String PREFS = "steamblox";
    private static final String KEY_URL = "site_url";
    private static final int REQ_MIC = 11;
    private static final int REQ_NOTIF = 12;
    private static final int REQ_FILE = 13;
    private static final String CHANNEL_ID = "steamblox_social";

    private WebView web;
    private FrameLayout root;
    private View customView;
    private WebChromeClient.CustomViewCallback customCallback;
    private PermissionRequest pendingPermission;
    private ValueCallback<Uri[]> fileCallback;
    private String siteUrl;
    private boolean visible = true;
    private int notifId = 100;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
        setVolumeControlStream(AudioManager.STREAM_MUSIC);
        root = new FrameLayout(this);
        root.setBackgroundColor(Color.parseColor("#0B0D14"));
        setContentView(root);
        createChannel();

        siteUrl = getSharedPreferences(PREFS, MODE_PRIVATE).getString(KEY_URL, null);
        String builtIn = getString(R.string.default_url);
        if ((siteUrl == null || siteUrl.isEmpty()) && builtIn != null && builtIn.startsWith("http")) siteUrl = builtIn;
        if (siteUrl == null || siteUrl.isEmpty()) showSetup(null);
        else startWeb(savedInstanceState, startUrl(getIntent()));
    }

    // ---------- Premier lancement : adresse du serveur ----------
    private void showSetup(String error) {
        root.removeAllViews();
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setGravity(Gravity.CENTER);
        int pad = dp(28);
        box.setPadding(pad, pad, pad, pad);

        TextView logo = new TextView(this);
        logo.setText("S");
        logo.setTextSize(44);
        logo.setTypeface(Typeface.DEFAULT_BOLD);
        logo.setTextColor(Color.parseColor("#0B0C10"));
        logo.setGravity(Gravity.CENTER);
        logo.setBackgroundColor(Color.parseColor("#8B7CFF"));
        box.addView(logo, new LinearLayout.LayoutParams(dp(84), dp(84)));

        TextView title = new TextView(this);
        title.setText("Bienvenue sur TheCombinedWebs");
        title.setTextSize(24);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        title.setTextColor(Color.WHITE);
        title.setGravity(Gravity.CENTER);
        title.setPadding(0, dp(20), 0, dp(6));
        box.addView(title);

        TextView sub = new TextView(this);
        sub.setText(error != null ? error : "Entre l'adresse de ton site TheCombinedWebs (celle que tu ouvres dans le navigateur).");
        sub.setTextColor(error != null ? Color.parseColor("#FFB3BA") : Color.parseColor("#A9AFBD"));
        sub.setGravity(Gravity.CENTER);
        sub.setTextSize(15);
        sub.setPadding(0, 0, 0, dp(18));
        box.addView(sub);

        final EditText input = new EditText(this);
        input.setHint("https://mon-steamblox.netlify.app");
        input.setHintTextColor(Color.parseColor("#5D6372"));
        input.setTextColor(Color.WHITE);
        input.setSingleLine(true);
        input.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
        input.setBackgroundColor(Color.parseColor("#151821"));
        input.setPadding(dp(14), dp(12), dp(14), dp(12));
        String prev = getSharedPreferences(PREFS, MODE_PRIVATE).getString(KEY_URL, "");
        input.setText(prev);
        box.addView(input, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        Button go = new Button(this);
        go.setText("Continuer");
        go.setAllCaps(false);
        go.setTextColor(Color.parseColor("#0B0C10"));
        go.setBackgroundColor(Color.WHITE);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(52));
        lp.topMargin = dp(14);
        box.addView(go, lp);

        go.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                String u = input.getText().toString().trim();
                if (u.isEmpty()) return;
                if (!u.startsWith("http://") && !u.startsWith("https://")) u = "https://" + u;
                while (u.endsWith("/")) u = u.substring(0, u.length() - 1);
                if (!URLUtil.isValidUrl(u)) { Toast.makeText(MainActivity.this, "Adresse invalide", Toast.LENGTH_SHORT).show(); return; }
                getSharedPreferences(PREFS, MODE_PRIVATE).edit().putString(KEY_URL, u).apply();
                siteUrl = u;
                startWeb(null, u + (isTv() ? "/cinestream?tv=1" : "/steamblox?source=android"));
            }
        });
        root.addView(box, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
    }

    private String startUrl(Intent intent) {
        String target = intent != null ? intent.getStringExtra("url") : null;
        if (target != null && !target.isEmpty()) return target.startsWith("http") ? target : siteUrl + target;
        return siteUrl + (isTv() ? "/cinestream?tv=1" : "/steamblox?source=android");
    }

    /** Téléviseur Android (Android TV, Google TV, Fire TV) : on ouvre CinéStream en mode TV. */
    private boolean isTv() {
        try {
            android.app.UiModeManager ui = (android.app.UiModeManager) getSystemService(UI_MODE_SERVICE);
            if (ui != null && ui.getCurrentModeType() == android.content.res.Configuration.UI_MODE_TYPE_TELEVISION) return true;
        } catch (Exception ignored) { }
        return getPackageManager().hasSystemFeature("android.software.leanback");
    }

    // ---------- WebView ----------
    @SuppressLint({"SetJavaScriptEnabled", "AddJavascriptInterface"})
    private void startWeb(Bundle state, String url) {
        root.removeAllViews();
        web = new WebView(this);
        web.setBackgroundColor(Color.parseColor("#0B0D14"));
        root.addView(web, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setLoadWithOverviewMode(true);
        s.setUseWideViewPort(true);
        s.setSupportMultipleWindows(false);
        s.setJavaScriptCanOpenWindowsAutomatically(true);
        s.setAllowFileAccess(false);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE);
        s.setUserAgentString(s.getUserAgentString() + " SteambloxApp/53 Android" + (isTv() ? " SteambloxTV" : ""));
        CookieManager cm = CookieManager.getInstance();
        cm.setAcceptCookie(true);
        cm.setAcceptThirdPartyCookies(web, true);
        WebView.setWebContentsDebuggingEnabled(false);

        web.addJavascriptInterface(new Bridge(), "SteambloxAndroid");
        web.setWebViewClient(new Client());
        web.setWebChromeClient(new Chrome());
        web.setDownloadListener((dlUrl, userAgent, contentDisposition, mimeType, contentLength) -> {
            if (dlUrl.startsWith("blob:") || dlUrl.startsWith("data:")) {
                Toast.makeText(this, "Ce fichier se télécharge depuis un navigateur (Chrome).", Toast.LENGTH_LONG).show();
                return;
            }
            try {
                DownloadManager.Request r = new DownloadManager.Request(Uri.parse(dlUrl));
                String name = URLUtil.guessFileName(dlUrl, contentDisposition, mimeType);
                r.setMimeType(mimeType);
                r.addRequestHeader("cookie", CookieManager.getInstance().getCookie(dlUrl));
                r.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
                r.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, name);
                ((DownloadManager) getSystemService(DOWNLOAD_SERVICE)).enqueue(r);
                Toast.makeText(this, "Téléchargement : " + name, Toast.LENGTH_SHORT).show();
            } catch (Exception e) {
                startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(dlUrl)));
            }
        });

        if (state != null) web.restoreState(state);
        else web.loadUrl(url);

        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, REQ_NOTIF);
        }
    }

    private boolean isOwnSite(Uri u) {
        if (u == null || siteUrl == null) return false;
        Uri site = Uri.parse(siteUrl);
        return u.getHost() != null && u.getHost().equalsIgnoreCase(site.getHost());
    }

    private class Client extends WebViewClient {
        @Override
        public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest req) {
            Uri u = req.getUrl();
            String scheme = u.getScheme() == null ? "" : u.getScheme();
            if (!req.isForMainFrame()) return false;
            if (scheme.equals("http") || scheme.equals("https")) {
                if (isOwnSite(u)) return false;
                openExternal(u);
                return true;
            }
            openExternal(u); // mailto:, tel:, intent:…
            return true;
        }

        @Override
        public void onReceivedError(WebView view, WebResourceRequest req, WebResourceError err) {
            if (!req.isForMainFrame()) return;
            String html = "<html><body style='background:#0b0d14;color:#fff;font-family:sans-serif;display:flex;flex-direction:column;align-items:center;justify-content:center;height:100vh;margin:0;text-align:center;padding:24px'>"
                + "<h2>Connexion impossible</h2><p style='color:#a9afbd'>Vérifie ta connexion Internet ou l'adresse du serveur.<br>" + escape(siteUrl) + "</p>"
                + "<button onclick='location.href=\"" + escape(siteUrl) + "/steamblox\"' style='padding:14px 22px;border:0;border-radius:12px;background:#fff;font-weight:700;margin:6px'>Réessayer</button>"
                + "<button onclick='SteambloxAndroid.changeServer()' style='padding:14px 22px;border:0;border-radius:12px;background:#232733;color:#fff;font-weight:700;margin:6px'>Changer d'adresse</button></body></html>";
            view.loadDataWithBaseURL(null, html, "text/html", "utf-8", null);
        }
    }

    private class Chrome extends WebChromeClient {
        @Override
        public void onPermissionRequest(final PermissionRequest request) {
            runOnUiThread(() -> {
                boolean wantsMic = false;
                for (String r : request.getResources()) if (PermissionRequest.RESOURCE_AUDIO_CAPTURE.equals(r)) wantsMic = true;
                if (!wantsMic) { request.deny(); return; }
                if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
                    request.grant(new String[]{PermissionRequest.RESOURCE_AUDIO_CAPTURE});
                } else {
                    pendingPermission = request;
                    requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, REQ_MIC);
                }
            });
        }

        @Override
        public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
            if (fileCallback != null) fileCallback.onReceiveValue(null);
            fileCallback = callback;
            try {
                startActivityForResult(params.createIntent(), REQ_FILE);
            } catch (Exception e) {
                fileCallback = null;
                return false;
            }
            return true;
        }

        @Override
        public void onShowCustomView(View view, CustomViewCallback callback) {
            if (customView != null) { callback.onCustomViewHidden(); return; }
            customView = view;
            customCallback = callback;
            root.addView(view, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
            web.setVisibility(View.GONE);
            immersive(true);
        }

        @Override
        public void onHideCustomView() {
            if (customView == null) return;
            root.removeView(customView);
            customView = null;
            web.setVisibility(View.VISIBLE);
            immersive(false);
            if (customCallback != null) customCallback.onCustomViewHidden();
            customCallback = null;
        }
    }

    /** Pont JavaScript : window.SteambloxAndroid */
    private class Bridge {
        @JavascriptInterface
        public void notify(String title, String body, String url, String tag) {
            if (visible) return;
            runOnUiThread(() -> showNotification(title, body, url, tag));
        }
        @JavascriptInterface
        public boolean canNotify() {
            return Build.VERSION.SDK_INT < 33 || checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED;
        }
        @JavascriptInterface
        public void changeServer() {
            runOnUiThread(() -> new AlertDialog.Builder(MainActivity.this)
                .setTitle("Changer d'adresse du serveur ?")
                .setMessage("Adresse actuelle : " + siteUrl)
                .setPositiveButton("Changer", (d, w) -> { if (web != null) { web.destroy(); web = null; } showSetup(null); })
                .setNegativeButton("Annuler", null).show());
        }
        @JavascriptInterface
        public String version() { return "52.0"; }
        @JavascriptInterface
        public void vibrate(int ms) {
            try {
                android.os.Vibrator v = (android.os.Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
                if (v != null) v.vibrate(Math.max(10, Math.min(ms, 800)));
            } catch (Exception ignored) { }
        }
    }

    // ---------- Notifications ----------
    private void createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel ch = new NotificationChannel(CHANNEL_ID, "Appels et messages", NotificationManager.IMPORTANCE_HIGH);
            ch.setDescription("Appels vocaux et messages privés du Discord TheCombinedWebs");
            ch.enableVibration(true);
            ((NotificationManager) getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(ch);
        }
    }

    private void showNotification(String title, String body, String url, String tag) {
        Intent open = new Intent(this, MainActivity.class);
        open.putExtra("url", url == null ? "/discord" : url);
        open.setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        int flags = PendingIntent.FLAG_UPDATE_CURRENT | (Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE : 0);
        PendingIntent pi = PendingIntent.getActivity(this, notifId, open, flags);
        Notification.Builder b = Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(this, CHANNEL_ID) : new Notification.Builder(this);
        b.setSmallIcon(android.R.drawable.stat_notify_chat)
            .setContentTitle(title)
            .setContentText(body)
            .setStyle(new Notification.BigTextStyle().bigText(body))
            .setAutoCancel(true)
            .setContentIntent(pi)
            .setColor(Color.parseColor("#8B7CFF"));
        if (Build.VERSION.SDK_INT < 26) b.setPriority(Notification.PRIORITY_HIGH).setDefaults(Notification.DEFAULT_ALL);
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        int id = tag == null ? notifId++ : Math.abs(tag.hashCode() % 100000);
        try { nm.notify(id, b.build()); } catch (SecurityException ignored) { }
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        String target = intent.getStringExtra("url");
        if (web != null && target != null && siteUrl != null) web.loadUrl(target.startsWith("http") ? target : siteUrl + target);
    }

    // ---------- Résultats & cycle de vie ----------
    @Override
    public void onRequestPermissionsResult(int code, String[] perms, int[] res) {
        super.onRequestPermissionsResult(code, perms, res);
        if (code == REQ_MIC && pendingPermission != null) {
            if (res.length > 0 && res[0] == PackageManager.PERMISSION_GRANTED) pendingPermission.grant(new String[]{PermissionRequest.RESOURCE_AUDIO_CAPTURE});
            else { pendingPermission.deny(); Toast.makeText(this, "Micro refusé : le chat vocal ne fonctionnera pas.", Toast.LENGTH_LONG).show(); }
            pendingPermission = null;
        }
    }

    @Override
    protected void onActivityResult(int code, int result, Intent data) {
        super.onActivityResult(code, result, data);
        if (code == REQ_FILE && fileCallback != null) {
            fileCallback.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(result, data));
            fileCallback = null;
        }
    }

    @Override
    public void onBackPressed() {
        if (customView != null) { new Chrome().onHideCustomView(); return; }
        if (web == null) { super.onBackPressed(); return; }
        // D'abord la page (mode TV : fermer le lecteur, l'écran de paiement…), puis l'historique.
        web.evaluateJavascript("(function(){try{var f=document.querySelector('iframe[title^=\\'Cin\\']');var w=f&&f.contentWindow;if(w&&w.SBBack&&w.SBBack())return 1;if(window.SBBack&&window.SBBack())return 1}catch(e){}return 0})()", value -> {
            if ("1".equals(value)) return;
            if (web.canGoBack()) web.goBack(); else finish();
        });
    }

    @Override protected void onResume() { super.onResume(); visible = true; if (web != null) web.onResume(); }
    // La WebView n'est pas mise en pause : le vocal et les notifications continuent en arrière-plan.
    @Override protected void onPause() { super.onPause(); visible = false; CookieManager.getInstance().flush(); }
    @Override protected void onSaveInstanceState(Bundle out) { super.onSaveInstanceState(out); if (web != null) web.saveState(out); }
    @Override protected void onDestroy() { if (web != null) web.destroy(); super.onDestroy(); }

    // ---------- Utilitaires ----------
    private void openExternal(Uri u) {
        try { startActivity(new Intent(Intent.ACTION_VIEW, u)); }
        catch (Exception e) { Toast.makeText(this, "Aucune application pour ouvrir ce lien", Toast.LENGTH_SHORT).show(); }
    }
    private void immersive(boolean on) {
        View d = getWindow().getDecorView();
        if (on) d.setSystemUiVisibility(View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY | View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
        else d.setSystemUiVisibility(View.SYSTEM_UI_FLAG_VISIBLE);
    }
    private int dp(int v) { return Math.round(v * getResources().getDisplayMetrics().density); }
    private static String escape(String s) { return s == null ? "" : s.replace("&", "&amp;").replace("<", "&lt;").replace("'", "&#39;").replace("\"", "&quot;"); }
}
