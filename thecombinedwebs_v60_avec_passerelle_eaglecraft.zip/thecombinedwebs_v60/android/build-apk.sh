#!/usr/bin/env bash
# Construit l'APK Android de TheCombinedWebs sans Gradle (aapt2 + javac + d8 + apksigner).
# Usage : SITE_URL=https://mon-steamblox.netlify.app ./build-apk.sh
#   SITE_URL vide  -> l'application demande l'adresse au premier lancement.
# Variables : ANDROID_SDK (défaut ~/android/sdk), JAVA_HOME, KEYSTORE / KS_PASS pour signer en release.
set -euo pipefail
cd "$(dirname "$0")"
SDK="${ANDROID_SDK:-$HOME/android/sdk}"
BT="$SDK/build-tools/34.0.0"
JAR="$SDK/platforms/android-34/android.jar"
SITE_URL="${SITE_URL:-}"
OUT="${OUT:-build/steamblox.apk}"
KEYSTORE="${KEYSTORE:-$HOME/.android/steamblox-debug.jks}"
KS_PASS="${KS_PASS:-steamblox}"
[ -x "$BT/aapt2" ] || { echo "Android SDK introuvable : $BT"; exit 1; }
rm -rf build && mkdir -p build/gen build/classes build/res-src
cp -r res/. build/res-src/
python3 - "$SITE_URL" <<'PY'
import sys,re
p="build/res-src/values/strings.xml"; s=open(p).read()
u=sys.argv[1].strip().rstrip("/")
s=s.replace("__SITE_URL__", u.replace("&","&amp;"))
open(p,"w").write(s)
PY
"$BT/aapt2" compile --dir build/res-src -o build/res.zip
"$BT/aapt2" link -I "$JAR" --manifest AndroidManifest.xml -o build/base.apk --java build/gen \
  --min-sdk-version 24 --target-sdk-version 34 --version-code 53 --version-name 53.0 build/res.zip --auto-add-overlay
javac -encoding UTF-8 -nowarn -source 8 -target 8 -bootclasspath "$JAR" -classpath "$JAR:$BT/core-lambda-stubs.jar" -d build/classes \
  build/gen/com/steamblox/app/R.java src/com/steamblox/app/*.java 2>&1 | grep -v "warning" || true
[ -f build/classes/com/steamblox/app/MainActivity.class ] || { echo "Échec de compilation Java"; exit 1; }
"$BT/d8" --min-api 24 --release --lib "$JAR" --output build $(find build/classes -name '*.class')
cp build/base.apk build/unsigned.apk
(cd build && zip -q -j unsigned.apk classes.dex)
"$BT/zipalign" -f -p 4 build/unsigned.apk build/aligned.apk
if [ ! -f "$KEYSTORE" ]; then
  mkdir -p "$(dirname "$KEYSTORE")"
  keytool -genkeypair -keystore "$KEYSTORE" -storepass "$KS_PASS" -keypass "$KS_PASS" -alias steamblox \
    -keyalg RSA -keysize 2048 -validity 10000 -dname "CN=Steamblox, O=Steamblox, C=FR" >/dev/null 2>&1
fi
"$BT/apksigner" sign --ks "$KEYSTORE" --ks-pass "pass:$KS_PASS" --key-pass "pass:$KS_PASS" --ks-key-alias steamblox --out "$OUT" build/aligned.apk
"$BT/apksigner" verify "$OUT" && echo "APK prêt : $OUT ($(du -h "$OUT" | cut -f1))"
