const http=require("http");
const express=require("express");
const {Server}=require("socket.io");

const app=express();
app.disable("x-powered-by");
app.get("/health",(_,res)=>res.json({ok:true,service:"steamblox-multiplayer",version:"3"}));
const server=http.createServer(app);
const io=new Server(server,{cors:{origin:"*",methods:["GET","POST"]},pingInterval:10000,pingTimeout:5000,maxHttpBufferSize:1e5,connectionStateRecovery:{maxDisconnectionDuration:120000,maxMissedPackets:100}});
const rooms=new Map();
const MAX_PLAYERS=16;
const MAX_STATE_HZ=30;
const crypto=require("crypto");
const GV_SECRET=()=>String(process.env.REALTIME_SECRET||"");
function verifyGlobalToken(token,username){try{const [body,sig]=String(token||"").split(".");if(!body||!sig||!GV_SECRET())return null;const expected=crypto.createHmac("sha256",GV_SECRET()).update(body).digest("hex");const a=Buffer.from(sig),b=Buffer.from(expected);if(a.length!==b.length||!crypto.timingSafeEqual(a,b))return null;const p=JSON.parse(Buffer.from(body,"base64url").toString("utf8"));const age=Date.now()-Number(p.t);if(p.u!==username||!Number.isFinite(age)||age<0||age>300000)return null;return {username:p.u,canSpeak:!!p.s}}catch{return null}}
const globalSpeakers=new Map();

function cleanNumber(v,f=0,limit=100000){return Number.isFinite(Number(v))?Math.max(-limit,Math.min(limit,Number(v))):f}
function cleanRoom(v){return String(v||"").replace(/[^a-zA-Z0-9_-]/g,"").slice(0,32)}
function cleanName(v){return String(v||"Player").trim().replace(/[\u0000-\u001f]/g,"").slice(0,20)||"Player"}
function cleanGame(v){return String(v||"lobby").replace(/[^a-zA-Z0-9_-]/g,"").slice(0,40)||"lobby"}
function publicPlayer(p){return {...p.public,ready:p.ready,team:p.team,troll:!p.noTroll}}
function roomState(room){const r=rooms.get(room);return r?[...r.players.values()].map(publicPlayer):[]}
function roomMeta(r){return {hostId:r?.hostId||null,started:!!r?.started,maxPlayers:MAX_PLAYERS,players:r?roomState(r):[],hostOptions:r?.hostOptions||{},hostEntities:r?.hostEntities||[]}}
function broadcastRoom(room){const r=rooms.get(room);if(r){io.to(room).emit("room:state",roomMeta(r));io.to("spec:"+room).emit("room:state",roomMeta(r))}}
// ————— Hôte : nettoyage des actions d'hôte —————
const TROLL_FX=new Set(["jumpscare","fakecrash","disconnect","flip","mirror","drunk","spin","shake","zoom","invert","darkness","rain","honk"]);
const MAX_ENTITIES=40;
const VALID_HOST_OPTIONS=new Set(["difficulty","speed","gravity","monsterRate","chaos","friendlyFire","fog","invincible","oneHitKO","slowMotion","bigHead","lowGravity","explosions","darkness"]);
function cleanHostOptions(opts){const o={};if(opts&&typeof opts==="object"){for(const k of Object.keys(opts)){if(VALID_HOST_OPTIONS.has(k)){if(k==="friendlyFire"||k==="invincible"||k==="oneHitKO"||k==="bigHead"||k==="lowGravity"||k==="explosions"||k==="darkness")o[k]=!!opts[k];else if(k==="difficulty")o[k]=String(opts[k]).slice(0,10);else o[k]=cleanNumber(opts[k],1,10)}}}return o}
const MONSTER_TYPES=["blob","fast","tank","swarm","boss","ghost","spike","explode"];
function cleanMonster(m){const t=String(m?.type||"").trim().slice(0,16);const type=MONSTER_TYPES.includes(t)?t:"blob";return {type,x:cleanNumber(m?.x,0,2000),y:cleanNumber(m?.y,0,2000),count:Math.max(1,Math.min(10,Number(m?.count)||1)),id:Math.random().toString(36).slice(2,10)}}
function cleanHostActionPayload(p){if(!p||typeof p!=="object")return{};const o={};for(const k of Object.keys(p)){const v=p[k];if(typeof v==="boolean")o[k]=v;else if(typeof v==="number")o[k]=cleanNumber(v,0,1000);else if(typeof v==="string")o[k]=String(v).replace(/[\u0000-\u001f]/g,"").trim().slice(0,100);else if(typeof v==="object"&&k==="pos")o[k]={x:cleanNumber(v?.x,0,2000),y:cleanNumber(v?.y,0,2000)}}return o}

io.on("connection",socket=>{
 let room=null,player=null,lastState=0,lastChat=0,lastTroll=0;
 socket.on("room:join",payload=>{
  if(player) return socket.emit("room:error",{message:"Tu es déjà dans un salon"});
  const roomId=cleanRoom(payload?.roomId), name=cleanName(payload?.name), game=cleanGame(payload?.game);
  if(!roomId)return socket.emit("room:error",{message:"Salon invalide"});
  if(!rooms.has(roomId))rooms.set(roomId,{players:new Map(),hostId:null,started:false,game,hostOptions:{},hostEntities:[]});
  const r=rooms.get(roomId);
  if(r.game!==game&&r.players.size)return socket.emit("room:error",{message:"Ce salon est réservé à un autre jeu"});
  if(r.players.size>=MAX_PLAYERS)return socket.emit("room:error",{message:"Salon complet"});
  room=roomId;
  player={id:socket.id,ready:false,team:(r.players.size%2)+1,public:{id:socket.id,name,x:0,y:0,vx:0,vy:0,rotation:0,score:0,game}};
  r.players.set(socket.id,player);if(!r.hostId)r.hostId=socket.id;socket.join(room);
  socket.emit("room:state",roomMeta(r));socket.emit("room:joined",{roomId,hostId:r.hostId});socket.to(room).emit("player:joined",{player:publicPlayer(player)});broadcastRoom(room);
 });
 socket.on("room:ready",value=>{if(!room||!player)return;player.ready=!!value;broadcastRoom(room)});
 socket.on("room:team",team=>{if(!room||!player)return;const t=Number(team);if(t===1||t===2){player.team=t;broadcastRoom(room)}});
 socket.on("room:start",()=>{if(!room||!player)return;const r=rooms.get(room);if(!r||r.hostId!==socket.id)return socket.emit("room:error",{message:"Seul l'hôte peut démarrer"});if(r.players.size<1)return;const notReady=[...r.players.values()].filter(p=>p.id!==socket.id&&!p.ready);if(notReady.length)return socket.emit("room:error",{message:"Tous les joueurs doivent être prêts"});r.started=true;io.to(room).emit("game:start",{serverTime:Date.now(),players:roomState(room)});broadcastRoom(room)});
 socket.on("room:leave",()=>socket.disconnect(true));
 socket.on("player:state",data=>{
  const now=Date.now();if(!room||!player||now-lastState<1000/MAX_STATE_HZ)return;lastState=now;
  const p=player.public,s=data?.state||data;
  p.x=cleanNumber(s?.x,p.x);p.y=cleanNumber(s?.y,p.y);p.vx=cleanNumber(s?.vx ?? s?.s,p.vx);p.vy=cleanNumber(s?.vy,p.vy);p.rotation=cleanNumber(s?.rotation ?? s?.a,p.rotation,100000);p.score=Math.max(0,Math.min(999999,Number(s?.score)||0));
  ((e)=>{io.to("spec:"+room).emit("player:state",e);socket.to(room).emit("player:state",e)})({id:p.id,username:p.name,state:{x:p.x,y:p.y,vx:p.vx,vy:p.vy,rotation:p.rotation,score:p.score,a:p.rotation,s:p.vx},player:publicPlayer(player),serverTime:now});
 });
 // ————— Hôte : spawn de monstres —————
 socket.on("host:spawn",data=>{
  if(!room||!player)return;const r=rooms.get(room);if(!r||r.hostId!==socket.id)return socket.emit("room:error",{message:"Seul l'hôte peut invoquer des monstres"});
  const m=cleanMonster(data);if(r.hostEntities.length>=MAX_ENTITIES)r.hostEntities.splice(0,r.hostEntities.length-MAX_ENTITIES+m.count);for(let i=0;i<m.count;i++)r.hostEntities.push({...m,id:Math.random().toString(36).slice(2,10)});io.to(room).emit("host:spawn",{monster:m,entities:r.hostEntities});
 });
 // ————— Hôte : modifier les options de partie —————
 socket.on("host:modify",data=>{
  if(!room||!player)return;const r=rooms.get(room);if(!r||r.hostId!==socket.id)return socket.emit("room:error",{message:"Seul l'hôte peut modifier la partie"});
  const opts=cleanHostOptions(data?.options);if(Object.keys(opts).length)r.hostOptions={...r.hostOptions,...opts};io.to(room).emit("host:modify",{options:r.hostOptions});broadcastRoom(room);
 });
 // ————— Hôte : action générique (chaos, reset, soin, etc.) —————
 socket.on("host:action",data=>{
  if(!room||!player)return;const r=rooms.get(room);if(!r||r.hostId!==socket.id)return socket.emit("room:error",{message:"Seul l'hôte peut déclencher des actions"});
  const action=String(data?.action||"").trim().slice(0,24);const payload=cleanHostActionPayload(data?.payload);if(action)io.to(room).emit("host:action",{action,payload,by:player.public.id,serverTime:Date.now()});
 });
 // ————— Hôte : effacer les monstres —————
 socket.on("host:clear",data=>{
  if(!room||!player)return;const r=rooms.get(room);if(!r||r.hostId!==socket.id)return socket.emit("room:error",{message:"Seul l'hôte peut effacer les monstres"});
  r.hostEntities=[];io.to(room).emit("host:clear",{});broadcastRoom(room);
 });
 // ————— Hôte : troll (jumpscare & co) —————
 socket.on("troll:optout",v=>{if(!room||!player)return;player.noTroll=!!v;broadcastRoom(room)});
 socket.on("host:troll",data=>{
  if(!room||!player)return;const r=rooms.get(room);if(!r||r.hostId!==socket.id)return socket.emit("room:error",{message:"Seul l'hôte peut troller"});
  const now=Date.now();if(now-lastTroll<1000)return;lastTroll=now;
  const effect=String(data?.effect||"");if(!TROLL_FX.has(effect))return;
  const ms=Math.max(500,Math.min(10000,Number(data?.ms)||3000));const target=String(data?.target||"all").slice(0,40);
  const ids=target==="all"?[...r.players.keys()].filter(id=>id!==socket.id):(r.players.has(target)&&target!==socket.id?[target]:[]);
  let sent=0,skipped=0;for(const id of ids){const p=r.players.get(id);if(!p||p.noTroll){skipped++;continue}sent++;io.to(id).emit("troll:fx",{effect,ms,from:player.public.name,serverTime:now})}
  socket.emit("troll:sent",{effect,sent,skipped});
 });
 // ————— Hôte : kick un joueur —————
 socket.on("host:kick",data=>{
  if(!room||!player)return;const r=rooms.get(room);if(!r||r.hostId!==socket.id)return socket.emit("room:error",{message:"Seul l'hôte peut exclure"});
  const target=String(data?.id||"").slice(0,40);if(target&&r.players.has(target)){io.to(target).emit("room:kicked",{message:"Tu as été exclu du salon"});const tp=r.players.get(target);io.to(room).emit("room:chat",{id:"server",name:"Serveur",text:`${tp?.public?.name||"Joueur"} a été exclu`,at:Date.now()});}
 });
 socket.on("latency:ping",(_,ack)=>{if(typeof ack==="function")ack({serverTime:Date.now()})});
 socket.on("party:mini",()=>{if(room&&player&&player.public.game==="party-pals")io.to(room).emit("party:mini",{by:player.public.id})});
 socket.on("voice:ready",()=>{if(room&&player){socket.to(room).emit("voice:peer",{from:socket.id,name:player.public.name});socket.emit("voice:sync")}});
 const gvState=()=>{const all=[...globalSpeakers.values()];const sp=all.find(x=>x.speaker);return {active:!!sp,speaker:sp?.username||null,listeners:all.filter(x=>!x.speaker).length}};
 const gvBroadcast=()=>io.to("global-voice").emit("global-voice:state",gvState());
 const gvRemove=()=>{if(!globalSpeakers.delete(socket.id))return;socket.leave("global-voice");socket.to("global-voice").emit("global-voice:left",{id:socket.id});gvBroadcast()};
 socket.on("global-voice:join",data=>{
  const username=String(data?.username||"");const auth=verifyGlobalToken(data?.token,username);
  if(!auth)return socket.emit("global-voice:error",{message:"Accès vocal global refusé"});
  const speaker=!!data?.speaker&&auth.canSpeak; // le droit de parler vient du token signé
  if(data?.speaker&&!auth.canSpeak)return socket.emit("global-voice:error",{message:"Seul Younes peut parler dans le vocal global"});
  globalSpeakers.set(socket.id,{username,speaker});socket.join("global-voice");
  for(const [id,info] of globalSpeakers){if(id===socket.id)continue;
   if(speaker&&!info.speaker)socket.emit("global-voice:listener",{id}); // le speaker appelle chaque auditeur déjà là
   if(!speaker&&info.speaker)io.to(id).emit("global-voice:listener",{id:socket.id}); // le speaker appelle le nouvel auditeur
  }
  socket.emit("global-voice:joined",{speaker});gvBroadcast();
 });
 socket.on("global-voice:leave",gvRemove);
 const gvRelay=(evt,key)=>socket.on(evt,data=>{if(globalSpeakers.has(socket.id)&&data?.to&&globalSpeakers.has(String(data.to))&&data[key])io.to(String(data.to)).emit(evt,{from:socket.id,[key]:data[key]})});
 gvRelay("global-voice:offer","offer");gvRelay("global-voice:answer","answer");gvRelay("global-voice:ice","candidate");
 socket.on("voice:off",()=>{if(room&&player)socket.to(room).emit("voice:left",{id:socket.id})});
 socket.on("voice:mute",data=>{if(room&&player)socket.to(room).emit("voice:mute",{id:socket.id,muted:!!data?.muted})});
 socket.on("voice:offer",data=>{if(room&&player&&data?.to)io.to(String(data.to)).emit("voice:offer",{from:socket.id,offer:data.offer})});
 socket.on("voice:answer",data=>{if(room&&player&&data?.to)io.to(String(data.to)).emit("voice:answer",{from:socket.id,answer:data.answer})});
 socket.on("voice:ice",data=>{if(room&&player&&data?.to&&data?.candidate)io.to(String(data.to)).emit("voice:ice",{from:socket.id,candidate:data.candidate})});
 socket.on("room:chat",msg=>{if(!room||!player)return;const now=Date.now();if(now-lastChat<350)return;lastChat=now;const text=String(msg?.text||"").replace(/[\u0000-\u001f]/g,"").trim().slice(0,180);if(text)io.to(room).emit("room:chat",{id:socket.id,name:player.public.name,text,at:now})});
 socket.on("disconnect",()=>{gvRemove();if(room&&rooms.has(room)){const r=rooms.get(room);r.players.delete(socket.id);socket.to(room).emit("player:left",{id:socket.id});socket.to(room).emit("voice:left",{id:socket.id});if(r.hostId===socket.id){r.hostId=r.players.keys().next().value||null;if(r.hostId)io.to(r.hostId).emit("room:promoted",{hostId:r.hostId})}if(r.players.size===0)rooms.delete(room);else broadcastRoom(room)}});
});


// ===== v58 · TheCombinedWebs : matchmaking, salons de visionnage synchronisés, spectateur =====
const mmQueues=new Map();
const watchRooms=new Map();
const rnd=n=>crypto.randomBytes(n).toString("hex").toUpperCase().slice(0,n);
const cleanCode=v=>String(v||"").replace(/[^a-zA-Z0-9]/g,"").toUpperCase().slice(0,12);
const wpMembers=code=>{const w=watchRooms.get(code);return w?[...w.members.entries()].map(([id,name])=>({id,name,host:id===w.host})):[]};
io.on("connection",socket=>{
 let user=null,mmGame=null,wpCode=null,lastWp=0,lastWpChat=0;
 const leaveMm=()=>{if(!mmGame)return;mmQueues.set(mmGame,(mmQueues.get(mmGame)||[]).filter(x=>x.id!==socket.id));mmGame=null};
 const leaveWp=()=>{if(!wpCode)return;const code=wpCode;wpCode=null;socket.leave("wp:"+code);const w=watchRooms.get(code);if(!w)return;w.members.delete(socket.id);
  if(!w.members.size){watchRooms.delete(code);return}
  if(w.host===socket.id)w.host=[...w.members.keys()][0];
  io.to("wp:"+code).emit("wp:members",wpMembers(code));io.to("wp:"+code).emit("wp:state",{...w.state,hostId:w.host,serverTime:Date.now()})};
 socket.on("tcb:auth",(d,ack)=>{const name=String(d?.username||"").slice(0,24);const auth=verifyGlobalToken(d?.token,name);
  if(!auth||!name){if(typeof ack==="function")ack({ok:false});return}
  user=name;if(typeof ack==="function")ack({ok:true,online:io.engine.clientsCount})});
 // — Matchmaking rapide —
 socket.on("mm:join",d=>{if(!user)return socket.emit("mm:error",{message:"Non authentifié"});leaveMm();
  const game=cleanGame(d?.game);mmGame=game;const q=mmQueues.get(game)||[];const other=q.find(x=>x.id!==socket.id&&x.user!==user);
  if(other){mmQueues.set(game,q.filter(x=>x.id!==other.id));mmGame=null;const roomId="MM"+rnd(5);
   io.to(other.id).emit("mm:found",{roomId,game,opponent:user});socket.emit("mm:found",{roomId,game,opponent:other.user})}
  else{q.push({id:socket.id,user});mmQueues.set(game,q);socket.emit("mm:waiting",{game,size:q.length})}});
 socket.on("mm:leave",()=>{leaveMm();socket.emit("mm:left")});
 // — Salon de visionnage synchronisé —
 socket.on("wp:join",d=>{if(!user)return socket.emit("wp:error",{message:"Non authentifié"});leaveWp();
  const code=cleanCode(d?.code)||("W"+rnd(5));
  if(!watchRooms.has(code)){if(watchRooms.size>=200)return socket.emit("wp:error",{message:"Trop de salons ouverts"});watchRooms.set(code,{host:socket.id,members:new Map(),state:{title:"",playing:false,pos:0,at:Date.now()}})}
  const w=watchRooms.get(code);if(w.members.size>=30)return socket.emit("wp:error",{message:"Salon complet"});
  w.members.set(socket.id,user);wpCode=code;socket.join("wp:"+code);
  socket.emit("wp:joined",{code,hostId:w.host,state:{...w.state,serverTime:Date.now()}});io.to("wp:"+code).emit("wp:members",wpMembers(code))});
 socket.on("wp:leave",leaveWp);
 socket.on("wp:state",d=>{const w=wpCode&&watchRooms.get(wpCode);if(!w||w.host!==socket.id)return;const now=Date.now();if(now-lastWp<150)return;lastWp=now;
  w.state={title:String(d?.title||"").replace(/[\u0000-\u001f<>]/g,"").slice(0,80),playing:!!d?.playing,pos:Math.max(0,Math.min(86400,Number(d?.pos)||0)),at:now};
  io.to("wp:"+wpCode).emit("wp:state",{...w.state,hostId:w.host,serverTime:now})});
 socket.on("wp:countdown",()=>{const w=wpCode&&watchRooms.get(wpCode);if(!w||w.host!==socket.id)return;const goAt=Date.now()+5000;
  w.state={...w.state,playing:true,pos:0,at:goAt};io.to("wp:"+wpCode).emit("wp:countdown",{goAt,serverTime:Date.now()});io.to("wp:"+wpCode).emit("wp:state",{...w.state,hostId:w.host,serverTime:Date.now()})});
 socket.on("wp:chat",d=>{if(!wpCode||!user)return;const now=Date.now();if(now-lastWpChat<400)return;lastWpChat=now;
  const text=String(d?.text||"").replace(/[\u0000-\u001f<>]/g,"").trim().slice(0,160);if(text)io.to("wp:"+wpCode).emit("wp:chat",{from:user,text,at:now})});
 // — Mode spectateur —
 socket.on("spec:list",(_,ack)=>{if(typeof ack!=="function")return;ack([...rooms.entries()].filter(([,r])=>r.players.size>0).slice(0,40).map(([id,r])=>({roomId:id,game:r.game,players:r.players.size,started:!!r.started})))});
 socket.on("spec:join",d=>{if(!user)return;const id=cleanRoom(d?.roomId);const r=rooms.get(id);if(!r)return socket.emit("spec:error",{message:"Salon introuvable"});socket.join("spec:"+id);socket.emit("spec:joined",{roomId:id,...roomMeta(r)})});
 socket.on("spec:leave",d=>{socket.leave("spec:"+cleanRoom(d?.roomId))});
 socket.on("disconnect",()=>{leaveMm();leaveWp()});
});
setInterval(()=>io.emit("tcb:online",{count:io.engine.clientsCount}),15000);

const port=Number(process.env.PORT)||3001;server.listen(port,()=>console.log(`TheCombinedWebs realtime server ready on ${port}`));
