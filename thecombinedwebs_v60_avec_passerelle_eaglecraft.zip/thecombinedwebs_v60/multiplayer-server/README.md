# TheCombinedWebs multiplayer

This is a dedicated Socket.IO server. It is separate from the Next.js web app because a real-time multiplayer connection needs a long-lived process.

Events:
- `room:join` `{roomId, username, game}`
- `player:state` `{roomId, state}`
- `room:chat` `{roomId, text}`
- `player:joined`
- `player:left`

Deploy this server on a Node host that supports persistent WebSockets. Put its public address in `MULTIPLAYER_SERVER_URL`.

For a production game, authoritative movement, collision, anti-cheat and matchmaking should run here rather than trusting client state.