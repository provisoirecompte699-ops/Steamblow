# TheCombinedWebs v53 — Écosystème

> v53 : jeux gratuits, mode TV pour TheCombinedWebs et CinéStream, manettes dans les jeux arcade, APK compatible Android TV. Voir V53_FEATURES.md.

Nouveautés v52 : classements, défi du jour, tournois, rediffusions, éditeur de niveaux, clans, profils publics, niveau/XP, passe de saison, boutique de cosmétiques, thèmes, partage d’écran Discord, signalements, soirée ciné, Ma liste / Reprendre / avis dans CinéStream, application installable et **APK Android** (`android/`) — voir `V52_FEATURES.md`. Versions précédentes : `V51_FEATURES.md`, `V50_FEATURES.md`.

Écosystème : TheCombinedWebs (jeux) · CinéStream VF (`/cinestream`) · Vortex (`/vortex`) · Baldi's Basics 3D (`/games/baldi-basics-3d`) · Crédits (`/credits`).
Un seul compte TheCombinedWebs pour tous les services — voir `CINESTREAM_INTEGRATION.md`.

Crédits : **Walid** (voir `CREDITS.md`).

## Historique
TheCombinedWebs v6.3

Plateforme web de jeux avec catalogue gratuit et premium, multijoueur, paiements par carte et demandes de paiement en espèces.

## Rôles
- `creator` : Younes, contrôle complet.
- `vice_creator` : Moustafa, validation des paiements espèces et des sanctions.
- `moderator` : peut signaler une demande de bannissement, mais ne peut pas bannir directement.
- `user` : joueur standard.

Les comptes initiaux Younes et Moustafa disposent d'empreintes de mots de passe dans le stockage. Leurs mots de passe actuels ne sont pas lisibles en clair et les données existantes sont conservées lors de cette mise à jour.

## Paiements en espèces
Un joueur connecté choisit « Payer en espèces ». Une demande serveur est créée. Elle apparaît dans le Centre de contrôle des créateurs. Le jeu n'est ajouté à la bibliothèque qu'après validation par Younes ou Moustafa.

## Modération
Le créateur peut promouvoir un utilisateur en modérateur. Le modérateur choisit une cible et fournit un motif. La demande est ensuite approuvée ou refusée par Younes ou Moustafa. Les comptes créateur et vice-créateur sont protégés de ce workflow.

## Développement
npm install
copy .env.example .env.local
npm run dev

Pour le multijoueur :
cd multiplayer-server
npm install
npm start


## Déploiement et EagleCraft

- Mono-écrivain TCB : consulter `TCB_SINGLE_WRITER_GUIDE.md` avant de configurer les variables serveur.
- Page EagleCraft : route `/games/eaglecraft`; lire `EAGLECRAFT_ATERNOS_PROTOCOL.md` pour les limites de passerelle et de compatibilité.
- Modifications IA/maintenance TCB : voir `MODIFICATIONS_OCTOBRE_2026.md`.

## Passerelle EagleCraft

Le service Node de relais WebSocket se trouve dans `gateway-eaglercraft/`. Le Blueprint Render à la racine (`render.yaml`) le déploie comme service séparé. Voir `gateway-eaglercraft/README.md` pour régler `UPSTREAM_WS_URL` avec l'adresse EaglerXServer exacte et configurer `NEXT_PUBLIC_EAGLECRAFT_GATEWAY_URL` dans le déploiement de TCB. La passerelle doit être déployée séparément ; inclure le code dans le ZIP ne l'héberge pas automatiquement.
