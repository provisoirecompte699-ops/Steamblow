# TheCombinedWebs v60 : démarrage du ZIP complet

Ce ZIP contient le projet Next.js modifié, ses assets, le serveur proxy, le serveur multijoueur, les tests et la documentation. Le fichier `data/users.json` fourni dans l'archive v59 est conservé à l'identique ; les comptes et les opérations de contrôle utilisés pour l'aperçu ne sont pas inclus.

## Confidentialité

Cette archive contient les données originales de tes comptes. Garde-la privée : ne publie pas `data/` dans un dépôt public et ne l'expose pas comme dossier de fichiers statiques.

Les dépendances installées, les builds locaux, l'historique Git, les journaux, les caches et les données de test sont exclus. Les dépendances seront réinstallées à partir des fichiers `package.json` et `package-lock.json`.

## Démarrage

Depuis le dossier `thecombinedwebs_v60`, après extraction :

```sh
npm ci
npm run test:features
npm run smoke
npm run dev
```

Ouvre l'adresse locale indiquée par Next.js. Pour un déploiement de production, configure d'abord les variables nécessaires, puis :

```sh
npm run build
npm start
```

## Configuration nécessaire

- **Sessions** : aucune clé manuelle ; Netlify Blobs ou un volume Node persistant conserve les sessions côté serveur. Reconnexion nécessaire après cette mise à jour.
- **Économie** : utiliser un serveur Node unique avec un dossier de données persistant. Ne pas répartir les nouvelles opérations bancaires sur plusieurs instances indépendantes.
- **Proxy** : déployer la version incluse dans `proxy-server/` et renseigner `PROXY_SECRET` sur les deux services ainsi que `NEXT_PUBLIC_PROXY_URL` dans le projet.
- **Notifications** : configurer les clés VAPID et servir l'application en HTTPS.
- **Loterie ponctuelle** : programmer l'appel authentifié au tirage, avec `TCB_CRON_SECRET`. Sans ordonnanceur, le tirage échu sera réglé à la prochaine consultation.

Le fichier `NOTES_V60.md` explique les règles des mises et des dettes, les fonctionnalités, les tests, les limites et toutes les variables à configurer. Le dossier `preview/` et ses scripts concernent l'aperçu de contrôle ; il n'est pas nécessaire de lancer cet aperçu pour utiliser le projet Next.js complet.
