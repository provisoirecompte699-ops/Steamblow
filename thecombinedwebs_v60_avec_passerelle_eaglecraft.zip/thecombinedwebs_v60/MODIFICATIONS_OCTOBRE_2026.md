# Modifications intégrées

- Suppression des fonctionnalités IA du site : page YounesAI, API associée, moniteur, agent de développement, scripts et fonctions planifiées.
- Suppression du mode de maintenance global et de la maintenance programmée de TCB Plus. La modération des signalements reste disponible.
- Retrait de l’onglet IA de TCB Plus et de l’endpoint `/api/tcb/ai`.
- Documentation de déploiement mono-écrivain : voir `TCB_SINGLE_WRITER_GUIDE.md`. Ne pas activer `TCB_SINGLE_WRITER=true` sur des fonctions Netlify indépendantes.
- EagleCraft se trouve à `/games/eaglecraft`. Cette page ouvre le client via `https://eaglercraft.com/play/` et garde l’adresse `youknowbro.eagler.host`. Une passerelle WebSocket Eaglercraft compatible reste nécessaire pour jouer sur ce serveur depuis le navigateur.
