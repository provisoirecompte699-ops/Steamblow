THECOMBINEDWEBS — HELLO NEIGHBOR PRE-ALPHA

Ce dossier est prévu pour recevoir un build WEB / HTML5 autorisé du jeu.

Fichier attendu :
  public/games/hello-neighbor-prealpha/index.html

Le navigateur chargera alors ce build directement dans TheCombinedWebs, sans lien Steam.

Ne copie pas les fichiers propriétaires d une distribution si tu n as pas le droit de les redistribuer.

NOTE v57 : le index.html actuellement présent est une version "hommage" 2D écrite pour TheCombinedWebs
(pas le jeu officiel de tinyBuild). Elle gère le multijoueur : les amis du même salon apparaissent
en vert, avec leur nombre de clés, et on peut envoyer des emotes (touches 1 à 4).
Si tu as un build web OFFICIEL et autorisé, remplace index.html par ce build.
