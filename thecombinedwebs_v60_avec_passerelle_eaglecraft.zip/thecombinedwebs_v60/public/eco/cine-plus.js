/* CinéStream v52 : Reprendre, Ma liste, Recommandé pour toi, avis des amis, soirée ciné.
   Les données sont liées au compte TheCombinedWebs (API /api/films/*). */
(function () {
  "use strict";
  var me = { list: [], history: [] };
  var ready = false;
  var $ = function (id) { return document.getElementById(id); };
  var esc = function (s) { return String(s == null ? "" : s).replace(/[&<>"']/g, function (c) { return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]; }); };
  var keyOf = function (it) { return it && it.tmdbId ? (it.mediaType === "tv" ? "tv-" : "m-") + it.tmdbId : null; };
  var byKey = function (k) { if (!window.CS) return null; for (var i = 0; i < CS.CATALOG.length; i++) if (keyOf(CS.CATALOG[i]) === k) return CS.CATALOG[i]; return null; };
  var post = function (url, body) { return fetch(url, { method: "POST", credentials: "same-origin", headers: { "content-type": "application/json" }, body: JSON.stringify(body) }).then(function (r) { return r.json(); }); };

  function css() {
    var s = document.createElement("style");
    s.textContent = ".ip-plus{display:flex;flex-direction:column;gap:8px;margin-top:10px}" +
      ".ip-plus .cp-row{display:flex;gap:8px;flex-wrap:wrap;align-items:center}" +
      ".cp-btn{border:1px solid var(--line,#2a2f3a);background:#1a1d26;color:#fff;border-radius:9px;padding:6px 11px;font:inherit;font-size:.78rem;font-weight:700;cursor:pointer}" +
      ".cp-btn.on{background:#fff;color:#0b0c10}" +
      ".cp-stars button{background:none;border:0;color:#555b6b;font-size:1.25rem;cursor:pointer;padding:0 1px}.cp-stars button.on{color:#ffd43b}" +
      ".cp-rev{font-size:.78rem;color:#c9ced8;border-left:2px solid #8b7cff;padding-left:8px}.cp-rev b{color:#fff}.cp-rev .f{color:#5ee7c4;font-size:.7rem}" +
      ".cp-ta{width:100%;min-height:46px;background:#0b0d13;border:1px solid var(--line,#2a2f3a);color:#fff;border-radius:8px;padding:6px 8px;font:inherit;font-size:.8rem;resize:vertical}" +
      ".cp-avg{font-size:.78rem;color:#a9afbd}.card .cp-prog{position:absolute;left:0;bottom:0;height:3px;background:#e50914}" +
      ".card .cp-ep{position:absolute;right:6px;bottom:24px;font-size:.66rem;font-weight:800;background:#000b;padding:2px 6px;border-radius:4px}";
    document.head.appendChild(s);
  }

  function rows() {
    if (!window.CS || !ready) return;
    var resume = me.history.map(function (h) { var it = byKey(h.key); if (!it) return null; return { it: it, h: h }; }).filter(Boolean).slice(0, 16);
    var r = $("rowResume");
    if (r) {
      r.hidden = !resume.length;
      if (resume.length) {
        var el = $("listResume"); el.innerHTML = "";
        resume.forEach(function (x) {
          var c = CS.card(x.it, false);
          if (x.it.mediaType === "tv" && x.h.season) {
            var tag = document.createElement("span"); tag.className = "cp-ep"; tag.textContent = "S" + x.h.season + " · E" + (x.h.episode || 1);
            var p = c.querySelector(".poster"); if (p) p.appendChild(tag);
            c.onclick = function () { x.it.season = x.h.season; x.it.episode = x.h.episode || 1; CS.openItem(x.it, false); };
          }
          el.appendChild(c);
        });
      }
    }
    var mine = me.list.map(function (l) { return byKey(l.key); }).filter(Boolean);
    var ml = $("rowMyList");
    if (ml) { ml.hidden = !mine.length; if (mine.length) { CS.fill($("listMyList"), mine); $("myListCount").textContent = mine.length + " titre" + (mine.length > 1 ? "s" : ""); } }
    // Recommandations : catégories et tags les plus regardés, titres pas encore vus
    var seen = {}, cats = {}, tags = {};
    me.history.concat(me.list).forEach(function (h) { seen[h.key] = 1; var it = byKey(h.key); if (!it) return; cats[it.cat] = (cats[it.cat] || 0) + 2; (it.tags || []).forEach(function (t) { tags[t] = (tags[t] || 0) + 1; }); });
    var reco = [];
    if (Object.keys(seen).length) {
      reco = CS.CATALOG.filter(function (it) { return it.tmdbId && !seen[keyOf(it)]; }).map(function (it) {
        var s = (cats[it.cat] || 0); (it.tags || []).forEach(function (t) { s += tags[t] || 0; });
        return { it: it, s: s + Math.random() * 0.5 };
      }).filter(function (x) { return x.s >= 1; }).sort(function (a, b) { return b.s - a.s; }).slice(0, 16).map(function (x) { return x.it; });
    }
    var rr = $("rowReco"); if (rr) { rr.hidden = !reco.length; if (reco.length) CS.fill($("listReco"), reco); }
  }

  function load() {
    fetch("/api/films/me", { credentials: "same-origin", cache: "no-store" }).then(function (r) { return r.ok ? r.json() : null; }).then(function (d) {
      if (!d) return; me = { list: d.list || [], history: d.history || [] }; ready = true; rows();
    }).catch(function () {});
  }

  var curKey = null;
  function panel(item) {
    var box = $("ipPlus"); if (!box) return;
    var k = keyOf(item); curKey = k;
    if (!k) { box.innerHTML = ""; return; }
    var ip = $("infoPanel"); if (ip) ip.style.display = "flex";
    if (!item.desc) { $("ipTitle").textContent = item.title; $("ipDesc").textContent = ""; }
    var inList = me.list.some(function (l) { return l.key === k; });
    box.innerHTML = '<div class="cp-row"><button class="cp-btn' + (inList ? " on" : "") + '" id="cpList">' + (inList ? "✓ Dans ma liste" : "+ Ma liste") + '</button>' +
      '<button class="cp-btn" id="cpParty">🍿 Regarder avec des amis</button><span class="cp-avg" id="cpAvg"></span></div>' +
      '<div class="cp-row"><span class="cp-stars" id="cpStars">' + [1, 2, 3, 4, 5].map(function (n) { return '<button data-n="' + n + '" aria-label="' + n + ' étoile' + (n > 1 ? "s" : "") + '">★</button>'; }).join("") + '</span><span class="cp-avg">Ta note</span></div>' +
      '<textarea class="cp-ta" id="cpText" maxlength="400" placeholder="Ton avis (facultatif)"></textarea><div class="cp-row"><button class="cp-btn" id="cpSend">Publier mon avis</button></div><div id="cpRevs"></div>';
    var rating = 0;
    var paint = function () { [].forEach.call(box.querySelectorAll("#cpStars button"), function (b) { b.classList.toggle("on", +b.dataset.n <= rating); }); };
    [].forEach.call(box.querySelectorAll("#cpStars button"), function (b) { b.onclick = function () { rating = +b.dataset.n; paint(); }; });
    $("cpList").onclick = function () {
      post("/api/films/list", { key: k, title: item.title, poster: CS.posterUrl(item) || "", type: item.mediaType === "tv" ? "tv" : "movie" }).then(function (d) {
        if (d.error) return CS.toast(d.error); me.list = d.list; var b = $("cpList"); if (b) { b.classList.toggle("on", d.inList); b.textContent = d.inList ? "✓ Dans ma liste" : "+ Ma liste"; } CS.toast(d.inList ? "Ajouté à ta liste" : "Retiré de ta liste"); rows();
      });
    };
    $("cpParty").onclick = function () {
      if (window.parent !== window) window.parent.postMessage({ type: "cs-party-open", film: filmOf(item) }, location.origin);
      else location.href = "/cinestream";
    };
    $("cpSend").onclick = function () {
      if (!rating) return CS.toast("Choisis une note de 1 à 5 étoiles");
      post("/api/films/reviews", { key: k, title: item.title, rating: rating, text: $("cpText").value }).then(function (d) { if (d.error) return CS.toast(d.error); CS.toast("Avis publié · +10 XP"); reviews(k); });
    };
    reviews(k, function (mine) { if (mine) { rating = mine.rating; paint(); $("cpText").value = mine.text || ""; } });
  }
  function reviews(k, cb) {
    fetch("/api/films/reviews?key=" + encodeURIComponent(k), { credentials: "same-origin", cache: "no-store" }).then(function (r) { return r.json(); }).then(function (d) {
      if (curKey !== k || d.error) return;
      $("cpAvg").textContent = d.count ? "★ " + d.avg.toFixed(1) + " / 5 · " + d.count + " avis" : "Pas encore d’avis";
      $("cpRevs").innerHTML = (d.reviews || []).slice(0, 6).map(function (r) { return '<div class="cp-rev"><b>' + esc(r.u) + '</b> ' + (r.friend ? '<span class="f">ami</span> ' : "") + '<span style="color:#ffd43b">' + "★".repeat(r.rating) + '</span>' + (r.text ? "<br>" + esc(r.text) : "") + "</div>"; }).join("");
      if (cb) cb(d.mine);
    }).catch(function () {});
  }
  function filmOf(item) { return { key: keyOf(item), title: item.title, tmdbId: item.tmdbId, type: item.mediaType === "tv" ? "tv" : "movie", season: item.season || 1, episode: item.episode || 1, poster: (window.CS && CS.posterUrl(item)) || "" }; }

  var lastSent = "";
  window.CSPlus = {
    onOpen: function (item, isLocal) {
      if (isLocal) return resumeLocal(item);
      var k = keyOf(item); if (!k) return;
      panel(item);
      var sig = k + ":" + (item.season || "") + ":" + (item.episode || "");
      if (sig !== lastSent) {
        lastSent = sig;
        post("/api/films/history", { key: k, title: item.title, poster: CS.posterUrl(item) || "", type: item.mediaType === "tv" ? "tv" : "movie", cat: item.cat, season: item.mediaType === "tv" ? item.season || 1 : undefined, episode: item.mediaType === "tv" ? item.episode || 1 : undefined })
          .then(function (d) { if (d && d.history) { me.history = d.history; rows(); } }).catch(function () {});
      }
      if (window.parent !== window) window.parent.postMessage({ type: "cs-open", film: filmOf(item) }, location.origin);
    }
  };

  // Reprise exacte pour les fichiers locaux (le temps est enregistré dans ce navigateur)
  function resumeLocal(item) {
    var v = $("vid"); if (!v || !item) return;
    var key = "cs:pos:" + (item.title || item.name || "");
    var pos = +localStorage.getItem(key) || 0;
    var once = function () { v.removeEventListener("loadedmetadata", once); if (pos > 10 && pos < (v.duration || 1e9) - 15) { v.currentTime = pos; window.CS && CS.toast("Reprise à " + Math.floor(pos / 60) + " min " + Math.floor(pos % 60) + " s"); } };
    v.addEventListener("loadedmetadata", once);
    v.ontimeupdate = function () { if (Math.floor(v.currentTime) % 5 === 0) localStorage.setItem(key, String(v.currentTime)); };
  }

  // Soirée ciné : la page parente demande d'ouvrir un titre
  window.addEventListener("message", function (e) {
    if (e.origin !== location.origin || !e.data) return;
    if (e.data.type === "cs-play" && e.data.film && window.CS) {
      var it = byKey(e.data.film.key); if (!it) return CS.toast("Titre introuvable dans le catalogue");
      if (it.mediaType === "tv") { it.season = e.data.film.season || 1; it.episode = e.data.film.episode || 1; }
      CS.openItem(it, false);
    }
  });

  function boot() { css(); load(); }
  if (window.CS) boot(); else window.addEventListener("cs-ready", boot, { once: true });
})();
