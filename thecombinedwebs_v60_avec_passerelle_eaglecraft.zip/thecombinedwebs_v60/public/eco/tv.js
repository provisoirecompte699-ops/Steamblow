/* TheCombinedWebs + CinéStream · Mode TV (même script sur tout l'écosystème)
   - S'active tout seul sur les téléviseurs (Android TV, Google TV, Fire TV, Samsung Tizen, LG webOS, Philips, Sony…)
     ou avec ?tv=1 (désactivation : ?tv=0). Bouton « Mode TV » dans l'en-tête pour basculer à la main.
   - Navigation à la télécommande : flèches = déplacer le focus, OK/Entrée = ouvrir, Retour = fermer.
   - Interface agrandie, lisible à 3 mètres, avec un focus bien visible. */
(function () {
  "use strict";
  var KEY = "cs-tv";
  var UA = navigator.userAgent || "";
  var TV_RE = /SmartTV|SMART-TV|Tizen|Web0S|webOS|NetCast|HbbTV|BRAVIA|Viera|AFT[A-Z]|Android TV|GoogleTV|CrKey|Roku|AppleTV|PhilipsTV|Hisense|VIDAA|SteambloxTV|; ?TV;/i;
  function topSearch() { try { return (window.top || window).location.search || ""; } catch (e) { return ""; } }
  var q = location.search + "&" + topSearch();
  if (/[?&]tv=1/.test(q)) try { localStorage.setItem(KEY, "1"); } catch (e) {}
  if (/[?&]tv=0/.test(q)) try { localStorage.setItem(KEY, "0"); } catch (e) {}
  var pref = null; try { pref = localStorage.getItem(KEY); } catch (e) {}
  var on = pref === "1" || (pref !== "0" && TV_RE.test(UA));

  var CS = document.body ? document.body.classList.contains("cs-app") : /cinestream/.test(location.pathname);
  var css = document.createElement("style");
  css.id = "cs-tv-style";
  css.textContent = [
    "html.cs-tv.cs-page{font-size:20px}",
    "html.cs-tv body{cursor:none}",
    "html.cs-tv .cs-app .top{padding:18px 5vw;gap:18px}",
    "html.cs-tv .cs-app .nav button{font-size:1rem;padding:10px 16px;border-radius:12px}",
    "html.cs-tv .cs-app .search input{font-size:1rem;padding:12px 16px}",
    "html.cs-tv .cs-app .card{flex:0 0 220px}",
    "html.cs-tv:not(.cs-page) a,html.cs-tv:not(.cs-page) button{scroll-margin:120px}",
    "html.cs-tv .cs-app .card:hover{transform:none}",
    "html.cs-tv .cs-app .row{margin-bottom:34px}",
    "html.cs-tv .cs-app .row-h h2{font-size:1.5rem}",
    "html.cs-tv .cs-app .scroller{gap:18px;padding:22px 10px 22px;scroll-snap-type:none}",
    "html.cs-tv .cs-app .hero{min-height:62vh}",
    "html.cs-tv .cs-app .hero h1{font-size:3.4rem}",
    "html.cs-tv .cs-app .btn{font-size:1.1rem;padding:16px 28px}",
    "html.cs-tv .cs-app .raimi-banner,html.cs-tv #btnAdd,html.cs-tv #btnBrowse{display:none!important}",
    "html.cs-tv .tv-focus{outline:4px solid #fff!important;outline-offset:4px;border-radius:14px;box-shadow:0 0 0 8px rgba(255,77,109,.45),0 20px 50px -10px rgba(0,0,0,.9)!important;z-index:5}",
    "html.cs-tv .card.tv-focus{transform:scale(1.06)!important;transition:transform .15s}",
    "html.cs-tv .card.tv-focus .label{opacity:1!important}",
    "html.cs-tv :focus{outline:none}",
    "html.cs-tv .modal button,html.cs-tv .fp-card button{min-height:48px}",
    ".cs-tv-btn{appearance:none;border:1px solid rgba(255,255,255,.16);background:rgba(255,255,255,.06);color:#fff;border-radius:999px;padding:6px 12px;font:inherit;font-size:.78rem;font-weight:700;cursor:pointer;white-space:nowrap}",
    "html.cs-tv .cs-tv-btn{background:#fff;color:#0b0d14;font-size:.9rem;padding:10px 16px}",
    ".cs-tv-hint{position:fixed;left:50%;bottom:24px;transform:translateX(-50%);z-index:2147483000;background:rgba(10,12,20,.92);border:1px solid rgba(255,255,255,.15);color:#e9ecef;padding:12px 20px;border-radius:14px;font-size:16px;display:none;gap:18px}",
    "html.cs-tv .cs-tv-hint.show{display:flex}",
    ".cs-tv-hint kbd{display:inline-block;min-width:26px;text-align:center;padding:2px 7px;margin-right:6px;border-radius:7px;background:#fff;color:#0b0d14;font:700 13px system-ui}"
  ].join("\n");
  document.head.appendChild(css);

  function setOn(v) {
    on = !!v;
    document.documentElement.classList.toggle("cs-tv", on);
    try { localStorage.setItem(KEY, on ? "1" : "0"); } catch (e) {}
    if (btn) btn.textContent = on ? "📺 Quitter le mode TV" : "📺 Mode TV";
    if (on) { makeFocusable(); setTimeout(function () { if (!current || !document.contains(current)) focusFirst(); }, 300); hint(); }
    else if (current) { current.classList.remove("tv-focus"); current = null; }
  }

  // ————— Éléments navigables —————
  var SEL = "button:not([disabled]),a[href],input:not([type=hidden]):not([disabled]),select,textarea,summary,[role=button],[tabindex]:not([tabindex='-1']),.cs-app .card,[data-tv]";
  function visible(el) {
    if (!el || el.closest("[hidden]")) return false;
    var r = el.getBoundingClientRect();
    if (r.width < 4 || r.height < 4) return false;
    var cs = getComputedStyle(el);
    return cs.visibility !== "hidden" && cs.display !== "none" && +cs.opacity > 0.05;
  }
  function scope() {
    var fp = document.querySelector(".fp-back"); if (fp) return fp;
    var m = document.getElementById("modal"); if (m && m.classList.contains("show")) return m;
    var dlg = document.querySelectorAll("[role=dialog][aria-modal=true],dialog[open]"); if (dlg.length) return dlg[dlg.length - 1];
    var gate = document.getElementById("csGate"); if (gate && visible(gate) && getComputedStyle(gate).display !== "none") return gate;
    return document.body;
  }
  function items() {
    var root = scope();
    var big = window.innerWidth * window.innerHeight * 0.3;
    return Array.prototype.filter.call(root.querySelectorAll(SEL), function (el) {
      if (!visible(el) || el.closest(".cs-tv-hint")) return false;
      if (/^(SECTION|DIV|MAIN|ARTICLE)$/.test(el.tagName) && !(CS && el.classList.contains("card")) && !el.hasAttribute("data-tv")) { var r = el.getBoundingClientRect(); if (r.width * r.height > big || el.querySelector("a[href],button")) return false; }
      return true;
    });
  }
  function makeFocusable() {
    var cards = document.querySelectorAll(".cs-app .card:not([tabindex])");
    for (var i = 0; i < cards.length; i++) cards[i].setAttribute("tabindex", "0");
  }

  var current = null;
  function focus(el) {
    if (!el) return;
    if (current) current.classList.remove("tv-focus");
    current = el; el.classList.add("tv-focus");
    try { el.focus({ preventScroll: true }); } catch (e) { el.focus(); }
    // défilement : horizontal dans la rangée, vertical dans la page
    var sc = el.closest(".scroller");
    if (sc) {
      var r = el.getBoundingClientRect(), s = sc.getBoundingClientRect();
      if (r.left < s.left + 40) sc.scrollBy({ left: r.left - s.left - 60, behavior: "smooth" });
      else if (r.right > s.right - 40) sc.scrollBy({ left: r.right - s.right + 60, behavior: "smooth" });
    }
    var rr = el.getBoundingClientRect(), vh = window.innerHeight;
    var box = el.closest(".modal,.fp-card");
    if (box && box.scrollHeight > box.clientHeight) { el.scrollIntoView({ block: "nearest", behavior: "smooth" }); }
    else if (rr.top < 110 || rr.bottom > vh - 40) window.scrollBy({ top: rr.top - vh * 0.38, behavior: "smooth" });
  }
  function focusFirst() {
    var list = items();
    var main = list.filter(function (el) { return el.closest("main") && !el.closest("nav,header"); });
    var pref = list.filter(function (el) { return el.id === "btnPlay" || el.classList.contains("arc-play"); })[0] || list.filter(function (el) { return el.classList.contains("card"); })[0] || main[0] || list[0];
    focus(pref);
  }

  // Recherche spatiale : élément le plus proche dans la direction demandée
  function move(dir) {
    var list = items();
    if (!current || list.indexOf(current) < 0) { focusFirst(); return; }
    var a = current.getBoundingClientRect();
    var ax = a.left + a.width / 2, ay = a.top + a.height / 2;
    var best = null, bestScore = Infinity;
    for (var i = 0; i < list.length; i++) {
      var el = list[i]; if (el === current) continue;
      var b = el.getBoundingClientRect();
      var bx = b.left + b.width / 2, by = b.top + b.height / 2;
      var dx = bx - ax, dy = by - ay, main, cross;
      if (dir === "right") { if (b.left < a.right - 6 && dx <= 4) continue; main = dx; cross = Math.abs(dy); }
      else if (dir === "left") { if (b.right > a.left + 6 && dx >= -4) continue; main = -dx; cross = Math.abs(dy); }
      else if (dir === "down") { if (b.top < a.bottom - 6 && dy <= 4) continue; main = dy; cross = Math.abs(dx); }
      else { if (b.bottom > a.top + 6 && dy >= -4) continue; main = -dy; cross = Math.abs(dx); }
      if (main <= 0) continue;
      // même rangée horizontale : on reste dans la rangée
      var sameRow = (dir === "left" || dir === "right") && Math.abs(dy) < Math.max(a.height, b.height) * 0.6;
      var score = main + cross * (dir === "left" || dir === "right" ? (sameRow ? 0.2 : 4) : 1.6);
      if (score < bestScore) { bestScore = score; best = el; }
    }
    if (best) focus(best);
  }

  // Retour : ferme le calque ouvert. Renvoie true si quelque chose a été fermé.
  function back() {
    var fp = document.querySelector(".fp-back .fp-x"); if (fp) { fp.click(); setTimeout(restore, 50); return true; }
    var m = document.getElementById("modal");
    if (m && m.classList.contains("show")) { var c = document.getElementById("btnClose"); if (c) c.click(); setTimeout(restore, 80); return true; }
    var dlg = document.querySelectorAll("[role=dialog][aria-modal=true],dialog[open]");
    if (dlg.length) { var d = dlg[dlg.length - 1], x = d.querySelector("[aria-label=Fermer],[data-close],.close,button[title=Fermer]"); if (x) { x.click(); setTimeout(focusFirst, 80); return true; } }
    var a = document.activeElement;
    if (a && /INPUT|TEXTAREA/.test(a.tagName)) { a.blur(); return true; }
    if (window.scrollY > 200) { window.scrollTo({ top: 0, behavior: "smooth" }); setTimeout(focusFirst, 300); return true; }
    return false;
  }
  var lastCard = null;
  function restore() { if (lastCard && document.contains(lastCard) && visible(lastCard)) focus(lastCard); else focusFirst(); }
  window.SBBack = function () { return on ? back() : false; };
  window.CSTV = { on: function () { return on; }, set: setOn, back: back };
  // Standard Gamepad mapping: D-pad / left stick, A confirm, B back, Start TV.
  // Input repeat is bounded; release is required for clicks and toggles.
  var padPrevious = {}, padRepeat = 0;
  function pollPad(now) {
    var pads; try { pads = navigator.getGamepads ? navigator.getGamepads() : []; } catch (e) { pads = []; }
    var pad = Array.prototype.find.call(pads, function (p) { return p && p.connected; });
    if (pad) {
      var pressed = function (i) { return !!(pad.buttons[i] && pad.buttons[i].pressed); };
      if (pressed(9) && !padPrevious.start) setOn(!on);
      var ingame = document.documentElement.hasAttribute("data-tvgame") || document.pointerLockElement;
      if (on && !ingame) {
        var x = pad.axes[0] || 0, y = pad.axes[1] || 0;
        var dir = pressed(12) || y < -.6 ? "up" : pressed(13) || y > .6 ? "down" : pressed(14) || x < -.6 ? "left" : pressed(15) || x > .6 ? "right" : null;
        var editing = document.activeElement && document.activeElement.tagName === "SELECT" && document.activeElement.dataset.padEditing;
        if (dir && (dir !== padPrevious.dir || now >= padRepeat)) {
          if (editing) {
            var select = document.activeElement;
            select.selectedIndex = Math.max(0, Math.min(select.options.length-1, select.selectedIndex+(dir==="up"||dir==="left"?-1:1)));
            select.dispatchEvent(new Event("change", { bubbles: true }));
          } else move(dir);
          padRepeat = now + (dir === padPrevious.dir ? 180 : 350);
        }
        var el = document.activeElement && scope().contains(document.activeElement) ? document.activeElement : current;
        if (pressed(0) && !padPrevious.confirm && el) {
          if (el.tagName === "SELECT") {
            if (!el.dataset.padEditing) el.dataset.padEditing = "1"; else delete el.dataset.padEditing;
          } else if (/INPUT|TEXTAREA/.test(el.tagName) && el.type !== "checkbox") {
            window.dispatchEvent(new CustomEvent("tcb-pad-keyboard", { detail: { element: el } }));
          } else el.click();
        }
        if (pressed(1) && !padPrevious.back) { if (el && el.dataset.padEditing) delete el.dataset.padEditing; else if (!back()) history.back(); }
      }
      padPrevious = { start: pressed(9), confirm: pressed(0), back: pressed(1), dir: dir };
    } else padPrevious = {};
    requestAnimationFrame(pollPad);
  }
  requestAnimationFrame(pollPad);

  var BACK_CODES = { 10009: 1, 461: 1, 8: 1, 27: 1, 166: 1 }; // Tizen, webOS, Retour arrière, Échap, Back navigateur
  window.addEventListener("keydown", function (e) {
    if (!on) return;
    if (document.documentElement.hasAttribute("data-tvgame") || document.pointerLockElement) return; // le jeu reçoit les touches
    var t = e.target, typing = t && (t.tagName === "INPUT" || t.tagName === "TEXTAREA") && t.type !== "checkbox";
    var k = e.key, dir = k === "ArrowRight" ? "right" : k === "ArrowLeft" ? "left" : k === "ArrowDown" ? "down" : k === "ArrowUp" ? "up" : null;
    if (dir) {
      if (typing && (dir === "left" || dir === "right")) return; // déplacement du curseur dans le texte
      e.preventDefault(); e.stopImmediatePropagation(); move(dir); return;
    }
    if (k === "Enter" || k === "OK" || e.keyCode === 13) {
      if (typing) { if (t.form) return; t.blur(); return; }
      if (current && document.contains(current)) {
        e.preventDefault(); e.stopImmediatePropagation();
        if (current.classList.contains("card")) lastCard = current;
        current.click();
        if (/INPUT|TEXTAREA|SELECT/.test(current.tagName)) current.focus();
        setTimeout(function () { makeFocusable(); var s = scope(); if (s !== document.body && (!current || !s.contains(current))) { var f = items()[0]; var pl = s.querySelector("#btnClose"); focus(f && f !== pl ? f : pl || f); } }, 350);
      }
      return;
    }
    if ((k === "Escape" || k === "GoBack" || k === "BrowserBack" || BACK_CODES[e.keyCode]) && !(typing && k === "Backspace")) {
      if (back()) { e.preventDefault(); e.stopImmediatePropagation(); }
      return;
    }
    if (k === "MediaPlayPause" || k === " " && !typing) {
      var v = document.querySelector("#modal.show video");
      if (v) { e.preventDefault(); v.paused ? v.play() : v.pause(); }
    }
  }, true);
  // la souris / le tactile reprennent la main
  window.addEventListener("mousemove", function () { if (current) current.classList.remove("tv-focus"); }, { passive: true });

  // Webos/Tizen : déclarer les touches de la télécommande
  try { if (window.tizen && tizen.tvinputdevice) ["MediaPlayPause", "MediaPlay", "MediaPause", "ColorF0Red"].forEach(function (n) { try { tizen.tvinputdevice.registerKey(n); } catch (e) {} }); } catch (e) {}

  var hintTimer = null, hintEl = null;
  function hint() {
    if (!hintEl) {
      hintEl = document.createElement("div"); hintEl.className = "cs-tv-hint";
      hintEl.innerHTML = "<span><kbd>←→↑↓</kbd>Naviguer</span><span><kbd>OK</kbd>Ouvrir</span><span><kbd>↩</kbd>Retour</span>";
      document.body.appendChild(hintEl);
    }
    hintEl.classList.add("show"); clearTimeout(hintTimer); hintTimer = setTimeout(function () { hintEl.classList.remove("show"); }, 6000);
  }

  var btn = null;
  function mountButton() {
    var top = document.querySelector(".cs-app .top"); if (!top || document.querySelector(".cs-tv-btn")) return;
    btn = document.createElement("button"); btn.type = "button"; btn.className = "cs-tv-btn"; btn.setAttribute("data-tv", "");
    btn.textContent = on ? "📺 Quitter le mode TV" : "📺 Mode TV";
    btn.title = "Interface pour téléviseur, navigable à la télécommande";
    btn.onclick = function () { setOn(!on); };
    var user = document.getElementById("csUser");
    top.insertBefore(btn, user || null);
  }
  function init() {
    CS = document.body.classList.contains("cs-app");
    document.documentElement.classList.toggle("cs-page", CS);
    mountButton();
    new MutationObserver(function () { if (!on) return; makeFocusable(); if (current && !document.contains(current)) { current = null; setTimeout(function () { if (!current) focusFirst(); }, 250); } }).observe(document.body, { childList: true, subtree: true });
    setOn(on);
  }
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", init); else init();
})();
