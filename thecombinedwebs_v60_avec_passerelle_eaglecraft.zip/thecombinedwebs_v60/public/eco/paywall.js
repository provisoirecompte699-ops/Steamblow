/* TheCombinedWebs FilmPay — chaque film ou série est payant (2,99 €).
   Deux moyens de paiement : espèces (remises à Younes ou Moustafa) ou une blague jugée par eux.
   Le déblocage est enregistré côté serveur sur le compte TheCombinedWebs (API /api/films). */
(function () {
  "use strict";
  var state = null, loading = null;
  var PRICE_TXT = "2,99 €";

  function css() {
    if (document.getElementById("fp-style")) return;
    var s = document.createElement("style"); s.id = "fp-style";
    s.textContent = [
      ".fp-back{position:fixed;inset:0;z-index:2147483600;background:rgba(4,5,10,.72);backdrop-filter:blur(10px);display:grid;place-items:center;padding:16px;animation:fpIn .2s ease}",
      "@keyframes fpIn{from{opacity:0}to{opacity:1}}",
      ".fp-card{width:min(640px,100%);max-height:calc(100vh - 32px);overflow:auto;background:#10121b;color:#f1f3f5;border:1px solid rgba(255,255,255,.1);border-radius:22px;box-shadow:0 40px 100px -30px rgba(0,0,0,.9);font-family:Outfit,system-ui,sans-serif}",
      ".fp-head{display:flex;gap:16px;padding:20px 20px 14px;align-items:center;position:relative}",
      ".fp-head img{width:74px;height:110px;object-fit:cover;border-radius:12px;flex:none;background:#1b1e2b}",
      ".fp-kick{font-size:11px;letter-spacing:.14em;text-transform:uppercase;color:#ff4d6d;font-weight:800}",
      ".fp-title{margin:4px 0 6px;font-size:22px;line-height:1.15;font-weight:800;letter-spacing:-.01em}",
      ".fp-price{display:inline-flex;align-items:center;gap:8px;font-size:14px;color:#c9ced8}",
      ".fp-price b{font-size:20px;color:#fff}",
      ".fp-x{position:absolute;right:14px;top:14px;width:34px;height:34px;border-radius:50%;border:1px solid rgba(255,255,255,.12);background:rgba(255,255,255,.06);color:#fff;font-size:16px;cursor:pointer}",
      ".fp-note{margin:0 20px 12px;padding:10px 12px;border-radius:12px;font-size:13px;line-height:1.45;background:rgba(255,212,59,.1);border:1px solid rgba(255,212,59,.3);color:#ffe8a3}",
      ".fp-grid{display:grid;grid-template-columns:1fr 1fr;gap:12px;padding:0 20px 20px}",
      "@media(max-width:560px){.fp-grid{grid-template-columns:1fr}.fp-head img{width:60px;height:90px}.fp-title{font-size:19px}}",
      ".fp-opt{display:flex;flex-direction:column;gap:9px;padding:16px;border-radius:16px;background:rgba(255,255,255,.04);border:1px solid rgba(255,255,255,.09)}",
      ".fp-opt h3{margin:0;font-size:16px;font-weight:800}",
      ".fp-opt p{margin:0;font-size:13px;line-height:1.45;color:#aab1c0}",
      ".fp-opt textarea{width:100%;min-height:84px;resize:vertical;border-radius:12px;border:1px solid rgba(255,255,255,.14);background:rgba(0,0,0,.25);color:#fff;padding:10px 12px;font:inherit;font-size:14px;box-sizing:border-box}",
      ".fp-btn{margin-top:auto;appearance:none;border:0;border-radius:12px;padding:12px 14px;font:inherit;font-weight:800;font-size:14px;cursor:pointer;background:#fff;color:#0b0d14}",
      ".fp-btn.joke{background:#ffd43b}",
      ".fp-btn[disabled]{opacity:.5;cursor:default}",
      ".fp-msg{font-size:12.5px;min-height:16px;color:#8ce99a}.fp-msg.err{color:#ff8787}",
      ".fp-foot{display:flex;justify-content:space-between;align-items:center;gap:10px;padding:0 20px 18px;font-size:12px;color:#8b93a7}",
      ".fp-foot button{appearance:none;border:1px solid rgba(255,255,255,.14);background:transparent;color:#e9ecef;border-radius:10px;padding:8px 12px;font:inherit;font-weight:700;cursor:pointer}"
    ].join("\n");
    document.head.appendChild(s);
  }

  function load(force) {
    if (state && !force) return Promise.resolve(state);
    if (loading && !force) return loading;
    loading = fetch("/api/films", { credentials: "same-origin", cache: "no-store" })
      .then(function (r) { return r.ok ? r.json() : { loggedIn: false }; })
      .catch(function () { return { loggedIn: false, offline: true }; })
      .then(function (d) { state = d; loading = null; return d; });
    return loading;
  }
  function keyFor(type, id) { return (type === "tv" ? "tv-" : "m-") + String(id).replace(/\D/g, "").slice(0, 9); }
  function owns(key) { return !!(state && (state.privileged || (state.owned || []).indexOf(key) >= 0)); }
  function esc(t) { return String(t || "").replace(/[&<>"']/g, function (c) { return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]; }); }

  function post(body) {
    return fetch("/api/films/purchase", { method: "POST", credentials: "same-origin", headers: { "content-type": "application/json" }, body: JSON.stringify(body) })
      .then(function (r) { return r.json().then(function (d) { if (!r.ok) throw new Error(d.error || "Erreur"); state = Object.assign({}, state, d); return d; }); });
  }

  function show(o) {
    css();
    return new Promise(function (resolve) {
      var pend = state && state.pending ? state.pending[o.key] : null;
      var isTv = o.type === "tv";
      var back = document.createElement("div"); back.className = "fp-back"; back.setAttribute("role", "dialog"); back.setAttribute("aria-modal", "true");
      back.innerHTML =
        '<div class="fp-card">' +
          '<div class="fp-head">' + (o.poster ? '<img alt="" src="' + esc(o.poster) + '">' : "") +
            '<div><div class="fp-kick">' + (isTv ? "Série payante" : "Film payant") + '</div><div class="fp-title">' + esc(o.title) + '</div>' +
            '<div class="fp-price"><b>' + PRICE_TXT + '</b>' + (isTv ? " · tous les épisodes" : " · accès illimité") + '</div></div>' +
            '<button class="fp-x" aria-label="Fermer">✕</button></div>' +
          (pend ? '<div class="fp-note">' + (pend === "cash" ? "Ta demande de paiement en espèces est en attente. Le film se débloque dès que Younes ou Moustafa confirme avoir reçu " + PRICE_TXT + "." : "Ta blague est en cours de jugement. Si elle fait rire, le film est offert.") + "</div>" : "") +
          '<div class="fp-grid">' +
            '<div class="fp-opt"><h3>💶 Payer en espèces</h3><p>Remets ' + PRICE_TXT + ' en main propre à Younes ou Moustafa. Ils valident la demande et le film se débloque sur ton compte.</p><div class="fp-msg" data-m="cash"></div><button class="fp-btn" data-a="cash"' + (pend === "cash" ? " disabled" : "") + '>' + (pend === "cash" ? "Demande envoyée" : "Envoyer la demande") + "</button></div>" +
            '<div class="fp-opt"><h3>😂 Payer avec une blague</h3><p>Écris ta meilleure blague. Si elle fait rire Younes ou Moustafa, le film t’est offert.</p><textarea maxlength="500" placeholder="Pourquoi les plongeurs plongent-ils toujours en arrière ?"' + (pend === "joke" ? " disabled" : "") + '></textarea><div class="fp-msg" data-m="joke"></div><button class="fp-btn joke" data-a="joke"' + (pend === "joke" ? " disabled" : "") + '>' + (pend === "joke" ? "Blague envoyée" : "Envoyer ma blague") + "</button></div>" +
          "</div>" +
          '<div class="fp-foot"><span>Aucune carte bancaire. Déblocage lié à ton compte TheCombinedWebs.</span><button data-a="refresh">Déjà validé ? Actualiser</button></div>' +
        "</div>";
      function close(ok) { document.removeEventListener("keydown", onKey); back.remove(); resolve(ok); }
      function onKey(e) { if (e.key === "Escape") close(false); }
      document.addEventListener("keydown", onKey);
      back.addEventListener("click", function (e) { if (e.target === back) close(false); });
      back.querySelector(".fp-x").onclick = function () { close(false); };
      var msg = function (k, t, err) { var m = back.querySelector('[data-m="' + k + '"]'); m.textContent = t; m.className = "fp-msg" + (err ? " err" : ""); };
      back.querySelector('[data-a="cash"]').onclick = function (e) {
        var b = e.currentTarget; b.disabled = true; msg("cash", "Envoi…");
        post({ key: o.key, title: o.title, method: "cash" }).then(function () { b.textContent = "Demande envoyée"; msg("cash", "Demande envoyée. Remets " + PRICE_TXT + " à Younes ou Moustafa."); })
          .catch(function (er) { b.disabled = false; msg("cash", er.message, true); });
      };
      back.querySelector('[data-a="joke"]').onclick = function (e) {
        var b = e.currentTarget, ta = back.querySelector("textarea"), joke = ta.value.trim();
        if (joke.length < 8) { msg("joke", "Ta blague est un peu courte.", true); return; }
        b.disabled = true; msg("joke", "Envoi…");
        post({ key: o.key, title: o.title, method: "joke", joke: joke }).then(function () { b.textContent = "Blague envoyée"; ta.disabled = true; msg("joke", "Blague envoyée. Verdict bientôt."); })
          .catch(function (er) { b.disabled = false; msg("joke", er.message, true); });
      };
      back.querySelector('[data-a="refresh"]').onclick = function () {
        load(true).then(function () { if (owns(o.key)) close(true); else msg(pend === "joke" ? "joke" : "cash", "Pas encore validé.", true); });
      };
      document.body.appendChild(back);
    });
  }

  /** Renvoie true si le film est débloqué, sinon ouvre l'écran de paiement. */
  function ensure(o) {
    return load(false).then(function (d) {
      if (!d || !d.loggedIn) { try { (window.top || window).location.href = "/login?next=" + encodeURIComponent((window.top || window).location.pathname); } catch (e) { location.href = "/login"; }; return false; }
      if (owns(o.key)) return true;
      return show(o);
    });
  }
  window.FilmPay = { ensure: ensure, keyFor: keyFor, owns: owns, refresh: function () { return load(true); }, price: PRICE_TXT };
  function paintChips() {
    if (!state || !state.loggedIn) return;
    var list = document.querySelectorAll("[data-fpkey]");
    for (var i = 0; i < list.length; i++) { var el = list[i]; var k = el.getAttribute("data-fpkey"); if (owns(k)) { el.textContent = "Débloqué"; el.classList.add("owned"); } else if (state.pending && state.pending[k]) { el.textContent = "En attente"; } }
  }
  load(false).then(paintChips);
  setInterval(paintChips, 2500);
})();
