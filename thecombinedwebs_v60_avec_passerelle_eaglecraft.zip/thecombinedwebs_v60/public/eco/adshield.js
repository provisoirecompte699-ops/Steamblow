/* TheCombinedWebs AdShield — bloqueur de pub natif
 * - Pop-ups / window.open sans geste utilisateur
 * - Scripts & iframes de réseaux publicitaires connus
 * - Sandbox des iframes marquées data-adshield (pas de pop-ups depuis l'embed)
 * - Clics piégés (target=_blank suspects)
 * Réglage : localStorage "steamblox:adshield" ("on" par défaut | "off")
 */
(function () {
  "use strict";
  if (window.AdShield && window.AdShield.__v >= 2) return;
  var KEY = "steamblox:adshield";
  var STATS = "steamblox:adshield:blocked";
  var SANDBOX = "allow-scripts allow-same-origin allow-forms allow-presentation allow-pointer-lock allow-orientation-lock";
  var AD_HOSTS = [
    "quge5.com", "monetag.com", "propellerads", "propellerads.com", "onclicka.com",
    "adnxs.com", "doubleclick.net", "googlesyndication.com", "googleadservices.com",
    "adservice.google", "pagead2.googlesyndication", "fundingchoicesmessages.google.com",
    "taboola.com", "outbrain.com", "mgid.com", "revcontent.com", "adsterra",
    "adexchangeprediction", "exoclick.com", "juicyads.com", "popads", "popcash",
    "trafficjunky", "adspyglass", "ad-maven", "clickadu", "hilltopads",
    "richads", "adcash", "advertising.com", "adskeeper", "yandex.ru/ads",
    "aniview.com", "vidoomy.com", "ad.mail.ru", "amazon-adsystem.com",
    "moatads.com", "scorecardresearch.com", "zedo.com", "adform.net",
    "openx.net", "pubmatic.com", "rubiconproject.com", "criteo.com",
    "smartadserver.com", "adsrvr.org", "bidr.io", "casalemedia.com",
    "contextweb.com", "sharethrough.com", "sovrn.com", "yieldmo.com",
    "adsafeprotected.com", "moatpixel", "outbrainimg", "taboola"
  ];
  var listeners = [];
  var blocked = 0;
  try { blocked = parseInt(localStorage.getItem(STATS) || "0", 10) || 0; } catch (e) {}

  function enabled() {
    try { return localStorage.getItem(KEY) !== "off"; } catch (e) { return true; }
  }
  function bump(n) {
    blocked += n || 1;
    try { localStorage.setItem(STATS, String(blocked)); } catch (e) {}
    listeners.forEach(function (fn) { try { fn(enabled(), blocked); } catch (e) {} });
  }
  function hostOf(url) {
    try {
      if (!url || url.indexOf("http") !== 0) return "";
      return new URL(url, location.href).hostname.toLowerCase();
    } catch (e) { return ""; }
  }
  function isAdUrl(url) {
    var h = hostOf(url);
    if (!h) return false;
    for (var i = 0; i < AD_HOSTS.length; i++) {
      if (h === AD_HOSTS[i] || h.indexOf("." + AD_HOSTS[i]) !== -1 || h.indexOf(AD_HOSTS[i]) !== -1) return true;
    }
    // heuristics
    if (/\/ads?\/|\/adserver|popunder|popunder|bannerid|zoneid=|data-zone=/i.test(url)) return true;
    return false;
  }

  function prepare(frame) {
    if (!frame) return frame;
    // Jeux WASM lourds (ex. GTA Web) : data-no-sandbox = pas de sandbox
    if (frame.getAttribute("data-no-sandbox") === "1" || frame.getAttribute("data-adshield") === "off") {
      frame.removeAttribute("sandbox");
      return frame;
    }
    if (enabled()) {
      frame.setAttribute("sandbox", SANDBOX);
    } else frame.removeAttribute("sandbox");
    return frame;
  }
  function reload(frame) {
    if (!frame) return;
    var src = frame.getAttribute("src");
    prepare(frame);
    if (src && src !== "about:blank") {
      frame.src = "about:blank";
      setTimeout(function () { frame.src = src; }, 30);
    }
  }
  function set(on) {
    try { localStorage.setItem(KEY, on ? "on" : "off"); } catch (e) {}
    document.querySelectorAll("iframe[data-adshield]").forEach(reload);
    listeners.forEach(function (fn) { try { fn(on, blocked); } catch (e) {} });
  }
  function onChange(fn) { listeners.push(fn); try { fn(enabled(), blocked); } catch (e) {} }

  // window.open sans geste récent
  var nativeOpen = window.open;
  var lastGesture = 0;
  ["pointerdown", "keydown", "touchstart", "click"].forEach(function (t) {
    window.addEventListener(t, function () { lastGesture = Date.now(); }, true);
  });
  window.open = function (url) {
    if (enabled()) {
      if (Date.now() - lastGesture > 800) { bump(); return null; }
      if (url && isAdUrl(String(url))) { bump(); return null; }
    }
    return nativeOpen.apply(window, arguments);
  };

  // Bloque l'injection de scripts / iframes pub
  function neutralize(node) {
    if (!enabled() || !node || node.nodeType !== 1) return;
    var tag = node.tagName;
    if (tag === "SCRIPT") {
      var src = node.src || node.getAttribute("src") || "";
      if (src && isAdUrl(src)) {
        node.type = "text/plain";
        node.removeAttribute("src");
        try { node.remove(); } catch (e) {}
        bump();
        return;
      }
      // inline monetag / zone
      var txt = node.textContent || "";
      if (/monetag|data-zone|quge5|propeller|popunder/i.test(txt) && !/AdShield|steamblox/i.test(txt)) {
        try { node.remove(); } catch (e) {}
        bump();
      }
    }
    if (tag === "IFRAME" || tag === "IMG" || tag === "EMBED" || tag === "OBJECT") {
      var u = node.src || node.getAttribute("src") || node.data || "";
      if (u && isAdUrl(u)) {
        try { node.remove(); } catch (e) { node.style.display = "none"; }
        bump();
      }
    }
    if (tag === "A") {
      var href = node.getAttribute("href") || "";
      if (href && isAdUrl(href)) {
        node.addEventListener("click", function (ev) {
          if (enabled()) { ev.preventDefault(); ev.stopPropagation(); bump(); }
        }, true);
      }
    }
  }

  function scanTree(root) {
    if (!root || !root.querySelectorAll) return;
    var nodes = root.querySelectorAll("script[src],iframe[src],img[src],embed[src],object[data],a[href]");
    for (var i = 0; i < nodes.length; i++) neutralize(nodes[i]);
  }

  var observer = new MutationObserver(function (muts) {
    if (!enabled()) return;
    for (var i = 0; i < muts.length; i++) {
      var m = muts[i];
      if (m.type === "childList") {
        for (var j = 0; j < m.addedNodes.length; j++) {
          var n = m.addedNodes[j];
          neutralize(n);
          if (n.querySelectorAll) scanTree(n);
        }
      } else if (m.type === "attributes" && m.target) {
        neutralize(m.target);
      }
    }
  });

  function startObserver() {
    try {
      observer.observe(document.documentElement || document.body, {
        childList: true,
        subtree: true,
        attributes: true,
        attributeFilter: ["src", "href", "data"]
      });
    } catch (e) {}
  }

  // Bloque les navigations top initiées par des pubs (beforeunload ne suffit pas)
  document.addEventListener("click", function (ev) {
    if (!enabled()) return;
    var a = ev.target && ev.target.closest ? ev.target.closest("a") : null;
    if (!a) return;
    var href = a.getAttribute("href") || "";
    if (isAdUrl(href)) {
      ev.preventDefault();
      ev.stopPropagation();
      bump();
    }
  }, true);

  function mountToggle(container, opts) {
    if (!container) return null;
    opts = opts || {};
    var btn = document.createElement("button");
    btn.type = "button";
    btn.className = opts.className || "adshield-toggle";
    btn.title = "Bloqueur de pub natif TheCombinedWebs";
    btn.addEventListener("click", function () {
      set(!enabled());
      if (opts.onToggle) opts.onToggle(enabled());
    });
    onChange(function (on, n) {
      btn.textContent = on ? "🛡 Anti-pub · " + n : "🛡 Anti-pub off";
      btn.setAttribute("aria-pressed", on ? "true" : "false");
      btn.dataset.on = on ? "1" : "0";
    });
    container.appendChild(btn);
    return btn;
  }

  window.AdShield = {
    __v: 2,
    enabled: enabled,
    set: set,
    prepare: prepare,
    reload: reload,
    onChange: onChange,
    mountToggle: mountToggle,
    isAdUrl: isAdUrl,
    SANDBOX: SANDBOX,
    get blocked() { return blocked; }
  };

  function boot() {
    document.querySelectorAll("iframe[data-adshield]").forEach(prepare);
    scanTree(document);
    startObserver();
  }
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", boot);
  else boot();
})();
