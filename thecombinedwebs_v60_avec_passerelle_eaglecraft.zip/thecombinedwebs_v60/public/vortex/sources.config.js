/* Sources de secours du lecteur Vortex.
   Peachify reste la source principale. Ajoute ici d'autres lecteurs dont tu as le droit d'utiliser l'intégration.
   Placeholders : {id} = id TMDB, {season}, {episode}. Seules les URL https:// sont acceptées.
   Exemple :
     movie: ['https://exemple.com/embed/movie/{id}'],
     tv:    ['https://exemple.com/embed/tv/{id}/{season}/{episode}']
*/
window.VORTEX_EXTRA_SOURCES = {
  movie: [],
  tv: []
};
