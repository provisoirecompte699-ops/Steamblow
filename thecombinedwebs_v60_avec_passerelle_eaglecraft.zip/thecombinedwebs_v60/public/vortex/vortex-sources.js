/* Sources de secours + bouton « Source suivante » (lit sources.config.js) */
(function () {
  'use strict';
  var cfg = window.VORTEX_EXTRA_SOURCES || {};
  function make(tpl) {
    return function (id, s, e) {
      return String(tpl)
        .replace('{id}', encodeURIComponent(id))
        .replace('{season}', encodeURIComponent(s == null ? 1 : s))
        .replace('{episode}', encodeURIComponent(e == null ? 1 : e));
    };
  }
  ['movie', 'tv'].forEach(function (kind) {
    (cfg[kind] || []).forEach(function (tpl) {
      if (typeof tpl === 'string' && /^https:\/\//i.test(tpl) && EMBED_SOURCES[kind]) EMBED_SOURCES[kind].push(make(tpl));
    });
  });

  var btn;
  function refresh() {
    if (!btn) return;
    var list = EMBED_SOURCES[currentEmbedKind] || [];
    btn.hidden = list.length < 2;
    var isTrailer = list[currentEmbedIndex] === EMBED_SOURCES.trailer[0];
    btn.textContent = isTrailer ? 'Bande-annonce' : 'Source ' + (currentEmbedIndex + 1) + '/' + list.length;
    btn.title = 'Le lecteur affiche une erreur ? Essaie la source suivante.';
  }
  var original = window.setPlayerSource;
  window.setPlayerSource = function (index) { original(index); refresh(); };

  function init() {
    var box = document.querySelector('.modal-header-actions');
    if (!box) return;
    btn = document.createElement('button');
    btn.type = 'button'; btn.className = 'modal-fullscreen vp-source-btn'; btn.hidden = true;
    btn.addEventListener('click', function () { nextEmbedSource(); });
    box.insertBefore(btn, box.firstChild);
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init); else init();
})();
