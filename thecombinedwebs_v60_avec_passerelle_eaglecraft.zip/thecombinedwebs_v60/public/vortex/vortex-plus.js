/* Vortex+ : catalogue TMDB étendu (films & séries), recherche live, notes.
   Lecture : films -> https://peachify.top/embed/movie/{tmdb_id}
             séries -> https://peachify.top/embed/tv/{tmdb_id}/{season}/{episode}
   (les embeds sont construits par openPlayer() dans index.html) */
(function () {
  'use strict';
  var GENRES = {28:'Action',12:'Aventure',16:'Animation',35:'Comédie',80:'Crime',99:'Documentaire',18:'Drame',10751:'Famille',14:'Fantastique',36:'Histoire',27:'Horreur',10402:'Musique',9648:'Mystère',10749:'Romance',878:'Science-Fiction',53:'Thriller',10752:'Guerre',37:'Western',10759:'Action',10765:'Science-Fiction',10768:'Guerre'};
  var MOVIE_GENRES = [[28,'Action'],[12,'Aventure'],[16,'Animation'],[35,'Comédie'],[80,'Crime'],[99,'Documentaire'],[18,'Drame'],[10751,'Famille'],[14,'Fantastique'],[36,'Histoire'],[27,'Horreur'],[9648,'Mystère'],[10749,'Romance'],[878,'Science-Fiction'],[53,'Thriller'],[10752,'Guerre'],[37,'Western']];
  var TV_GENRES = [[10759,'Action & Aventure'],[16,'Animation'],[35,'Comédie'],[80,'Crime'],[99,'Documentaire'],[18,'Drame'],[10751,'Famille'],[9648,'Mystère'],[10765,'SF & Fantastique'],[10768,'Guerre & Politique']];

  /* Rangées ajoutées : [id, emoji, titre, endpoint, type] */
  var ROWS = [
    ['vpTrendMovies','🔥','Films <span>tendances</span> cette semaine','/trending/movie/week','movie','new'],
    ['vpNowPlaying','🍿','Actuellement <span>au cinéma</span>','/movie/now_playing?region=FR','movie','new'],
    ['vpTopMovies','🏆','Films <span>les mieux notés</span>','/movie/top_rated','movie','HD'],
    ['vpThriller','🔪','Films <span>Thriller</span>','/discover/movie?with_genres=53&sort_by=popularity.desc&vote_count.gte=300','movie'],
    ['vpCrime','🕵️','Films <span>Crime</span> & Polar','/discover/movie?with_genres=80&sort_by=popularity.desc&vote_count.gte=300','movie'],
    ['vpDrama','🎭','Films <span>Drame</span>','/discover/movie?with_genres=18&sort_by=vote_average.desc&vote_count.gte=2000','movie'],
    ['vpAdventure','🧭','Films <span>Aventure</span>','/discover/movie?with_genres=12&sort_by=popularity.desc&vote_count.gte=500','movie'],
    ['vpFantasy','🐉','Films <span>Fantastique</span>','/discover/movie?with_genres=14&sort_by=popularity.desc&vote_count.gte=500','movie'],
    ['vpMystery','🧩','Films <span>Mystère</span>','/discover/movie?with_genres=9648&sort_by=popularity.desc&vote_count.gte=400','movie'],
    ['vpWar','🎖️','Films <span>de guerre</span>','/discover/movie?with_genres=10752&sort_by=popularity.desc&vote_count.gte=400','movie'],
    ['vpRomance','💘','Films <span>Romance</span>','/discover/movie?with_genres=10749&sort_by=popularity.desc&vote_count.gte=500','movie'],
    ['vpDoc','🎥','<span>Documentaires</span>','/discover/movie?with_genres=99&sort_by=popularity.desc&vote_count.gte=200','movie'],
    ['vpTrendTv','📺','Séries <span>tendances</span> cette semaine','/trending/tv/week','tv','new'],
    ['vpTopTv','⭐','Séries <span>les mieux notées</span>','/tv/top_rated','tv','HD'],
    ['vpScifiTv','🛸','Séries <span>SF & Fantastique</span>','/discover/tv?with_genres=10765&sort_by=popularity.desc&vote_count.gte=300','tv'],
    ['vpCrimeTv','🚨','Séries <span>Crime</span>','/discover/tv?with_genres=80&sort_by=popularity.desc&vote_count.gte=300','tv'],
    ['vpDramaTv','🎬','Séries <span>Drame</span>','/discover/tv?with_genres=18&sort_by=vote_average.desc&vote_count.gte=1000','tv']
  ];

  function $(id) { return document.getElementById(id); }
  function el(tag, cls, html) { var e = document.createElement(tag); if (cls) e.className = cls; if (html != null) e.innerHTML = html; return e; }
  function withParams(ep, extra) { return ep + (ep.indexOf('?') > -1 ? '&' : '?') + 'include_adult=false' + (extra || ''); }
  function norm(item, type) {
    return Object.assign({}, item, {
      type: type || item.media_type || (item.first_air_date ? 'tv' : 'movie'),
      title: item.title || item.name
    });
  }
  function usable(item) {
    return item && item.id && (item.title || item.name) && item.poster_path && !item.adult &&
      item.original_language !== 'hi' && !(item.origin_country && item.origin_country.indexOf('IN') > -1) &&
      !(typeof isDeleted === 'function' && isDeleted(item.id));
  }
  function register(item) {
    try {
      if (contentDatabase.find(function (d) { return String(d.id) === String(item.id); })) return;
      var seen = {}, g = (item.genre_ids || []).map(function (i) { return GENRES[i]; }).filter(function (n) { if (!n || seen[n]) return false; seen[n] = 1; return true; });
      contentDatabase.push({ id: String(item.id), title: item.title, type: item.type, genres: g, image: IMG_BASE + item.poster_path });
    } catch (e) {}
  }
  function makeCard(item, badge) {
    var card = createCardElement(item, false, null, badge || null);
    if (item.vote_average > 0) card.appendChild(el('div', 'vp-rating', '★ ' + item.vote_average.toFixed(1)));
    if (item.type === 'tv') card.appendChild(el('div', 'vp-kind', 'SÉRIE'));
    return card;
  }
  function skeleton(n) { var h = ''; for (var i = 0; i < n; i++) h += '<div class="vp-skel"></div>'; return h; }

  /* ── Rangées ───────────────────────────────────────────── */
  function buildRow(def, anchor) {
    var id = def[0], row = el('div', 'row vp-row'); row.id = id + 'Row';
    row.innerHTML =
      '<div class="row-header"><div class="row-title">' + def[1] + ' ' + def[2] + '</div>' +
      '<div class="row-nav"><button class="vp-seeall" type="button">Tout voir ›</button>' +
      '<button class="row-arrow" onclick="scrollRow(\'' + id + '\',-1)" aria-label="Précédent">‹</button>' +
      '<button class="row-arrow" onclick="scrollRow(\'' + id + '\',1)" aria-label="Suivant">›</button></div></div>' +
      '<div class="cards-scroll" id="' + id + '">' + skeleton(8) + '</div>';
    row.querySelector('.vp-seeall').addEventListener('click', function () {
      openCatalogue(def[3], def[4], row.querySelector('.row-title').textContent.replace(/\s+/g, ' ').trim());
    });
    anchor.insertAdjacentElement('afterend', row);
    return row;
  }
  function loadRow(def) {
    var box = $(def[0]);
    if (!box || box.dataset.loaded) return;
    box.dataset.loaded = '1';
    fetchFromTMDB(withParams(def[3])).then(function (data) {
      var items = (data.results || []).map(function (r) { return norm(r, def[4]); }).filter(usable);
      items = typeof filterDeleted === 'function' ? filterDeleted(items) : items;
      if (!items.length) { box.closest('.row').style.display = 'none'; return; }
      items.forEach(register);
      box.innerHTML = '';
      items.forEach(function (it) { box.appendChild(makeCard(it, def[5])); });
    }).catch(function () { box.innerHTML = '<div class="search-no-results">Impossible de charger cette rangée.</div>'; });
  }
  function initRows() {
    var anchor = $('newReleasesRow') || document.querySelector('.row:last-of-type');
    if (!anchor) return;
    var rows = [];
    ROWS.forEach(function (def) { anchor = buildRow(def, anchor); rows.push([def, anchor]); });
    var cat = buildCatalogue(); anchor.insertAdjacentElement('afterend', cat);
    if (!('IntersectionObserver' in window)) { ROWS.forEach(loadRow); return; }
    var io = new IntersectionObserver(function (entries) {
      entries.forEach(function (e) {
        if (!e.isIntersecting) return;
        io.unobserve(e.target);
        var d = rows.find(function (r) { return r[1] === e.target; });
        if (d) loadRow(d[0]);
      });
    }, { rootMargin: '600px 0px' });
    rows.forEach(function (r) { io.observe(r[1]); });
  }

  /* ── Catalogue complet (filtres + charger plus) ─────────── */
  var cat = { type: 'movie', genre: '', sort: 'popularity.desc', page: 1, loading: false, endpoint: null, total: 1 };
  function buildCatalogue() {
    var s = el('section', 'row vp-catalogue'); s.id = 'vpCatalogue';
    s.innerHTML =
      '<div class="row-header"><div class="row-title">🎞️ <span>Catalogue</span> complet</div></div>' +
      '<div class="vp-filters">' +
      '<div class="vp-seg" role="tablist"><button type="button" data-type="movie" class="active">Films</button><button type="button" data-type="tv">Séries</button></div>' +
      '<select id="vpGenre" aria-label="Genre"></select>' +
      '<select id="vpSort" aria-label="Tri"><option value="popularity.desc">Popularité</option><option value="vote_average.desc">Mieux notés</option><option value="primary_release_date.desc">Plus récents</option></select>' +
      '</div><div class="vp-grid" id="vpGrid"></div>' +
      '<div class="vp-more"><button type="button" class="vp-morebtn" id="vpMore">Charger plus</button><small id="vpCount"></small></div>';
    setTimeout(function () {
      fillGenres();
      s.querySelectorAll('.vp-seg button').forEach(function (b) {
        b.addEventListener('click', function () {
          s.querySelectorAll('.vp-seg button').forEach(function (x) { x.classList.toggle('active', x === b); });
          cat.type = b.dataset.type; cat.genre = ''; cat.endpoint = null; fillGenres(); resetCatalogue();
        });
      });
      $('vpGenre').addEventListener('change', function (e) { cat.genre = e.target.value; cat.endpoint = null; resetCatalogue(); });
      $('vpSort').addEventListener('change', function (e) { cat.sort = e.target.value; cat.endpoint = null; resetCatalogue(); });
      $('vpMore').addEventListener('click', function () { loadCatalogue(false); });
      var lazy = new IntersectionObserver(function (en) { if (en[0].isIntersecting) { lazy.disconnect(); resetCatalogue(); } }, { rootMargin: '500px' });
      lazy.observe(s);
    }, 0);
    return s;
  }
  function fillGenres() {
    var list = cat.type === 'tv' ? TV_GENRES : MOVIE_GENRES, sel = $('vpGenre');
    sel.innerHTML = '<option value="">Tous les genres</option>' + list.map(function (g) { return '<option value="' + g[0] + '">' + g[1] + '</option>'; }).join('');
  }
  function catUrl() {
    if (cat.endpoint) return cat.endpoint + '&page=' + cat.page;
    var sort = cat.type === 'tv' && cat.sort === 'primary_release_date.desc' ? 'first_air_date.desc' : cat.sort;
    var q = '/discover/' + cat.type + '?sort_by=' + sort + (cat.genre ? '&with_genres=' + cat.genre : '') + '&vote_count.gte=' + (sort.indexOf('vote_average') === 0 ? 1500 : 100);
    if (sort.indexOf('date.desc') > -1) q += (cat.type === 'tv' ? '&first_air_date.lte=' : '&primary_release_date.lte=') + new Date().toISOString().slice(0, 10);
    return withParams(q) + '&page=' + cat.page;
  }
  function resetCatalogue() { cat.page = 1; cat.total = 1; $('vpGrid').innerHTML = ''; loadCatalogue(true); }
  function loadCatalogue(first) {
    if (cat.loading || cat.page > cat.total) return;
    cat.loading = true; var btn = $('vpMore'); btn.disabled = true; btn.textContent = 'Chargement…';
    if (first) $('vpGrid').innerHTML = skeleton(12);
    fetchFromTMDB(catUrl()).then(function (data) {
      cat.total = Math.min(data.total_pages || 1, 500);
      var grid = $('vpGrid'); if (first) grid.innerHTML = '';
      var items = (data.results || []).map(function (r) { return norm(r, cat.type); }).filter(usable);
      items.forEach(function (it) { register(it); grid.appendChild(makeCard(it)); });
      cat.page++;
      $('vpCount').textContent = grid.children.length + ' titres affichés';
      btn.style.display = cat.page > cat.total ? 'none' : '';
    }).catch(function () { $('vpCount').textContent = 'Erreur de chargement, réessaie.'; })
      .finally(function () { cat.loading = false; btn.disabled = false; btn.textContent = 'Charger plus'; });
  }
  /* « Tout voir » d'une rangée : ouvre le catalogue sur la même requête */
  function openCatalogue(endpoint, type, label) {
    var s = $('vpCatalogue'); if (!s) return;
    cat.type = type; cat.genre = ''; cat.endpoint = withParams(endpoint);
    s.querySelectorAll('.vp-seg button').forEach(function (x) { x.classList.toggle('active', x.dataset.type === type); });
    fillGenres(); resetCatalogue();
    var t = s.querySelector('.row-title'); t.innerHTML = '🎞️ <span>' + label.replace(/^\S+\s/, '') + '</span>';
    s.scrollIntoView({ behavior: 'smooth', block: 'start' });
  }

  /* ── Recherche live TMDB (tous les films / séries) ──────── */
  function initSearch() {
    var input = $('searchInput'), timer;
    if (!input) return;
    input.addEventListener('input', function () {
      clearTimeout(timer);
      var q = input.value.trim();
      if (q.length < 2) return;
      timer = setTimeout(function () {
        fetchFromTMDB(withParams('/search/multi?query=' + encodeURIComponent(q))).then(function (data) {
          if (input.value.trim() !== q) return;
          var grid = $('searchResultsGrid'); if (!grid) return;
          var empty = grid.querySelector('.search-no-results'); if (empty) empty.remove();
          var items = (data.results || []).filter(function (r) { return r.media_type === 'movie' || r.media_type === 'tv'; }).map(function (r) { return norm(r); }).filter(usable);
          items.forEach(function (it) {
            if (grid.querySelector('[data-id="' + it.id + '"]')) return;
            register(it); grid.appendChild(makeCard(it));
          });
          var title = $('searchResultsTitle');
          if (title) title.textContent = 'Résultats pour « ' + q + ' » (' + grid.children.length + ')';
          if (!grid.children.length) grid.innerHTML = '<div class="search-no-results">Aucun résultat trouvé.</div>';
          $('searchResults') && $('searchResults').classList.add('active');
        }).catch(function () {});
      }, 350);
    });
  }

  /* ── Bouton retour en haut ──────────────────────────────── */
  function initTop() {
    var b = el('button', 'vp-top', '↑'); b.type = 'button'; b.setAttribute('aria-label', 'Retour en haut');
    b.addEventListener('click', function () { window.scrollTo({ top: 0, behavior: 'smooth' }); });
    document.body.appendChild(b);
    window.addEventListener('scroll', function () { b.classList.toggle('show', window.scrollY > 900); }, { passive: true });
  }

  function start() { try { initRows(); initSearch(); initTop(); } catch (e) { console.error('Vortex+', e); } }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', start); else start();
})();
