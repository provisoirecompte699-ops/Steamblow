const CACHE='steamblox-static-v10';
const STATIC=['/steamblox-welcome.wav'];
self.addEventListener('install',event=>{event.waitUntil(caches.open(CACHE).then(c=>c.addAll(STATIC)).then(()=>self.skipWaiting()))});
self.addEventListener('activate',event=>{event.waitUntil(caches.keys().then(keys=>Promise.all(keys.filter(k=>k!==CACHE).map(k=>caches.delete(k)))).then(()=>self.clients.claim()))});
self.addEventListener('fetch',event=>{
 const req=event.request;
 if(req.method!=='GET'||new URL(req.url).origin!==self.location.origin)return;
 const url=new URL(req.url);
 const staticAsset=url.pathname.startsWith('/_next/static/')||url.pathname.startsWith('/icons/')||url.pathname.endsWith('.woff2')||url.pathname.endsWith('.wav');
 if(url.pathname.startsWith('/api/'))return;
 if(!staticAsset){
  // v58 hors-ligne : réseau d'abord, copie en cache si la connexion tombe
  event.respondWith(fetch(req).then(res=>{if(res.ok&&res.type==='basic'){const copy=res.clone();caches.open(CACHE).then(c=>c.put(req,copy))}return res}).catch(()=>caches.match(req).then(c=>c||new Response('<meta name=viewport content="width=device-width"><body style="font:16px system-ui;background:#0b0d14;color:#fff;display:grid;place-items:center;height:100vh;margin:0"><div style="text-align:center"><h1>TCB hors-ligne</h1><p>Cette page n\'a pas encore été visitée. Reconnecte-toi puis réessaie.</p></div>',{status:503,headers:{'content-type':'text/html; charset=utf-8'}}))));
  return;
 }
 event.respondWith(caches.match(req).then(cached=>cached||fetch(req).then(res=>{if(res.ok){const copy=res.clone();caches.open(CACHE).then(c=>c.put(req,copy))}return res})));
});

// v52 : notifications (appels, messages) et clic → ouvrir la bonne page
self.addEventListener('message',event=>{const d=event.data||{};if(d.type==='notify'){self.registration.showNotification(d.title||'TheCombinedWebs',{body:d.body||'',tag:d.tag||'steamblox',icon:'/icons/icon-192.png',badge:'/icons/icon-192.png',data:{url:d.url||'/discord'},renotify:!!d.renotify,requireInteraction:!!d.sticky})}});
self.addEventListener('notificationclick',event=>{event.notification.close();const url=(event.notification.data&&event.notification.data.url)||'/discord';event.waitUntil(self.clients.matchAll({type:'window',includeUncontrolled:true}).then(list=>{for(const c of list){if('focus' in c){c.navigate&&c.navigate(url);return c.focus()}}return self.clients.openWindow(url)}))});
// Web Push wakes the service worker even when the app is closed.
self.addEventListener('push',event=>{
 let d={};try{d=event.data.json()}catch{}
 const url=typeof d.url==='string'&&d.url.startsWith('/')&&!d.url.startsWith('//')?d.url:'/evenements';
 event.waitUntil(self.registration.showNotification(d.title||'TheCombinedWebs',{body:d.body||'',tag:d.tag||'tcb-push',icon:'/icons/icon-192.png',badge:'/icons/icon-192.png',data:{url}}));
});
