# v57 — Multijoueur dans tous les jeux
- Audit : les 13 jeux Arcade, Algèbre/Calcul/Fractions, Infinite Ascent, Sky Jump, Turbo Kart, Neon Drift, Baldi, Hello Neighbor et Ultrakill ont tous un salon (code, chat, vocal, hôte).
- Correctif : dans les jeux Arcade (ArcadeGame), les autres joueurs restaient figés (positions lues seulement via room:state). Ajout des écouteurs `player:state` / `player:left` + interpolation fluide.
- Catalogue : ULTRAKILL marqué multijoueur (overlay déjà présent).
- Prérequis : définir NEXT_PUBLIC_MULTIPLAYER_SERVER_URL (serveur `multiplayer-server`).
- Limite : Baldi / Hello Neighbor / Ultrakill (iframe/externe) = salon, chat, vocal, effets d'hôte ; pas de synchro des positions dans le jeu lui-même.
- Invitation entre amis : bouton 🔗 Inviter (lien ?room=CODE, code prérempli). Guide d'hébergement : DEPLOY_MULTIPLAYER.md (+ render.yaml, Dockerfile).
- Hello Neighbor (version hommage 2D) : amis visibles en jeu (position, clés), emotes 1-4. Le vrai jeu officiel ne peut pas être ajouté (propriétaire, non redistribuable) : voir BUILD_README.txt.
- 🎭 Panneau admin de l'hôte (TrollKit) : l'hôte choisit une cible (tous / un joueur) et un effet : jumpscare, faux plantage, fausse déconnexion, écran à l'envers, miroir, ivre, tourniquet, tremblement, zoom, couleurs inversées, lampe torche, pluie d'emojis, klaxon.
  Serveur : événements `host:troll` (hôte uniquement, 1/s, liste blanche d'effets) → `troll:fx`, et `troll:optout`.
  Garde-fous : bouton 🛡️ « bloquer les trolls » pour chaque joueur, Échap pour tout arrêter, prefers-reduced-motion respecté, pas de stroboscope, son plafonné, toast « 🎭 X t'a troll ».
  Monté dans tous les jeux multijoueur (Arcade, maths, Infinite Ascent, Sky Jump, Turbo Kart, Neon Drift, Baldi, Hello Neighbor, Ultrakill). Redéployer multiplayer-server.
