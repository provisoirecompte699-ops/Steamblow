# Vocal global de Younes

- **Younes** (rôle `creator`) clique sur « Démarrer le direct » (dashboard ou /admin) : son micro est diffusé en WebRTC à tous les joueurs connectés.
- **Les joueurs** cliquent sur « Écouter le vocal » : ils reçoivent le flux, règlent le volume et voient le nombre d'auditeurs.
- Le droit de parler est **signé dans le token** (`/api/global-voice`) et vérifié par `multiplayer-server/server.js` : un joueur ne peut pas se déclarer speaker.
- Le token expire après 5 min ; il est renouvelé à chaque (re)connexion, la reconnexion est automatique.

## Configuration
1. `NEXT_PUBLIC_MULTIPLAYER_SERVER_URL` = URL du serveur temps réel (côté site).
2. `REALTIME_SECRET` doit être **identique** sur le site et sur `multiplayer-server`. Cette signature de service est indépendante des sessions de connexion.
3. Le micro exige HTTPS (sauf localhost).
4. Derrière certains réseaux (4G/entreprise), un serveur TURN peut être nécessaire : ajoute-le dans `ICE` de `app/GlobalVoice.tsx`.
