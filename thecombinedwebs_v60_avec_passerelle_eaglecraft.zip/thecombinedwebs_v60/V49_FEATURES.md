# TheCombinedWebs v49

## Bloqueur de pub (AdShield)
- Script partagé `public/eco/adshield.js`, chargé par CinéStream et Vortex.
- Les lecteurs vidéo externes sont placés dans une iframe `sandbox` **sans** `allow-popups` ni `allow-top-navigation` :
  les pop-ups, les nouveaux onglets publicitaires et les redirections de la page sont bloqués par le navigateur.
- Les `window.open` lancés sans clic de l'utilisateur sont aussi bloqués.
- Bouton « 🛡 Anti-pub » dans la barre du lecteur (CinéStream et Vortex) et interrupteur dans TheCombinedWebs → Réglages.
  Réglage partagé : `localStorage["steamblox:adshield"]` (activé par défaut).
- Limite : une bannière dessinée *à l'intérieur* de la vidéo d'un lecteur externe ne peut pas être retirée depuis notre site.
  Certains lecteurs refusent de fonctionner en bac à sable : il suffit de changer de source ou de couper l'anti-pub un instant.

## Interface épurée
- Nouveau tableau de bord : barre de navigation simple, accueil « Prêt à jouer ? », reprise de la dernière partie,
  statistiques compactes, tuiles d'écosystème (CinéStream, Vortex, Baldi 3D, Multijoueur), quêtes, bibliothèque, amis et vocal,
  réglages, options avancées repliées.
- Cartes de jeu plates ; l'achat est replié derrière un seul bouton « Acheter · prix ».
- Couche CSS « V49 » dans `app/globals.css` (une palette, surfaces plates, pas de halos) ;
  CinéStream et Vortex utilisent `public/eco/eco-ui.css`.

## Algèbre Facile
- Moteur `lib/algebra.ts` : calcul exact en fractions, analyse d'expressions (multiplication implicite, parenthèses, x²).
- Solveur pas à pas : équations du 1er degré (avec vérification), du 2nd degré (discriminant, racines exactes avec radical simplifié,
  forme factorisée, produit nul), développement/factorisation, systèmes 2×2 (déterminant + vérification).
- 9 chapitres de cours (définition, méthode, exemple, erreur fréquente), formulaire, exercices sur 4 niveaux
  avec 2 essais puis correction détaillée et statistiques locales.
