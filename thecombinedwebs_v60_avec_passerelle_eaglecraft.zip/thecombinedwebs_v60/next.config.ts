import type { NextConfig } from "next";

const securityHeaders = [
  { key: "X-Content-Type-Options", value: "nosniff" },
  { key: "Referrer-Policy", value: "strict-origin-when-cross-origin" },
  { key: "Permissions-Policy", value: "camera=(self), microphone=(self), geolocation=()" },
  { key: "X-Frame-Options", value: "SAMEORIGIN" },
  { key: "Cross-Origin-Opener-Policy", value: "same-origin-allow-popups" },
];

const nextConfig: NextConfig = {
  distDir: process.env.NEXT_DIST_DIR || ".next",
  poweredByHeader: false,
  reactStrictMode: true,
  async headers(){
    const isolate = !!process.env.NEXT_PUBLIC_PROXY_URL; // GTA : page hôte isolée (SharedArrayBuffer) pour l'iframe du proxy
    return [
      { source: "/(.*)", headers: securityHeaders },
      ...(isolate ? [{ source: "/games/gta-web", headers: [{ key: "Cross-Origin-Opener-Policy", value: "same-origin" }, { key: "Cross-Origin-Embedder-Policy", value: "require-corp" }] }] : []),
      ...(isolate ? [{source:"/portails/jouer",headers:[{key:"Cross-Origin-Opener-Policy",value:"same-origin"},{key:"Cross-Origin-Embedder-Policy",value:"require-corp"}]}] : []),
    ];
  },
};

export default nextConfig;
