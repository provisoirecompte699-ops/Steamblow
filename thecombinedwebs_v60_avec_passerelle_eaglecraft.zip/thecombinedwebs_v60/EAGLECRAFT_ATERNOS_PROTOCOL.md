# EagleCraft + Aternos — protocole et tests

Cette version améliore `/games/eaglecraft` avec :
- sauvegarde locale des serveurs (migration de l'ancienne clé localStorage) ;
- adresse Minecraft/Aternos et URL WebSocket de passerelle séparées ;
- validation des URL `ws://` / `wss://` ;
- test de joignabilité WebSocket avec délai maximal et messages de diagnostic ;
- explication explicite des limites de compatibilité.

## Limite importante — ne pas promettre une connexion automatique

Une adresse Aternos classique n'est pas une URL WebSocket Eaglercraft. Pour connecter un client Eaglercraft à un serveur Minecraft Java, il faut une passerelle/proxy compatible qui parle le protocole Eaglercraft côté navigateur et rejoint le serveur Java côté serveur. Le ZIP du site seul ne peut pas créer cette passerelle : elle doit être déployée et configurée sur un service serveur distinct, et Aternos peut ne pas autoriser l'installation du plugin requis.

Le test intégré vérifie uniquement que la poignée de main WebSocket s'ouvre. Il ne prouve pas que la négociation de protocole, l'authentification, la version ou le jeu fonctionnent. Le test final doit être fait dans le client avec un serveur compatible.

Ne pas mettre de secrets Aternos dans le site. Les modpacks Forge/Fabric/Java ne sont pas rendus compatibles avec EagleCraft par ce changement.

## Sources utiles
- Aternos aide sur l'installation de mods : https://support.aternos.org/hc/en-us/articles/360027235871-Install-mods-Minecraft-Java-Edition
- Référence EaglercraftX : https://github.com/EaglercraftZ-Devs/EaglercraftZ-Source/blob/master/EAGLERCRAFTX_README.md

## Vérifications effectuées
- Archive source extraite et fichiers modifiés.
- Contrôle statique du code de la page et validation des états de test.
- Contrôle ZIP après génération.
- Un test de compilation Next.js et un test réel sur un serveur Aternos ne sont pas déclarés réussis ici : ils nécessitent l'installation des dépendances et une passerelle/serveur de test accessible.
