import React from "react";
export default function Link({ href, children, onClick, ...rest }: any) {
  return (
    <a
      {...rest}
      href={
        typeof href === "string" && href.startsWith("/") ? `#${href}` : href
      }
      onClick={onClick}
    >
      {children}
    </a>
  );
}
