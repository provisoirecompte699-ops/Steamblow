import { useEffect, useState } from "react";
export function usePathname() {
  const [p, setP] = useState(location.hash.slice(1) || "/portails");
  useEffect(() => {
    const h = () => setP(location.hash.slice(1) || "/portails");
    window.addEventListener("hashchange", h);
    return () => window.removeEventListener("hashchange", h);
  }, []);
  return p;
}
