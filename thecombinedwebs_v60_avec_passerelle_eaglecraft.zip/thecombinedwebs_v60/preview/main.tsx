import React, { useEffect, useState } from "react";
import { createRoot } from "react-dom/client";
import FeaturePage, { Economy } from "../app/FeaturePages";
import DiscordVoiceProvider from "../app/DiscordVoiceProvider";
import PadKeyboard from "../app/PadKeyboard";
import LiveFeatures from "../app/LiveFeatures";
const nativeFetch = window.fetch.bind(window);
const base = "__PORT_5000__".startsWith("__")
  ? location.port === "3000"
    ? ""
    : "http://127.0.0.1:5000"
  : "__PORT_5000__";
let token = "";
window.fetch = (input, init = {}) => {
  const raw =
    typeof input === "string"
      ? input
      : input instanceof URL
        ? input.href
        : input.url;
  if (raw.startsWith("/api/")) {
    const headers = new Headers(init.headers);
    if (token) headers.set("authorization", `Bearer ${token}`);
    return nativeFetch(`${base}${raw}`, { ...init, headers });
  }
  return nativeFetch(input, init);
};
function Preview() {
  const [route, setRoute] = useState(location.hash.slice(1) || "/portails"),
    [account, setAccount] = useState("DemoCreateur"),
    [auth, setAuth] = useState(0),
    [error, setError] = useState("");
  const login = async (name: string) => {
    try {
      const r = await window.fetch("/api/auth/login", {
        method: "POST",
        headers: {
          "content-type": "application/json",
          "x-tcb-client": "bearer",
        },
        body: JSON.stringify({ username: name, password: "PreviewTCB60!" }),
      });
      const d = await r.json();
      if (!r.ok || !d.token)
        throw new Error("Connexion de l'aperçu indisponible.");
      token = d.token;
      setAccount(name);
      setAuth((v) => v + 1);
      setError("");
    } catch (e) {
      setError((e as Error).message);
    }
  };
  useEffect(() => {
    const h = () => setRoute(location.hash.slice(1) || "/portails");
    window.addEventListener("hashchange", h);
    login("DemoCreateur");
    return () => window.removeEventListener("hashchange", h);
  }, []);
  const mode = ["portails", "evenements", "social", "economie"].includes(
    route.slice(1),
  )
    ? (route.slice(1) as "portails" | "evenements" | "social" | "economie")
    : "portails";
  const home = route === "/steamblox";
  const nativeOnly =
    !home &&
    !["/portails", "/evenements", "/social", "/economie"].includes(route);
  return (
    <>
      <aside className="preview-bar">
        <span>Aperçu v60 · Comptes de test isolés · {account}</span>
        <div>
          <button
            onClick={() =>
              login(account === "DemoCreateur" ? "DemoAmi" : "DemoCreateur")
            }
          >
            Changer de joueur
          </button>{" "}
          <a href="#/steamblox">Boutique de l'accueil</a>
        </div>
        {error && <span role="alert">{error}</span>}
      </aside>
      {!auth ? (
        <div className="feature-panel" style={{ margin: 32 }} role="status">
          {error || "Connexion aux comptes de test…"}
        </div>
      ) : (
        <DiscordVoiceProvider key={auth}>
          <PadKeyboard />
          <LiveFeatures />
          {nativeOnly ? (
            <div
              className="feature-panel"
              style={{ maxWidth: 1000, margin: "32px auto" }}
            >
              <h1>Page du projet Next.js</h1>
              <p>
                Cette page, les jeux complets et les profils sont disponibles
                dans le projet modifié. Cet aperçu se concentre sur les
                nouvelles interfaces connectées aux API du projet.
              </p>
              <a className="f-btn" href="#/portails">
                Retour aux portails
              </a>
            </div>
          ) : home ? (
            <div className="feature-shell">
              <div className="f-header">
                <a className="f-brand" href="#/portails">
                  TheCombinedWebs
                </a>
                <a className="f-btn" href="#/economie">
                  Boutique & banque
                </a>
                <a className="f-btn" href="#/social">
                  Social
                </a>
                <button
                  className="f-btn"
                  onClick={() =>
                    (window as any).CSTV?.set(!(window as any).CSTV.on())
                  }
                >
                  Mode TV
                </button>
              </div>
              <main className="f-main">
                <h1 style={{ fontSize: 28 }}>
                  Accueil : boutique et mini-jeux bancaires
                </h1>
                <Economy compact />
              </main>
            </div>
          ) : (
            <FeaturePage key={`${mode}:${auth}`} mode={mode} />
          )}
        </DiscordVoiceProvider>
      )}
    </>
  );
}
createRoot(document.getElementById("root")!).render(<Preview />);
