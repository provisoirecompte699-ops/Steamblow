// Compatibility shim for the existing voice engine in opaque preview iframes.
// No browser storage is accessed; preferences last only for this tab.
const values=new Map<string,string>();
export const localStorage={getItem:(key:string)=>values.get(key)||null,setItem:(key:string,value:string)=>values.set(key,value),removeItem:(key:string)=>values.delete(key)};
