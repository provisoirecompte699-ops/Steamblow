"use client";
import Link from "next/link";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { VoiceEngine, type VoiceSnapshot } from "./voice";
import { useDiscordVoice } from "../DiscordVoiceProvider";
import "@/app/hub.css";

type Channel = { id: string; name: string; topic: string; icon: string; readOnly?: boolean };
type Msg = { id: string; at: number; author: string; text: string; reactions?: Record<string, string[]>; edited?: number; replyTo?: { id: string; author: string; text: string } };
type Friend = { username: string; online: boolean; where: string; voice: string | null; lastSeen: number };
type DM = { id: string; with: string; last: number; preview: string; unread: boolean };
type VMember = { u: string; muted?: boolean; deaf?: boolean; speaking?: boolean };
type Sync = {
  me: { username: string; role: string }; channels: Channel[]; voiceRooms: { id: string; name: string }[]; voiceMax: number; reactions: string[];
  clan: { id: string; name: string; tag: string; emoji: string; color: string; channel: Channel } | null; cos: Record<string, { border?: string; name?: string; sound?: string }>;
  friends: Friend[]; dms: DM[]; voice: Record<string, VMember[]>; call: { from: string; room: string; at: number } | null; channel: string; rev: number; messages: Msg[] | null;
};
type View = { kind: "channel"; id: string } | { kind: "dm"; with: string; id: string } | { kind: "friends" } | { kind: "voice"; id: string };
type Req = { id: string; from: string };

const low = (u: string) => u.toLowerCase();
const dmId = (a: string, b: string) => "dm~" + [low(a), low(b)].sort().join("~");
const HUES = [258, 168, 205, 330, 28, 140, 288, 8, 48, 190];
const hue = (u: string) => { let h = 0; for (const c of u) h = (h * 31 + c.charCodeAt(0)) >>> 0; return HUES[h % HUES.length]; };
// Cosmétiques équipés (bordure, effet de pseudo, son) — mis à jour à chaque synchro
let COS: Record<string, { border?: string; name?: string; sound?: string }> = {};
const nameCls = (u: string) => (COS[low(u)]?.name ? `cos-${COS[low(u)]!.name}` : "");
const Avatar = ({ u, size = 36, ring = false, dot }: { u: string; size?: number; ring?: boolean; dot?: "on" | "off" | "voice" }) => (
  <span className={`dc-av${ring ? " talk" : ""}${COS[low(u)]?.border ? ` cos-${COS[low(u)]!.border}` : ""}`} style={{ width: size, height: size, fontSize: size * 0.42, background: `linear-gradient(140deg,hsl(${hue(u)} 70% 58%),hsl(${hue(u) + 30} 62% 38%))` }} aria-hidden="true">
    {u.slice(0, 1).toUpperCase()}{dot && <i className={`dc-dot ${dot}`} />}
  </span>
);
const time = (t: number) => {
  const d = new Date(t), now = new Date();
  const hm = d.toLocaleTimeString("fr-FR", { hour: "2-digit", minute: "2-digit" });
  if (d.toDateString() === now.toDateString()) return `Aujourd’hui à ${hm}`;
  const y = new Date(now); y.setDate(now.getDate() - 1);
  if (d.toDateString() === y.toDateString()) return `Hier à ${hm}`;
  return `${d.toLocaleDateString("fr-FR")} ${hm}`;
};
const ago = (t: number) => { if (!t) return "jamais vu"; const m = Math.round((Date.now() - t) / 60000); if (m < 60) return `vu il y a ${Math.max(1, m)} min`; const h = Math.round(m / 60); if (h < 48) return `vu il y a ${h} h`; return `vu il y a ${Math.round(h / 24)} j`; };

function richText(text: string, me: string) {
  const parts = text.split(/(https?:\/\/[^\s<]+|\/replay\/[a-z0-9]{6,20}|@[a-zA-Z0-9_.-]{2,24}|\*\*[^*]+\*\*|`[^`]+`)/g);
  return parts.map((p, i) => {
    if (/^\/replay\/[a-z0-9]{6,20}$/.test(p)) return <span key={i} className="dc-replay"><video src={`/api${p.replace("/replay/", "/replays/")}`} controls preload="metadata" playsInline /><Link href={p}>Ouvrir la rediffusion</Link></span>;
    if (/^https?:\/\//.test(p)) return <a key={i} href={p} target="_blank" rel="noopener noreferrer nofollow">{p}</a>;
    if (p.startsWith("@") && p.length > 2) return <span key={i} className={`dc-mention${low(p.slice(1)) === low(me) || p === "@everyone" ? " me" : ""}`}>{p}</span>;
    if (p.startsWith("**") && p.endsWith("**") && p.length > 4) return <b key={i}>{p.slice(2, -2)}</b>;
    if (p.startsWith("`") && p.endsWith("`") && p.length > 2) return <code key={i}>{p.slice(1, -1)}</code>;
    return <span key={i}>{p}</span>;
  });
}

// Petits sons (WebAudio, sans fichier)
let sfxCtx: AudioContext | null = null;
function tone(seq: [number, number][], vol = 0.06) {
  try {
    sfxCtx ||= new (window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext)();
    let t = sfxCtx.currentTime;
    for (const [f, d] of seq) {
      const o = sfxCtx.createOscillator(), g = sfxCtx.createGain();
      o.type = "sine"; o.frequency.value = f; g.gain.setValueAtTime(vol, t); g.gain.exponentialRampToValueAtTime(0.0001, t + d);
      o.connect(g).connect(sfxCtx.destination); o.start(t); o.stop(t + d); t += d * 0.8;
    }
  } catch { /* audio indisponible */ }
}
const SFX = { join: () => tone([[523, 0.09], [784, 0.14]]), leave: () => tone([[659, 0.09], [392, 0.16]]), msg: () => tone([[880, 0.07]], 0.035), ring: () => tone([[740, 0.18], [988, 0.18], [740, 0.18], [988, 0.25]], 0.07) };

export default function DiscordClient({ username, initialDm, autoJoin }: { username: string; initialDm?: string; autoJoin?: boolean }) {
  const [data, setData] = useState<Sync | null>(null);
  const [view, setView] = useState<View>(initialDm ? { kind: "dm", with: initialDm, id: dmId(username, initialDm) } : { kind: "channel", id: "general" });
  const [messages, setMessages] = useState<Msg[]>([]);
  const [draft, setDraft] = useState("");
  const [replyTo, setReplyTo] = useState<Msg | null>(null);
  const [editing, setEditing] = useState<{ id: string; text: string } | null>(null);
  const [picker, setPicker] = useState<string | null>(null);
  const [drawer, setDrawer] = useState(false);
  const [members, setMembers] = useState(true);
  const [toast, setToast] = useState("");
  const [settings, setSettings] = useState(false);
  const [devices, setDevices] = useState<MediaDeviceInfo[]>([]);
  const [incoming, setIncoming] = useState<Sync["call"]>(null);
  const [outgoing, setOutgoing] = useState<{ to: string; at: number } | null>(null);
  const [friendTab, setFriendTab] = useState<"online" | "all" | "add">("online");
  const [requests, setRequests] = useState<Req[]>([]);
  const [search, setSearch] = useState("");
  const [results, setResults] = useState<{ username: string }[]>([]);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");

  const { engine, voice: providerVoice, subscribeEvents } = useDiscordVoice();
  const [voice, setVoice] = useState<VoiceSnapshot | null>(providerVoice);
  const revRef = useRef(-1);
  const chanRef = useRef("");
  const listRef = useRef<HTMLDivElement>(null);
  const stick = useRef(true);
  const lastMsgAt = useRef(0);
  const dismissedCall = useRef(0);
  const inputRef = useRef<HTMLTextAreaElement>(null);

  const channelId = view.kind === "channel" || view.kind === "dm" ? view.id : null;
  const flash = useCallback((t: string) => { setToast(t); setTimeout(() => setToast((c) => (c === t ? "" : c)), 3200); }, []);

  // Moteur vocal — utilise le moteur global du provider pour que le vocal survive à la navigation
  useEffect(() => {
    if (!engine) return;
    const off = engine.subscribe(setVoice);
    // Les sons de join/leave sont maintenant gérés par le provider via le bus d'événements
    return () => { off(); };
  }, [engine]);

  // Synchronisation (messages, amis, présence, salons vocaux)
  const sync = useCallback(async (force = false) => {
    const c = channelId || "general";
    if (chanRef.current !== c) { chanRef.current = c; revRef.current = -1; }
    const v = engine?.snap.room || "";
    try {
      const r = await fetch(`/api/discord/sync?c=${encodeURIComponent(c)}&rev=${force ? -1 : revRef.current}&voice=${encodeURIComponent(v)}`, { cache: "no-store" });
      if (r.status === 401) { location.href = "/login?next=/discord"; return; }
      const d = (await r.json()) as Sync & { error?: string };
      if (!r.ok) { setError(d.error || "Erreur"); return; }
      setError("");
      setData(d);
      if (d.channel === chanRef.current && d.messages) {
        revRef.current = d.rev;
        const last = d.messages[d.messages.length - 1];
        if (last && lastMsgAt.current && last.at > lastMsgAt.current && low(last.author) !== low(username)) SFX.msg();
        lastMsgAt.current = last?.at || 0;
        setMessages(d.messages);
      }
      if (d.call && d.call.at !== dismissedCall.current && engine?.snap.room !== d.call.room) setIncoming(d.call);
      else if (!d.call) setIncoming(null);
    } catch { setError("Connexion perdue… nouvelle tentative"); }
  }, [channelId, username, engine]);

  useEffect(() => {
    sync(true);
    let t: ReturnType<typeof setTimeout>;
    const loop = () => { t = setTimeout(async () => { await sync(); loop(); }, document.hidden ? 6000 : 1800); };
    loop();
    return () => clearTimeout(t);
  }, [sync]);

  // Demandes d'amis
  const loadFriends = useCallback(async () => { const r = await fetch("/api/friends"); if (r.ok) { const d = await r.json(); setRequests(d.incoming || []); } }, []);
  useEffect(() => { loadFriends(); const t = setInterval(loadFriends, 15000); return () => clearInterval(t); }, [loadFriends]);
  useEffect(() => {
    const t = setTimeout(async () => { if (search.trim().length < 1) { setResults([]); return; } const r = await fetch(`/api/friends?q=${encodeURIComponent(search)}`); if (r.ok) setResults((await r.json()).users || []); }, 250);
    return () => clearTimeout(t);
  }, [search]);

  // Défilement automatique
  useEffect(() => { const el = listRef.current; if (el && stick.current) el.scrollTop = el.scrollHeight; }, [messages, view]);
  useEffect(() => { stick.current = true; setReplyTo(null); setEditing(null); setPicker(null); if (channelId) setMessages([]); }, [channelId]);

  // Sonnerie d'appel entrant
  useEffect(() => { if (!incoming) return; SFX.ring(); const t = setInterval(SFX.ring, 2600); return () => clearInterval(t); }, [incoming]);

  // Appel sortant : expire après 45 s, s'arrête quand l'ami décroche
  useEffect(() => {
    if (!outgoing || !voice?.room) return;
    if (voice.members.some((m) => low(m.u) === low(outgoing.to))) { setOutgoing(null); return; }
    const t = setTimeout(() => { setOutgoing(null); fetch("/api/discord/call", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ action: "cancel", to: outgoing.to }) }); flash(`${outgoing.to} ne répond pas.`); }, Math.max(0, 45000 - (Date.now() - outgoing.at)));
    return () => clearTimeout(t);
  }, [outgoing, voice?.members, voice?.room, flash]);

  // Appui-pour-parler : touche V maintenue
  useEffect(() => {
    const down = (e: KeyboardEvent) => { if (e.code === "KeyV" && !(e.target instanceof HTMLTextAreaElement || e.target instanceof HTMLInputElement)) engine?.setPttDown(true); };
    const up = (e: KeyboardEvent) => { if (e.code === "KeyV") engine?.setPttDown(false); };
    addEventListener("keydown", down); addEventListener("keyup", up);
    return () => { removeEventListener("keydown", down); removeEventListener("keyup", up); };
  }, []);

  useEffect(() => { if (voice?.error) flash(voice.error); }, [voice?.error, flash]);

  const joinVoice = useCallback(async (room: string, show = true) => {
    engine?.unlock();
    await engine?.join(room);
    if (show && !room.startsWith("dm~")) setView({ kind: "voice", id: room });
    setDrawer(false);
    sync();
  }, [sync, engine]);
  const leaveVoice = useCallback(async () => { await engine?.leave(); setOutgoing(null); sync(); }, [sync, engine]);

  // Rejoindre automatiquement un appel (lien depuis la notification)
  const autoDone = useRef(false);
  useEffect(() => { if (autoJoin && initialDm && !autoDone.current && engine) { autoDone.current = true; joinVoice(dmId(username, initialDm), false); fetch("/api/discord/call", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ action: "dismiss" }) }); } }, [autoJoin, initialDm, joinVoice, username, engine]);

  const callFriend = async (f: string) => {
    const room = dmId(username, f);
    await joinVoice(room, false);
    if (!engine?.snap.room) return;
    const r = await fetch("/api/discord/call", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ action: "ring", to: f }) });
    const d = await r.json();
    if (!r.ok) { flash(d.error || "Appel impossible"); return; }
    setOutgoing({ to: f, at: Date.now() });
  };
  const acceptCall = async () => {
    if (!incoming) return;
    const c = incoming; dismissedCall.current = c.at; setIncoming(null);
    await fetch("/api/discord/call", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ action: "dismiss" }) });
    setView({ kind: "dm", with: c.from, id: c.room });
    await joinVoice(c.room, false);
  };
  const declineCall = async () => {
    if (!incoming) return;
    dismissedCall.current = incoming.at; setIncoming(null);
    await fetch("/api/discord/call", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ action: "dismiss" }) });
  };

  const post = async (body: Record<string, unknown>) => {
    const r = await fetch("/api/discord/message", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify(body) });
    const d = await r.json().catch(() => ({}));
    if (!r.ok) flash(d.error || "Action impossible");
    await sync(true);
    return r.ok;
  };
  const send = async () => {
    const text = draft.trim();
    if (!text || !channelId || busy) return;
    setBusy(true); stick.current = true;
    const optimistic: Msg = { id: `tmp-${Date.now()}`, at: Date.now(), author: username, text, ...(replyTo ? { replyTo: { id: replyTo.id, author: replyTo.author, text: replyTo.text.slice(0, 120) } } : {}) };
    setMessages((m) => [...m, optimistic]); setDraft(""); const rt = replyTo?.id; setReplyTo(null);
    const ok = await post({ action: "send", channel: channelId, text, replyTo: rt });
    if (!ok) setDraft(text);
    setBusy(false);
    inputRef.current?.focus();
  };
  const saveEdit = async () => { if (!editing || !channelId) return; await post({ action: "edit", channel: channelId, id: editing.id, text: editing.text }); setEditing(null); };
  const react = (id: string, emoji: string) => { setPicker(null); if (channelId) post({ action: "react", channel: channelId, id, emoji }); };
  const remove = (id: string) => { if (channelId && confirm("Supprimer ce message ?")) post({ action: "delete", channel: channelId, id }); };
  const friendAction = async (body: Record<string, unknown>, ok: string) => {
    const r = await fetch("/api/friends", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify(body) });
    const d = await r.json().catch(() => ({}));
    flash(d.error || ok); setSearch(""); setResults([]); loadFriends(); sync();
  };

  const openSettings = async () => {
    setSettings(true);
    try { setDevices((await navigator.mediaDevices.enumerateDevices()).filter((d) => d.kind === "audioinput")); } catch { setDevices([]); }
  };

  const me = data?.me;
  const staff = me && ["creator", "vice_creator", "moderator"].includes(me.role);
  if (data?.cos) COS = data.cos;
  const allChannels = data ? (data.clan ? [...data.channels, data.clan.channel] : data.channels) : [];
  const curChannel = view.kind === "channel" ? allChannels.find((c) => c.id === view.id) : undefined;
  const report = async (m: Msg) => {
    const reason = prompt(`Pourquoi signaler ce message de ${m.author} ? (insulte, spam, arnaque…)`);
    if (reason === null || !channelId) return;
    const r = await fetch("/api/discord/message", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ action: "report", channel: channelId, id: m.id, text: reason }) });
    const d = await r.json().catch(() => ({}));
    flash(d.error || "Merci, le message a été signalé à la modération.");
  };
  const canShare = VoiceEngine.canShare();
  const Screens = () => { const entries = Object.entries(voice?.videos || {}); if (!entries.length && !voice?.sharing) return null;
    return <div className="dc-screens">{voice?.sharing && <div className="dc-screen mine"><b>Tu partages ton écran</b><button className="dc-btn danger" onClick={() => engine?.stopShare()}>Arrêter</button></div>}
      {entries.map(([k, st]) => <div key={k} className="dc-screen"><video autoPlay playsInline muted ref={(el) => { if (el && el.srcObject !== st) el.srcObject = st; }} onDoubleClick={(e) => e.currentTarget.requestFullscreen?.()} /><span>Écran de {voice?.members.find((m) => low(m.u) === k)?.u || k} · double-clic plein écran</span></div>)}</div>; };
  const canWrite = view.kind === "dm" || (curChannel && (!curChannel.readOnly || me?.role === "creator" || me?.role === "vice_creator"));
  const unreadDM = data?.dms.filter((d) => d.unread).length || 0;
  const online = data?.friends.filter((f) => f.online) || [];
  const roomName = (id: string | null | undefined) => !id ? "" : id.startsWith("dm~") ? `Appel avec ${(() => { const o = id.split("~").slice(1).find((p) => p !== low(username)) || ""; return data?.friends.find((f) => low(f.username) === o)?.username || o; })()}` : data?.voiceRooms.find((r) => r.id === id)?.name || id;
  const speakingOf = (u: string) => !!voice?.speaking[low(u)];
  const inThisDmCall = view.kind === "dm" && voice?.room === view.id;

  // Messages groupés par auteur (5 min)
  const grouped = useMemo(() => messages.map((m, i) => { const p = messages[i - 1]; return { m, head: !p || p.author !== m.author || m.at - p.at > 300000 || !!m.replyTo }; }), [messages]);

  const voiceMembersOf = (room: string): VMember[] => (voice?.room === room ? voice.members : data?.voice[room]) || [];

  const VoiceTile = ({ m }: { m: VMember }) => {
    const self = low(m.u) === low(username);
    const st = self ? "connected" : voice?.peers[low(m.u)] || "connexion";
    const talk = speakingOf(m.u);
    return <div key={m.u} className={`dc-tile${talk ? " talk" : ""}`}>
      <Avatar u={m.u} size={84} ring={talk} />
      <b className={nameCls(m.u)}>{m.u}{self ? " (toi)" : ""}</b>
      <span className="dc-tile-state">{m.deaf ? "🔇 Sourdine casque" : m.muted ? "🎙️ Micro coupé" : self ? (voice?.ptt ? "Maintiens V pour parler" : "Micro ouvert") : st === "connected" ? "Connecté" : st === "failed" ? "Connexion impossible" : "Connexion…"}</span>
      {!self && <label className="dc-vol" title="Volume">🔊<input type="range" min={0} max={1} step={0.05} defaultValue={engine?.volumes[low(m.u)] ?? 1} onChange={(e) => engine?.setVolume(m.u, Number(e.target.value))} aria-label={`Volume de ${m.u}`} /></label>}
    </div>;
  };

  const VoicePanel = () => !voice?.room ? null : <div className="dc-vpanel">
    <div className="dc-vpanel-top">
      <div><b className={voice.joining ? "wait" : "ok"}>{voice.joining ? "Connexion au vocal…" : "Vocal connecté"}</b><span>{roomName(voice.room)}</span></div>
      <button className="dc-ibtn danger" onClick={leaveVoice} title="Quitter le vocal" aria-label="Quitter le vocal">⏏</button>
    </div>
    <div className="dc-meter"><i style={{ width: `${Math.round((voice.level || 0) * 100)}%` }} /></div>
    {voice.ptt && <button className={`dc-ptt${voice.pttDown ? " on" : ""}`} onPointerDown={() => engine?.setPttDown(true)} onPointerUp={() => engine?.setPttDown(false)} onPointerLeave={() => engine?.setPttDown(false)} onPointerCancel={() => engine?.setPttDown(false)}>{voice.pttDown ? "Tu parles…" : "Maintiens pour parler (V)"}</button>}
  </div>;

  const UserPanel = () => <div className="dc-user">
    <Avatar u={username} size={34} ring={speakingOf(username)} dot="on" />
    <div className="dc-user-name"><b className={nameCls(username)}>{username}</b><span>{voice?.room ? "En vocal" : "En ligne"}</span></div>
    <button className={`dc-ibtn${voice?.muted ? " off" : ""}`} onClick={() => engine?.setMuted(!voice?.muted)} title={voice?.muted ? "Réactiver le micro" : "Couper le micro"} aria-label="Micro">{voice?.muted ? "🚫" : "🎙️"}</button>
    <button className={`dc-ibtn${voice?.deaf ? " off" : ""}`} onClick={() => engine?.setDeaf(!voice?.deaf)} title={voice?.deaf ? "Réactiver le son" : "Sourdine casque"} aria-label="Casque">{voice?.deaf ? "🔇" : "🎧"}</button>
    <button className="dc-ibtn" onClick={openSettings} title="Paramètres vocaux" aria-label="Paramètres">⚙️</button>
  </div>;

  const Sidebar = () => <aside className={`dc-side${drawer ? " open" : ""}`}>
    <div className="dc-side-head"><b>TheCombinedWebs</b><span>{online.length} ami{online.length > 1 ? "s" : ""} en ligne</span></div>
    <div className="dc-side-scroll">
      <button className={`dc-item big${view.kind === "friends" ? " on" : ""}`} onClick={() => { setView({ kind: "friends" }); setDrawer(false); }}>👥 Amis{requests.length > 0 && <em className="dc-badge">{requests.length}</em>}</button>
      <div className="dc-cat">Salons textuels</div>
      {data?.clan && <><div className="dc-cat" style={{ color: data.clan.color }}>{data.clan.emoji} Clan {data.clan.tag}</div>
        <button className={`dc-item${view.kind === "channel" && view.id === data.clan.channel.id ? " on" : ""}`} onClick={() => { setView({ kind: "channel", id: data.clan!.channel.id }); setDrawer(false); }}><span className="dc-hash">{data.clan.emoji}</span>{data.clan.channel.name}</button></>}
      {data?.channels.map((c) => <button key={c.id} className={`dc-item${view.kind === "channel" && view.id === c.id ? " on" : ""}`} onClick={() => { setView({ kind: "channel", id: c.id }); setDrawer(false); }}><span className="dc-hash">{c.icon}</span>{c.name}</button>)}
      <div className="dc-cat">Salons vocaux</div>
      {data?.voiceRooms.map((r) => { const list = voiceMembersOf(r.id); return <div key={r.id}>
        <button className={`dc-item${voice?.room === r.id ? " live" : ""}${view.kind === "voice" && view.id === r.id ? " on" : ""}`} onClick={() => (voice?.room === r.id ? (setView({ kind: "voice", id: r.id }), setDrawer(false)) : joinVoice(r.id))}><span className="dc-hash">🔊</span>{r.name}{list.length > 0 && <em className="dc-count">{list.length}/{data.voiceMax}</em>}</button>
        {list.map((m) => <div key={m.u} className="dc-vmember"><Avatar u={m.u} size={22} ring={voice?.room === r.id ? speakingOf(m.u) : !!m.speaking} /><span>{m.u}</span>{m.deaf ? <i>🔇</i> : m.muted ? <i>🚫</i> : null}</div>)}
      </div>; })}
      <div className="dc-cat">Messages privés {unreadDM > 0 && <em className="dc-badge">{unreadDM}</em>}</div>
      {data?.dms.length === 0 && <p className="dc-empty-s">Ajoute des amis pour discuter en privé.</p>}
      {data?.dms.map((d) => { const f = data.friends.find((x) => x.username === d.with); return <button key={d.id} className={`dc-item dm${view.kind === "dm" && view.id === d.id ? " on" : ""}${d.unread ? " unread" : ""}`} onClick={() => { setView({ kind: "dm", with: d.with, id: d.id }); setDrawer(false); }}>
        <Avatar u={d.with} size={30} dot={f?.voice ? "voice" : f?.online ? "on" : "off"} /><span className="dc-dm-txt"><b>{d.with}</b><small>{d.preview || (f?.online ? f.where || "En ligne" : ago(f?.lastSeen || 0))}</small></span>
      </button>; })}
    </div>
    {VoicePanel()}
    {UserPanel()}
  </aside>;

  const header = view.kind === "channel" ? <><span className="dc-hash lg">{curChannel?.icon || "#"}</span><b>{curChannel?.name}</b><span className="dc-topic">{curChannel?.topic}</span></>
    : view.kind === "dm" ? <><Avatar u={view.with} size={26} dot={data?.friends.find((f) => f.username === view.with)?.online ? "on" : "off"} /><b>{view.with}</b><span className="dc-topic">{data?.friends.find((f) => f.username === view.with)?.where || ""}</span></>
    : view.kind === "voice" ? <><span className="dc-hash lg">🔊</span><b>{roomName(view.id)}</b><span className="dc-topic">Salon vocal · {voiceMembersOf(view.id).length}/{data?.voiceMax || 8}</span></>
    : <><span className="dc-hash lg">👥</span><b>Amis</b></>;

  return <div className="dc" onPointerDown={() => engine?.unlock()}>
    <nav className="dc-rail" aria-label="Écosystème">
      <Link href="/steamblox" className="dc-rail-btn home" title="TheCombinedWebs">TCB</Link>
      <span className="dc-rail-sep" />
      <button className="dc-rail-btn on" title="Discord TheCombinedWebs" onClick={() => setView({ kind: "channel", id: "general" })}>💬</button>
      <Link href="/cinestream" className="dc-rail-btn" title="CinéStream">🍿</Link>
      <Link href="/vortex" className="dc-rail-btn" title="Vortex">🎬</Link>
    </nav>
    {drawer && <div className="dc-scrim" onClick={() => setDrawer(false)} />}
    {Sidebar()}
    <main className="dc-main">
      <header className="dc-head">
        <button className="dc-ibtn dc-menu" onClick={() => setDrawer(true)} aria-label="Menu">☰</button>
        <div className="dc-head-title">{header}</div>
        <div className="dc-head-actions">
          {view.kind === "dm" && (inThisDmCall
            ? <button className="dc-btn danger" onClick={leaveVoice}>Raccrocher</button>
            : <button className="dc-btn ok" onClick={() => callFriend(view.with)} disabled={!!voice?.joining}>📞 Appeler</button>)}
          {view.kind !== "voice" && view.kind !== "friends" && <button className={`dc-ibtn dc-memb-btn${members ? " on" : ""}`} onClick={() => setMembers(!members)} title="Membres" aria-label="Afficher les membres">👥</button>}
        </div>
      </header>
      {error && <div className="dc-error">{error}</div>}

      {view.kind === "dm" && voice?.room === view.id && Screens()}
      {view.kind === "dm" && voice?.room === view.id && <div className="dc-callbar">
        {voice.members.map((m) => VoiceTile({ m }))}
        {canShare && <button className="dc-btn" style={{ alignSelf: "center" }} onClick={() => (voice.sharing ? engine?.stopShare() : engine?.startShare())}>{voice.sharing ? "Arrêter le partage" : "🖥️ Partager l’écran"}</button>}
        {outgoing && <div className="dc-tile ringing"><Avatar u={outgoing.to} size={84} /><b>{outgoing.to}</b><span className="dc-tile-state">Ça sonne…</span></div>}
      </div>}

      {view.kind === "voice" ? <section className="dc-stage">
        {voice?.room !== view.id ? <div className="dc-stage-empty">
          <h2>{roomName(view.id)}</h2><p>{voiceMembersOf(view.id).length ? `${voiceMembersOf(view.id).map((m) => m.u).join(", ")} ${voiceMembersOf(view.id).length > 1 ? "sont" : "est"} dans le salon.` : "Personne pour l’instant. Lance la discussion."}</p>
          <button className="dc-btn ok lg" onClick={() => joinVoice(view.id)}>Rejoindre le vocal</button>
        </div> : <>
          {Screens()}
          <div className="dc-tiles">{voice.members.map((m) => VoiceTile({ m }))}</div>
          {voice.members.length <= 1 && <p className="dc-stage-hint">Tu es seul ici. Invite un ami : il lui suffit de cliquer sur « {roomName(view.id)} ».</p>}
          <div className="dc-stage-bar">
            <button className={`dc-round${voice.muted ? " off" : ""}`} onClick={() => engine?.setMuted(!voice.muted)}>{voice.muted ? "🚫" : "🎙️"}<span>{voice.muted ? "Micro coupé" : "Micro"}</span></button>
            <button className={`dc-round${voice.deaf ? " off" : ""}`} onClick={() => engine?.setDeaf(!voice.deaf)}>{voice.deaf ? "🔇" : "🎧"}<span>Casque</span></button>
            <button className={`dc-round${voice.ptt ? " on" : ""}`} onClick={() => engine?.setPtt(!voice.ptt)}>⌨️<span>{voice.ptt ? "Appui pour parler" : "Détection voix"}</span></button>
            {canShare && <button className={`dc-round${voice.sharing ? " on" : ""}`} onClick={() => (voice.sharing ? engine?.stopShare() : engine?.startShare())}>🖥️<span>{voice.sharing ? "Arrêter le partage" : "Partager l’écran"}</span></button>}
            <button className="dc-round" onClick={openSettings}>⚙️<span>Réglages</span></button>
            <button className="dc-round danger" onClick={leaveVoice}>⏏<span>Quitter</span></button>
          </div>
        </>}
      </section>

      : view.kind === "friends" ? <section className="dc-friends">
        <div className="dc-tabs">
          <button className={friendTab === "online" ? "on" : ""} onClick={() => setFriendTab("online")}>En ligne · {online.length}</button>
          <button className={friendTab === "all" ? "on" : ""} onClick={() => setFriendTab("all")}>Tous · {data?.friends.length || 0}</button>
          <button className={`add${friendTab === "add" ? " on" : ""}`} onClick={() => setFriendTab("add")}>Ajouter un ami{requests.length > 0 && <em className="dc-badge">{requests.length}</em>}</button>
        </div>
        {friendTab === "add" ? <div className="dc-add">
          <h3>Ajouter un ami</h3><p>Cherche un pseudo TheCombinedWebs. Une fois amis, vous pouvez vous écrire et vous appeler.</p>
          <input className="dc-input" value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Pseudo…" aria-label="Rechercher un pseudo" />
          {results.map((u) => <div key={u.username} className="dc-frow"><Avatar u={u.username} size={34} /><b>{u.username}</b><button className="dc-btn" onClick={() => friendAction({ action: "add", username: u.username }, "Demande envoyée")}>Ajouter</button></div>)}
          {requests.length > 0 && <><h3>Demandes reçues</h3>{requests.map((r) => <div key={r.id} className="dc-frow"><Avatar u={r.from} size={34} /><b>{r.from}</b><button className="dc-btn ok" onClick={() => friendAction({ action: "respond", from: r.from, accept: true }, "Ami ajouté")}>Accepter</button><button className="dc-btn" onClick={() => friendAction({ action: "respond", from: r.from, accept: false }, "Demande refusée")}>Refuser</button></div>)}</>}
        </div> : <div className="dc-flist">
          {(friendTab === "online" ? online : data?.friends || []).map((f) => <div key={f.username} className="dc-frow">
            <Avatar u={f.username} size={38} dot={f.voice ? "voice" : f.online ? "on" : "off"} />
            <div className="dc-fmeta"><b>{f.username}</b><small>{f.voice ? `En vocal · ${roomName(f.voice)}` : f.online ? f.where || "En ligne" : ago(f.lastSeen)}</small></div>
            <button className="dc-ibtn" title="Message" aria-label={`Écrire à ${f.username}`} onClick={() => setView({ kind: "dm", with: f.username, id: dmId(username, f.username) })}>💬</button>
            <button className="dc-ibtn" title="Appeler" aria-label={`Appeler ${f.username}`} onClick={() => { setView({ kind: "dm", with: f.username, id: dmId(username, f.username) }); callFriend(f.username); }}>📞</button>
            {f.voice && !f.voice.startsWith("dm~") && <button className="dc-btn" onClick={() => joinVoice(f.voice!)}>Rejoindre</button>}
          </div>)}
          {(friendTab === "online" ? online : data?.friends || []).length === 0 && <div className="dc-empty"><b>{friendTab === "online" ? "Aucun ami en ligne" : "Pas encore d’amis"}</b><p>Ajoute des amis pour les appeler en vocal.</p><button className="dc-btn ok" onClick={() => setFriendTab("add")}>Ajouter un ami</button></div>}
        </div>}
      </section>

      : <section className="dc-chat">
        <div className="dc-msgs" ref={listRef} onScroll={(e) => { const el = e.currentTarget; stick.current = el.scrollHeight - el.scrollTop - el.clientHeight < 80; }}>
          <div className="dc-intro">
            {view.kind === "dm" ? <><Avatar u={view.with} size={72} /><h2>{view.with}</h2><p>Début de ta conversation privée avec {view.with}. Clique sur Appeler pour lancer un appel vocal.</p></>
              : <><span className="dc-intro-ic">{curChannel?.icon || "#"}</span><h2>Bienvenue dans #{curChannel?.name}</h2><p>{curChannel?.topic}</p></>}
          </div>
          {grouped.map(({ m, head }) => <div key={m.id} tabIndex={0} className={`dc-msg${head ? " head" : ""}${m.id.startsWith("tmp-") ? " pending" : ""}${new RegExp(`@(${username}|everyone)\\b`, "i").test(m.text) ? " ping" : ""}`}>
            {m.replyTo && <div className="dc-reply-ref">↱ <b>{m.replyTo.author}</b> {m.replyTo.text}</div>}
            {head ? <Avatar u={m.author} size={40} /> : <span className="dc-gut">{new Date(m.at).toLocaleTimeString("fr-FR", { hour: "2-digit", minute: "2-digit" })}</span>}
            <div className="dc-body">
              {head && <div className="dc-meta"><Link href={`/u/${encodeURIComponent(m.author)}`} className={nameCls(m.author)} style={{ color: `hsl(${hue(m.author)} 75% 72%)`, fontWeight: 700 }}>{m.author}</Link><time>{time(m.at)}</time></div>}
              {editing?.id === m.id ? <div className="dc-edit"><textarea value={editing.text} onChange={(e) => setEditing({ id: m.id, text: e.target.value })} onKeyDown={(e) => { if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); saveEdit(); } if (e.key === "Escape") setEditing(null); }} autoFocus /><small>Entrée pour enregistrer · Échap pour annuler</small></div>
                : <div className="dc-text">{richText(m.text, username)}{m.edited && <small className="dc-edited"> (modifié)</small>}</div>}
              {m.reactions && Object.keys(m.reactions).length > 0 && <div className="dc-reacts">{Object.entries(m.reactions).map(([e, us]) => <button key={e} className={us.some((u) => low(u) === low(username)) ? "mine" : ""} onClick={() => react(m.id, e)} title={us.join(", ")}>{e} {us.length}</button>)}</div>}
            </div>
            {!m.id.startsWith("tmp-") && <div className="dc-tools">
              <button onClick={() => setPicker(picker === m.id ? null : m.id)} title="Réagir" aria-label="Réagir">😊</button>
              {canWrite && <button onClick={() => { setReplyTo(m); inputRef.current?.focus(); }} title="Répondre" aria-label="Répondre">↩</button>}
              {low(m.author) === low(username) && <button onClick={() => setEditing({ id: m.id, text: m.text })} title="Modifier" aria-label="Modifier">✏️</button>}
              {(low(m.author) === low(username) || staff) && <button onClick={() => remove(m.id)} title="Supprimer" aria-label="Supprimer">🗑</button>}
              {low(m.author) !== low(username) && <button onClick={() => report(m)} title="Signaler" aria-label="Signaler">🚩</button>}
              {picker === m.id && <div className="dc-picker">{data?.reactions.map((e) => <button key={e} onClick={() => react(m.id, e)}>{e}</button>)}</div>}
            </div>}
          </div>)}
        </div>
        {canWrite ? <div className="dc-compose">
          {replyTo && <div className="dc-replying">Réponse à <b>{replyTo.author}</b><button onClick={() => setReplyTo(null)} aria-label="Annuler la réponse">✕</button></div>}
          <div className="dc-compose-box">
            <textarea ref={inputRef} rows={1} value={draft} maxLength={1200} onChange={(e) => setDraft(e.target.value)} onKeyDown={(e) => { if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); send(); } if (e.key === "ArrowUp" && !draft) { const mine = [...messages].reverse().find((x) => low(x.author) === low(username) && !x.id.startsWith("tmp-")); if (mine) setEditing({ id: mine.id, text: mine.text }); } }}
              placeholder={view.kind === "dm" ? `Envoyer un message à @${view.with}` : `Envoyer un message dans #${curChannel?.name || ""}`} aria-label="Message" />
            <button className="dc-send" onClick={send} disabled={!draft.trim() || busy} aria-label="Envoyer">➤</button>
          </div>
          <small className="dc-hint">Entrée pour envoyer · Maj+Entrée pour aller à la ligne · **gras**, `code`, @pseudo</small>
        </div> : <div className="dc-readonly">Seuls Younes et Moustafa peuvent écrire dans ce salon.</div>}
      </section>}
    </main>

    {members && view.kind !== "voice" && view.kind !== "friends" && <aside className="dc-members">
      <div className="dc-cat">En ligne · {online.length + 1}</div>
      <div className="dc-mrow"><Avatar u={username} size={32} dot="on" /><span><b className={nameCls(username)}>{username}</b><small>{voice?.room ? `En vocal · ${roomName(voice.room)}` : "Sur Discord"}</small></span></div>
      {online.map((f) => <div key={f.username} className="dc-mrow"><Avatar u={f.username} size={32} dot={f.voice ? "voice" : "on"} /><span><Link href={`/u/${encodeURIComponent(f.username)}`}><b className={nameCls(f.username)}>{f.username}</b></Link><small>{f.voice ? `En vocal · ${roomName(f.voice)}` : f.where || "En ligne"}</small></span></div>)}
      {(data?.friends.filter((f) => !f.online).length || 0) > 0 && <div className="dc-cat">Hors ligne</div>}
      {data?.friends.filter((f) => !f.online).map((f) => <div key={f.username} className="dc-mrow off"><Avatar u={f.username} size={32} dot="off" /><span><b>{f.username}</b><small>{ago(f.lastSeen)}</small></span></div>)}
    </aside>}

    {incoming && <div className="dc-modal-back"><div className="dc-call-modal">
      <Avatar u={incoming.from} size={96} ring />
      <h3>{incoming.from}</h3><p>t’appelle…</p>
      <div className="dc-call-actions"><div className="dc-ca"><button className="dc-cbtn no" onClick={declineCall} aria-label="Refuser">✕</button><span>Refuser</span></div><div className="dc-ca"><button className="dc-cbtn yes" onClick={acceptCall} aria-label="Accepter">📞</button><span>Accepter</span></div></div>
    </div></div>}

    {settings && <div className="dc-modal-back" onClick={(e) => { if (e.target === e.currentTarget) setSettings(false); }}><div className="dc-settings">
      <div className="dc-settings-head"><h3>Réglages vocaux</h3><button className="dc-ibtn" onClick={() => setSettings(false)} aria-label="Fermer">✕</button></div>
      <label>Micro<select className="dc-input" defaultValue={engine?.settings.inputId || ""} onChange={(e) => engine?.setSettings({ inputId: e.target.value })}><option value="">Par défaut</option>{devices.map((d, i) => <option key={d.deviceId || i} value={d.deviceId}>{d.label || `Micro ${i + 1}`}</option>)}</select></label>
      <label className="dc-check"><input type="checkbox" defaultChecked={engine?.settings.noise} onChange={(e) => engine?.setSettings({ noise: e.target.checked })} />Suppression du bruit</label>
      <label className="dc-check"><input type="checkbox" defaultChecked={engine?.settings.echo} onChange={(e) => engine?.setSettings({ echo: e.target.checked })} />Annulation de l’écho</label>
      <label className="dc-check"><input type="checkbox" defaultChecked={engine?.settings.agc} onChange={(e) => engine?.setSettings({ agc: e.target.checked })} />Gain automatique</label>
      <label className="dc-check"><input type="checkbox" checked={!!voice?.ptt} onChange={(e) => engine?.setPtt(e.target.checked)} />Appui pour parler (touche V)</label>
      <label>Sensibilité de détection de voix<input type="range" min={0.03} max={0.4} step={0.01} defaultValue={engine?.settings.sensitivity ?? 0.12} onChange={(e) => engine?.setSettings({ sensitivity: Number(e.target.value) })} /></label>
      <div className="dc-meter big"><i style={{ width: `${Math.round((voice?.level || 0) * 100)}%` }} /><b style={{ left: `${Math.round(((engine?.settings.sensitivity ?? 0.12)) * 100)}%` }} /></div>
      <p className="dc-note">La voix passe directement entre les navigateurs (pair-à-pair). Sur certains réseaux très fermés (école, entreprise), un relais TURN peut être nécessaire : voir le README.</p>
    </div></div>}

    {toast && <div className="dc-toast" role="status">{toast}</div>}
  </div>;
}
