// Moteur vocal du Discord TheCombinedWebs : WebRTC en maillage (jusqu'à 8 personnes),
// signalisation par l'API /api/discord/voice (aucun serveur externe nécessaire).

export type VoiceMember = { u: string; muted?: boolean; deaf?: boolean; speaking?: boolean };
export type PeerInfo = { u: string; state: string };
export type VoiceSnapshot = {
  room: string | null;
  joining: boolean;
  members: VoiceMember[];
  peers: Record<string, string>; // u (minuscule) -> état de connexion
  speaking: Record<string, boolean>; // u (minuscule) -> parle
  level: number; // niveau du micro local 0..1
  muted: boolean;
  deaf: boolean;
  ptt: boolean;
  pttDown: boolean;
  error: string;
  sharing: boolean; // je partage mon écran
  videos: Record<string, MediaStream>; // u (minuscule) -> écran partagé reçu
};
export type VoiceSettings = { noise: boolean; echo: boolean; agc: boolean; inputId: string; sensitivity: number };

const low = (u: string) => u.toLowerCase();

function iceServers(): RTCIceServer[] {
  const list: RTCIceServer[] = [{ urls: ["stun:stun.l.google.com:19302", "stun:stun1.l.google.com:19302"] }, { urls: "stun:stun.cloudflare.com:3478" }];
  const turn = process.env.NEXT_PUBLIC_TURN_URL;
  if (turn) list.push({ urls: turn.split(",").map((s) => s.trim()).filter(Boolean), username: process.env.NEXT_PUBLIC_TURN_USERNAME || undefined, credential: process.env.NEXT_PUBLIC_TURN_CREDENTIAL || undefined });
  return list;
}

function gathered(pc: RTCPeerConnection) {
  return new Promise<void>((res) => {
    if (pc.iceGatheringState === "complete") return res();
    const t = setTimeout(res, 2500);
    pc.addEventListener("icegatheringstatechange", () => { if (pc.iceGatheringState === "complete") { clearTimeout(t); res(); } });
  });
}

type Peer = { u: string; pc: RTCPeerConnection; audio: HTMLAudioElement; analyser?: AnalyserNode; initiator: boolean; createdAt: number; stream?: MediaStream };
type OutSignal = { to: string; kind: "offer" | "answer" | "bye"; sdp?: unknown };

export class VoiceEngine {
  me: string;
  snap: VoiceSnapshot = { room: null, joining: false, members: [], peers: {}, speaking: {}, level: 0, muted: false, deaf: false, ptt: false, pttDown: false, error: "", sharing: false, videos: {} };
  settings: VoiceSettings = { noise: true, echo: true, agc: true, inputId: "", sensitivity: 0.12 };
  volumes: Record<string, number> = {};
  private stream: MediaStream | null = null;
  private screen: MediaStream | null = null;
  private ctx: AudioContext | null = null;
  private localAnalyser: AnalyserNode | null = null;
  private peers = new Map<string, Peer>();
  private out: OutSignal[] = [];
  private timer: ReturnType<typeof setTimeout> | null = null;
  private meterTimer: ReturnType<typeof setInterval> | null = null;
  private listeners = new Set<(s: VoiceSnapshot) => void>();
  private busy = false;
  private lastSpeaking = false;
  private holdUntil = 0;
  onEvent?: (kind: "join" | "leave" | "self-join" | "self-leave", who: string) => void;

  constructor(me: string) {
    this.me = me;
    try {
      const v = JSON.parse(localStorage.getItem("steamblox:voice:volumes") || "{}"); if (v && typeof v === "object") this.volumes = v;
      const s = JSON.parse(localStorage.getItem("steamblox:voice:settings") || "{}"); if (s && typeof s === "object") this.settings = { ...this.settings, ...s };
      this.snap.ptt = localStorage.getItem("steamblox:voice:ptt") === "1";
    } catch { /* stockage indisponible */ }
  }

  subscribe(fn: (s: VoiceSnapshot) => void) { this.listeners.add(fn); fn(this.snap); return () => { this.listeners.delete(fn); }; }
  private emit(patch: Partial<VoiceSnapshot> = {}) { this.snap = { ...this.snap, ...patch }; this.listeners.forEach((f) => f(this.snap)); }

  private constraints(): MediaStreamConstraints {
    const s = this.settings;
    return { audio: { echoCancellation: s.echo, noiseSuppression: s.noise, autoGainControl: s.agc, channelCount: 1, ...(s.inputId ? { deviceId: { exact: s.inputId } } : {}) }, video: false };
  }

  private applyMic() {
    const t = this.stream?.getAudioTracks()[0];
    if (t) t.enabled = !(this.snap.muted || this.snap.deaf || (this.snap.ptt && !this.snap.pttDown));
  }
  private applyDeaf() { this.peers.forEach((p) => { p.audio.muted = this.snap.deaf; }); }

  async join(room: string) {
    if (this.snap.room === room) return;
    if (this.snap.room) await this.leave();
    this.emit({ joining: true, error: "" });
    try {
      if (!navigator.mediaDevices?.getUserMedia) throw new Error("Ton navigateur ne permet pas le vocal (HTTPS requis).");
      this.stream = await navigator.mediaDevices.getUserMedia(this.constraints());
    } catch (e) {
      const msg = e instanceof Error && /denied|NotAllowed/i.test(e.name + e.message) ? "Micro refusé : autorise le micro dans ton navigateur." : e instanceof Error ? e.message : "Micro indisponible";
      this.emit({ joining: false, error: msg });
      return;
    }
    try {
      const AC = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      this.ctx = new AC();
      this.localAnalyser = this.ctx.createAnalyser();
      this.localAnalyser.fftSize = 512;
      this.ctx.createMediaStreamSource(this.stream).connect(this.localAnalyser);
    } catch { /* jauge indisponible */ }
    this.applyMic();
    this.emit({ room, members: [], peers: {}, speaking: {} });
    const ok = await this.beat("join");
    if (!ok) { this.cleanup(); this.emit({ room: null, joining: false }); return; }
    this.emit({ joining: false });
    this.onEvent?.("self-join", this.me);
    this.meterTimer = setInterval(() => this.meter(), 90);
    this.schedule();
  }

  async leave() {
    const room = this.snap.room;
    if (!room) return;
    const byes = [...this.peers.keys()].map((u) => ({ to: u, kind: "bye" as const }));
    this.cleanup();
    this.emit({ room: null, members: [], peers: {}, speaking: {}, level: 0, joining: false });
    this.onEvent?.("self-leave", this.me);
    try {
      if (byes.length) await fetch("/api/discord/voice", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ action: "beat", room, signals: byes }) });
      await fetch("/api/discord/voice", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ action: "leave", room }), keepalive: true });
    } catch { /* hors ligne */ }
  }

  /** Quitte sans réseau (fermeture de page). */
  leaveBeacon() {
    const room = this.snap.room;
    if (!room) return;
    try { navigator.sendBeacon?.("/api/discord/voice", new Blob([JSON.stringify({ action: "leave", room })], { type: "application/json" })); } catch { /* ignore */ }
    this.cleanup();
  }

  private cleanup() {
    if (this.timer) clearTimeout(this.timer);
    if (this.meterTimer) clearInterval(this.meterTimer);
    this.timer = null; this.meterTimer = null;
    this.peers.forEach((p) => this.closePeer(p.u, false));
    this.peers.clear();
    this.stream?.getTracks().forEach((t) => t.stop());
    this.stream = null;
    this.screen?.getTracks().forEach((t) => t.stop());
    this.screen = null;
    this.snap = { ...this.snap, sharing: false, videos: {} };
    this.ctx?.close().catch(() => {});
    this.ctx = null; this.localAnalyser = null;
    this.out = [];
  }

  setMuted(v: boolean) { this.emit({ muted: v, ...(v ? {} : { deaf: false }) }); this.applyMic(); this.applyDeaf(); }
  setDeaf(v: boolean) { this.emit({ deaf: v }); this.applyMic(); this.applyDeaf(); }
  setPtt(v: boolean) { this.emit({ ptt: v }); try { localStorage.setItem("steamblox:voice:ptt", v ? "1" : "0"); } catch {} this.applyMic(); }
  setPttDown(v: boolean) { if (this.snap.pttDown === v) return; this.emit({ pttDown: v }); this.applyMic(); }
  setVolume(u: string, v: number) {
    this.volumes[low(u)] = v;
    const p = this.peers.get(low(u)); if (p) p.audio.volume = Math.max(0, Math.min(1, v));
    try { localStorage.setItem("steamblox:voice:volumes", JSON.stringify(this.volumes)); } catch {}
  }
  async setSettings(s: Partial<VoiceSettings>) {
    this.settings = { ...this.settings, ...s };
    try { localStorage.setItem("steamblox:voice:settings", JSON.stringify(this.settings)); } catch {}
    if (!this.stream || ("sensitivity" in s && Object.keys(s).length === 1)) return;
    try {
      const fresh = await navigator.mediaDevices.getUserMedia(this.constraints());
      const track = fresh.getAudioTracks()[0];
      this.peers.forEach((p) => p.pc.getSenders().forEach((snd) => { if (snd.track?.kind === "audio") snd.replaceTrack(track).catch(() => {}); }));
      this.stream.getTracks().forEach((t) => t.stop());
      this.stream = fresh;
      if (this.ctx && this.localAnalyser) this.ctx.createMediaStreamSource(fresh).connect(this.localAnalyser);
      this.applyMic();
    } catch (e) { this.emit({ error: e instanceof Error ? e.message : "Micro indisponible" }); }
  }

  private schedule() {
    if (!this.snap.room) return;
    const negotiating = [...this.peers.values()].some((p) => p.pc.connectionState !== "connected") || this.out.length > 0;
    this.timer = setTimeout(async () => { await this.beat(this.snap.members.some((m) => low(m.u) === low(this.me)) ? "beat" : "join"); this.schedule(); }, negotiating ? 800 : 1800);
  }

  private async beat(action: "join" | "beat") {
    const room = this.snap.room;
    if (!room || this.busy) return true;
    this.busy = true;
    const signals = this.out.splice(0, 16);
    try {
      const r = await fetch("/api/discord/voice", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ action, room, muted: this.snap.muted, deaf: this.snap.deaf, speaking: this.lastSpeaking, signals }) });
      const d = await r.json();
      if (!r.ok) { this.emit({ error: d.error || "Erreur vocale" }); if (action === "join") return false; return true; }
      if (this.snap.room !== room) return true;
      for (const s of d.inbox || []) await this.onSignal(s);
      this.reconcile(d.members || []);
      return true;
    } catch {
      this.out.unshift(...signals);
      return action !== "join";
    } finally { this.busy = false; }
  }

  private reconcile(members: VoiceMember[]) {
    const meL = low(this.me);
    const prev = new Set(this.snap.members.map((m) => low(m.u)));
    const now = new Set(members.map((m) => low(m.u)));
    for (const m of members) {
      const k = low(m.u);
      if (k === meL) continue;
      if (!prev.has(k) && this.snap.members.length) this.onEvent?.("join", m.u);
      const p = this.peers.get(k);
      const stale = p && (p.pc.connectionState === "failed" || p.pc.connectionState === "closed" || (p.pc.connectionState !== "connected" && Date.now() - p.createdAt > 15000));
      if (stale) this.closePeer(k);
      if ((!p || stale) && meL < k) this.initiate(m.u);
    }
    for (const k of [...this.peers.keys()]) if (!now.has(k)) this.closePeer(k);
    for (const k of prev) if (!now.has(k) && k !== meL) { const m = this.snap.members.find((x) => low(x.u) === k); this.onEvent?.("leave", m?.u || k); }
    this.emit({ members, peers: Object.fromEntries([...this.peers].map(([k, p]) => [k, p.pc.connectionState])) });
  }

  private makePeer(u: string, initiator: boolean): Peer {
    const pc = new RTCPeerConnection({ iceServers: iceServers() });
    const audio = new Audio();
    audio.autoplay = true;
    audio.muted = this.snap.deaf;
    audio.volume = Math.max(0, Math.min(1, this.volumes[low(u)] ?? 1));
    const peer: Peer = { u, pc, audio, initiator, createdAt: Date.now() };
    this.stream?.getTracks().forEach((t) => pc.addTrack(t, this.stream!));
    this.screen?.getVideoTracks().forEach((t) => pc.addTrack(t, this.screen!));
    pc.ontrack = (ev) => {
      if (ev.track.kind === "video") {
        const vs = new MediaStream([ev.track]);
        const drop = () => { if (this.snap.videos[low(u)]?.getVideoTracks()[0] === ev.track) { const v = { ...this.snap.videos }; delete v[low(u)]; this.emit({ videos: v }); } };
        ev.track.addEventListener("ended", drop);
        this.emit({ videos: { ...this.snap.videos, [low(u)]: vs } });
        return;
      }
      const st = ev.streams[0] || new MediaStream([ev.track]);
      peer.stream = st;
      audio.srcObject = st;
      audio.play().catch(() => { /* lecture après interaction */ });
      try { if (this.ctx) { const a = this.ctx.createAnalyser(); a.fftSize = 512; this.ctx.createMediaStreamSource(st).connect(a); peer.analyser = a; } } catch { /* ignore */ }
    };
    pc.onconnectionstatechange = () => this.emit({ peers: { ...this.snap.peers, [low(u)]: pc.connectionState } });
    this.peers.set(low(u), peer);
    return peer;
  }

  private closePeer(k: string, emit = true) {
    const p = this.peers.get(low(k));
    if (!p) return;
    try { p.pc.close(); } catch {}
    p.audio.srcObject = null;
    this.peers.delete(low(k));
    if (this.snap.videos[low(k)]) { const v = { ...this.snap.videos }; delete v[low(k)]; this.snap = { ...this.snap, videos: v }; }
    if (emit) { const peers = { ...this.snap.peers }; delete peers[low(k)]; this.emit({ peers }); }
  }

  private async initiate(u: string) {
    const p = this.makePeer(u, true);
    try {
      const offer = await p.pc.createOffer({ offerToReceiveAudio: true, offerToReceiveVideo: true });
      await p.pc.setLocalDescription(offer);
      await gathered(p.pc);
      if (this.peers.get(low(u)) === p) this.out.push({ to: u, kind: "offer", sdp: p.pc.localDescription?.toJSON() });
    } catch { this.closePeer(u); }
  }

  private async onSignal(s: { from: string; kind: string; sdp?: RTCSessionDescriptionInit }) {
    const k = low(s.from);
    if (s.kind === "bye") { this.closePeer(k); return; }
    if (s.kind === "offer" && s.sdp) {
      this.closePeer(k);
      const p = this.makePeer(s.from, false);
      try {
        await p.pc.setRemoteDescription(s.sdp);
        const ans = await p.pc.createAnswer();
        await p.pc.setLocalDescription(ans);
        await gathered(p.pc);
        if (this.peers.get(k) === p) this.out.push({ to: s.from, kind: "answer", sdp: p.pc.localDescription?.toJSON() });
      } catch { this.closePeer(k); }
      return;
    }
    if (s.kind === "answer" && s.sdp) {
      const p = this.peers.get(k);
      if (p && p.pc.signalingState === "have-local-offer") { try { await p.pc.setRemoteDescription(s.sdp); } catch { this.closePeer(k); } }
    }
  }

  private buf = new Uint8Array(256);
  private levelOf(a?: AnalyserNode | null) {
    if (!a) return 0;
    if (this.buf.length !== a.fftSize) this.buf = new Uint8Array(a.fftSize);
    a.getByteTimeDomainData(this.buf);
    let sum = 0;
    for (let i = 0; i < this.buf.length; i++) { const v = (this.buf[i] - 128) / 128; sum += v * v; }
    return Math.min(1, Math.sqrt(sum / this.buf.length) * 4);
  }

  private meter() {
    if (this.ctx?.state === "suspended") this.ctx.resume().catch(() => {});
    const lvl = this.levelOf(this.localAnalyser);
    const micOn = !!this.stream?.getAudioTracks()[0]?.enabled;
    const now = Date.now();
    if (micOn && lvl > this.settings.sensitivity) this.holdUntil = now + 280;
    const speaking = micOn && now < this.holdUntil;
    this.lastSpeaking = speaking;
    const map: Record<string, boolean> = { [low(this.me)]: speaking };
    this.peers.forEach((p, k) => { map[k] = !p.audio.muted && this.levelOf(p.analyser) > 0.08; });
    const changed = Object.keys(map).some((k) => !!map[k] !== !!this.snap.speaking[k]) || Math.abs(lvl - this.snap.level) > 0.04;
    if (changed) this.emit({ speaking: map, level: micOn ? lvl : 0 });
  }

  /** Partage d'écran (ordinateur uniquement) : renégocie chaque connexion avec la piste vidéo. */
  static canShare() { return typeof navigator !== "undefined" && !!navigator.mediaDevices?.getDisplayMedia && !/Android|iPhone|iPad|SteambloxApp/i.test(navigator.userAgent); }
  async startShare() {
    if (!this.snap.room || this.screen) return;
    try {
      const s = await navigator.mediaDevices.getDisplayMedia({ video: { frameRate: 15, width: { max: 1600 }, height: { max: 900 } }, audio: false });
      this.screen = s;
      s.getVideoTracks()[0]?.addEventListener("ended", () => this.stopShare());
      this.emit({ sharing: true });
      this.renegotiateAll();
    } catch (e) { if (!(e instanceof Error && /NotAllowed|denied|abort/i.test(e.name + e.message))) this.emit({ error: "Partage d’écran impossible sur cet appareil." }); }
  }
  stopShare() {
    if (!this.screen) return;
    this.screen.getTracks().forEach((t) => t.stop());
    this.screen = null;
    this.emit({ sharing: false });
    this.renegotiateAll();
  }
  private renegotiateAll() { for (const [k, p] of [...this.peers]) { this.closePeer(k); this.initiate(p.u); } }

  /** Débloque la lecture audio après une interaction (Safari / iOS). */
  unlock() { this.ctx?.resume().catch(() => {}); this.peers.forEach((p) => p.audio.play().catch(() => {})); }
}
