import { redirect } from "next/navigation";
import { currentUser } from "@/lib/auth";
import DiscordClient from "./DiscordClient";
import "./discord.css";

export const metadata = { title: "Discord · Écosystème TheCombinedWebs", description: "Salons texte, messages privés et chat vocal entre amis." };
export const dynamic = "force-dynamic";

export default async function DiscordPage({ searchParams }: { searchParams?: Promise<{ dm?: string; join?: string }> }) {
  const u = await currentUser();
  if (!u) { redirect("/login?next=/discord"); return null; }
  const q = searchParams ? await searchParams : {};
  const dm = q.dm && (u.friends || []).find((f) => f.toLowerCase() === String(q.dm).toLowerCase());
  return <DiscordClient username={u.username} initialDm={dm || undefined} autoJoin={!!dm && q.join === "1"} />;
}
