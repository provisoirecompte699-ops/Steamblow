"use client";
export default function GlobalError({reset}:{error:Error & {digest?:string};reset:()=>void}){
  return <html lang="fr"><body><main className="error-page"><div className="card error-card"><div className="eyebrow">THECOMBINEDWEBS</div><h1>TheCombinedWebs a besoin d’un redémarrage.</h1><p className="muted">Une erreur critique a empêché l’interface de se charger.</p><button className="button" onClick={()=>reset()}>Redémarrer</button></div></main></body></html>
}
