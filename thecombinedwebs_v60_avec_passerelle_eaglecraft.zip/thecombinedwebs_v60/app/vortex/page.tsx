import Link from "next/link";
import EcosystemBar from "../EcosystemBar";

export default function VortexPage() {
  return (
    <main className="vortex-shell" style={{ minHeight: "100dvh", background: "#060608", color: "#fff" }}>
      <EcosystemBar current="vortex" />
      <div style={{ position: "fixed", top: 12, left: 12, zIndex: 30000 }}>
        <Link
          href="/steamblox"
          style={{
            display: "inline-flex",
            alignItems: "center",
            gap: 8,
            padding: "9px 14px",
            borderRadius: 10,
            background: "rgba(6,6,8,.82)",
            border: "1px solid rgba(255,255,255,.12)",
            color: "#fff",
            textDecoration: "none",
            fontWeight: 700,
            backdropFilter: "blur(12px)",
          }}
        >
          ← TheCombinedWebs
        </Link>
      </div>
      <iframe
        title="Vortex Streaming"
        src="/vortex/index.html"
        style={{ width: "100%", height: "100dvh", minHeight: "100dvh", border: 0, display: "block" }}
        allow="autoplay; encrypted-media; picture-in-picture; fullscreen" referrerPolicy="strict-origin-when-cross-origin" loading="eager"
        allowFullScreen
      />
    </main>
  );
}
