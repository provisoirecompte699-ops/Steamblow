"use client";
import { useState, type FormEvent } from "react";
import { safeNext } from "@/lib/login-redirect";

const MESSAGES: Record<string, string> = {
  invalid: "Pseudo ou mot de passe incorrect.",
  rate_limited: "Trop de tentatives. Réessaie dans une minute.",
  unavailable: "La connexion a échoué côté serveur. Réessaie ; si cela continue, consulte le journal Netlify. Ne supprime pas tes comptes ou sauvegardes.",
};

export default function LoginForm({ next }: { next: string }) {
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState("");
  async function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (busy) return;
    const form = new FormData(event.currentTarget);
    setBusy(true);
    setMessage("");
    try {
      const response = await fetch("/api/auth/login", {
        method: "POST",
        headers: { "content-type": "application/json" },
        credentials: "same-origin",
        cache: "no-store",
        body: JSON.stringify({ username: form.get("username"), password: form.get("password") }),
      });
      const result = await response.json();
      if (!response.ok || !result.ok) {
        setMessage(MESSAGES[result.error] || MESSAGES.unavailable);
        return;
      }
      const target = safeNext(next);
      const params = new URLSearchParams();
      if (result.reward) {
        params.set("loginReward", String(result.reward));
        params.set("streak", String(result.streak));
      }
      if (result.streak > 8) {
        params.set("streakMessage", "wash");
        params.set("streak", String(result.streak));
      }
      // Full navigation ensures the login screen starts with a fresh session state.
      window.location.assign(target === "/steamblox" && params.size ? `${target}?${params}` : target);
    } catch {
      setMessage("Connexion réseau indisponible. Réessaie sans supprimer tes données.");
    } finally {
      setBusy(false);
    }
  }
  return <form onSubmit={submit} className="form-stack" aria-busy={busy}>
    {message && <p className="status error" role="alert">{message}</p>}
    <label>Nom<input className="input" name="username" required autoComplete="username" maxLength={40} /></label>
    <label>Mot de passe<input className="input" type="password" name="password" required autoComplete="current-password" maxLength={200} /></label>
    <button className="button" disabled={busy}>{busy ? "Connexion…" : "Se connecter"}</button>
  </form>;
}
