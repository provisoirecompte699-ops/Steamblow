import Link from "next/link";
import { safeNext } from "@/lib/login-redirect";
import LoginForm from "./LoginForm";

export default async function Login({ searchParams }: { searchParams?: Promise<{ error?: string; next?: string }> }) {
  const q = searchParams ? await searchParams : {};
  const error = q.error || "";
  const next = safeNext(q.next, "");

  return <main className="wrap">
    <section className="card" style={{ maxWidth: 460, margin: "70px auto" }}>
      <div className="eyebrow">ÉCOSYSTÈME THECOMBINEDWEBS</div>
      <h1>Connexion</h1>
      <p className="status">Un seul compte pour TheCombinedWebs, Vortex, CinéStream et Baldi&apos;s Basics 3D.</p>
      {error === "invalid" && <p className="status error" role="alert">Pseudo ou mot de passe incorrect.</p>}
      {error === "rate" && <p className="status error" role="alert">Trop de tentatives. Réessaie dans une minute.</p>}
      <LoginForm next={next} />
      <p className="status" style={{ marginTop: 16 }}>Pas encore de compte ? <Link href={next ? `/register?next=${encodeURIComponent(next)}` : "/register"}>Créer un compte</Link></p>
      <p className="status" style={{ marginTop: 8, opacity: .7 }}>Crédits : Walid</p>
    </section>
  </main>;
}
