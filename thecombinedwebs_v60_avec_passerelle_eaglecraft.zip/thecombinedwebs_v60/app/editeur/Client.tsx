"use client";
import Link from "next/link";
import { useCallback, useEffect, useRef, useState } from "react";

type Mode = { mode: string; gameId: string; title: string };
type MapMeta = { id: string; name: string; author: string; mode: string; cols: number; rows: number; at: number; plays: number; likes: string[] };
const TOOLS = [{ v: 0, name: "Sol", c: "#2a2f45" }, { v: 1, name: "Mur", c: "#8b7cff" }, { v: 2, name: "Caisse", c: "#b07a4a" }, { v: 9, name: "Départ", c: "#5ee7c4" }];
const COL = ["#1b1f30", "#8b7cff", "#b07a4a", "#05060a"];
const SIZES = [{ c: 20, r: 13, n: "Petite" }, { c: 26, r: 17, n: "Moyenne" }, { c: 32, r: 20, n: "Grande" }];

function blank(cols: number, rows: number) { const g = new Array(cols * rows).fill(0); for (let x = 0; x < cols; x++) { g[x] = 1; g[(rows - 1) * cols + x] = 1; } for (let y = 0; y < rows; y++) { g[y * cols] = 1; g[y * cols + cols - 1] = 1; } return g; }
function draw(cv: HTMLCanvasElement, cols: number, rows: number, g: number[], spawn?: { x: number; y: number }, gridLines = true) {
  const w = cv.clientWidth || 600, cell = w / cols; cv.width = Math.round(w * devicePixelRatio); cv.height = Math.round(cell * rows * devicePixelRatio); cv.style.height = `${cell * rows}px`;
  const x = cv.getContext("2d")!; x.setTransform(devicePixelRatio, 0, 0, devicePixelRatio, 0, 0);
  for (let i = 0; i < g.length; i++) { const cx = i % cols, cy = Math.floor(i / cols); x.fillStyle = COL[g[i]] || COL[0]; x.fillRect(cx * cell, cy * cell, cell, cell); if (g[i] === 1) { x.fillStyle = "#ffffff22"; x.fillRect(cx * cell, cy * cell, cell, cell * 0.25); } if (g[i] === 2) { x.strokeStyle = "#0006"; x.lineWidth = 1.5; x.strokeRect(cx * cell + 3, cy * cell + 3, cell - 6, cell - 6); } }
  if (gridLines) { x.strokeStyle = "#ffffff0d"; x.lineWidth = 1; for (let i = 1; i < cols; i++) { x.beginPath(); x.moveTo(i * cell, 0); x.lineTo(i * cell, rows * cell); x.stroke(); } for (let i = 1; i < rows; i++) { x.beginPath(); x.moveTo(0, i * cell); x.lineTo(cols * cell, i * cell); x.stroke(); } }
  if (spawn) { x.fillStyle = "#5ee7c4"; x.beginPath(); x.arc((spawn.x + 0.5) * cell, (spawn.y + 0.5) * cell, cell * 0.36, 0, Math.PI * 2); x.fill(); }
}
function Preview({ id }: { id: string }) {
  const ref = useRef<HTMLCanvasElement>(null);
  useEffect(() => { fetch(`/api/maps?id=${id}`).then((r) => r.json()).then((d) => { if (d.map && ref.current) draw(ref.current, d.map.cols, d.map.rows, d.map.grid.split("").map(Number), d.map.spawn, false); }); }, [id]);
  return <canvas ref={ref} />;
}

export default function Client({ me }: { me: string }) {
  const [modes, setModes] = useState<Mode[]>([]);
  const [maps, setMaps] = useState<MapMeta[]>([]);
  const [size, setSize] = useState(SIZES[1]);
  const [grid, setGrid] = useState<number[]>(() => blank(26, 17));
  const [spawn, setSpawn] = useState({ x: 2, y: 2 });
  const [tool, setTool] = useState(1);
  const [mirror, setMirror] = useState(true);
  const [name, setName] = useState("");
  const [mode, setMode] = useState("meteor");
  const [editId, setEditId] = useState<string | null>(null);
  const [msg, setMsg] = useState<{ t: string; err?: boolean } | null>(null);
  const cv = useRef<HTMLCanvasElement>(null);
  const painting = useRef(false);
  const load = useCallback(async () => { const d = await (await fetch("/api/maps")).json(); if (d.modes) { setModes(d.modes); setMaps(d.maps); } }, []);
  useEffect(() => { load(); }, [load]);
  useEffect(() => { if (cv.current) draw(cv.current, size.c, size.r, grid, spawn); }, [grid, spawn, size]);
  useEffect(() => { const h = () => cv.current && draw(cv.current, size.c, size.r, grid, spawn); addEventListener("resize", h); return () => removeEventListener("resize", h); }, [grid, spawn, size]);
  const paint = (e: React.PointerEvent) => {
    const r = cv.current!.getBoundingClientRect(); const cx = Math.floor(((e.clientX - r.left) / r.width) * size.c), cy = Math.floor(((e.clientY - r.top) / r.height) * size.r);
    if (cx < 1 || cy < 1 || cx >= size.c - 1 || cy >= size.r - 1) return;
    if (tool === 9) { setSpawn({ x: cx, y: cy }); setGrid((g) => { const n = [...g]; n[cy * size.c + cx] = 0; return n; }); return; }
    setGrid((g) => { const n = [...g]; n[cy * size.c + cx] = tool; if (mirror) n[cy * size.c + (size.c - 1 - cx)] = tool; return n; });
  };
  const resize = (s: typeof SIZES[number]) => { setSize(s); setGrid(blank(s.c, s.r)); setSpawn({ x: 2, y: 2 }); setEditId(null); };
  const randomize = () => { const g = blank(size.c, size.r); for (let y = 2; y < size.r - 2; y++) for (let x = 2; x < Math.ceil(size.c / 2); x++) { const v = Math.random() < 0.13 ? 1 : Math.random() < 0.06 ? 2 : 0; g[y * size.c + x] = v; g[y * size.c + size.c - 1 - x] = v; } g[spawn.y * size.c + spawn.x] = 0; setGrid(g); };
  const save = async () => {
    setMsg(null);
    const r = await (await fetch("/api/maps", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ action: "save", map: { id: editId || undefined, name, mode, cols: size.c, rows: size.r, grid: grid.join(""), spawn } }) })).json();
    if (r.error) setMsg({ t: r.error, err: true }); else { setEditId(r.map.id); setMsg({ t: "Carte publiée. Tout le monde peut maintenant la jouer." }); load(); }
  };
  const edit = async (id: string) => { const d = await (await fetch(`/api/maps?id=${id}`)).json(); if (!d.map) return; const s = SIZES.find((x) => x.c === d.map.cols && x.r === d.map.rows) || { c: d.map.cols, r: d.map.rows, n: "Perso" }; setSize(s); setGrid(d.map.grid.split("").map(Number)); setSpawn(d.map.spawn); setName(d.map.name); setMode(d.map.mode); setEditId(d.map.id); scrollTo({ top: 0, behavior: "smooth" }); };
  const post = async (action: string, id: string) => { await fetch("/api/maps", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ action, id }) }); load(); };
  const gameOf = (m: string) => modes.find((x) => x.mode === m);
  return <>
    <div className="hub-head"><div><span className="hub-kick">Création</span><h1>Éditeur de niveaux</h1><p>Dessine ton arène, choisis le jeu, publie-la : tes amis peuvent la jouer et chaque carte a son propre classement. Crée 3 cartes pour obtenir le badge Créateur.</p></div></div>
    <div className="hub-card ed" style={{ marginBottom: 16 }}>
      <div className="ed-tools">
        <div><b>Outil</b><div className="ed-pal" style={{ marginTop: 6 }}>{TOOLS.map((t) => <button key={t.v} className={tool === t.v ? "on" : ""} onClick={() => setTool(t.v)}><i style={{ background: t.c }} />{t.name}</button>)}</div></div>
        <label className="hub-row hub-muted" style={{ gap: 6 }}><input type="checkbox" checked={mirror} onChange={(e) => setMirror(e.target.checked)} /> Symétrie miroir</label>
        <div><b>Taille</b><div className="hub-row" style={{ marginTop: 6 }}>{SIZES.map((s) => <button key={s.n} className={`hub-btn sm ${size.c === s.c ? "acc" : ""}`} onClick={() => resize(s)}>{s.n}</button>)}</div></div>
        <div className="hub-row"><button className="hub-btn sm" onClick={randomize}>Aléatoire</button><button className="hub-btn sm" onClick={() => { setGrid(blank(size.c, size.r)); }}>Effacer</button></div>
        <input className="hub-input" placeholder="Nom de la carte" maxLength={32} value={name} onChange={(e) => setName(e.target.value)} />
        <select className="hub-select" value={mode} onChange={(e) => setMode(e.target.value)}>{modes.map((m) => <option key={m.mode} value={m.mode}>{m.title}</option>)}</select>
        <button className="hub-btn pri" onClick={save}>{editId ? "Mettre à jour" : "Publier la carte"}</button>
        {editId && <Link className="hub-btn" href={`/games/${gameOf(mode)?.gameId}?map=${editId}`}>Tester</Link>}
        {msg && <p className={`hub-msg ${msg.err ? "err" : ""}`} style={{ margin: 0 }}>{msg.t}</p>}
      </div>
      <canvas ref={cv} className="ed-canvas" onPointerDown={(e) => { painting.current = true; (e.target as HTMLElement).setPointerCapture(e.pointerId); paint(e); }} onPointerMove={(e) => painting.current && tool !== 9 && paint(e)} onPointerUp={() => (painting.current = false)} onPointerCancel={() => (painting.current = false)} />
    </div>
    <h2>Cartes de la communauté</h2>
    {!maps.length ? <div className="hub-card hub-empty">Aucune carte publiée. Sois le premier.</div> :
      <div className="maps">{maps.map((m) => { const g = gameOf(m.mode), liked = m.likes.some((x) => x.toLowerCase() === me.toLowerCase()), mine = m.author.toLowerCase() === me.toLowerCase();
        return <div key={m.id} className="map-card"><Preview id={m.id} /><div><b>{m.name}</b><span className="hub-muted" style={{ fontSize: 13 }}>{g?.title} · par {m.author} · {m.plays} parties</span>
          <div className="hub-row"><Link className="hub-btn sm pri" href={`/games/${g?.gameId}?map=${m.id}`}>Jouer</Link><button className={`hub-btn sm ${liked ? "acc" : ""}`} onClick={() => post("like", m.id)}>♥ {m.likes.length}</button><Link className="hub-btn sm" href={`/classements?scope=map&map=${m.id}`} style={{ display: "none" }}>Classement</Link>{mine && <><button className="hub-btn sm" onClick={() => edit(m.id)}>Modifier</button><button className="hub-btn sm danger" onClick={() => confirm("Supprimer cette carte ?") && post("delete", m.id)}>Suppr.</button></>}</div></div></div>; })}</div>}
  </>;
}
