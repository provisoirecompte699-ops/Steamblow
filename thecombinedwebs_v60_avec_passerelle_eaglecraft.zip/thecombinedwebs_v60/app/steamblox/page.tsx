import Link from "next/link";
import {catalog} from "@/lib/store";
import {currentUser} from "@/lib/auth";
import {redirect} from "next/navigation";
import GameGallery from "../GameGallery";
import LoginRewardPopup from "../LoginRewardPopup";
import Friends from "../Friends";
import SteambloxDashboard from "../SteambloxDashboard";
import DashboardExtras from "../DashboardExtras";
import Announcements from "../Announcements";
export const dynamic = "force-dynamic";
export default async function TheCombinedWebs({searchParams}:{searchParams?:Promise<{loginReward?:string;streak?:string;streakMessage?:string}>}){const u=await currentUser();if(!u){redirect("/special");return null;}const q=searchParams?await searchParams:{};const reward=Number(q.loginReward||0);const streak=Number(q.streak||0);const streakMessage=q.streakMessage||"";const privileged=["creator","vice_creator"].includes(u.role);const effectiveOwned=privileged?catalog.map(g=>g.id):(u.owned||[]);return <main className="sb-app ui-page"><LoginRewardPopup reward={reward} streak={streak} message={streakMessage}/><Announcements/><SteambloxDashboard games={catalog} username={u.username} owned={effectiveOwned} playTimeMinutes={u.playTimeMinutes||0} achievements={(u.achievements||[]).length} friendList={u.friends||[]} library={<GameGallery games={catalog} owned={effectiveOwned} privileged={privileged}/>} friends={<section className="friends"><Friends initialFriends={u.friends||[]}/></section>}/><footer className="ui-footer"><span>TheCombinedWebs · Crédits : Walid</span><Link href="/credits">Crédits</Link><Link href="/">Algèbre Facile</Link></footer></main>}
