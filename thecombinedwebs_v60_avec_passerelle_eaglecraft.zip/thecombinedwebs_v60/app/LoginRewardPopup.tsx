"use client";
import {useEffect,useState} from "react";

export default function LoginRewardPopup({reward,streak,message}:{reward:number;streak:number;message?:string}){
 const hasMessage=message==="wash";
 const [open,setOpen]=useState(Boolean(reward||hasMessage));
 useEffect(()=>{if(!reward)return;const t=setTimeout(()=>setOpen(false),6500);return()=>clearTimeout(t)},[reward]);
 if(!open)return null;
 return <div className="sb-reward-overlay" role="dialog" aria-live="polite" aria-label="Récompense de connexion">
  <div className="sb-reward-card">
   <div className="sb-reward-emoji">{hasMessage ? "🧼" : "🪙"}</div>
   <div className="eyebrow">{streak} JOURS D'AFFILÉE</div>
   <h2>{hasMessage ? "Va te laver tdc va" : `Tu fais pitié, tient, ${reward} Bobux`}</h2>
   {hasMessage && <p>Plus de 8 jours de connexion consécutifs. Même TheCombinedWebs commence à s'inquiéter.</p>}
   {reward > 0 && <><p>Tu t'es connecté 4 jours de suite. TheCombinedWebs a donc décidé de te soudoyer.</p>
   <div className="sb-reward-coins">+{reward.toLocaleString("fr-FR")} Bobux</div></>}
   <button className="button" onClick={()=>setOpen(false)}>{reward > 0 ? "Récupérer mes Bobux" : "Fermer"}</button>
  </div>
 </div>
}
