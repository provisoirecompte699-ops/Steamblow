"use client";
import { useEffect, useRef, useState } from "react";
import { usePathname, useRouter } from "next/navigation";
import { hashPin, loadParental, type Parental } from "./tcbShared";

type Res = { games: { id: string; title: string }[]; users: { username: string }[]; pages: { href: string; label: string }[] };
const QUICK = [{ href: "/steamblox", label: "Accueil" }, { href: "/discord", label: "Discord" }, { href: "/cinestream", label: "CinéStream" }, { href: "/tournois", label: "Tournois" }, { href: "/passe", label: "Passe & boutique" }, { href: "/tcb", label: "TCB Plus" }, { href: "/games/eaglecraft", label: "EagleCraft" }];
const GO: Record<string, string> = { j: "/steamblox", d: "/discord", c: "/cinestream", t: "/tournois", p: "/passe", a: "/account" };

/** TheCombinedWebs : recherche globale, raccourcis, contrôle parental, statut « en jeu », parrainage et effets de troll. */
export default function TcbGlobal() {
  const path = usePathname() || ""; const router = useRouter();
  const inGame = path.startsWith("/games/") || path.startsWith("/multiplayer");
  const gameId = path.startsWith("/games/") ? path.split("/")[2] : null;
  const [open, setOpen] = useState<"" | "search" | "help">("");
  const [q, setQ] = useState(""); const [res, setRes] = useState<Res | null>(null);
  const [par, setPar] = useState<Parental | null>(null);
  const [usage, setUsage] = useState(0); const [bonus, setBonus] = useState(0); const [unlocked, setUnlocked] = useState<string[]>([]);
  const [pin, setPin] = useState(""); const [pinErr, setPinErr] = useState(false);
  const [fake, setFake] = useState<string | null>(null); const [toast, setToast] = useState("");
  const gKey = useRef(0); const input = useRef<HTMLInputElement>(null);

  // Économie de données + contrôle parental (réglages locaux)
  useEffect(() => {
    const sync = () => { document.documentElement.toggleAttribute("data-tcb-saver", localStorage.getItem("tcb:datasaver") === "1"); setPar(loadParental()); };
    sync(); window.addEventListener("tcb-settings", sync); window.addEventListener("storage", sync);
    try { setUnlocked(JSON.parse(sessionStorage.getItem("tcb:unlocked") || "[]")); } catch { /* ignore */ }
    return () => { window.removeEventListener("tcb-settings", sync); window.removeEventListener("storage", sync); };
  }, []);

  // Temps passé aujourd'hui (uniquement si un contrôle parental existe)
  useEffect(() => {
    if (!par) return;
    const day = new Date().toISOString().slice(0, 10);
    const read = () => { try { const u = JSON.parse(localStorage.getItem("tcb:usage") || "{}"); return u.date === day ? u : { date: day, sec: 0, bonus: 0 }; } catch { return { date: day, sec: 0, bonus: 0 }; } };
    const u0 = read(); setUsage(u0.sec); setBonus(u0.bonus);
    const t = setInterval(() => { if (document.visibilityState !== "visible") return; const u = read(); u.sec += 5; localStorage.setItem("tcb:usage", JSON.stringify(u)); setUsage(u.sec); setBonus(u.bonus || 0); }, 5000);
    return () => clearInterval(t);
  }, [par]);


  // Trolls reçus (effets visuels inoffensifs, désactivables dans TCB Plus)
  useEffect(() => {
    if (inGame) return; let stop = false;
    const apply = (t: { from: string; effect: string }) => {
      setToast(`🤡 ${t.from} te troll !`); setTimeout(() => setToast(""), 4000);
      const el = document.documentElement;
      if (t.effect === "confetti") { for (let i = 0; i < 36; i++) { const s = document.createElement("span"); s.className = "tcb-confetti"; s.textContent = ["🎉", "🎊", "✨", "🪙"][i % 4]; s.style.left = Math.random() * 100 + "vw"; s.style.animationDelay = Math.random() * 1.2 + "s"; document.body.appendChild(s); setTimeout(() => s.remove(), 4500); } }
      else if (t.effect === "fakecrash") { setFake(t.from); setTimeout(() => setFake(null), 5000); }
      else { const cls = `tcb-fx-${t.effect}`; el.classList.add(cls); setTimeout(() => el.classList.remove(cls), 7000); }
    };
    const poll = async () => { if (stop || document.visibilityState === "hidden") return; try { const r = await fetch("/api/tcb/fun", { cache: "no-store" }); if (r.status === 401) { stop = true; return; } if (r.ok) (await r.json()).trolls?.forEach(apply); } catch { /* ignore */ } };
    const t = setInterval(poll, 8000); return () => clearInterval(t);
  }, [inGame]);

  // Statut « en jeu » pour les amis
  useEffect(() => {
    const send = (g: string | null) => fetch("/api/tcb", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ action: "presence", gameId: g }), keepalive: true }).catch(() => {});
    if (!gameId) return; send(gameId); const t = setInterval(() => send(gameId), 60000);
    return () => { clearInterval(t); send(null); };
  }, [gameId]);

  // Parrainage par lien (?ref=Pseudo) : mémorisé puis validé une fois connecté
  useEffect(() => {
    const ref = new URLSearchParams(location.search).get("ref"); if (ref) localStorage.setItem("tcb:ref", ref.slice(0, 24));
    const stored = localStorage.getItem("tcb:ref"); if (!stored || ["/login", "/register", "/special"].some((p) => path.startsWith(p))) return;
    fetch("/api/tcb", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ action: "redeem", code: stored }) }).then((r) => { if (r.status !== 401) localStorage.removeItem("tcb:ref"); }).catch(() => {});
  }, [path]);

  // Raccourcis clavier (désactivés dans les jeux et pendant la saisie)
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      const el = e.target as HTMLElement; const typing = /INPUT|TEXTAREA|SELECT/.test(el.tagName) || el.isContentEditable;
      if (e.key === "Escape") { setOpen(""); return; }
      if (inGame) return;
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === "k") { e.preventDefault(); setOpen("search"); return; }
      if (typing || e.ctrlKey || e.metaKey || e.altKey) return;
      if (e.key === "/") { e.preventDefault(); setOpen("search"); }
      else if (e.key === "?") setOpen("help");
      else if (e.key === "g") gKey.current = Date.now();
      else if (GO[e.key] && Date.now() - gKey.current < 1200) { gKey.current = 0; router.push(GO[e.key]); }
    };
    window.addEventListener("keydown", onKey); return () => window.removeEventListener("keydown", onKey);
  }, [inGame, router]);

  useEffect(() => { if (open === "search") { setQ(""); setRes(null); setTimeout(() => input.current?.focus(), 30); } }, [open]);
  useEffect(() => {
    if (open !== "search" || !q.trim()) { setRes(null); return; }
    const t = setTimeout(async () => { try { const r = await fetch(`/api/tcb?section=search&q=${encodeURIComponent(q)}`); if (r.ok) setRes(await r.json()); } catch { /* ignore */ } }, 200);
    return () => clearTimeout(t);
  }, [q, open]);

  const go = (href: string) => { setOpen(""); router.push(href); };
  const unlock = async (kind: "time" | "game") => {
    if (!par) return; if ((await hashPin(pin)) !== par.pinHash) { setPinErr(true); return; }
    setPinErr(false); setPin("");
    if (kind === "time") { const day = new Date().toISOString().slice(0, 10); const u = JSON.parse(localStorage.getItem("tcb:usage") || "{}"); localStorage.setItem("tcb:usage", JSON.stringify({ date: day, sec: u.sec || 0, bonus: (u.bonus || 0) + 15 })); setBonus((b) => b + 15); }
    else if (gameId) { const n = [...unlocked, gameId]; setUnlocked(n); sessionStorage.setItem("tcb:unlocked", JSON.stringify(n)); }
  };

  const timeUp = !!par && !path.startsWith("/login") && usage >= (par.limitMin + bonus) * 60;
  const blocked = !!par && !!gameId && par.hidden.includes(gameId) && !unlocked.includes(gameId);
  const items: { href: string; label: string; tag: string }[] = res ? [...res.games.map((g) => ({ href: `/games/${g.id}`, label: g.title, tag: "Jeu" })), ...res.users.map((u) => ({ href: `/u/${encodeURIComponent(u.username)}`, label: u.username, tag: "Joueur" })), ...res.pages.map((p) => ({ ...p, tag: "Page" }))] : QUICK.map((p) => ({ ...p, tag: "Page" }));

  return <>
    {toast && <div className="tcb-toast" role="status">{toast}</div>}
    {fake && <div className="tcb-fake" onClick={() => setFake(null)}><div><b>💥</b>Erreur critique… ou pas ! 🤡<br />C’est un troll de {fake}. Cet écran se ferme tout seul.</div></div>}
    {open === "search" && <div className="tcb-overlay" onClick={() => setOpen("")}><div className="tcb-box" onClick={(e) => e.stopPropagation()} role="dialog" aria-label="Recherche">
      <input ref={input} className="tcb-input" placeholder="Chercher un jeu, un joueur, une page…" value={q} onChange={(e) => setQ(e.target.value)} onKeyDown={(e) => { if (e.key === "Enter" && items[0]) go(items[0].href); }} />
      <ul className="tcb-list">{items.length === 0 ? <li className="tcb-empty">Aucun résultat</li> : items.map((i) => <li key={i.tag + i.href}><button onClick={() => go(i.href)}><span>{i.label}</span><small>{i.tag}</small></button></li>)}</ul></div></div>}
    {open === "help" && <div className="tcb-overlay" onClick={() => setOpen("")}><div className="tcb-box" onClick={(e) => e.stopPropagation()} role="dialog" aria-label="Aide">
      <h3>Raccourcis clavier</h3><p><kbd>/</kbd> ou <kbd>Ctrl</kbd>+<kbd>K</kbd> recherche · <kbd>?</kbd> cette aide · <kbd>Échap</kbd> fermer</p><p><kbd>g</kbd> puis <kbd>j</kbd> jeux · <kbd>d</kbd> Discord · <kbd>c</kbd> CinéStream · <kbd>t</kbd> tournois · <kbd>p</kbd> passe · <kbd>a</kbd> compte</p><p style={{ opacity: .7 }}>Désactivés pendant les parties.</p></div></div>}
    {(timeUp || blocked) && <div className="tcb-lock" role="alertdialog"><div className="tcb-box">
      <h3>{timeUp ? "⏰ Temps de jeu atteint" : "🚫 Jeu masqué"}</h3><p>{timeUp ? "La limite quotidienne est atteinte." : "Ce jeu est masqué par le contrôle parental."} Entre le code PIN pour {timeUp ? "ajouter 15 minutes" : "le débloquer pour cette session"}.</p>
      <input className="tcb-input" inputMode="numeric" maxLength={4} type="password" placeholder="PIN" value={pin} onChange={(e) => { setPin(e.target.value.replace(/\D/g, "")); setPinErr(false); }} onKeyDown={(e) => { if (e.key === "Enter") unlock(timeUp ? "time" : "game"); }} />
      {pinErr && <p style={{ color: "#ffb3ba" }}>PIN incorrect.</p>}
      <div className="tcb-actions"><button className="tcb-btn" onClick={() => unlock(timeUp ? "time" : "game")}>Débloquer</button>{!timeUp && <button className="tcb-btn ghost" onClick={() => router.push("/steamblox")}>Retour</button>}</div></div></div>}
  </>;
}
