import {clearSession} from "@/lib/auth";
import {redirect} from "next/navigation";

export default async function Banned({searchParams}:{searchParams?:Promise<{reason?:string}>}){
  const q=searchParams?await searchParams:{};
  async function logout(){"use server";await clearSession();redirect("/special");}
  return <main className="wrap"><section className="card" style={{maxWidth:620,margin:"90px auto"}}><div className="eyebrow">ACCÈS BLOQUÉ</div><h1>Compte banni</h1><p className="status error">Ton accès à TheCombinedWebs a été suspendu.</p>{q.reason&&<p className="muted"><b>Motif :</b> {q.reason}</p>}<form action={logout}><button className="button">Se déconnecter</button></form></section></main>;
}
