'use client';
import {useEffect,useMemo,useRef,useState} from "react";
import {connectMultiplayer} from "@/lib/multiplayer";
import VoiceChat from "@/app/VoiceChat";

export default function Multiplayer(){
 const [room,setRoom]=useState("");const [name,setName]=useState("Player");const [joined,setJoined]=useState(false);const [players,setPlayers]=useState<any[]>([]);const [hostId,setHostId]=useState<string|null>(null);const [ready,setReady]=useState(false);const [started,setStarted]=useState(false);const [socket,setSocket]=useState<any>(null);const [chat,setChat]=useState<{name:string,text:string}[]>([]);const [text,setText]=useState("");const [latency,setLatency]=useState<number|null>(null);const [status,setStatus]=useState("Hors ligne");
 const mpRef=useRef<ReturnType<typeof connectMultiplayer>|null>(null);
 useEffect(()=>{const q=new URLSearchParams(location.search).get("room");if(q)setRoom(q.toUpperCase())},[]);
 const invite=useMemo(()=>room?`${location.origin}/multiplayer?room=${encodeURIComponent(room)}`:"",[room]);
 useEffect(()=>{
  if(!joined||!room)return;
  const mp=connectMultiplayer(room,name,"lobby"); mpRef.current=mp;
  if(!mp){setStatus("Serveur non configuré");return}
  setStatus("Connexion…");const socket=mp.socket;
  const ping=()=>{const t=performance.now();socket.timeout(2500).emit("latency:ping",{},()=>setLatency(Math.round(performance.now()-t)))};
  const timer=setInterval(ping,3000);
  const onConnect=()=>{setStatus("En ligne");setSocket(socket)}; const onDisconnect=()=>{setStatus("Reconnexion…");setSocket(null)};
  socket.on("connect",onConnect);socket.on("disconnect",onDisconnect);socket.on("connect_error",()=>setStatus("Connexion impossible"));
  socket.on("room:state",m=>{setPlayers(m.players||[]);setHostId(m.hostId||null);setStarted(!!m.started)});
  socket.on("room:joined",m=>setHostId(m.hostId||null));
  socket.on("game:start",()=>setStarted(true));
  socket.on("room:error",m=>setStatus(m?.message||"Erreur du salon"));socket.on("player:joined",m=>{setPlayers(p=>{const n=p.some(x=>x.id===m.player.id)?p:[...p,m.player];checkEncounter(n);return n});});
  const checkEncounter=(list:any[])=>{const names=new Set(list.map(x=>String(x.name||x.username||"").toLowerCase()));const hits=["younes","moustafa"].filter(n=>names.has(n));if(!hits.length)return;fetch("/api/achievements",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({ids:hits.map(n=>`meet-${n}`)})}).catch(()=>{})};socket.on("player:left",m=>setPlayers(p=>p.filter(x=>x.id!==m.id)));socket.on("player:state",m=>setPlayers(p=>p.map(x=>x.id===m.player.id?m.player:x)));socket.on("room:chat",m=>setChat(c=>[...c,m]));
  return()=>{clearInterval(timer);socket.removeAllListeners();mp.close();mpRef.current=null;setSocket(null)};
 },[joined,room,name]);
 function create(){const code=Math.random().toString(36).slice(2,8).toUpperCase();setRoom(code);setJoined(true)}
 function join(){if(name.trim()&&room.trim())setJoined(true)}
 function sendChat(){const clean=text.trim().slice(0,180);if(!clean)return;mpRef.current?.socket.emit("room:chat",{text:clean});setText("")}
 function toggleReady(){const next=!ready;setReady(next);mpRef.current?.socket.emit("room:ready",next)}
 function startGame(){mpRef.current?.socket.emit("room:start")}
 return <main className="page"><nav className="nav"><a className="brand" href="/">TheCombinedWebs</a><span className="status">{status}</span></nav><section className="hero"><div className="eyebrow">MULTIJOUEUR À DISTANCE</div><h1>Un salon privé</h1><p className="muted">Partage le code ou le lien d'invitation. Pas besoin de télépathie réseau, heureusement.</p></section>{!joined?<section className="card" style={{maxWidth:560}}><label>Pseudo<input className="input" maxLength={20} value={name} onChange={e=>setName(e.target.value)} placeholder="Pseudo"/></label><label>Code du salon<input className="input" maxLength={32} value={room} onChange={e=>setRoom(e.target.value.toUpperCase().replace(/[^A-Z0-9_-]/g,""))} placeholder="Ex. 4F7K2A"/></label><div className="actions"><button className="button" onClick={create} disabled={!name.trim()}>Créer un salon</button><button className="button secondary" onClick={join} disabled={!name.trim()||!room.trim()}>Rejoindre</button></div></section>:<section className="split"><div className="card"><div className="eyebrow">SALON {room}</div><h2>{players.length}/16 joueurs</h2><p className="muted">{status}{latency!==null&&` · ${latency} ms`}</p><div className="actions"><input className="input" readOnly value={invite}/><button className="button" onClick={()=>navigator.clipboard?.writeText(invite)}>Copier</button></div><div className="players">{players.map(p=><span className="player-pill" key={p.id}>{p.name}</span>)}</div></div><div className="card"><div className="actions"><button className="button" onClick={toggleReady}>{ready?"✓ Prêt":"Se mettre prêt"}</button>{hostId===mpRef.current?.socket.id&&<button className="button" onClick={startGame} disabled={started||players.some(p=>p.id!==hostId&&!p.ready)}>Démarrer</button>}</div><p className="muted">{started?"La partie a commencé.":"Chaque joueur doit être prêt avant le démarrage."}</p></div><VoiceChat socket={socket} username={name}/><div className="card"><h2>Chat</h2><div className="chat chatlog">{chat.length?chat.slice(-30).map((m,i)=><div key={i}><b>{m.name}</b> {m.text}</div>):<span className="muted">Aucun message</span>}</div><input className="input" maxLength={180} value={text} onChange={e=>setText(e.target.value)} onKeyDown={e=>e.key==='Enter'&&sendChat()} placeholder="Message"/><button className="button" onClick={sendChat}>Envoyer</button></div></section>}</main>
}
