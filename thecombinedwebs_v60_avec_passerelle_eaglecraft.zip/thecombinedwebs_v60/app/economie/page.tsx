import FeaturePage from "../FeaturePages";
export const metadata={title:"Boutique & banque · TheCombinedWebs"};
export default function Page(){return <FeaturePage mode="economie"/>;}
