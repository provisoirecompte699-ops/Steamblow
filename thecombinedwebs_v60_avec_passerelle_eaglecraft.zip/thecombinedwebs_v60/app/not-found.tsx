import Link from "next/link";
export default function NotFound(){return <main className="error-page"><div className="card error-card"><div className="eyebrow">404 · THECOMBINEDWEBS</div><h1>Cette zone n’existe pas.</h1><p className="muted">Le lien est peut-être ancien ou le jeu n’est pas encore disponible.</p><Link className="button" href="/steamblox">Retour à TheCombinedWebs</Link></div></main>}
