import {currentUser} from "@/lib/auth";
import {catalog,hasGameAccess} from "@/lib/store";
import {redirect} from "next/navigation";
import QuestGameTracker from "@/app/QuestGameTracker";
import TurboKartClient from "./TurboKartClient";
export default async function TurboKartPage(){const u=await currentUser();if(!u){redirect("/login");return null;}const game=catalog.find(g=>g.id==="turbo-kart")!;if(!hasGameAccess(u,game.id))redirect("/?purchase=turbo-kart");return <main className="wrap"><QuestGameTracker gameId={game.id}/><h1>Turbo Kart 3D</h1><p className="muted">Course 3D en perspective, physique fluide et multijoueur à distance. Jeu premium.</p><TurboKartClient username={u.username}/></main>}
