import { currentUser } from "@/lib/auth";
import { catalog, hasGameAccess } from "@/lib/store";
import { redirect } from "next/navigation";
import QuestGameTracker from "@/app/QuestGameTracker";
import NeonDriftClient from "./NeonDriftClient";

export default async function NeonDriftPage() {
  const user = await currentUser();
  if (!user) { redirect("/login"); return null; }
  const game = catalog.find(g => g.id === "neon-drift-3d")!;
  if (!hasGameAccess(user, game.id)) redirect("/?purchase=neon-drift-3d");
  return <main className="wrap"><QuestGameTracker gameId={game.id}/><NeonDriftClient username={user.username}/></main>;
}
