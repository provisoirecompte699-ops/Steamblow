"use client";
import { useCallback, useEffect, useRef, useState } from "react";
import ProxyFrame from "@/app/proxy/ProxyFrame";

const SRC = "https://gta.deloskiyt.pl";

const USE_PROXY = !!process.env.NEXT_PUBLIC_PROXY_URL;

export default function GtaEmbed() {
  if (USE_PROXY) return <ProxyFrame site="gta" label="GTA Web" fallbackUrl={SRC} />;
  return <DirectEmbed />;
}

function DirectEmbed() {
  const ref = useRef<HTMLIFrameElement>(null);
  const [mode, setMode] = useState<"embed" | "failed">("embed");
  const [loading, setLoading] = useState(true);

  // Ne PAS sandboxer : le moteur WASM/WebGL a besoin de workers, SharedArrayBuffer, etc.
  // AdShield reste actif sur la page parente (pop-ups hors iframe).

  useEffect(() => {
    const t = setTimeout(() => setLoading(false), 12000);
    return () => clearTimeout(t);
  }, []);

  const openExternal = useCallback(() => {
    // Ouverture volontaire (geste utilisateur) — AdShield laisse passer
    const w = window.open(SRC, "_blank", "noopener,noreferrer");
    if (!w) {
      // Popup bloqué → navigation directe
      window.location.href = SRC;
    }
  }, []);

  const onLoad = () => {
    setLoading(false);
  };

  const onError = () => {
    setLoading(false);
    setMode("failed");
  };

  return (
    <div style={{ position: "relative", width: "100%", height: "calc(100dvh - 100px)", background: "#000" }}>
      {mode === "embed" ? (
        <>
          <iframe
            ref={ref}
            title="GTA Web"
            src={SRC}
            // pas de sandbox — requis pour le moteur du jeu
            style={{ width: "100%", height: "100%", border: 0, display: "block", background: "#000" }}
            allow="autoplay; fullscreen; gamepad; keyboard-map; cross-origin-isolated"
            allowFullScreen
            referrerPolicy="no-referrer-when-downgrade"
            onLoad={onLoad}
            onError={onError}
          />
          {loading && (
            <div
              style={{
                position: "absolute",
                inset: 0,
                display: "grid",
                placeItems: "center",
                background: "rgba(0,0,0,.7)",
                color: "#ccc",
                fontFamily: "monospace",
                fontSize: 13,
                pointerEvents: "none",
              }}
            >
              Chargement de GTA Web… (peut prendre 1–2 min)
            </div>
          )}
        </>
      ) : (
        <div
          style={{
            height: "100%",
            display: "grid",
            placeItems: "center",
            padding: 24,
            textAlign: "center",
            color: "#eef0f4",
          }}
        >
          <div style={{ maxWidth: 420 }}>
            <h2 style={{ margin: "0 0 10px", fontSize: 20 }}>Impossible d’afficher le jeu ici</h2>
            <p style={{ color: "#8b909c", lineHeight: 1.5, margin: "0 0 16px" }}>
              Le navigateur ou le site source bloque l’intégration en iframe. Lance le jeu dans un nouvel onglet
              (recommandé pour les perfs et la compatibilité).
            </p>
            <button
              type="button"
              onClick={openExternal}
              style={{
                padding: "12px 20px",
                borderRadius: 10,
                border: "none",
                background: "#8b7cff",
                color: "#fff",
                fontWeight: 700,
                fontSize: 14,
                cursor: "pointer",
              }}
            >
              Lancer GTA Web ↗
            </button>
            <p style={{ marginTop: 14 }}>
              <button
                type="button"
                onClick={() => { setMode("embed"); setLoading(true); }}
                style={{
                  background: "transparent",
                  border: "1px solid #2a2e38",
                  color: "#aaa",
                  borderRadius: 8,
                  padding: "8px 12px",
                  cursor: "pointer",
                  fontSize: 12,
                }}
              >
                Réessayer l’embed
              </button>
            </p>
          </div>
        </div>
      )}

      <div
        style={{
          position: "absolute",
          bottom: 12,
          right: 12,
          display: "flex",
          gap: 8,
          zIndex: 5,
          flexWrap: "wrap",
          justifyContent: "flex-end",
        }}
      >
        <button
          type="button"
          onClick={openExternal}
          style={{
            padding: "8px 12px",
            borderRadius: 9,
            background: "#8b7cff",
            border: "none",
            color: "#fff",
            fontSize: 12,
            fontWeight: 700,
            cursor: "pointer",
          }}
        >
          Lancer hors iframe (stable) ↗
        </button>
        {mode === "embed" && (
          <button
            type="button"
            onClick={() => setMode("failed")}
            style={{
              padding: "8px 12px",
              borderRadius: 9,
              background: "rgba(0,0,0,.75)",
              border: "1px solid #2a2e38",
              color: "#fff",
              fontSize: 12,
              fontWeight: 650,
              cursor: "pointer",
            }}
          >
            Problème ? Autre mode
          </button>
        )}
      </div>
    </div>
  );
}
