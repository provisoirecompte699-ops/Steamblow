import Link from "next/link";
import { redirect } from "next/navigation";
import { currentUser } from "@/lib/auth";
import { catalog, hasGameAccess } from "@/lib/store";
import QuestGameTracker from "@/app/QuestGameTracker";
import GtaEmbed from "./GtaEmbed";

export const dynamic = "force-dynamic";
export const metadata = { title: "GTA Web · TheCombinedWebs" };

export default async function GtaWebPage() {
  const user = await currentUser();
  if (!user) {
    redirect("/login?next=/games/gta-web");
    return null;
  }
  const game = catalog.find((g) => g.id === "gta-web");
  if (!game) redirect("/");
  if (!hasGameAccess(user, game.id)) redirect(`/steamblox?purchase=${game.id}`);

  return (
    <main style={{ minHeight: "100dvh", background: "#0a0b0f", color: "#eef0f4" }}>
      <QuestGameTracker gameId="gta-web" />
      <div
        style={{
          display: "flex",
          alignItems: "center",
          justifyContent: "space-between",
          gap: 12,
          flexWrap: "wrap",
          padding: "10px 14px",
          borderBottom: "1px solid #1e212a",
          background: "rgba(10,11,15,.92)",
        }}
      >
        <div>
          <div style={{ fontSize: 11, fontWeight: 800, letterSpacing: "0.12em", textTransform: "uppercase", color: "#8b7cff" }}>
            Jeu gratuit
          </div>
          <h1 style={{ margin: 0, fontSize: 18, fontWeight: 800 }}>GTA Web</h1>
        </div>
        <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
          <Link
            href="/steamblox#bibliotheque"
            style={{
              padding: "8px 12px",
              borderRadius: 9,
              background: "#181b22",
              border: "1px solid #2a2e38",
              color: "#fff",
              fontSize: 13,
              fontWeight: 650,
            }}
          >
            ← Catalogue
          </Link>
          <a
            href="https://gta.deloskiyt.pl"
            target="_blank"
            rel="noopener noreferrer"
            style={{
              padding: "8px 12px",
              borderRadius: 9,
              background: "#8b7cff",
              color: "#fff",
              fontSize: 13,
              fontWeight: 650,
            }}
          >
            Ouvrir en plein écran ↗
          </a>
        </div>
      </div>
      <GtaEmbed />
      <p style={{ margin: 0, padding: "8px 14px", fontSize: 12, color: "#8b909c" }}>
        Hébergé sur gta.deloskiyt.pl (non affilié à Rockstar). Si une erreur apparaît dans l’iframe, utilise « Lancer hors iframe » — mode le plus stable.
      </p>
    </main>
  );
}
