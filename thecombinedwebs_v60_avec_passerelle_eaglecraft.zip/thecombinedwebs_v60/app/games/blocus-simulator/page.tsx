import { currentUser } from "@/lib/auth";
import { catalog, hasGameAccess } from "@/lib/store";
import { redirect } from "next/navigation";
import QuestGameTracker from "@/app/QuestGameTracker";
import BlocusClient from "./BlocusClient";

export const metadata = { title: "Blocus Simulator · TheCombinedWebs" };

export default async function Page() {
  const u = await currentUser();
  if (!u) {
    redirect("/login?next=/games/blocus-simulator");
    return null;
  }
  const g = catalog.find((x) => x.id === "blocus-simulator");
  if (!g) redirect("/");
  if (!hasGameAccess(u, g.id)) redirect(`/steamblox?purchase=${g.id}`);
  return (
    <main className="hub" style={{ minHeight: "100vh", padding: "24px 16px 48px" }}>
      <QuestGameTracker gameId={g.id} />
      <div style={{ maxWidth: 560, margin: "0 auto" }}>
        <p style={{ margin: "0 0 6px", fontSize: 12, fontWeight: 800, letterSpacing: "0.12em", textTransform: "uppercase", color: "#5ee7c4" }}>
          Jeu gratuit
        </p>
        <h1 style={{ margin: "0 0 8px", fontSize: 28, letterSpacing: "-0.03em" }}>🚨 Blocus Simulator</h1>
        <p style={{ margin: "0 0 18px", color: "#a3a9b6", lineHeight: 1.5 }}>
          Fuite en pixel art. Esquive les flashballs, les fumigènes et les CRS. Dash avec Espace / Shift. Les combos montent en frôlant les projectiles.
        </p>
        <BlocusClient username={u.username} />
      </div>
    </main>
  );
}
