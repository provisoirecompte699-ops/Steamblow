"use client";
import { useState } from "react";
import BlocusSimulator from "@/app/tcb/BlocusSimulator";
import Link from "next/link";

export default function BlocusClient({ username }: { username: string }) {
  const [key, setKey] = useState(0);
  const [last, setLast] = useState<{ won: boolean; score: number } | null>(null);
  const [debtMsg, setDebtMsg] = useState<string | null>(null);

  const onFinish = async (won: boolean, score: number) => {
    setLast({ won, score });
    // Si le joueur a une dette bancaire, tenter de l'appliquer via l'API banque
    try {
      const r = await fetch("/api/tcb/bank", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ action: "blocus", won, score }),
      });
      const j = await r.json().catch(() => ({}));
      if (!j.error) {
        if (won && j.forgiven) setDebtMsg(`Dette bancaire réduite de ${j.forgiven} Bobux.`);
        else if (!won && j.penalty) setDebtMsg(`Dette bancaire +${j.penalty} Bobux.`);
        else setDebtMsg(null);
      } else {
        // Pas de dette ou cooldown — jeu libre, pas d'erreur affichée
        setDebtMsg(null);
      }
    } catch {
      setDebtMsg(null);
    }
    // score classement (best effort)
    try {
      await fetch("/api/leaderboard", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ gameId: "blocus-simulator", score }),
      }).catch(() => null);
    } catch { /* ignore */ }
  };

  return (
    <div>
      <BlocusSimulator
        key={key}
        onFinish={onFinish}
        onClose={() => setKey((k) => k + 1)}
      />
      {last && (
        <p className="hub-sub" style={{ marginTop: 12 }}>
          Dernière partie : {last.won ? "fuite réussie" : "attrapé"} — score {last.score}/100
          {debtMsg ? ` · ${debtMsg}` : ""}
        </p>
      )}
      <p style={{ marginTop: 16 }}>
        <Link href="/steamblox" style={{ color: "#8b7cff" }}>← Retour aux jeux</Link>
        {" · "}
        <Link href="/tcb" style={{ color: "#8b7cff" }}>TCB Banque</Link>
      </p>
      <p className="hub-sub" style={{ marginTop: 8, fontSize: 12 }}>
        Connecté en tant que {username}. Si tu as une dette à la TCB Banque, gagner ici peut la réduire.
      </p>
    </div>
  );
}
