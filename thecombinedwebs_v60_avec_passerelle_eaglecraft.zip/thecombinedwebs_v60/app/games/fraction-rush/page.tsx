import { currentUser } from "@/lib/auth";
import { redirect } from "next/navigation";
import FractionRushClient from "./FractionRushClient";

export default async function FractionRushPage() {
  const user = await currentUser();
  if (!user) { redirect("/login?next=/games/fraction-rush"); return null; }
  return <FractionRushClient username={user.username} />;
}
