"use client";
import { useEffect, useRef, useState } from "react";
import Link from "next/link";
import useCloudRecord from "@/app/useCloudRecord";
import {gameMemory as localStorage} from "@/app/game-memory";
import MultiplayerPanel from "@/app/games/_components/MultiplayerPanel";

type GameState = "menu" | "playing" | "over";
type Frac = { n: number; d: number };

function gcd(a: number, b: number): number { a = Math.abs(a); b = Math.abs(b); while (b) { [a, b] = [b, a % b]; } return a || 1; }
function randFrac(): Frac { const d = 2 + Math.floor(Math.random() * 9); const n = 1 + Math.floor(Math.random() * (d * 2)); const g = gcd(n, d); return { n: n / g, d: d / g }; }
function fracVal(f: Frac): number { return f.n / f.d; }
function fracStr(f: Frac): string { return f.d === 1 ? `${f.n}` : `${f.n}/${f.d}`; }

export default function FractionRushClient({ username }: { username: string }) {
  const [phase, setPhase] = useState<GameState>("menu");
  const [score, setScore] = useState(0);
  const [timeLeft, setTimeLeft] = useState(30);
  const [frac1, setFrac1] = useState<Frac>({ n: 1, d: 2 });
  const [frac2, setFrac2] = useState<Frac>({ n: 3, d: 4 });
  const [best, setBest] = useState(0);
  useCloudRecord("fraction-rush",best,setBest);
  const [streak, setStreak] = useState(0);
  const [feedback, setFeedback] = useState("");
  const [mpScores, setMpScores] = useState<{ id: string; name: string; score: number }[]>([]);
  const remotesRef = useRef<Map<string, { name: string; score: number }>>(new Map());
  const sendStateRef = useRef<((state: Record<string, number>) => void) | null>(null);
  const [hostOpts, setHostOpts] = useState<Record<string, unknown>>({});

  useEffect(() => { setBest(Number(localStorage.getItem("steamblox:fraction:best") || 0)); }, []);

  const generate = () => { setFrac1(randFrac()); setFrac2(randFrac()); setFeedback(""); };

  const start = () => { setPhase("playing"); setScore(0); setStreak(0); setTimeLeft(hostOpts.chaos ? 15 : 30); generate(); };

  useEffect(() => {
    if (phase !== "playing") return;
    const t = setInterval(() => {
      setTimeLeft(s => { if (s <= 1) { setPhase("over"); const prev = Number(localStorage.getItem("steamblox:fraction:best") || 0); if (score > prev) { localStorage.setItem("steamblox:fraction:best", String(score)); setBest(score); } return 0; } return s - 1; });
    }, 1000);
    return () => clearInterval(t);
  }, [phase, score]);

  const answer = (which: "left" | "right" | "equal") => {
    const v1 = fracVal(frac1), v2 = fracVal(frac2);
    const correct = which === "left" ? v1 > v2 : which === "right" ? v2 > v1 : v1 === v2;
    if (correct) { const pts = 10 + Math.min(20, streak * 2); setScore(s => { sendStateRef.current?.({ score: s + pts }); return s + pts; }); setStreak(s => s + 1); setFeedback("✓"); }
    else { setStreak(0); setFeedback("✗"); }
    generate();
    setTimeout(() => setFeedback(""), 300);
  };

  return <div className="aa-wrap">
    <MultiplayerPanel
      username={username}
      gameId="fraction-rush"
      compact
      onPlayerState={(p) => { remotesRef.current.set(p.id, { name: p.username, score: p.state.score || 0 }); setMpScores([...remotesRef.current.values()].map((v, i) => ({ id: String(i), name: v.name, score: v.score }))); }}
      onPlayerLeft={(id) => { remotesRef.current.delete(id); setMpScores([...remotesRef.current.values()].map((v, i) => ({ id: String(i), name: v.name, score: v.score }))); }}
      onRoomState={(meta) => { remotesRef.current.clear(); for (const p of meta.players) remotesRef.current.set(p.id, { name: p.name, score: p.score }); setMpScores([...remotesRef.current.values()].map((v, i) => ({ id: String(i), name: v.name, score: v.score }))); }}
      onHostModify={(opts) => setHostOpts(opts)}
      onHostAction={(action) => { if (action === "heal") setTimeLeft(t => t + 10); else if (action === "chaos") setTimeLeft(10); else if (action === "jumpscare") { document.body.style.background = "#ff2e4d"; setTimeout(() => document.body.style.background = "", 200); } }}
      onHostSpawn={() => { setScore(s => s + 50); }}
      onHostClear={() => { setStreak(0); }}
      sendStateRef={sendStateRef}
    />

    {mpScores.length > 0 && (
      <div className="mp-score-board" style={{ position: "static", marginBottom: 8 }}>
        {mpScores.map((p, i) => <div key={i} className="mp-score-row"><span>👤 {p.name}</span><b>{p.score}</b></div>)}
      </div>
    )}

    <div className="arc-nav" style={{ width: "100%", maxWidth: 500 }}>
      <Link href="/steamblox#bibliotheque" className="arc-back">← Bibliothèque</Link>
      <div className="arc-nav-title"><b>Fraction Rush</b><span>Compare vite !</span></div>
    </div>
    {phase === "menu" && <div className="aa-canvas-wrap">
      <div className="aa-overlay" style={{ background: "#0a0b10" }}>
        <div><h2>➗ Fraction Rush</h2>
        <p>Compare des fractions le plus vite possible !<br/>30 secondes, 3 choix : gauche, droite ou égal.<br/>Combo : chaque bonne réponse augmente ton bonus.<br/><small style={{ color: "#8b7cff" }}>🎮 Multijoueur : compare tes scores en temps réel. L'hôte peut modifier la partie.</small></p>
        <button className="arc-play" onClick={start}>Jouer</button>
        {best > 0 && <div className="arc-best">Record : {best} pts</div>}</div>
      </div>
      <div style={{ height: 300 }} />
    </div>}
    {phase === "playing" && <div className="aa-canvas-wrap" style={{ padding: 20, background: "#0a0b10", borderRadius: 12, border: "1px solid #ffffff14" }}>
      <div className="aa-hud"><span>⏱ {timeLeft}s</span><span>Score : <b>{score}</b></span><span>Combo : ×{streak} {feedback}</span></div>
      <p style={{ textAlign: "center", color: "#a9afbd", margin: "16px 0 8px" }}>Quelle fraction est la plus grande ?</p>
      <div style={{ display: "flex", gap: 12, justifyContent: "center", alignItems: "center", margin: "20px 0" }}>
        <button className="aa-card" style={{ fontSize: 28, fontWeight: 900, flex: 1, maxWidth: 120, justifyContent: "center" }} onClick={() => answer("left")}>{fracStr(frac1)}</button>
        <button className="aa-card" style={{ flex: "0 0 auto", padding: "12px 16px", justifyContent: "center", borderColor: "#ffffff33" }} onClick={() => answer("equal")}>＝</button>
        <button className="aa-card" style={{ fontSize: 28, fontWeight: 900, flex: 1, maxWidth: 120, justifyContent: "center" }} onClick={() => answer("right")}>{fracStr(frac2)}</button>
      </div>
    </div>}
    {phase === "over" && <div className="aa-canvas-wrap">
      <div className="aa-overlay" style={{ background: "#0a0b10ee" }}>
        <div><h2>Temps écoulé !</h2>
        <p>Score : <b style={{ color: "#ffd43b", fontSize: 24 }}>{score}</b><br/>{score > best ? "Nouveau record ! 🎉" : `Record : ${best}`}</p>
        <button className="arc-play" onClick={start}>Rejouer</button></div>
      </div>
      <div style={{ height: 300 }} />
    </div>}
  </div>;
}
