import { currentUser } from "@/lib/auth";
import { redirect } from "next/navigation";
import AlgebraDuelClient from "./AlgebraDuelClient";

export default async function AlgebraDuelPage() {
  const user = await currentUser();
  if (!user) { redirect("/login?next=/games/algebra-duel"); return null; }
  return <AlgebraDuelClient username={user.username} />;
}
