"use client";
import { useEffect, useRef, useState } from "react";
import Link from "next/link";
import { generateExercise, type Level } from "@/lib/algebra";
import MultiplayerPanel from "@/app/games/_components/MultiplayerPanel";

type Phase = "menu" | "playing" | "over";
type Player = "you" | "bot";

export default function AlgebraDuelClient({ username }: { username: string }) {
  const [phase, setPhase] = useState<Phase>("menu");
  const [yourScore, setYourScore] = useState(0);
  const [botScore, setBotScore] = useState(0);
  const [round, setRound] = useState(1);
  const [ex, setEx] = useState<{ text: string; answers: string[] } | null>(null);
  const [answer, setAnswer] = useState("");
  const [result, setResult] = useState("");
  const [botTimer, setBotTimer] = useState(0);
  const [mpScores, setMpScores] = useState<{ id: string; name: string; score: number }[]>([]);
  const remotesRef = useRef<Map<string, { name: string; score: number }>>(new Map());
  const sendStateRef = useRef<((state: Record<string, number>) => void) | null>(null);
  const [hostOpts, setHostOpts] = useState<Record<string, unknown>>({});
  const inputRef = useRef<HTMLInputElement>(null);
  const maxRound = 10;
  const targetScore = 5;

  useEffect(() => { if (phase === "playing") inputRef.current?.focus(); }, [phase, round]);

  const start = () => {
    setPhase("playing"); setYourScore(0); setBotScore(0); setRound(1); nextQuestion();
  };

  const nextQuestion = () => {
    const level = Math.min(4, Math.floor(round / 3) + 1) as Level;
    const e = generateExercise(level);
    setEx({ text: e.text, answers: e.answers.map(a => a.toString()) });
    setAnswer(""); setResult("");
    const botTime = (hostOpts.speed as number) ? 3000 / (hostOpts.speed as number) + Math.random() * 5000 / (hostOpts.speed as number) : 3000 + Math.random() * 5000;
    setBotTimer(botTime as unknown as number);
  };

  useEffect(() => {
    if (phase !== "playing" || !ex) return;
    const botTime = botTimer as unknown as number;
    if (typeof botTime !== "number") return;
    const t = setTimeout(() => {
      const botChance = (hostOpts.chaos as number) ? 0.4 : 0.7;
      if (Math.random() < botChance) {
        setBotScore(s => {
          const ns = s + 1;
          if (ns >= targetScore) endGame("bot");
          return ns;
        });
      }
    }, botTime);
    return () => clearTimeout(t);
  }, [phase, ex, botTimer]);

  const endGame = (winner: Player) => {
    setPhase("over");
    setResult(winner === "you" ? "🏆 Tu as gagné le duel !" : "💀 Le bot a gagné...");
  };

  const check = () => {
    if (!ex) return;
    const ok = ex.answers.includes(answer.trim());
    if (ok) {
      setYourScore(s => { sendStateRef.current?.({ score: s + 1 });
        const ns = s + 1;
        if (ns >= targetScore) { endGame("you"); return ns; }
        setRound(r => r + 1); nextQuestion();
        return ns;
      });
      setResult("✓ +1 point");
    } else {
      setResult("✗ Mauvaise réponse");
      setAnswer("");
    }
  };

  return <div className="aa-wrap">
    <MultiplayerPanel
      username={username}
      gameId="algebra-duel"
      compact
      onPlayerState={(p) => { remotesRef.current.set(p.id, { name: p.username, score: p.state.score || 0 }); setMpScores([...remotesRef.current.values()].map((v, i) => ({ id: String(i), name: v.name, score: v.score }))); }}
      onPlayerLeft={(id) => { remotesRef.current.delete(id); setMpScores([...remotesRef.current.values()].map((v, i) => ({ id: String(i), name: v.name, score: v.score }))); }}
      onRoomState={(meta) => { remotesRef.current.clear(); for (const p of meta.players) remotesRef.current.set(p.id, { name: p.name, score: p.score }); setMpScores([...remotesRef.current.values()].map((v, i) => ({ id: String(i), name: v.name, score: v.score }))); }}
      onHostModify={(opts) => setHostOpts(opts)}
      onHostAction={(action) => { if (action === "heal") setYourScore(s => Math.min(targetScore, s + 1)); else if (action === "chaos") setBotScore(s => Math.min(targetScore, s + 2)); else if (action === "jumpscare") { document.body.style.background = "#ff2e4d"; setTimeout(() => document.body.style.background = "", 200); } }}
      onHostSpawn={() => { setYourScore(s => Math.min(targetScore, s + 1)); }}
      onHostClear={() => { setBotScore(0); }}
      sendStateRef={sendStateRef}
    />

    {mpScores.length > 0 && (
      <div className="mp-score-board" style={{ position: "static", marginBottom: 8 }}>
        {mpScores.map((p, i) => <div key={i} className="mp-score-row"><span>👤 {p.name}</span><b>{p.score}</b></div>)}
      </div>
    )}

    <div className="arc-nav" style={{ width: "100%", maxWidth: 500 }}>
      <Link href="/steamblox#bibliotheque" className="arc-back">← Bibliothèque</Link>
      <div className="arc-nav-title"><b>Algebra Duel</b><span>Duel temps réel</span></div>
    </div>
    {phase === "menu" && <div className="aa-canvas-wrap">
      <div className="aa-overlay" style={{ background: "#0a0b10" }}>
        <div><h2>⚔️ Algebra Duel</h2>
        <p>Affronte l'IA en temps réel !<br/>Premier à 5 bonnes réponses gagne.<br/>Les équations deviennent plus dures à chaque manche.<br/><small style={{ color: "#8b7cff" }}>🎮 Multijoueur : compare tes scores en temps réel. L'hôte peut modifier la partie.</small></p>
        <button className="arc-play" onClick={start}>Lancer le duel</button></div>
      </div>
      <div style={{ height: 300 }} />
    </div>}
    {phase === "playing" && ex && <div className="aa-canvas-wrap" style={{ padding: 20, background: "#0a0b10", borderRadius: 12, border: "1px solid #ffffff14" }}>
      <div className="af-story-hud" style={{ background: "#8b7cff15" }}>
        <span className="af-story-boss">🧑 Toi : {yourScore}/{targetScore}</span>
        <span className="af-progress">Manche {round}</span>
        <span className="af-story-boss" style={{ color: "#ef4444" }}>🤖 Bot : {botScore}/{targetScore}</span>
      </div>
      <div className="af-ex-eq" style={{ fontSize: 28, textAlign: "center", margin: "20px 0" }}>{ex.text}</div>
      <form className="af-row" style={{ justifyContent: "center" }} onSubmit={e => { e.preventDefault(); check(); }}>
        <input ref={inputRef} className="af-input af-input-math" style={{ fontSize: 20, width: 140, textAlign: "center" }} value={answer} onChange={e => setAnswer(e.target.value)} placeholder="x = ?" inputMode="text" />
        <button className="af-btn">Valider</button>
      </form>
      {result && <p style={{ textAlign: "center", fontWeight: 700, marginTop: 8 }}>{result}</p>}
      <p className="muted" style={{ fontSize: 12, textAlign: "center", marginTop: 12 }}>Le bot répond en aléatoire 3-8s, 70% de réussite. Sois plus rapide !</p>
    </div>}
    {phase === "over" && <div className="aa-canvas-wrap">
      <div className="aa-overlay" style={{ background: "#0a0b10ee" }}>
        <div><h2>{result.includes("gagné") ? "🏆" : "💀"}</h2>
        <p style={{ fontSize: 20, fontWeight: 700 }}>{result}</p>
        <p>Toi : {yourScore} · Bot : {botScore}</p>
        <button className="arc-play" onClick={start}>Revanche</button></div>
      </div>
      <div style={{ height: 300 }} />
    </div>}
  </div>;
}
