import { promises as fs } from "node:fs";
import path from "node:path";
import { currentUser } from "@/lib/auth";
import { catalog, hasGameAccess } from "@/lib/store";
import { redirect } from "next/navigation";
import HelloNeighborEmbed from "./HelloNeighborEmbed";

export default async function HelloNeighborPreAlphaPage() {
  const user = await currentUser();
  if (!user) { redirect("/login"); return null; }

  const game = catalog.find((g) => g.id === "hello-neighbor-prealpha");
  if (!game) { redirect("/steamblox#bibliotheque"); return null; }
  if (!hasGameAccess(user, game.id) && game.price > 0) {
    redirect(`/steamblox?purchase=${game.id}`);
  }

  const indexPath = path.join(process.cwd(), "public", "games", "hello-neighbor-prealpha", "index.html");
  let hasBuild = false;
  try {
    await fs.access(indexPath);
    hasBuild = true;
  } catch {}

  if (!hasBuild) {
    return (
      <main className="wrap">
        <section className="card game-unavailable">
          <span className="tag">BUILD ABSENT</span>
          <h1>Hello Neighbor: Pre-Alpha</h1>
          <p className="muted">Le build web autorisé n’est pas présent dans cette version de TheCombinedWebs. Le bouton de lancement est donc volontairement désactivé au lieu d’afficher un jeu cassé.</p>
          <a className="button" href="/steamblox#bibliotheque">← Retour à la bibliothèque</a>
        </section>
      </main>
    );
  }
  return <HelloNeighborEmbed hasBuild username={user.username} />;
}
