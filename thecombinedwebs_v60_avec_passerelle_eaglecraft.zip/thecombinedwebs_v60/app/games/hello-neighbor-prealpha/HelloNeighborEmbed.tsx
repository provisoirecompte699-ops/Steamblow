"use client";

import Link from "next/link";
import { useEffect, useState } from "react";
import OverlayMultiplayer from "../_components/OverlayMultiplayer";

export default function HelloNeighborEmbed({ hasBuild, username }: { hasBuild: boolean; username: string }) {
  const [loaded, setLoaded] = useState(false);
  useEffect(() => {
    if (hasBuild) {
      const t = window.setTimeout(() => setLoaded(true), 80);
      return () => window.clearTimeout(t);
    }
  }, [hasBuild]);

  return (
    <main className="wrap">
      <nav className="nav">
        <Link href="/steamblox" className="brand">TheCombinedWebs</Link>
        <Link href="/games/3d" className="button secondary">Jeux 3D</Link>
      </nav>

      <section className="card game-launcher" style={{ marginTop: 18 }}>
        <div className="eyebrow">INTÉGRÉ À THECOMBINEDWEBS</div>
        <div className="game-launcher-head">
          <div>
            <h1>Hello Neighbor: Pre-Alpha</h1>
            <p className="muted">Lancement dans cette page. Aucun renvoi vers Steam.</p>
          </div>
          <span className="tag accent">3D · GRATUIT</span>
        </div>

        {hasBuild ? (
          <div className="embed-shell" aria-label="Hello Neighbor Pre-Alpha intégré">
            {!loaded && <div className="embed-loading">Chargement du jeu…</div>}
            <OverlayMultiplayer username={username} gameId="hello-neighbor-prealpha" />
            <iframe
              title="Hello Neighbor: Pre-Alpha"
              src="/games/hello-neighbor-prealpha/index.html"
              className="game-iframe"
              allow="fullscreen; autoplay; gamepad"
              onLoad={() => setLoaded(true)}
            />
          </div>
        ) : (
          <div className="card" style={{ marginTop: 18, padding: 20 }}>
            <h2>Build web non installé</h2>
            <p className="muted">
              La fiche est déjà intégrée à TheCombinedWebs, mais aucun build HTML5/WebAssembly autorisé n’est présent dans le projet.
            </p>
            <div className="notice">
              Place le fichier <code>public/games/hello-neighbor-prealpha/index.html</code> et ses fichiers associés dans ce dossier. La page lancera automatiquement le build ici.
            </div>
            <p className="muted" style={{ marginTop: 12 }}>
              La pré-alpha officielle est distribuée comme application Windows. Pour la faire tourner dans un navigateur, il faut donc un build web compatible.
            </p>
          </div>
        )}

        <div className="actions" style={{ marginTop: 16 }}>
          <Link href="/steamblox#bibliotheque" className="button secondary">Retour à la bibliothèque</Link>
        </div>
      </section>
    </main>
  );
}
