import {currentUser} from "@/lib/auth";
import {catalog,hasGameAccess} from "@/lib/store";
import {redirect} from "next/navigation";
import QuestGameTracker from "@/app/QuestGameTracker";
import SkyJumpClient from "./SkyJumpClient";
export default async function SkyJumpPage(){const u=await currentUser();if(!u){redirect("/login");return null;}const game=catalog.find(g=>g.id==="sky-jump")!;if(!hasGameAccess(u,game.id))redirect("/?purchase=sky-jump");return <main className="wrap"><QuestGameTracker gameId={game.id}/><h1>Sky Jump 3D</h1><p className="muted">Plateformes 3D en perspective, optimisées clavier et tactile. Jeu premium.</p><SkyJumpClient username={u.username}/></main>}
