"use client";
/**
 * CompactGameVoice — barre vocale compacte pour les pages de jeu.
 *
 * Fonctionnalités :
 * - Détecte si l'utilisateur est en vocal Discord avec au moins un autre membre
 * - Barre flottante avec avatars, indicateurs de parole, contrôles mute/sourdine
 * - Notifications toast quand un ami rejoint ou quitte le vocal
 * - Visible en plein écran (rendu à l'intérieur du conteneur fullscreen)
 * - Auto-réduction après 4s de silence
 * - Bouton push-to-talk (PTT) en mode compact
 * - Indicateur de qualité de connexion
 * - Classe globale `sb-discord-voice-compact` sur <html> pour adapter les jeux
 */
import { useEffect, useRef, useState, useCallback } from "react";
import { useDiscordVoice } from "../../DiscordVoiceProvider";
import type { VoiceSnapshot } from "../../discord/voice";

const low = (u: string) => u.toLowerCase();
const HUES = [258, 168, 205, 330, 28, 140, 288, 8, 48, 190];
const hue = (u: string) => { let h = 0; for (const c of u) h = (h * 31 + c.charCodeAt(0)) >>> 0; return HUES[h % HUES.length]; };

type Toast = { id: string; who: string; kind: "join" | "leave"; at: number };

type Props = {
  username: string;
};

/** Retourne true si l'utilisateur est en vocal Discord avec au moins un autre membre. */
export function useVoiceWithFriends(username: string): { active: boolean; voice: VoiceSnapshot | null } {
  const { voice } = useDiscordVoice();
  const active = !!voice?.room && voice.members.some((m) => low(m.u) !== low(username));
  return { active, voice };
}

export default function CompactGameVoice({ username }: Props) {
  const { voice, engine, subscribeEvents } = useDiscordVoice();
  const active = !!voice?.room && voice.members.some((m) => low(m.u) !== low(username));
  const [expanded, setExpanded] = useState(true);
  const [toasts, setToasts] = useState<Toast[]>([]);
  const [pttDown, setPttDown] = useState(false);
  const lastSpeakingRef = useRef(Date.now());

  // Applique la classe globale pour le mode compact
  useEffect(() => {
    document.documentElement.classList.toggle("sb-discord-voice-compact", active);
    return () => document.documentElement.classList.remove("sb-discord-voice-compact");
  }, [active]);

  // Notifications join/leave
  useEffect(() => {
    if (!subscribeEvents) return;
    const off = subscribeEvents((evt) => {
      // Ignorer ses propres événements
      if (evt.kind === "self-join" || evt.kind === "self-leave") return;
      if (low(evt.who) === low(username)) return;
      const toast: Toast = { id: `${evt.kind}-${evt.who}-${evt.at}`, who: evt.who, kind: evt.kind === "join" ? "join" : "leave", at: evt.at };
      setToasts((t) => [...t, toast]);
      setTimeout(() => setToasts((t) => t.filter((x) => x.id !== toast.id)), 4000);
    });
    return off;
  }, [subscribeEvents, username]);

  // Auto-réduction après 4 secondes de silence
  useEffect(() => {
    if (!active || !voice) return;
    const anyoneSpeaking = voice.members.some((m) => voice.speaking[low(m.u)]);
    if (anyoneSpeaking) {
      lastSpeakingRef.current = Date.now();
      setExpanded(true);
    }
    const t = setTimeout(() => {
      if (Date.now() - lastSpeakingRef.current >= 4000) setExpanded(false);
    }, 4000);
    return () => clearTimeout(t);
  }, [active, voice?.speaking, voice?.level]);

  // Push-to-talk : touche V maintenue
  useEffect(() => {
    if (!active) return;
    const down = (e: KeyboardEvent) => {
      if (e.code === "KeyV" && !(e.target instanceof HTMLTextAreaElement || e.target instanceof HTMLInputElement)) {
        setPttDown(true);
        engine?.setPttDown(true);
      }
    };
    const up = (e: KeyboardEvent) => {
      if (e.code === "KeyV") {
        setPttDown(false);
        engine?.setPttDown(false);
      }
    };
    addEventListener("keydown", down);
    addEventListener("keyup", up);
    return () => { removeEventListener("keydown", down); removeEventListener("keyup", up); };
  }, [active, engine]);

  const toggleMute = useCallback(() => {
    if (!voice || !engine) return;
    engine.setMuted(!voice.muted);
  }, [voice, engine]);

  const toggleDeaf = useCallback(() => {
    if (!voice || !engine) return;
    engine.setDeaf(!voice.deaf);
  }, [voice, engine]);

  const leaveVoice = useCallback(() => {
    engine?.leave();
  }, [engine]);

  if (!active || !voice) return null;

  const otherMembers = voice.members.filter((m) => low(m.u) !== low(username));
  const speakingMembers = voice.members.filter((m) => voice.speaking[low(m.u)]);
  const connectedPeers = Object.values(voice.peers).filter((s) => s === "connected").length;
  const totalPeers = Object.keys(voice.peers).length;
  const connectionQuality = totalPeers === 0 ? "none" : connectedPeers === totalPeers ? "good" : "poor";

  const roomName = voice.room?.startsWith("dm~")
    ? `Appel avec ${otherMembers[0]?.u || "ami"}`
    : voice.room?.startsWith("vc-")
    ? ({ "vc-general": "Salon général", "vc-jeux": "Gaming", "vc-cine": "Ciné-club", "vc-chill": "Chill" } as Record<string, string>)[voice.room] || voice.room
    : voice.room || "Vocal";

  return (
    <>
      {/* Notifications toast */}
      <div className="cgv-toasts">
        {toasts.map((t) => (
          <div key={t.id} className={`cgv-toast ${t.kind}`}>
            <span className="cgv-toast-icon">{t.kind === "join" ? "➡️" : "⬅️"}</span>
            <span className="cgv-toast-text">
              <b>{t.who}</b> {t.kind === "join" ? "a rejoint le vocal" : "a quitté le vocal"}
            </span>
          </div>
        ))}
      </div>

      {/* Barre vocale compacte */}
      <div className={`cgv ${expanded ? "expanded" : "collapsed"}`}>
        <div className="cgv-bar" onClick={() => setExpanded(!expanded)}>
          <div className="cgv-info">
            <span className={`cgv-dot ${voice.joining ? "connecting" : ""}`} />
            <span className="cgv-room">{roomName}</span>
            <span className="cgv-count">
              {voice.members.length} en vocal
              {connectionQuality !== "none" && (
                <span className={`cgv-quality ${connectionQuality}`} title={connectionQuality === "good" ? "Connexion stable" : "Connexion instable"}>
                  {connectionQuality === "good" ? "●" : "●"}
                </span>
              )}
            </span>
          </div>

          <div className="cgv-avatars">
            {voice.members.map((m) => {
              const isMe = low(m.u) === low(username);
              const talking = voice.speaking[low(m.u)];
              const peerState = isMe ? "connected" : voice.peers[low(m.u)] || "connecting";
              return (
                <div
                  key={m.u}
                  className={`cgv-avatar ${talking ? "talking" : ""} ${isMe ? "me" : ""} ${peerState === "failed" ? "failed" : ""}`}
                  style={{ background: `linear-gradient(140deg,hsl(${hue(m.u)} 70% 58%),hsl(${hue(m.u) + 30} 62% 38%))` }}
                  title={`${m.u}${isMe ? " (toi)" : ""}${peerState === "connected" ? "" : peerState === "failed" ? " — connexion impossible" : " — connexion…"}`}
                >
                  {m.u.slice(0, 1).toUpperCase()}
                  {talking && <span className="cgv-avatar-ring" />}
                  {m.muted && <span className="cgv-badge-icon">🚫</span>}
                  {m.deaf && <span className="cgv-badge-icon deaf">🔇</span>}
                  {!isMe && peerState === "connecting" && <span className="cgv-badge-icon connecting">⋯</span>}
                </div>
              );
            })}
          </div>

          <div className="cgv-controls" onClick={(e) => e.stopPropagation()}>
            {voice.ptt ? (
              <button
                className={`cgv-btn ptt ${pttDown ? "active" : ""}`}
                onPointerDown={() => { setPttDown(true); engine?.setPttDown(true); }}
                onPointerUp={() => { setPttDown(false); engine?.setPttDown(false); }}
                onPointerLeave={() => { if (pttDown) { setPttDown(false); engine?.setPttDown(false); } }}
                onPointerCancel={() => { setPttDown(false); engine?.setPttDown(false); }}
                title="Maintiens pour parler (V)"
              >
                {pttDown ? "🎙️" : "⌨️"}
              </button>
            ) : null}
            <button
              className={`cgv-btn ${voice.muted ? "off" : ""}`}
              onClick={toggleMute}
              title={voice.muted ? "Réactiver le micro" : "Couper le micro"}
            >
              {voice.muted ? "🚫" : "🎙️"}
            </button>
            <button
              className={`cgv-btn ${voice.deaf ? "off" : ""}`}
              onClick={toggleDeaf}
              title={voice.deaf ? "Réactiver le son" : "Sourdine casque"}
            >
              {voice.deaf ? "🔇" : "🎧"}
            </button>
            <button
              className="cgv-btn danger"
              onClick={leaveVoice}
              title="Quitter le vocal"
            >
              ⏏
            </button>
          </div>
        </div>

        {expanded && (
          <div className="cgv-extra">
            {speakingMembers.length > 0 && (
              <div className="cgv-speaking">
                🔊 {speakingMembers.map((m) => m.u).join(", ")} parle{speakingMembers.length > 1 ? "nt" : ""}
              </div>
            )}
            {voice.error && <div className="cgv-error">{voice.error}</div>}
            {voice.ptt && (
              <div className="cgv-ptt-hint">
                {pttDown ? "Tu parles…" : "Maintiens V ou le bouton pour parler"}
              </div>
            )}
          </div>
        )}

        {/* Jauge de niveau micro */}
        {expanded && !voice.muted && (
          <div className="cgv-meter">
            <div className="cgv-meter-bar">
              <i style={{ width: `${Math.min(100, (voice.level || 0) * 100)}%` }} />
            </div>
          </div>
        )}
      </div>
    </>
  );
}
