"use client";
import { useEffect, useRef, useState, useCallback } from "react";
import { connectMultiplayer, MONSTER_TYPES, HOST_ACTIONS, type Multiplayer, type RoomMeta, type HostOptions, type HostEntity } from "@/lib/multiplayer";
import type { Socket } from "socket.io-client";
import { roomFromUrl, copyInvite } from "@/lib/invite";
import TrollKit from "@/app/games/_components/TrollKit";
import VoiceChat from "@/app/VoiceChat";
import CompactGameVoice from "@/app/games/_components/CompactGameVoice";

type Props = {
  username: string;
  gameId: string;
  compact?: boolean;
  onHostSpawn?: (monster: { type: string; x: number; y: number; count: number; id: string }) => void;
  onHostModify?: (options: HostOptions) => void;
  onHostAction?: (action: string, payload: Record<string, unknown>) => void;
  onHostClear?: () => void;
  onPlayerState?: (player: { id: string; username: string; state: Record<string, number> }) => void;
  onPlayerLeft?: (id: string) => void;
  onRoomState?: (meta: RoomMeta) => void;
  sendStateRef?: React.MutableRefObject<((state: Record<string, number>) => void) | null>;
};

export default function MultiplayerPanel({
  username, gameId, compact = false,
  onHostSpawn, onHostModify, onHostAction, onHostClear,
  onPlayerState, onPlayerLeft, onRoomState, sendStateRef,
}: Props) {
  const [room, setRoom] = useState("");
  useEffect(() => { const r = roomFromUrl(); if (r) setRoom(r); }, []);
  const [copied, setCopied] = useState(false);
  const [joined, setJoined] = useState(false);
  const [meta, setMeta] = useState<RoomMeta | null>(null);
  const [status, setStatus] = useState("");
  const [chat, setChat] = useState<{ id: string; name: string; text: string; at: number }[]>([]);
  const [chatInput, setChatInput] = useState("");
  const [showPanel, setShowPanel] = useState(false);
  const [showHostPanel, setShowHostPanel] = useState(false);
  const mpRef = useRef<Multiplayer | null>(null);
  const [socket, setSocket] = useState<Socket | null>(null);

  const isHost = meta?.hostId === mpRef.current?.socket.id;

  const join = useCallback(() => {
    const code = room || Math.random().toString(36).slice(2, 8).toUpperCase();
    setRoom(code);
    mpRef.current?.close();
    const mp = connectMultiplayer(code, username, gameId);
    if (!mp) { setStatus("Multijoueur en ligne indisponible : serveur non configuré (voir DEPLOY_MULTIPLAYER.md)."); return; }
    mpRef.current = mp;
    setSocket(mp.socket);
    setJoined(true);
    setStatus(`Connexion au salon ${code}…`);

    mp.socket.on("connect", () => setStatus(`Salon ${code} · en ligne`));
    mp.socket.on("disconnect", () => setStatus(`Déconnecté du salon ${code}`));
    mp.socket.on("room:state", (m: RoomMeta) => { setMeta(m); onRoomState?.(m); });
    mp.socket.on("room:joined", ({ roomId, hostId }: { roomId: string; hostId: string }) => {
      setStatus(`Salon ${roomId} · connecté`);
    });
    mp.socket.on("room:error", (m: { message: string }) => setStatus(m?.message || "Erreur"));
    mp.socket.on("room:promoted", () => setStatus("Tu es maintenant l'hôte du salon !"));
    mp.socket.on("room:kicked", (m: { message: string }) => {
      setStatus(m?.message || "Exclu du salon");
      mpRef.current?.close(); mpRef.current = null; setJoined(false); setMeta(null);
    });
    mp.socket.on("player:state", (m: { id: string; username: string; state: Record<string, number> }) => onPlayerState?.(m));
    mp.socket.on("player:left", (m: { id: string }) => onPlayerLeft?.(m.id));
    mp.socket.on("room:chat", (m: { id: string; name: string; text: string; at: number }) => {
      setChat((c) => [...c.slice(-30), m]);
    });
    // Host events
    mp.socket.on("host:spawn", (m: { monster: { type: string; x: number; y: number; count: number; id: string }; entities: unknown[] }) => {
      onHostSpawn?.(m.monster);
    });
    mp.socket.on("host:modify", (m: { options: HostOptions }) => onHostModify?.(m.options));
    mp.socket.on("host:action", (m: { action: string; payload: Record<string, unknown> }) => onHostAction?.(m.action, m.payload));
    mp.socket.on("host:clear", () => onHostClear?.());
  }, [room, username, gameId, onHostSpawn, onHostModify, onHostAction, onHostClear, onPlayerState, onPlayerLeft, onRoomState]);

  const leave = useCallback(() => {
    mpRef.current?.close(); mpRef.current = null;
    setSocket(null); setJoined(false); setMeta(null); setChat([]);
    setStatus(""); setShowPanel(false); setShowHostPanel(false);
  }, []);

  // Expose sendState
  useEffect(() => {
    if (sendStateRef && mpRef.current) {
      sendStateRef.current = (state: Record<string, number>) => {
        mpRef.current?.socket.emit("player:state", { state });
      };
    }
    return () => { if (sendStateRef) sendStateRef.current = null; };
  }, [joined, sendStateRef]);

  useEffect(() => () => { mpRef.current?.close(); }, []);

  const sendChat = () => {
    const text = chatInput.trim();
    if (!text || !mpRef.current) return;
    mpRef.current.socket.emit("room:chat", { text });
    setChatInput("");
  };

  const hostSpawn = (type: string, count: number = 1) => {
    mpRef.current?.socket.emit("host:spawn", { type, count, x: Math.random() * 1000, y: Math.random() * 600 });
  };
  const hostModify = (opts: HostOptions) => {
    mpRef.current?.socket.emit("host:modify", { options: opts });
  };
  const hostAction = (action: string) => {
    mpRef.current?.socket.emit("host:action", { action });
  };
  const hostClear = () => {
    mpRef.current?.socket.emit("host:clear", {});
  };

  const playerCount = meta?.players?.length || 0;
  const playerList = meta?.players || [];

  return (
    <div className={`mp-panel ${compact ? "mp-compact" : ""}`}>
      {socket && <TrollKit socket={socket} />}
      {!joined ? (
        <div className="mp-join">
          <div className="mp-join-row">
            <input
              value={room}
              onChange={(e) => setRoom(e.target.value.toUpperCase().replace(/[^A-Z0-9_-]/g, "").slice(0, 20))}
              placeholder="CODE SALON"
              className="mp-input"
              onKeyDown={(e) => e.key === "Enter" && join()}
            />
            <button onClick={join} className="mp-btn-join">Rejoindre</button>
{room && <button className="mp-btn-join" onClick={async () => { if (await copyInvite(room)) { setCopied(true); setTimeout(() => setCopied(false), 2000); } }}>{copied ? "✓ Copié" : "🔗 Inviter"}</button>}
          </div>
          {status && <small className="mp-status">{status}</small>}
        </div>
      ) : (
        <>
          <button className="mp-toggle" onClick={() => setShowPanel(!showPanel)}>
            🎮 {room} · {playerCount} joueur{playerCount > 1 ? "s" : ""} {isHost ? "👑" : ""} {showPanel ? "▲" : "▼"}
          </button>
          {status && <small className="mp-status">{status}</small>}

          {showPanel && (
            <div className="mp-body">
              <div className="mp-players">
                {playerList.map((p) => (
                  <div key={p.id} className="mp-player">
                    <span className="mp-player-name">{p.name}{p.id === meta?.hostId ? " 👑" : ""}</span>
                    {p.score > 0 && <span className="mp-player-score">{p.score}</span>}
                  </div>
                ))}
              </div>

              {isHost && (
                <button className="mp-host-toggle" onClick={() => setShowHostPanel(!showHostPanel)}>
                  ⚙️ Contrôles hôte {showHostPanel ? "▲" : "▼"}
                </button>
              )}

              {isHost && showHostPanel && (
                <div className="mp-host-controls">
                  <div className="mp-host-section">
                    <b>👹 Invoquer des monstres</b>
                    <div className="mp-monster-grid">
                      {MONSTER_TYPES.map((m) => (
                        <button key={m.type} className="mp-monster-btn" onClick={() => hostSpawn(m.type, m.type === "swarm" ? 5 : 1)} title={m.desc}>
                          <span className="mp-monster-icon">{m.icon}</span>
                          <span className="mp-monster-label">{m.label}</span>
                        </button>
                      ))}
                    </div>
                    <button className="mp-clear-btn" onClick={hostClear}>🧹 Effacer tous les monstres</button>
                  </div>

                  <div className="mp-host-section">
                    <b>⚙️ Modifier la partie</b>
                    <div className="mp-opt-row">
                      <label>Vitesse</label>
                      <input type="range" min="0.3" max="3" step="0.1" defaultValue="1" onChange={(e) => hostModify({ speed: parseFloat(e.target.value) })} />
                    </div>
                    <div className="mp-opt-row">
                      <label>Gravité</label>
                      <input type="range" min="0.3" max="3" step="0.1" defaultValue="1" onChange={(e) => hostModify({ gravity: parseFloat(e.target.value) })} />
                    </div>
                    <div className="mp-opt-row">
                      <label>Taux monstres</label>
                      <input type="range" min="0" max="5" step="0.5" defaultValue="1" onChange={(e) => hostModify({ monsterRate: parseFloat(e.target.value) })} />
                    </div>
                    <div className="mp-opt-row">
                      <label>Brouillard</label>
                      <input type="range" min="0" max="1" step="0.1" defaultValue="0" onChange={(e) => hostModify({ fog: parseFloat(e.target.value) })} />
                    </div>
                    <div className="mp-opt-toggles">
                      <button className="mp-toggle-btn" onClick={() => hostModify({ chaos: 1 })}>🌪️ Chaos</button>
                      <button className="mp-toggle-btn" onClick={() => hostModify({ friendlyFire: true })}>⚔️ Feu ami</button>
                      <button className="mp-toggle-btn" onClick={() => hostModify({ invincible: true })}>🛡️ Invincible</button>
                      <button className="mp-toggle-btn" onClick={() => hostModify({ oneHitKO: true })}>💀 One-hit KO</button>
                      <button className="mp-toggle-btn" onClick={() => hostModify({ slowMotion: 1 })}>🐌 Slow-mo</button>
                      <button className="mp-toggle-btn" onClick={() => hostModify({ bigHead: true })}>🎈 Grosses têtes</button>
                      <button className="mp-toggle-btn" onClick={() => hostModify({ lowGravity: true })}>🚀 Faible gravité</button>
                      <button className="mp-toggle-btn" onClick={() => hostModify({ explosions: true })}>💥 Explosions</button>
                      <button className="mp-toggle-btn" onClick={() => hostModify({ darkness: true })}>🌙 Obscurité</button>
                    </div>
                    <button className="mp-reset-btn" onClick={() => hostModify({ speed: 1, gravity: 1, monsterRate: 1, fog: 0, chaos: 0, friendlyFire: false, invincible: false, oneHitKO: false, slowMotion: 0, bigHead: false, lowGravity: false, explosions: false, darkness: false })}>
                      🔄 Réinitialiser tout
                    </button>
                  </div>

                  <div className="mp-host-section">
                    <b>⚡ Actions instantanées</b>
                    <div className="mp-action-grid">
                      {HOST_ACTIONS.map((a) => (
                        <button key={a.action} className="mp-action-btn" onClick={() => hostAction(a.action)} title={a.label}>
                          <span>{a.icon}</span>
                          <small>{a.label}</small>
                        </button>
                      ))}
                    </div>
                  </div>
                </div>
              )}

              <div className="mp-chat">
                <div className="mp-chat-list">
                  {chat.map((c, i) => (
                    <div key={i} className="mp-chat-msg"><b>{c.name}:</b> {c.text}</div>
                  ))}
                </div>
                <div className="mp-chat-input-row">
                  <input
                    value={chatInput}
                    onChange={(e) => setChatInput(e.target.value.slice(0, 180))}
                    onKeyDown={(e) => e.key === "Enter" && sendChat()}
                    placeholder="Message…"
                    className="mp-input mp-chat-input"
                  />
                  <button onClick={sendChat} className="mp-btn-send">➤</button>
                </div>
              </div>

              <button className="mp-leave" onClick={leave}>Quitter le salon</button>
              {socket && <VoiceChat socket={socket} username={username} compact />}
            </div>
          )}
        </>
      )}
      {/* CompactGameVoice est en dehors du panneau repliable pour rester visible */}
      <CompactGameVoice username={username} />
    </div>
  );
}
