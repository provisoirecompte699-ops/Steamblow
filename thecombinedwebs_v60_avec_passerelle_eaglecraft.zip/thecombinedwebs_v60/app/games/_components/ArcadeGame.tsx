// @ts-nocheck
"use client";
import { useEffect, useRef, useState, type CSSProperties } from "react";
import {gameMemory as localStorage} from "@/app/game-memory";
import Link from "next/link";
import TrollKit from "@/app/games/_components/TrollKit";
import { roomFromUrl, copyInvite } from "@/lib/invite";
import { connectMultiplayer, MONSTER_TYPES, HOST_ACTIONS, type RoomMeta, type HostOptions } from "@/lib/multiplayer";
import VoiceChat from "@/app/VoiceChat";
import CompactGameVoice, { useVoiceWithFriends } from "@/app/games/_components/CompactGameVoice";
import * as C from "./arcade/core";
import { MODES, INFO } from "./arcade/modes";

const NO_HP = new Set(["tag", "party", "rooftop", "crystal"]);
const AUTO_FIRE = new Set(["cyber", "arena"]);
const REAL_RANDOM = Math.random;
const mulberry = (a) => () => { a |= 0; a = (a + 0x6d2b79f5) | 0; let t = Math.imul(a ^ (a >>> 15), 1 | a); t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t; return ((t ^ (t >>> 14)) >>> 0) / 4294967296; };
const blobToB64 = (b) => new Promise((res, rej) => { const r = new FileReader(); r.onload = () => res(String(r.result).split(",")[1] || ""); r.onerror = rej; r.readAsDataURL(b); });

export default function ArcadeGame({ username, gameId, mode }: { username: string; gameId: string; mode: string }) {
  const info = INFO[mode], M = MODES[mode];
  // Mode compact : s'active automatiquement quand l'utilisateur est en vocal Discord avec des amis
  const { active: voiceCompact } = useVoiceWithFriends(username);
  const wrapRef = useRef(null), stageRef = useRef(null), cvRef = useRef(null), joyRef = useRef(null), knobRef = useRef(null);
  const SR = useRef(null), phaseRef = useRef("menu"), mpRef = useRef(null), ghostsRef = useRef([]);
  const I = useRef({ keys: new Set(), joy: null, act: false, actP: false, dashP: false, touch: false, aim: null, mx: 0, my: 0, hasMouse: false, pad: null, tv: false, move() { if (this.joy) return [this.joy.x, this.joy.y]; if (this.pad) return this.pad; const k = this.keys; const x = (k.has("KeyD") || k.has("ArrowRight") ? 1 : 0) - (k.has("KeyA") || k.has("KeyQ") || k.has("ArrowLeft") ? 1 : 0); const y = (k.has("KeyS") || k.has("ArrowDown") ? 1 : 0) - (k.has("KeyW") || k.has("KeyZ") || k.has("ArrowUp") ? 1 : 0); return [x, y]; } }).current;
  const [phase, setPhase] = useState("menu");
  const [hud, setHud] = useState(null);
  const [result, setResult] = useState(null);
  const [best, setBest] = useState(0);
  const cloudRef = useRef({version:0,ready:false,bestScore:0,achievements:[],difficulty:"normal"});
  const progressionRef=useRef({achievements:[],difficulty:"normal"});
  const [cloudStatus,setCloudStatus]=useState("Chargement du cloud…");
  useEffect(()=>{
    let off=false;
    fetch(`/api/saves?game=${encodeURIComponent(gameId)}`,{cache:"no-store"}).then(r=>r.json()).then(d=>{
      if(off)return;if(d.error)throw new Error(d.error);
      cloudRef.current={...d.save.data,version:d.save.version,ready:true};
      setBest(v=>Math.max(v,d.save.data.bestScore));setAchievements(v=>[...new Set([...v,...d.save.data.achievements])]);setDifficulty(d.save.data.difficulty);
      setCloudStatus(d.save.version?"Progression restaurée depuis ton compte":"Cloud prêt");
    }).catch(e=>{if(!off)setCloudStatus(e.message||"Cloud indisponible");});
    return()=>{off=true;};
  },[gameId]);
  const saveCloud=async(score,ids=[])=>{
    if(!cloudRef.current.ready){setCloudStatus("Cloud indisponible : progression non synchronisée");return;}
    const current=cloudRef.current;
    const data={bestScore:Math.max(current.bestScore,score),achievements:[...new Set([...current.achievements,...progressionRef.current.achievements,...ids])],difficulty:progressionRef.current.difficulty};
    try{
      const r=await fetch("/api/saves",{method:"PUT",headers:{"content-type":"application/json"},body:JSON.stringify({gameId,baseVersion:current.version,data})});
      const d=await r.json();if(!r.ok)throw new Error(d.error);
      cloudRef.current={...d.save.data,version:d.save.version,ready:true};setCloudStatus("Progression sauvegardée dans ton compte");
    }catch(e){setCloudStatus(e.message||"Sauvegarde échouée");}
  };
  const [muted, setMuted] = useState(false);
  const [immersive, setImmersive] = useState(false);
  const [touch, setTouch] = useState(false);
  const [portrait, setPortrait] = useState(false);
  const [room, setRoom] = useState("");
  useEffect(() => { const r = roomFromUrl(); if (r) setRoom(r); }, []);
  const [copied, setCopied] = useState(false);
  const [mpStatus, setMpStatus] = useState("");
  const [socket, setSocket] = useState(null);
  const [isHost, setIsHost] = useState(false);
  const [showHostPanel, setShowHostPanel] = useState(false);
  const [mpPlayers, setMpPlayers] = useState([]);
  const [hostOpts, setHostOpts] = useState({});
  const hostOptsRef = useRef({});
  const spawnedMonstersRef = useRef([]);
  const bestKey = `steamblox:arcade:${mode}:best`;
  // v52 : défi du jour, carte perso, tournoi, progression, rediffusion
  const [run, setRun] = useState({ kind: "normal" });
  const runRef = useRef({ kind: "normal" });
  const [award, setAward] = useState(null);
  const [replay, setReplay] = useState(null);
  const [showReplay, setShowReplay] = useState(false);
  const [shareMsg, setShareMsg] = useState("");
  const recRef = useRef(null);
  const setRunBoth = (r) => { runRef.current = r; setRun(r); };
  const seedOn = () => { const r = runRef.current; if (r.seed != null) Math.random = mulberry(r.seed); };
  const seedOff = () => { Math.random = REAL_RANDOM; };
  // v54 : succès partagés et options de jeu
  const [achievements, setAchievements] = useState([]);
  const [newAchievements, setNewAchievements] = useState([]);
  const [showAchievements, setShowAchievements] = useState(false);
  const [difficulty, setDifficulty] = useState("normal");
  progressionRef.current={achievements,difficulty};
  const [showOptions, setShowOptions] = useState(false);
  const [gameStats, setGameStats] = useState({ hits: 0, kills: 0, dashCount: 0, noHit: true, combo5: false, startTime: 0 });
  const gameStatsRef = useRef({ hits: 0, kills: 0, dashCount: 0, noHit: true, combo5: false, startTime: 0 });
  const onGameEventRef = useRef(() => {});
  const achKey = `steamblox:arcade:achievements`;
  const ACH_DEFS = [
    { id: "first_game", label: "Première partie", icon: "🎮", desc: "Jouer ton premier jeu" },
    { id: "score_100", label: "Centurion", icon: "💯", desc: "Atteindre 100 points" },
    { id: "score_500", label: "Demi-millier", icon: "🔥", desc: "Atteindre 500 points" },
    { id: "score_1000", label: "Millennium", icon: "⚡", desc: "Atteindre 1000 points" },
    { id: "score_5000", label: "Légende", icon: "👑", desc: "Atteindre 5000 points" },
    { id: "no_hit", label: "Intouchable", icon: "🛡️", desc: "Terminer une partie sans encaisser de coup" },
    { id: "combo_5", label: "En feu", icon: "🌟", desc: "Atteindre un combo x5" },
    { id: "speedrun", label: "Éclair", icon: "💨", desc: "Survivre plus de 60 secondes" },
    { id: "dash_10", label: "Acrobate", icon: "🤸", desc: "Utiliser 10 dashs en une partie" },
    { id: "comeback", label: "Revenant", icon: "💀", desc: "Terminer une partie avec 1 PV restant" },
    { id: "all_games", label: "Explorateur", icon: "🗺️", desc: "Jouer aux 11 jeux arcade" },
    { id: "night_owl", label: "Hibou de nuit", icon: "🦉", desc: "Jouer après minuit" },
  ];
  useEffect(() => { try { const s = JSON.parse(localStorage.getItem(achKey) || "{}"); setAchievements(Object.keys(s)); const d = localStorage.getItem(`steamblox:arcade:${mode}:diff`); if (d) setDifficulty(d); } catch {} }, []);
  const unlockAch = (ids) => { try { const s = JSON.parse(localStorage.getItem(achKey) || "{}"); const fresh = []; for (const id of ids) { if (!s[id]) { s[id] = Date.now(); fresh.push(id); } } if (fresh.length) { localStorage.setItem(achKey, JSON.stringify(s)); setAchievements(Object.keys(s)); setNewAchievements(fresh); setTimeout(() => setNewAchievements([]), 4000); } } catch {} };
  const onGameStart = () => { const s = { hits: 0, kills: 0, dashCount: 0, noHit: true, combo5: false, startTime: Date.now() }; gameStatsRef.current = s; setGameStats(s); if (padRef.current) { padRef.current.hp = null; padRef.current.dashCd = 0; } const played = JSON.parse(localStorage.getItem("steamblox:arcade:played") || "[]"); if (!played.includes(mode)) { played.push(mode); localStorage.setItem("steamblox:arcade:played", JSON.stringify(played)); } unlockAch(["first_game"]); if (new Date().getHours() < 1) unlockAch(["night_owl"]); if (played.length >= 11) unlockAch(["all_games"]); };
  const onGameEvent = (event, value) => { const s = { ...gameStatsRef.current }; if (event === "hit") { s.hits++; s.noHit = false; } if (event === "dash") { s.dashCount++; if (s.dashCount >= 10) unlockAch(["dash_10"]); } if (event === "combo" && value >= 5 && !s.combo5) { s.combo5 = true; unlockAch(["combo_5"]); } gameStatsRef.current = s; setGameStats(s); };
  const onGameEnd = (score, win, hp) => { const ids = []; if (score >= 100) ids.push("score_100"); if (score >= 500) ids.push("score_500"); if (score >= 1000) ids.push("score_1000"); if (score >= 5000) ids.push("score_5000"); if (gameStatsRef.current.noHit && win) ids.push("no_hit"); if (Date.now() - gameStatsRef.current.startTime > 60000) ids.push("speedrun"); if (hp !== null && hp === 1 && win) ids.push("comeback"); unlockAch(ids); };
  // Exposer onGameEvent pour la boucle d'animation
  onGameEventRef.current = onGameEvent;

  const quality = () => { const q = document.documentElement.dataset.tcbQuality || "high"; let v = q === "eco" ? 0.35 : q === "balanced" ? 0.65 : 1; if (I.touch) v = Math.min(v, 0.7); if (I.tv) v = Math.min(v, 0.65); return v; };
  const fresh = () => {
    const S = C.makeState(mode, info.theme); S.username = username; S.q = quality();
    S.end = (win, title, lines) => {
      if (S.over) return; S.over = true; const score = Math.floor(S.score); const prev = Number(localStorage.getItem(bestKey) || 0); const nb = score > prev; if (nb) localStorage.setItem(bestKey, String(score));
      setBest(Math.max(prev, score)); setResult({ win, title, lines, score, newBest: nb && score > 0 }); C.sfx(win ? "win" : "boom");
      seedOff(); stopRec();
      const r = runRef.current; if (r.kind === "tournament") setRunBoth({ ...r, done: true });
      setAward({ loading: true });
      // v54 : déclencher les succès
      onGameEnd(score, win, S.p ? S.p.hp : null);
      const duelQuery=new URLSearchParams(location.search);
      saveCloud(score,score>=100?["first_game","score_100"]:["first_game"]);
      fetch("/api/arcade/score", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ gameId, score, duration: Math.round(S.t), duel:duelQuery.get("duel")||undefined,duelToken:duelQuery.get("duelToken")||undefined,daily: r.kind === "daily", mapId: r.kind === "custom" ? r.mapId : undefined, tournament: r.kind === "tournament" ? r.tid : undefined, match: r.kind === "tournament" ? r.match : undefined }) })
        .then((x) => x.json()).then((d) => setAward(d.error ? { error: d.error } : d)).catch(() => setAward({ error: "Score non envoyé (hors ligne)" }));
      setTimeout(() => { phaseRef.current = "over"; setPhase("over"); }, 900);
    };
    if (runRef.current.kind === "custom" && runRef.current.map) S.custom = { ...runRef.current.map };
    M.setup(S); C.settleCustom(S); return S;
  };
  // ----- enregistrement de la rediffusion (canvas → WebM) -----
  const startRec = () => {
    stopRec(true); setReplay(null); setShareMsg("");
    try {
      const cv = cvRef.current; if (!cv?.captureStream || typeof MediaRecorder === "undefined") return;
      const types = ["video/webm;codecs=vp9", "video/webm;codecs=vp8", "video/webm", "video/mp4"]; const mime = types.find((t) => MediaRecorder.isTypeSupported?.(t));
      if (!mime) return;
      const rec = new MediaRecorder(cv.captureStream(30), { mimeType: mime, videoBitsPerSecond: 450000 });
      const chunks = []; rec.ondataavailable = (e) => { if (e.data?.size) chunks.push(e.data); };
      rec.onstop = () => { if (rec.discard || !chunks.length) return; const blob = new Blob(chunks, { type: mime.split(";")[0] }); setReplay({ blob, url: URL.createObjectURL(blob), mime: mime.split(";")[0] }); };
      rec.start(1000); recRef.current = rec; rec.cap = setTimeout(() => { if (rec.state !== "inactive") rec.stop(); }, 60000);
    } catch { recRef.current = null; }
  };
  const stopRec = (discard = false) => { const rec = recRef.current; if (!rec) return; clearTimeout(rec.cap); rec.discard = discard; try { if (rec.state !== "inactive") rec.stop(); } catch {} recRef.current = null; };
  const shareReplay = async (share) => {
    if (!replay || !result) return; setShareMsg(share ? "Envoi dans Discord…" : "Envoi…");
    if (replay.blob.size > 4_000_000) { setShareMsg("Rediffusion trop lourde pour être partagée (télécharge-la)."); return; }
    try { const data = await blobToB64(replay.blob); const r = await fetch("/api/replays", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ gameId, score: result.score, data, mime: replay.mime, share }) }); const d = await r.json(); setShareMsg(d.error ? d.error : share ? "Partagée dans #jeux sur Discord" : `Lien : ${location.origin}${d.url}`); }
    catch { setShareMsg("Envoi impossible"); }
  };

  // Contexte de la partie depuis l'URL (?daily=1, ?map=ID, ?t=TOURNOI)
  useEffect(() => {
    const q = new URLSearchParams(location.search);
    (async () => {
      try {
        if (q.get("t")) {
          const d = await (await fetch(`/api/tournaments?id=${encodeURIComponent(q.get("t"))}`)).json();
          if (d.tournament && d.tournament.gameId === gameId) { const m = d.myMatch; setRunBoth(m ? { kind: "tournament", tid: d.tournament.id, name: d.tournament.name, match: m.id, seed: d.tournament.seed + m.id.length * 7919 + Number(m.id.replace(/\D/g, "")), vs: m.a?.toLowerCase() === username.toLowerCase() ? m.b : m.a } : { kind: "tournament-wait", tid: d.tournament.id, name: d.tournament.name }); }
        } else if (q.get("map")) {
          const d = await (await fetch(`/api/maps?id=${encodeURIComponent(q.get("map"))}`)).json();
          if (d.map && d.map.mode === mode) { setRunBoth({ kind: "custom", mapId: d.map.id, name: d.map.name, author: d.map.author, map: { cols: d.map.cols, rows: d.map.rows, grid: d.map.grid.split("").map(Number), spawn: d.map.spawn } }); SR.current = fresh(); }
        } else if (q.get("daily") === "1") {
          const d = await (await fetch("/api/leaderboard?scope=daily")).json();
          if (d.daily?.id === gameId) setRunBoth({ kind: "daily", seed: d.daily.seed, day: d.daily.day });
        }
      } catch { /* hors ligne : partie normale */ }
    })();
    return () => { seedOff(); stopRec(true); };
  }, []);

  // ————— Manettes (Xbox, PlayStation, manettes TV) —————
  const padRef = useRef({ prev: [], hp: null, idx: -1 });
  const [padName, setPadName] = useState("");
  const rumble = (dur, mag) => { try { const g = navigator.getGamepads?.()[padRef.current.idx]; g?.vibrationActuator?.playEffect?.("dual-rumble", { duration: dur * 1000, strongMagnitude: mag, weakMagnitude: mag * 0.6 }); } catch {} };
  const pollPad = (ph) => {
    const pads = navigator.getGamepads ? Array.from(navigator.getGamepads()).filter(Boolean) : [];
    const g = pads[0];
    if (!g) { if (I.pad) I.pad = null; return; }
    padRef.current.idx = g.index;
    const btn = (i) => !!g.buttons[i]?.pressed;
    const prev = padRef.current.prev; const down = (i) => btn(i) && !prev[i];
    let x = g.axes[0] || 0, y = g.axes[1] || 0;
    if (btn(14)) x = -1; if (btn(15)) x = 1; if (btn(12)) y = -1; if (btn(13)) y = 1;
    const dead = Math.hypot(x, y) < 0.22;
    I.pad = dead ? null : [Math.max(-1, Math.min(1, x)), Math.max(-1, Math.min(1, y))];
    if (ph === "play") {
      const a = btn(0) || btn(7) || btn(2); if (a && !I.padAct) { I.act = true; I.actP = true; I.padAct = true; } else if (!a && I.padAct) { I.act = false; I.padAct = false; }
      if (down(1) || down(5) || down(6)) I.dashP = true;
      // stick droit = visée
      const rx = g.axes[2] || 0, ry = g.axes[3] || 0;
      I.padAim = Math.hypot(rx, ry) > 0.35 ? [rx, ry] : null;
      if (down(9)) { phaseRef.current = "pause"; setPhase("pause"); }
    } else if (down(0) || down(9)) {
      const b = wrapRef.current?.querySelector(".arc-play"); if (b && !b.disabled) b.click();
    }
    padRef.current.prev = g.buttons.map((b) => b.pressed);
  };
  useEffect(() => {
    const on = (e) => { setPadName(e.gamepad?.id ? e.gamepad.id.replace(/\(.*?\)/g, "").trim().slice(0, 40) || "Manette" : ""); };
    const off = () => setPadName(navigator.getGamepads && Array.from(navigator.getGamepads()).some(Boolean) ? "Manette" : "");
    addEventListener("gamepadconnected", on); addEventListener("gamepaddisconnected", off);
    return () => { removeEventListener("gamepadconnected", on); removeEventListener("gamepaddisconnected", off); };
  }, []);
  // Pendant une partie, le mode TV laisse les flèches et OK au jeu
  useEffect(() => {
    const el = document.documentElement;
    if (phase === "play") el.setAttribute("data-tvgame", "1"); else el.removeAttribute("data-tvgame");
    return () => el.removeAttribute("data-tvgame");
  }, [phase]);

  useEffect(() => {
    setBest(Number(localStorage.getItem(bestKey) || 0));
    I.tv = document.documentElement.classList.contains("cs-tv") || /SmartTV|SMART-TV|Tizen|Web0S|webOS|AFT[A-Z]|Android TV|GoogleTV|SteambloxTV|; ?TV;/i.test(navigator.userAgent);
    const coarse = !I.tv && (matchMedia("(pointer: coarse)").matches || "ontouchstart" in window); I.touch = coarse; setTouch(coarse);
    C.audio.muted = localStorage.getItem("steamblox:arcade:muted") === "1"; setMuted(C.audio.muted);
    SR.current = fresh();
    const cv = cvRef.current, ctx = cv.getContext("2d", { alpha: false });
    let raf = 0, last = performance.now(), hudT = 0, net = 0, vig = null, vigKey = "";
    const resize = () => { const r = cv.getBoundingClientRect(); const dpr = Math.min(I.tv ? 1 : I.touch ? 1.6 : 2, devicePixelRatio || 1); cv.width = Math.max(2, Math.round(r.width * dpr)); cv.height = Math.max(2, Math.round(r.height * dpr)); SR.current.dpr = dpr; setPortrait(r.height > r.width * 1.05); };
    const ro = new ResizeObserver(resize); ro.observe(cv); resize();
    const frame = (now) => {
      const S = SR.current; const dt = Math.min(0.033, (now - last) / 1000); last = now;
      const ph = phaseRef.current; const playing = ph === "play" && !S.over;
      pollPad(ph);
      const cw = cv.width, ch = cv.height, th = C.TH[S.theme];
      const port = ch > cw; const sc = Math.max(Math.min(cw / (port ? 760 : 1180), ch / (port ? 1180 : 700)), cw / Math.max(1, S.W), ch / Math.max(1, S.H));
      const vw = cw / sc, vh = ch / sc;
      // caméra
      const p = S.p; const tx = p ? p.x + p.vx * 0.18 : S.W / 2, ty = p ? p.y + p.vy * 0.18 : S.H / 2;
      if (!S.cam.init) { S.cam.x = tx; S.cam.y = ty; S.cam.init = true; }
      S.cam.x += (tx - S.cam.x) * Math.min(1, dt * 6); S.cam.y += (ty - S.cam.y) * Math.min(1, dt * 6);
      const cx = S.W > vw ? C.clamp(S.cam.x, vw / 2, S.W - vw / 2) : S.W / 2, cy = S.H > vh ? C.clamp(S.cam.y, vh / 2 - 20, S.H - vh / 2) : S.H / 2;
      const shx = (Math.random() - 0.5) * S.shake, shy = (Math.random() - 0.5) * S.shake;
      const ox = cx - vw / 2 + shx, oy = cy - vh / 2 + shy;
      I.aim = I.padAim && p ? { x: p.x + I.padAim[0] * 220, y: p.y + I.padAim[1] * 220 } : I.hasMouse && !I.touch ? { x: I.mx * S.dpr / sc + ox, y: I.my * S.dpr / sc + oy } : null;
      // simulation
      S.lights = []; S.cones = [];
      if (playing) {
        S.t += dt;
        for (const a of [S.p, ...S.bots, ...S.foes]) if (a) C.tickActor(a, dt);
        S.p.lockFace = false;
        M.update(S, I, dt); C.updateShots(S, dt); if (S.lockGrid) C.settleCustom(S);
      } else if (ph === "menu") { S.t += dt; M.update(S, { move: () => [0, 0], act: false, actP: false, dashP: false, touch: true, aim: null }, 0); }
      I.actP = false; I.dashP = false;
      if (ph !== "pause") C.updateFx(S, dt);
      // rendu
      ctx.setTransform(1, 0, 0, 1, 0, 0);
      const sky = ctx.createLinearGradient(0, 0, 0, ch); sky.addColorStop(0, th.sky[0]); sky.addColorStop(1, th.sky[1]); ctx.fillStyle = sky; ctx.fillRect(0, 0, cw, ch);
      if (M.bg) M.bg(ctx, S, sc, ox, oy);
      ctx.setTransform(sc, 0, 0, sc, -ox * sc, -oy * sc);
      if (S.mapDirty || !S.mapCv) C.buildMap(S);
      ctx.drawImage(S.mapCv, 0, 0);
      M.under && M.under(ctx, S);
      for (const pk of S.picks) C.drawPick(ctx, S, pk);
      C.drawShots(ctx, S);
      const actors = [S.p, ...S.bots, ...S.foes].filter(Boolean).sort((a, b) => a.y - b.y);
      for (const g of ghostsRef.current) { if (g.tx != null) { const k = Math.min(1, dt * 12); g.x += (g.tx - g.x) * k; g.y += (g.ty - g.y) * k; } }
      for (const g of ghostsRef.current) C.drawActor(ctx, S, g, { alpha: 0.45, name: g.name });
      for (const a of actors) C.drawActor(ctx, S, a, (M.actorOpts && M.actorOpts(S, a)) || {});
      M.over && M.over(ctx, S);
      C.drawFx(ctx, S);
      ctx.setTransform(1, 0, 0, 1, 0, 0);
      if (M.dark) C.drawLighting(ctx, S, sc, ox, oy, cw, ch, M.dark);
      const vk = cw + "x" + ch; if (vk !== vigKey) { vigKey = vk; vig = ctx.createRadialGradient(cw / 2, ch / 2, Math.min(cw, ch) * 0.35, cw / 2, ch / 2, Math.max(cw, ch) * 0.75); vig.addColorStop(0, "rgba(0,0,0,0)"); vig.addColorStop(1, "rgba(0,0,0,.55)"); }
      ctx.fillStyle = vig; ctx.fillRect(0, 0, cw, ch);
      if (S.flash > 0) { ctx.globalAlpha = Math.min(0.45, S.flash * 1.6); ctx.fillStyle = S.flashC; ctx.fillRect(0, 0, cw, ch); ctx.globalAlpha = 1; }
      // réseau
      if (mpRef.current && playing && now - net > 80) { net = now; mpRef.current.socket.emit("player:state", { state: { x: p.x, y: p.y, score: Math.floor(S.score), mode } }); }
      hudT -= dt;
      if (playing && S.p && padRef.current.hp != null && S.p.hp < padRef.current.hp) { rumble(0.18, 0.7); onGameEventRef.current("hit"); }
      if (S.p) padRef.current.hp = S.p.hp;
      // v54 : suivi combo et dash
      if (playing && S.p && S.p.dashCd > 0 && (padRef.current.dashCd || 0) <= 0) onGameEventRef.current("dash");
      if (S.p) padRef.current.dashCd = S.p.dashCd;
      if (playing && S.combo >= 5) onGameEventRef.current("combo", S.combo);
      if (hudT <= 0 && (playing || ph === "over")) { hudT = 0.1; const h = M.hud(S); setHud({ ...h, t: S.t, hp: S.p.hp, maxHp: S.p.maxHp, msg: S.msgT > 0 ? S.msg : "", sub: S.msgSub, dashReady: S.p.dashCd <= 0, actReady: S.p.actCd <= 0 }); }
      raf = requestAnimationFrame(frame);
    };
    raf = requestAnimationFrame(frame);
    const code = (e) => e.code || e.key;
    const kd = (e) => {
      const c = code(e);
      if (e.keyCode === 10009 || e.keyCode === 461 || c === "GoBack" || c === "BrowserBack") { if (phaseRef.current === "play") { e.preventDefault(); phaseRef.current = "pause"; setPhase("pause"); } return; }
      if (c === "Escape" || c === "KeyP") { if (phaseRef.current === "play") { phaseRef.current = "pause"; setPhase("pause"); } else if (phaseRef.current === "pause") { phaseRef.current = "play"; setPhase("play"); } return; }
      if (phaseRef.current !== "play") return;
      if (["ArrowUp", "ArrowDown", "ArrowLeft", "ArrowRight", "Space"].includes(c)) e.preventDefault();
      I.keys.add(c);
      if (e.repeat) return;
      if (c === "Space" || c === "KeyE" || c === "KeyJ" || c === "Enter") { I.act = true; I.actP = true; }
      if (c === "ShiftLeft" || c === "ShiftRight" || c === "KeyK") I.dashP = true;
    };
    const ku = (e) => { const c = code(e); I.keys.delete(c); if (c === "Space" || c === "KeyE" || c === "KeyJ" || c === "Enter") I.act = false; };
    const vis = () => { if (document.hidden && phaseRef.current === "play") { phaseRef.current = "pause"; setPhase("pause"); } };
    const blur = () => { I.keys.clear(); I.act = false; };
    addEventListener("keydown", kd); addEventListener("keyup", ku); addEventListener("blur", blur); document.addEventListener("visibilitychange", vis);
    return () => { cancelAnimationFrame(raf); ro.disconnect(); removeEventListener("keydown", kd); removeEventListener("keyup", ku); removeEventListener("blur", blur); document.removeEventListener("visibilitychange", vis); mpRef.current?.close(); };
  }, []);

  useEffect(() => {
    if (!immersive) return;
    const prev = document.body.style.overflow; document.body.style.overflow = "hidden"; document.documentElement.classList.add("arc-lock");
    return () => { document.body.style.overflow = prev; document.documentElement.classList.remove("arc-lock"); };
  }, [immersive]);

  const enterImmersive = () => {
    setImmersive(true);
    const el = wrapRef.current; try { if (el?.requestFullscreen && !document.fullscreenElement) el.requestFullscreen({ navigationUI: "hide" }).catch(() => {}); } catch {}
  };
  const exitImmersive = () => { setImmersive(false); try { if (document.fullscreenElement) document.exitFullscreen(); } catch {} };
  const start = () => {
    if (runRef.current.kind === "tournament" && runRef.current.done) return;
    if (runRef.current.kind === "tournament-wait") return;
    seedOn(); SR.current = fresh(); setResult(null); setAward(null); I.keys.clear(); I.act = false; startRec();
    onGameStart();
    phaseRef.current = "play"; setPhase("play"); C.sfx("tick");
    if (I.touch) enterImmersive();
    stageRef.current?.focus?.();
  };
  const resume = () => { phaseRef.current = "play"; setPhase("play"); try { recRef.current?.resume?.(); } catch {} };
  const pause = () => { if (phaseRef.current === "play") { phaseRef.current = "pause"; setPhase("pause"); try { recRef.current?.pause?.(); } catch {} } };
  const toMenu = () => { exitImmersive(); seedOff(); stopRec(true); phaseRef.current = "menu"; setPhase("menu"); SR.current = fresh(); };
  const toggleMute = () => { C.audio.muted = !C.audio.muted; setMuted(C.audio.muted); localStorage.setItem("steamblox:arcade:muted", C.audio.muted ? "1" : "0"); };
  const joinRoom = () => {
    const code = room || Math.random().toString(36).slice(2, 8).toUpperCase(); setRoom(code);
    mpRef.current?.close(); const c = connectMultiplayer(code, username, gameId);
    if (!c) { setMpStatus("Multijoueur en ligne indisponible : serveur non configuré (voir DEPLOY_MULTIPLAYER.md)."); return; }
    mpRef.current = c; setSocket(c.socket); setMpStatus(`Connexion au salon ${code}…`);
    c.socket.on("connect", () => setMpStatus(`Salon ${code} · en ligne`));
    c.socket.on("room:state", (m) => {
      const list = (m.players || []).filter((x) => x.id !== c.socket.id);
      const prevG = new Map(ghostsRef.current.map((g) => [g.nid, g]));
      ghostsRef.current = list.map((x) => {
        const old = prevG.get(x.id);
        if (old) { old.name = String(x.name || "Ami").slice(0, 16); return old; }
        const g = C.actor(Number(x.x) || 0, Number(x.y) || 0, { name: String(x.name || "Ami").slice(0, 16), color: "#e9ecef" });
        g.nid = x.id; g.tx = g.x; g.ty = g.y; return g;
      });
      setMpPlayers(m.players || []);
      setIsHost(m.hostId === c.socket.id);
      if (m.hostOptions) { hostOptsRef.current = m.hostOptions; setHostOpts(m.hostOptions); }
      setMpStatus(`Salon ${code} · ${list.length + 1} joueur${list.length ? "s" : ""}${m.hostId === c.socket.id ? " · hôte" : ""}`);
    });
    // Positions en direct des autres joueurs (sinon les fantômes restent figés)
    c.socket.on("player:state", (m) => {
      const st = m?.state; if (!st) return;
      const g = ghostsRef.current.find((x) => x.nid === m.id);
      if (g) { g.tx = Number(st.x) || 0; g.ty = Number(st.y) || 0; }
    });
    c.socket.on("player:left", (m) => { ghostsRef.current = ghostsRef.current.filter((x) => x.nid !== m?.id); });
    c.socket.on("room:error", (m) => setMpStatus(m?.message || "Erreur du salon"));
    c.socket.on("room:promoted", () => { setIsHost(true); setMpStatus(`Salon ${code} · tu es maintenant l'hôte`); });
    // ————— Événements hôte —————
    c.socket.on("host:spawn", (m) => {
      if (!m?.monster) return;
      const S = SR.current;
      const count = m.monster.type === "swarm" ? 5 : m.monster.count || 1;
      for (let i = 0; i < count; i++) {
        const x = m.monster.x || S.p?.x + C.R(-200, 200) || S.W / 2;
        const y = m.monster.y || S.p?.y + C.R(-200, 200) || S.H / 2;
        const foe = C.actor(C.clamp(x, 40, S.W - 40), C.clamp(y, 40, S.H - 40), { hp: m.monster.type === "boss" ? 8 : m.monster.type === "tank" ? 6 : 3, maxHp: m.monster.type === "boss" ? 8 : m.monster.type === "tank" ? 6 : 3, speed: m.monster.type === "fast" ? 260 : m.monster.type === "tank" ? 140 : 200, color: m.monster.type === "boss" ? "#ff2e4d" : m.monster.type === "fast" ? "#ffd43b" : m.monster.type === "ghost" ? "#b197fc" : m.monster.type === "tank" ? "#ff8c42" : "#ff6b9d", name: m.monster.type === "boss" ? "BOSS" : m.monster.type, r: m.monster.type === "boss" ? 32 : m.monster.type === "tank" ? 24 : 16, shape: m.monster.type === "ghost" ? "blob" : "blob" });
        if (S.foes) S.foes.push(foe); spawnedMonstersRef.current.push(foe);
        C.burst(S, foe.x, foe.y, foe.color, 16, 200, 5, 0.6); C.sfx("act");
      }
    });
    c.socket.on("host:modify", (m) => {
      if (!m?.options) return;
      hostOptsRef.current = m.options; setHostOpts(m.options);
      const S = SR.current;
      if (S?.p) {
        if (m.options.speed != null) S.p.speed = 310 * m.options.speed;
        if (m.options.invincible) S.p.hp = S.p.maxHp;
      }
    });
    c.socket.on("host:action", (m) => {
      if (!m?.action) return;
      const S = SR.current;
      if (!S) return;
      const a = m.action;
      if (a === "heal") { if (S.p) { S.p.hp = S.p.maxHp; C.floatText(S, S.p.x, S.p.y - 40, "+PV", "#5ee7c4"); } }
      else if (a === "damage") { if (S.p) { C.hurt(S, S.p, 1, S.p); C.burst(S, S.p.x, S.p.y, "#ff2e4d", 14, 200, 4, 0.4); } }
      else if (a === "reset") { spawnedMonstersRef.current.forEach((f) => { const idx = S.foes?.indexOf(f); if (idx >= 0) S.foes.splice(idx, 1); }); spawnedMonstersRef.current = []; C.banner(S, "Reset", "Monstres effacés"); }
      else if (a === "chaos") { C.shakeIt(S, 20); C.burst(S, S.p.x, S.p.y, "#ffd43b", 40, 400, 8, 0.8); for (let i = 0; i < 5; i++) { const f = C.actor(C.R(80, S.W - 80), C.R(80, S.H - 80), { color: "#ff6b9d", hp: 2, maxHp: 2, speed: 250, name: "Chaos" }); S.foes?.push(f); spawnedMonstersRef.current.push(f); } }
      else if (a === "freeze") { for (const f of (S.foes || [])) f.freeze = 4; C.banner(S, "Gelé", "Les monstres sont immobiles"); }
      else if (a === "speed") { if (S.p) S.p.speed *= 1.5; C.floatText(S, S.p.x, S.p.y - 40, "VITESSE+", "#ffd43b"); }
      else if (a === "slow") { for (const f of (S.foes || [])) f.speed *= 0.4; C.banner(S, "Ralenti", "Les monstres ralentissent"); }
      else if (a === "rain") { for (let i = 0; i < 8; i++) S.picks.push({ ...C.randOpen(S, S.p, 300), kind: "star", r: 16, t: 0 }); C.banner(S, "Pluie de bonus", "Ramasse tout !"); }
      else if (a === "jumpscare") { S.flash = 1; S.flashC = "#ff2e4d"; C.shakeIt(S, 15); C.sfx("boom"); }
      else if (a === "party") { C.burst(S, S.p.x, S.p.y, "#ffd166", 50, 500, 10, 1); C.banner(S, "FÊTE", "🎉🎉🎉"); }
    });
    c.socket.on("host:clear", () => {
      const S = SR.current;
      spawnedMonstersRef.current.forEach((f) => { const idx = S.foes?.indexOf(f); if (idx >= 0) S.foes.splice(idx, 1); });
      spawnedMonstersRef.current = []; C.banner(S, "Effacé", "Monstres supprimés");
    });
  };
  // ————— Actions d'hôte (envoyées au serveur) —————
  const hostSpawn = (type, count = 1) => { mpRef.current?.socket.emit("host:spawn", { type, count, x: Math.random() * 1000, y: Math.random() * 600 }); };
  const hostModify = (opts) => { mpRef.current?.socket.emit("host:modify", { options: opts }); };
  const hostAction = (action) => { mpRef.current?.socket.emit("host:action", { action }); };
  const hostClear = () => { mpRef.current?.socket.emit("host:clear", {}); };

  // ----- contrôles tactiles -----
  const joyDown = (e) => {
    if (e.pointerType === "mouse") return; e.preventDefault(); I.touch = true; if (!touch) setTouch(true);
    e.currentTarget.setPointerCapture?.(e.pointerId);
    const r = stageRef.current.getBoundingClientRect(); const ox = e.clientX - r.left, oy = e.clientY - r.top;
    I.joyO = { x: ox, y: oy, id: e.pointerId }; I.joy = { x: 0, y: 0 };
    const base = joyRef.current; if (base) { base.style.display = "block"; base.style.left = ox + "px"; base.style.top = oy + "px"; }
    if (knobRef.current) knobRef.current.style.transform = "translate(-50%,-50%)";
  };
  const joyMove = (e) => {
    if (!I.joyO || e.pointerId !== I.joyO.id) return; e.preventDefault();
    const r = stageRef.current.getBoundingClientRect(); let dx = e.clientX - r.left - I.joyO.x, dy = e.clientY - r.top - I.joyO.y; const l = Math.hypot(dx, dy), max = 58;
    if (l > max) { dx = dx / l * max; dy = dy / l * max; }
    const n = Math.hypot(dx, dy) / max; I.joy = n < 0.12 ? { x: 0, y: 0 } : { x: dx / max, y: dy / max };
    if (knobRef.current) knobRef.current.style.transform = `translate(calc(-50% + ${dx}px), calc(-50% + ${dy}px))`;
  };
  const joyUp = (e) => { if (I.joyO && e.pointerId !== I.joyO.id) return; I.joyO = null; I.joy = null; if (joyRef.current) joyRef.current.style.display = "none"; };
  const btn = (kind) => ({
    onPointerDown: (e) => { e.preventDefault(); e.stopPropagation(); I.touch = true; if (kind === "dash") I.dashP = true; else { I.act = true; I.actP = true; } navigator.vibrate?.(8); },
    onPointerUp: (e) => { e.preventDefault(); if (kind === "act") I.act = false; },
    onPointerCancel: () => { if (kind === "act") I.act = false; },
    onContextMenu: (e) => e.preventDefault(),
  });
  // ----- souris -----
  const onMouseMove = (e) => { if (e.pointerType !== "mouse") return; const r = cvRef.current.getBoundingClientRect(); I.mx = e.clientX - r.left; I.my = e.clientY - r.top; I.hasMouse = true; if (I.touch && !matchMedia("(pointer: coarse)").matches) { I.touch = false; setTouch(false); } };
  const onMouseDown = (e) => { if (e.pointerType !== "mouse" || phaseRef.current !== "play") return; if (e.button === 2) { I.dashP = true; return; } if (e.button === 0) { I.act = true; I.actP = true; } };
  const onMouseUp = (e) => { if (e.pointerType === "mouse" && e.button === 0) I.act = false; };

  const showAct = info.act && !(touch && AUTO_FIRE.has(mode));
  const style = { "--acc": info.accent } as CSSProperties;
  const hearts = hud && !NO_HP.has(mode) ? Array.from({ length: hud.maxHp }, (_, i) => <i key={i} className={i < hud.hp ? "on" : ""} />) : null;

  return (
    <section ref={wrapRef} className={`arc ${immersive ? "arc-full" : ""} ${touch ? "arc-touch" : ""} ${voiceCompact ? "arc-voice-compact" : ""}`} style={style}>
      {!immersive && (
        <div className="arc-nav">
          <Link href="/steamblox#bibliotheque" className="arc-back">← Bibliothèque</Link>
          <div className="arc-nav-title"><b>{info.title}</b><span>{info.tag}</span></div>
          <span className="arc-nav-best" role="status">{best > 0 ? `Record ${best} · ` : ""}{cloudStatus}</span>
        </div>
      )}
      <div ref={stageRef} className="arc-stage" tabIndex={-1} onPointerMove={onMouseMove} onPointerDown={onMouseDown} onPointerUp={onMouseUp} onContextMenu={(e) => e.preventDefault()}>
        <canvas ref={cvRef} className={`arc-canvas ${phase !== "play" ? "dim" : ""} ${AUTO_FIRE.has(mode) || ["brawl", "castle", "mines", "heist"].includes(mode) ? "aim" : ""}`} />

        {phase === "play" && hud && (
          <div className="arc-hud">
            <div className="arc-hud-l"><b>{info.title}</b><span>{hud.left}</span></div>
            <div className={`arc-hud-c ${hud.urgent ? "urgent" : ""}`}>
              <span>{hud.obj}</span>
              {hud.timer != null && <em>{C.fmtTime(hud.timer)}</em>}
              {hud.bar && <div className={`arc-bar ${hud.bar.center ? "center" : ""}`}><i style={{ width: `${Math.round(C.clamp(hud.bar.v, 0, 1) * 100)}%`, background: hud.bar.color }} /></div>}
            </div>
            <div className="arc-hud-r"><b>{hud.right}</b>{hearts && <div className="arc-hearts">{hearts}</div>}{hud.combo > 1.05 && <span className="arc-combo">×{hud.combo.toFixed(1)}</span>}</div>
          </div>
        )}
        {phase === "play" && hud?.board && (
          <div className="arc-board">{hud.board.map((b) => <div key={b.name}><i style={{ background: b.color }} /><span>{b.name}</span><b>{b.v}</b>{b.m !== "" && <em>{b.m}</em>}</div>)}</div>
        )}
        {phase === "play" && hud?.msg && <div className="arc-banner" key={hud.msg}><b>{hud.msg}</b>{hud.sub && <span>{hud.sub}</span>}</div>}

        <div className="arc-tools">
          {phase === "play" && <button onClick={pause} aria-label="Pause" title="Pause (Échap)">❚❚</button>}
          <button onClick={toggleMute} aria-label={muted ? "Activer le son" : "Couper le son"} title="Son">{muted ? "🔇" : "🔊"}</button>
          <button onClick={immersive ? exitImmersive : enterImmersive} aria-label="Plein écran" title="Plein écran">{immersive ? "✕" : "⛶"}</button>
        </div>

        {phase === "play" && touch && (
          <>
            <div className="arc-joyzone" onPointerDown={joyDown} onPointerMove={joyMove} onPointerUp={joyUp} onPointerCancel={joyUp}>
              <div ref={joyRef} className="arc-joy"><div ref={knobRef} className="arc-knob" /></div>
              {(hud?.t ?? 0) < 6 && <span className="arc-joyhint">Glisse pour bouger</span>}
            </div>
            <div className="arc-btns">
              <button className={`arc-btn dash ${hud?.dashReady ? "" : "cd"}`} {...btn("dash")}>Dash</button>
              {showAct && <button className={`arc-btn act ${hud?.actReady ? "" : "cd"}`} {...btn("act")}>{info.act}</button>}
            </div>
          </>
        )}

        {phase === "menu" && (
          <div className="arc-overlay">
            <div className="arc-card">
              <span className="arc-kicker">{info.tag}</span>
              <h2>{info.title}</h2>
              {run.kind === "daily" && <div className="arc-run daily">🎯 Défi du jour · même carte pour tout le monde · +100 XP</div>}
              {run.kind === "custom" && <div className="arc-run">🧱 Carte perso « {run.name} » par {run.author}</div>}
              {run.kind === "tournament" && <div className="arc-run tour">🏆 {run.name} · match contre {run.vs} · une seule tentative</div>}
              {run.kind === "tournament-wait" && <div className="arc-run tour">🏆 {run.name} · pas de match à jouer pour l’instant</div>}
              <p className="arc-goal">{info.goal}</p>
              <ul className="arc-how">{info.how.map((h) => <li key={h}>{h}</li>)}</ul>
              <div className="arc-keys">{padName ? <>🎮 {padName} : stick ou croix · <kbd>A</kbd> action · <kbd>B</kbd> dash · stick droit : viser · <kbd>Start</kbd> pause</> : touch ? "Joystick : pouce gauche · Boutons : pouce droit" : <>ZQSD / WASD / flèches · <kbd>Espace</kbd> ou clic : action · <kbd>Maj</kbd> ou clic droit : dash · <kbd>Échap</kbd> : pause · télécommande TV et manettes compatibles</>}</div>
              <button className="arc-play" onClick={start} disabled={run.kind === "tournament-wait" || (run.kind === "tournament" && run.done)}>{run.kind === "tournament" ? "Jouer mon match" : "Jouer"}</button>
              <div className="arc-links"><Link href={`/classements?game=${gameId}`}>Classement</Link><Link href="/tournois">Tournois</Link><Link href="/editeur">Éditeur</Link><button className="arc-ach-btn" onClick={() => setShowAchievements(true)}>🏆 Succès ({achievements.length}/{ACH_DEFS.length})</button><button className="arc-ach-btn" onClick={() => setShowOptions(true)}>⚙️ Options</button></div>
              {best > 0 && <div className="arc-best">Ton record : {best} pts</div>}
              <details className="arc-mp">
                <summary>Jouer avec des amis · Multijoueur</summary>
                <p>Entre le même code que tes amis : vous vous voyez en fantôme et pouvez parler en vocal. L'hôte peut invoquer des monstres et modifier la partie.</p>
                <div className="arc-mp-row"><input value={room} onChange={(e) => setRoom(e.target.value.toUpperCase().replace(/[^A-Z0-9_-]/g, "").slice(0, 20))} placeholder="CODE" /><button onClick={joinRoom}>Rejoindre</button>{room && <button onClick={async () => { if (await copyInvite(room)) { setCopied(true); setTimeout(() => setCopied(false), 2000); } }}>{copied ? "✓ Copié" : "🔗 Inviter"}</button>}</div>
                {mpStatus && <small>{mpStatus}</small>}
                {mpPlayers.length > 1 && (
                  <div className="arc-mp-players">
                    {mpPlayers.map((p) => <span key={p.id} className="arc-mp-player">{p.name}{p.id === mpPlayers[0]?.id ? " 👑" : ""}</span>)}
                  </div>
                )}
                {isHost && socket && (
                  <button className="arc-ach-btn" onClick={() => setShowHostPanel(true)} style={{ marginTop: 8 }}>⚙️ Contrôles hôte (monstres + modifications)</button>
                )}
              </details>
              {portrait && touch && <div className="arc-rotate">Astuce : tourne ton téléphone pour voir plus large</div>}
            </div>
          </div>
        )}
        {phase === "pause" && (
          <div className="arc-overlay">
            <div className="arc-card small">
              <h2>Pause</h2>
              <button className="arc-play" onClick={resume}>Reprendre</button>
              <div className="arc-row"><button className="arc-ghost" onClick={start}>Recommencer</button><button className="arc-ghost" onClick={toMenu}>Menu</button></div>
            </div>
          </div>
        )}
        {phase === "over" && result && (
          <div className="arc-overlay">
            <div className={`arc-card small ${result.win ? "win" : ""}`}>
              <span className="arc-kicker">{result.win ? "Victoire" : "Partie terminée"}</span>
              <h2>{result.title}</h2>
              <div className="arc-score"><b>{result.score}</b><span>points{result.newBest ? " · nouveau record" : best ? ` · record ${best}` : ""}</span></div>
              <ul className="arc-lines">{result.lines.map((l) => <li key={l}>{l}</li>)}</ul>
              {award && <div className="arc-award">
                {award.loading ? <span className="arc-award-wait">Envoi du score…</span> : award.error ? <span className="arc-award-err">{award.error}</span> : <>
                  {award.xp && <div className="arc-xp"><b>+{award.xp.gained} XP</b><span>Niveau {award.xp.level}{award.xp.levelUp ? " · niveau supérieur" : ""}</span><div className="arc-xpbar"><i style={{ width: `${Math.round((award.xp.into / Math.max(1, award.xp.need)) * 100)}%` }} /></div></div>}
                  <div className="arc-ranks">
                    {award.boards?.week?.rank > 0 && <span>Semaine : <b>{award.boards.week.rank}{award.boards.week.rank === 1 ? "er" : "e"}</b></span>}
                    {award.boards?.all?.rank > 0 && <span>Mondial : <b>{award.boards.all.rank}{award.boards.all.rank === 1 ? "er" : "e"}</b></span>}
                    {award.boards?.daily?.rank > 0 && <span>Défi du jour : <b>{award.boards.daily.rank}{award.boards.daily.rank === 1 ? "er" : "e"}</b></span>}
                    {award.boards?.map?.rank > 0 && <span>Carte perso : <b>{award.boards.map.rank}{award.boards.map.rank === 1 ? "er" : "e"}</b></span>}
                    {award.tournament && <span>Tournoi : {award.tournament.status === "done" ? `terminé · ${award.tournament.champion || "?"} champion` : "score envoyé"}</span>}
                  </div>
                </>}
              </div>}
              {replay && <div className="arc-replay"><button className="arc-ghost" onClick={() => setShowReplay(true)}>▶ Revoir</button><a className="arc-ghost" href={replay.url} download={`steamblox-${gameId}-${result.score}.webm`}>Télécharger</a><button className="arc-ghost" onClick={() => shareReplay(true)}>Partager dans Discord</button>{shareMsg && <small>{shareMsg}</small>}</div>}
              {run.kind === "tournament" ? <Link className="arc-play" href={`/tournois?id=${run.tid}`} onClick={exitImmersive}>Retour au tournoi</Link> : <button className="arc-play" onClick={start}>Rejouer</button>}
              <div className="arc-links"><Link href={`/classements?game=${gameId}${run.kind === "daily" ? "&scope=daily" : ""}`} onClick={exitImmersive}>Voir le classement</Link></div>
              <div className="arc-row"><Link className="arc-ghost" href="/steamblox#bibliotheque" onClick={exitImmersive}>Bibliothèque</Link><button className="arc-ghost" onClick={toMenu}>Menu</button></div>
            </div>
          </div>
        )}
      </div>
      {showReplay && replay && <div className="arc-replay-modal" onClick={(e) => { if (e.target === e.currentTarget) setShowReplay(false); }}><div><video src={replay.url} controls autoPlay playsInline /><button className="arc-ghost" onClick={() => setShowReplay(false)}>Fermer</button></div></div>}
      {socket && <TrollKit socket={socket} />}
      {socket && !immersive && <VoiceChat socket={socket} username={username} compact />}
      <CompactGameVoice username={username} />
      {newAchievements.length > 0 && (
        <div className="arc-ach-toast">
          {newAchievements.map(id => { const a = ACH_DEFS.find(x => x.id === id); return a ? <div key={id} className="arc-ach-item"><span className="arc-ach-icon">{a.icon}</span><div><b>{a.label}</b><small>{a.desc}</small></div></div> : null; })}
        </div>
      )}
      {showAchievements && (
        <div className="arc-modal" onClick={(e) => { if (e.target === e.currentTarget) setShowAchievements(false); }}>
          <div className="arc-modal-card">
            <header><b>🏆 Succès</b><button onClick={() => setShowAchievements(false)}>✕</button></header>
            <p className="arc-modal-sub">{achievements.length} / {ACH_DEFS.length} débloqués</p>
            <div className="arc-ach-grid">
              {ACH_DEFS.map(a => <div key={a.id} className={`arc-ach-cell ${achievements.includes(a.id) ? "unlocked" : "locked"}`}><span className="arc-ach-icon">{achievements.includes(a.id) ? a.icon : "🔒"}</span><div><b>{a.label}</b><small>{a.desc}</small></div></div>)}
            </div>
          </div>
        </div>
      )}
      {showOptions && (
        <div className="arc-modal" onClick={(e) => { if (e.target === e.currentTarget) setShowOptions(false); }}>
          <div className="arc-modal-card">
            <header><b>⚙️ Options de jeu</b><button onClick={() => setShowOptions(false)}>✕</button></header>
            <div className="arc-opt-row">
              <span>Difficulté</span>
              <div className="arc-opt-btns">
                {[["easy","Facile"],["normal","Normal"],["hard","Difficile"]].map(([v,l]) => <button key={v} className={difficulty===v?"on":""} onClick={() => { setDifficulty(v); localStorage.setItem(`steamblox:arcade:${mode}:diff`, v); }}>{l}</button>)}
              </div>
            </div>
            <p className="arc-modal-sub">La difficulté sera bientôt appliquée aux jeux. Pour l'instant, elle est sauvegardée dans tes préférences.</p>
          </div>
        </div>
      )}
      {showHostPanel && (
        <div className="arc-modal" onClick={(e) => { if (e.target === e.currentTarget) setShowHostPanel(false); }}>
          <div className="arc-modal-card" style={{ maxWidth: 460, maxHeight: "80vh", overflowY: "auto" }}>
            <header><b>⚙️ Contrôles hôte</b><button onClick={() => setShowHostPanel(false)}>✕</button></header>
            <p className="arc-modal-sub">Tu es l'hôte du salon. Invoque des monstres, modifie la partie et déclenche des événements.</p>
            
            <div style={{ display: "flex", flexDirection: "column", gap: 14, marginTop: 10 }}>
              <div>
                <b style={{ fontSize: 12, textTransform: "uppercase", color: "#a7adbd" }}>👹 Invoquer des monstres</b>
                <div style={{ display: "grid", gridTemplateColumns: "repeat(4,1fr)", gap: 6, marginTop: 6 }}>
                  {MONSTER_TYPES.map(m => (
                    <button key={m.type} onClick={() => hostSpawn(m.type, m.type === "swarm" ? 5 : 1)} title={m.desc} style={{ background: "#161a24", border: "1px solid #292f3e", borderRadius: 8, padding: "8px 4px", display: "flex", flexDirection: "column", alignItems: "center", gap: 3, cursor: "pointer", color: "inherit" }}>
                      <span style={{ fontSize: 20 }}>{m.icon}</span>
                      <span style={{ fontSize: 9, color: "#a7adbd" }}>{m.label}</span>
                    </button>
                  ))}
                </div>
                <button onClick={hostClear} style={{ width: "100%", marginTop: 6, background: "#2a1a1a", border: "1px solid #ff727244", borderRadius: 8, padding: 8, color: "#ff9999", fontWeight: 700, fontSize: 12, cursor: "pointer" }}>🧹 Effacer tous les monstres</button>
              </div>

              <div>
                <b style={{ fontSize: 12, textTransform: "uppercase", color: "#a7adbd" }}>⚙️ Modifier la partie</b>
                <div style={{ display: "flex", flexDirection: "column", gap: 6, marginTop: 6 }}>
                  <label style={{ display: "flex", alignItems: "center", justifyContent: "space-between", fontSize: 12, color: "#a7adbd" }}>Vitesse <input type="range" min="0.3" max="3" step="0.1" defaultValue={hostOpts.speed || 1} onChange={e => hostModify({ speed: parseFloat(e.target.value) })} style={{ accentColor: "#8b7cff" }} /></label>
                  <label style={{ display: "flex", alignItems: "center", justifyContent: "space-between", fontSize: 12, color: "#a7adbd" }}>Gravité <input type="range" min="0.3" max="3" step="0.1" defaultValue={hostOpts.gravity || 1} onChange={e => hostModify({ gravity: parseFloat(e.target.value) })} style={{ accentColor: "#8b7cff" }} /></label>
                  <label style={{ display: "flex", alignItems: "center", justifyContent: "space-between", fontSize: 12, color: "#a7adbd" }}>Taux monstres <input type="range" min="0" max="5" step="0.5" defaultValue={hostOpts.monsterRate || 1} onChange={e => hostModify({ monsterRate: parseFloat(e.target.value) })} style={{ accentColor: "#8b7cff" }} /></label>
                </div>
                <div style={{ display: "grid", gridTemplateColumns: "repeat(3,1fr)", gap: 6, marginTop: 8 }}>
                  {["chaos","friendlyFire","invincible","oneHitKO","slowMotion","bigHead","lowGravity","explosions","darkness"].map(k => (
                    <button key={k} onClick={() => hostModify({ [k]: !hostOpts[k] })} style={{ background: hostOpts[k] ? "#8b7cff" : "#161a24", border: "1px solid #292f3e", borderRadius: 8, padding: "6px 4px", color: hostOpts[k] ? "#0b0c10" : "inherit", fontSize: 11, cursor: "pointer", textAlign: "center" }}>{k.replace(/([A-Z])/g,' $1').trim()}</button>
                  ))}
                </div>
                <button onClick={() => hostModify({ speed: 1, gravity: 1, monsterRate: 1, chaos: 0, friendlyFire: false, invincible: false, oneHitKO: false, slowMotion: 0, bigHead: false, lowGravity: false, explosions: false, darkness: false })} style={{ width: "100%", marginTop: 6, background: "#1a2a1a", border: "1px solid #5ee7c444", borderRadius: 8, padding: 8, color: "#9ee9c4", fontWeight: 700, fontSize: 12, cursor: "pointer" }}>🔄 Réinitialiser tout</button>
              </div>

              <div>
                <b style={{ fontSize: 12, textTransform: "uppercase", color: "#a7adbd" }}>⚡ Actions instantanées</b>
                <div style={{ display: "grid", gridTemplateColumns: "repeat(3,1fr)", gap: 6, marginTop: 6 }}>
                  {HOST_ACTIONS.map(a => (
                    <button key={a.action} onClick={() => hostAction(a.action)} title={a.label} style={{ background: "#161a24", border: "1px solid #292f3e", borderRadius: 8, padding: "8px 4px", display: "flex", flexDirection: "column", alignItems: "center", gap: 3, cursor: "pointer", color: "inherit" }}>
                      <span style={{ fontSize: 18 }}>{a.icon}</span>
                      <span style={{ fontSize: 9, color: "#a7adbd", textAlign: "center" }}>{a.label}</span>
                    </button>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </section>
  );
}
