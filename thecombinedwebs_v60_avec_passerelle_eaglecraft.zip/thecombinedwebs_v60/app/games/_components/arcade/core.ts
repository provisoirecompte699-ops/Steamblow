// @ts-nocheck
/* TheCombinedWebs Arcade Engine v49 — moteur 2D partagé (rendu, physique, IA, effets). */

export const R = (a, b) => a + Math.random() * (b - a);
export const RI = (a, b) => Math.floor(R(a, b + 1));
export const clamp = (v, a, b) => (v < a ? a : v > b ? b : v);
export const dist = (a, b) => Math.hypot(a.x - b.x, a.y - b.y);
export const angTo = (a, b) => Math.atan2(b.y - a.y, b.x - a.x);
export const pick = (a) => a[Math.floor(Math.random() * a.length)];
export const hash = (x, y) => { let h = (x * 374761393 + y * 668265263) | 0; h = Math.imul(h ^ (h >>> 13), 1274126177); return ((h ^ (h >>> 16)) >>> 0) / 4294967295; };
export const angDiff = (a, b) => { let d = b - a; while (d > Math.PI) d -= Math.PI * 2; while (d < -Math.PI) d += Math.PI * 2; return d; };
export const lerpAng = (a, b, k) => a + angDiff(a, b) * k;
export const fmtTime = (s) => { s = Math.max(0, Math.ceil(s)); return `${Math.floor(s / 60)}:${String(s % 60).padStart(2, "0")}`; };
const D4 = [[1, 0], [-1, 0], [0, 1], [0, -1]];
const D8 = [[1, 0], [-1, 0], [0, 1], [0, -1], [1, 1], [1, -1], [-1, 1], [-1, -1]];

export function shade(hex, amt) {
  const n = parseInt(hex.slice(1), 16);
  let r = (n >> 16) & 255, g = (n >> 8) & 255, b = n & 255;
  if (amt >= 0) { r += (255 - r) * amt; g += (255 - g) * amt; b += (255 - b) * amt; }
  else { r *= 1 + amt; g *= 1 + amt; b *= 1 + amt; }
  return `rgb(${r | 0},${g | 0},${b | 0})`;
}
export function rgba(hex, a) { const n = parseInt(hex.slice(1), 16); return `rgba(${(n >> 16) & 255},${(n >> 8) & 255},${n & 255},${a})`; }

/* ---------- Thèmes visuels ---------- */
export const TH = {
  moon: { sky: ["#0d0817", "#1d1030"], f1: "#2a2238", f2: "#2e253e", wTop: "#6b5a80", wSide: "#33284a", dark: 0 },
  neon: { sky: ["#03070f", "#0a1426"], f1: "#08111f", f2: "#0a1424", grid: "#47d7ff", wTop: "#12304a", wSide: "#081a2a", dark: 0 },
  ice: { sky: ["#061424", "#0d2a44"], f1: "#173a57", f2: "#1a4060", wTop: "#bfefff", wSide: "#5aa3c9", dark: 0 },
  cave: { sky: ["#050403", "#0b0806"], f1: "#1c1814", f2: "#201b16", wTop: "#4d3d31", wSide: "#241b15", rTop: "#7a6250", rSide: "#3e3027", dark: 0.93 },
  office: { sky: ["#05060c", "#0b0e1a"], f1: "#1e2440", f2: "#212845", wTop: "#c9cfe0", wSide: "#6c7390", dark: 0.7 },
  arena: { sky: ["#0d0610", "#1d0c22"], f1: "#251329", f2: "#2b172f", wTop: "#4c2c58", wSide: "#22112a", rTop: "#c98a4a", rSide: "#7a4b22", dark: 0 },
  castle: { sky: ["#0c140b", "#16220f"], f1: "#2f4b29", f2: "#33512c", wTop: "#a39882", wSide: "#5d5547", dark: 0 },
  circuit: { sky: ["#010806", "#04140e"], f1: "#06130f", f2: "#071610", grid: "#00ffa3", wTop: "#17372c", wSide: "#0a1a15", dark: 0 },
  violet: { sky: ["#07030f", "#150a2a"], f1: "#110a20", f2: "#130b25", grid: "#c86bff", wTop: "#3a2160", wSide: "#1a0f2e", dark: 0 },
  party: { sky: ["#1b1430", "#2a1f4a"], tiles: ["#ff8fab", "#ffd166", "#8ce99a", "#74c0fc", "#b197fc"], wTop: "#f8f4ff", wSide: "#b9b0d9", dark: 0 },
  roof: { sky: ["#0a0716", "#2a1638"], f1: "#3a3542", f2: "#3e3947", wTop: "#9a97a8", wSide: "#545160", dark: 0 },
};

/* ---------- État ---------- */
export function makeState(mode, theme) {
  return { mode, theme, t: 0, cell: 64, cols: 0, rows: 0, grid: null, W: 0, H: 0, p: null, bots: [], foes: [], shots: [], picks: [], fx: [], txt: [], rings: [], swings: [], decals: [], lights: [], cones: [], score: 0, level: 1, shake: 0, flash: 0, flashC: "#ff2e4d", combo: 1, comboT: 0, msg: "", msgSub: "", msgT: 0, data: {}, cam: { x: 0, y: 0, init: false }, over: false, q: 1, mapDirty: true, kills: 0, flows: new Map(), ghosts: [] };
}
export function actor(x, y, o = {}) {
  return Object.assign({ x, y, vx: 0, vy: 0, r: 18, hp: 3, maxHp: 3, face: 0, dashT: 0, dashCd: 0, actCd: 0, inv: 0, stun: 0, freeze: 0, hitT: 0, color: "#4dabf7", name: "", speed: 300, shape: "blob" }, o);
}

/* ---------- Grille ---------- */
export function newGrid(S, cols, rows, fill = 0) {
  // Carte personnalisée (éditeur de niveaux) : remplace la génération et bloque les écritures du « setup »
  if (S.custom) { cols = S.custom.cols; rows = S.custom.rows; S.cols = cols; S.rows = rows; S.grid = Uint8Array.from(S.custom.grid); S.W = cols * S.cell; S.H = rows * S.cell; S.mapDirty = true; S.flows.clear(); S.lockGrid = true; return; }
  S.cols = cols; S.rows = rows; S.grid = new Uint8Array(cols * rows).fill(fill); S.W = cols * S.cell; S.H = rows * S.cell; S.mapDirty = true; S.flows.clear();
}
/** Après le « setup » d'une carte perso : déverrouille la grille et sort les entités des murs. */
export function settleCustom(S) {
  if (!S.custom || !S.lockGrid) return;
  S.lockGrid = false;
  const sp = S.custom.spawn;
  if (S.p && sp && !S.custom.placed) { const c = center(S, sp.x, sp.y); S.p.x = c.x; S.p.y = c.y; S.custom.placed = true; S.cam.init = false; }
  const fix = (e) => { if (!e) return; if (hits(S, e.x, e.y, e.r || 16)) { const c = randOpen(S, S.p && e !== S.p ? S.p : null, e === S.p ? 0 : 160); e.x = c.x; e.y = c.y; } };
  fix(S.p); for (const a of S.bots) fix(a); for (const f of S.foes) fix(f); for (const k of S.picks) fix({ ...k, r: k.r || 14 }) ;
  for (const k of S.picks) if (hits(S, k.x, k.y, k.r || 14)) { const c = randOpen(S, null, 0); k.x = c.x; k.y = c.y; }
}
export const gget = (S, cx, cy) => (cx < 0 || cy < 0 || cx >= S.cols || cy >= S.rows ? 1 : S.grid[cy * S.cols + cx]);
export const gset = (S, cx, cy, v) => { if (S.lockGrid) return; if (cx >= 0 && cy >= 0 && cx < S.cols && cy < S.rows) { S.grid[cy * S.cols + cx] = v; S.mapDirty = true; S.flows.clear(); } };
export const solidV = (v) => v === 1 || v === 2;
export const cellOf = (S, x, y) => [Math.floor(x / S.cell), Math.floor(y / S.cell)];
export const cellAt = (S, x, y) => { const [cx, cy] = cellOf(S, x, y); return gget(S, cx, cy); };
export const center = (S, cx, cy) => ({ x: cx * S.cell + S.cell / 2, y: cy * S.cell + S.cell / 2 });
export function border(S, v = 1) { for (let x = 0; x < S.cols; x++) { gset(S, x, 0, v); gset(S, x, S.rows - 1, v); } for (let y = 0; y < S.rows; y++) { gset(S, 0, y, v); gset(S, S.cols - 1, y, v); } }
export function fillRect(S, x, y, w, h, v) { for (let j = y; j < y + h; j++) for (let i = x; i < x + w; i++) gset(S, i, j, v); }
export function pillars(S, n, size = 2, avoid = null, minD = 200, v = 1) {
  for (let k = 0, tries = 0; k < n && tries < 400; tries++) {
    const cx = RI(2, S.cols - 2 - size), cy = RI(2, S.rows - 2 - size);
    const c = center(S, cx, cy);
    if (avoid && Math.hypot(c.x - avoid.x, c.y - avoid.y) < minD) continue;
    let ok = true; for (let j = -1; j <= size; j++) for (let i = -1; i <= size; i++) if (gget(S, cx + i, cy + j) !== 0) ok = false;
    if (!ok) continue; fillRect(S, cx, cy, size, size, v); k++;
  }
}
export function hits(S, x, y, r) {
  const c = S.cell, x0 = Math.floor((x - r) / c), x1 = Math.floor((x + r) / c), y0 = Math.floor((y - r) / c), y1 = Math.floor((y + r) / c);
  for (let cy = y0; cy <= y1; cy++) for (let cx = x0; cx <= x1; cx++) {
    if (!solidV(gget(S, cx, cy))) continue;
    const nx = clamp(x, cx * c, cx * c + c), ny = clamp(y, cy * c, cy * c + c);
    if ((x - nx) ** 2 + (y - ny) ** 2 < r * r) return true;
  }
  return false;
}
export function move(S, e, dx, dy) {
  const steps = Math.max(1, Math.ceil(Math.max(Math.abs(dx), Math.abs(dy)) / (e.r * 0.5)));
  const sx = dx / steps, sy = dy / steps; let hit = false;
  for (let i = 0; i < steps; i++) {
    e.x += sx; if (hits(S, e.x, e.y, e.r)) { e.x -= sx; e.vx *= -0.15; hit = true; }
    e.y += sy; if (hits(S, e.x, e.y, e.r)) { e.y -= sy; e.vy *= -0.15; hit = true; }
  }
  return hit;
}
export function randOpen(S, avoid = null, minD = 0, val = 0, margin = 1) {
  for (let i = 0; i < 600; i++) {
    const cx = RI(margin, S.cols - 1 - margin), cy = RI(margin, S.rows - 1 - margin);
    if (gget(S, cx, cy) !== val) continue;
    const c = center(S, cx, cy);
    if (avoid && Math.hypot(c.x - avoid.x, c.y - avoid.y) < minD) continue;
    return c;
  }
  return center(S, S.cols >> 1, S.rows >> 1);
}
export function los(S, a, b) {
  const d = Math.hypot(b.x - a.x, b.y - a.y), n = Math.ceil(d / 16);
  for (let i = 1; i < n; i++) { const x = a.x + (b.x - a.x) * i / n, y = a.y + (b.y - a.y) * i / n; if (solidV(cellAt(S, x, y))) return false; }
  return true;
}
export function flowMap(S, tx, ty) {
  const [cx, cy] = cellOf(S, tx, ty); const key = cy * S.cols + cx;
  const cached = S.flows.get(key); if (cached && S.t - cached.t < 0.4) return cached.d;
  const n = S.cols * S.rows, d = new Int16Array(n).fill(-1), q = new Int32Array(n); let h = 0, t = 0;
  if (cx >= 0 && cy >= 0 && cx < S.cols && cy < S.rows && !solidV(S.grid[key])) { d[key] = 0; q[t++] = key; }
  while (h < t) {
    const k = q[h++], x = k % S.cols, y = (k / S.cols) | 0;
    for (const [ox, oy] of D4) { const nx = x + ox, ny = y + oy; if (nx < 0 || ny < 0 || nx >= S.cols || ny >= S.rows) continue; const nk = ny * S.cols + nx; if (d[nk] >= 0 || solidV(S.grid[nk])) continue; d[nk] = d[k] + 1; q[t++] = nk; }
  }
  if (S.flows.size > 40) S.flows.clear();
  S.flows.set(key, { d, t: S.t });
  return d;
}
export function steer(S, e, tx, ty) {
  const T = { x: tx, y: ty }; const dd = Math.hypot(tx - e.x, ty - e.y);
  if (dd < 1) return [0, 0];
  if (dd < S.cell * 1.1 || los(S, e, T)) return [(tx - e.x) / dd, (ty - e.y) / dd];
  const d = flowMap(S, tx, ty); const [cx, cy] = cellOf(S, e.x, e.y);
  let best = 1e9, bx = 0, by = 0;
  for (const [ox, oy] of D8) {
    const nx = cx + ox, ny = cy + oy; if (nx < 0 || ny < 0 || nx >= S.cols || ny >= S.rows) continue;
    const v = d[ny * S.cols + nx]; if (v < 0) continue;
    if (ox && oy && (solidV(gget(S, cx + ox, cy)) || solidV(gget(S, cx, cy + oy)))) continue;
    const sc = v + (ox && oy ? 0.42 : 0); if (sc < best) { best = sc; bx = ox; by = oy; }
  }
  if (best === 1e9) return [(tx - e.x) / dd, (ty - e.y) / dd];
  const c = center(S, cx + bx, cy + by); const l = Math.hypot(c.x - e.x, c.y - e.y) || 1;
  return [(c.x - e.x) / l, (c.y - e.y) / l];
}

/* ---------- Mouvements ---------- */
export function moveActor(S, e, ix, iy, dt, speed) {
  const l = Math.hypot(ix, iy); if (l > 1) { ix /= l; iy /= l; }
  if (e.stun > 0 || e.freeze > 0) { ix = 0; iy = 0; }
  if (e.dashT > 0) {
    if (Math.random() < 0.85 * S.q) S.fx.push({ x: e.x, y: e.y, vx: 0, vy: 0, life: 0.22, max: 0.22, size: e.r * 0.95, color: e.color, drag: 0, ghost: 1 });
  } else {
    const k = Math.min(1, dt * (e.accel || 11)); e.vx += (ix * speed - e.vx) * k; e.vy += (iy * speed - e.vy) * k;
  }
  if (l > 0.15 && e.dashT <= 0 && !e.lockFace) e.face = lerpAng(e.face, Math.atan2(iy, ix), Math.min(1, dt * 14));
  return move(S, e, e.vx * dt, e.vy * dt);
}
export function dash(S, e, dx, dy) {
  if (e.dashCd > 0 || e.stun > 0 || e.freeze > 0) return false;
  const l = Math.hypot(dx, dy) || 1; const sp = e.dashSpeed || 980;
  e.dashT = e.dashDur || 0.18; e.dashCd = e.dashCdMax || 0.85; e.vx = dx / l * sp; e.vy = dy / l * sp;
  burst(S, e.x, e.y, "#ffffff", 6, 160, 3, 0.3);
  return true;
}
export function tickActor(e, dt) { e.dashT -= dt; e.dashCd -= dt; e.actCd -= dt; e.inv -= dt; e.stun -= dt; e.freeze -= dt; e.hitT -= dt; e.atk = (e.atk || 0) - dt; }
export function separate(list, strength = 0.5) {
  for (let i = 0; i < list.length; i++) for (let j = i + 1; j < list.length; j++) {
    const a = list[i], b = list[j]; if (a.out || b.out) continue; const dx = b.x - a.x, dy = b.y - a.y, d = Math.hypot(dx, dy), m = a.r + b.r;
    if (d > 0 && d < m) { const o = (m - d) * strength / d; a.x -= dx * o; a.y -= dy * o; b.x += dx * o; b.y += dy * o; }
  }
}

/* ---------- Effets ---------- */
export function burst(S, x, y, color, n = 14, sp = 260, size = 4, life = 0.6, opt = {}) {
  n = Math.ceil(n * S.q);
  for (let i = 0; i < n; i++) {
    const a = opt.a != null ? opt.a + R(-(opt.spread || 0.6), opt.spread || 0.6) : R(0, Math.PI * 2), v = R(0.25, 1) * sp;
    S.fx.push({ x, y, vx: Math.cos(a) * v, vy: Math.sin(a) * v, life: R(life * 0.55, life), max: life, size: R(size * 0.6, size * 1.3), color, drag: opt.drag ?? 3.2, g: opt.g || 0, sq: opt.sq });
  }
  if (S.fx.length > 700) S.fx.splice(0, S.fx.length - 700);
}
export function floatText(S, x, y, text, color = "#ffffff", size = 18) { S.txt.push({ x, y, text, color, life: 1.1, size }); }
export function banner(S, msg, sub = "", t = 2) { S.msg = msg; S.msgSub = sub; S.msgT = t; }
export function shakeIt(S, v) { S.shake = Math.max(S.shake, v); }

/* ---------- Son (WebAudio, aucun fichier) ---------- */
let AC = null; let lastShot = 0;
export const audio = { muted: false };
export function sfx(kind) {
  if (audio.muted || typeof window === "undefined") return;
  try {
    AC = AC || new (window.AudioContext || window.webkitAudioContext)();
    const t = AC.currentTime; if (kind === "shoot") { if (t - lastShot < 0.06) return; lastShot = t; }
    const P = { pick: [880, 1480, 0.09, "triangle", 0.07], hurt: [240, 70, 0.22, "sawtooth", 0.1], boom: [140, 35, 0.4, "sawtooth", 0.11], shoot: [720, 380, 0.05, "square", 0.025], hit: [320, 140, 0.07, "square", 0.05], dash: [380, 760, 0.08, "sine", 0.05], win: [523, 1046, 0.45, "triangle", 0.09], act: [500, 980, 0.13, "triangle", 0.06], tick: [1200, 1200, 0.03, "square", 0.02], fall: [600, 90, 0.5, "sine", 0.07] }[kind];
    if (!P) return;
    const o = AC.createOscillator(), g = AC.createGain();
    o.type = P[3]; o.frequency.setValueAtTime(P[0], t); o.frequency.exponentialRampToValueAtTime(Math.max(30, P[1]), t + P[2]);
    g.gain.setValueAtTime(P[4], t); g.gain.exponentialRampToValueAtTime(0.0001, t + P[2]);
    o.connect(g).connect(AC.destination); o.start(t); o.stop(t + P[2] + 0.02);
  } catch { /* audio indisponible */ }
}

/* ---------- Combat ---------- */
export function hurt(S, e, dmg = 1, from = null) {
  if (e.inv > 0 || e.dashT > 0 || e.out) return false;
  e.hp -= dmg; e.inv = e === S.p ? 1.1 : 0.15; e.hitT = 0.12;
  if (from) { const a = angTo(from, e); e.vx += Math.cos(a) * 420; e.vy += Math.sin(a) * 420; }
  burst(S, e.x, e.y, e === S.p ? "#ff4d6d" : e.color, 16, 300, 4, 0.5);
  if (e === S.p) { shakeIt(S, 13); S.flash = 0.28; S.flashC = "#ff2e4d"; S.combo = 1; sfx("hurt"); }
  return true;
}
export function damageFoe(S, f, d, from = null, kb = 380) {
  if (f.dead) return; f.hp -= d; f.hitT = 0.1;
  if (from) { const a = angTo(from, f); f.vx += Math.cos(a) * kb / (f.mass || 1); f.vy += Math.sin(a) * kb / (f.mass || 1); }
  burst(S, f.x, f.y, "#ffffff", 5, 200, 3, 0.25);
  sfx("hit");
  if (f.hp <= 0) killFoe(S, f);
}
export function killFoe(S, f) {
  if (f.dead) return; f.dead = true; S.kills++;
  const pts = Math.round((f.score || 50) * S.combo); S.score += pts;
  S.combo = Math.min(8, S.combo + 0.25); S.comboT = 2.5;
  burst(S, f.x, f.y, f.color, 24, 340, 5, 0.75); burst(S, f.x, f.y, "#ffffff", 8, 200, 3, 0.4);
  S.rings.push({ x: f.x, y: f.y, r: f.r, max: f.r * 3, life: 0.35, maxLife: 0.35, color: f.color });
  floatText(S, f.x, f.y - 22, `+${pts}`, "#ffd166"); shakeIt(S, f.r > 22 ? 9 : 4); sfx("boom");
  const roll = Math.random(); const dp = f.drops ?? 0.1;
  if (roll < dp) S.picks.push({ x: f.x, y: f.y, kind: pick(f.dropKinds || ["heart"]), r: 14, t: 0, life: 12 });
}
export function swing(S, e, arc, range, dmg, kb, color = "#ffffff") {
  const a = e.face; let n = 0;
  S.swings.push({ x: e.x, y: e.y, a, arc, range, life: 0.16, max: 0.16, color });
  for (const f of S.foes) {
    if (f.dead) continue; const d = dist(e, f); if (d > range + f.r) continue;
    if (Math.abs(angDiff(a, angTo(e, f))) > arc + 0.25) continue;
    damageFoe(S, f, dmg, e, kb); f.stun = Math.max(f.stun, 0.25); n++;
  }
  // casse les blocs destructibles devant soi
  for (const da of [-arc * 0.6, 0, arc * 0.6]) {
    const x = e.x + Math.cos(a + da) * (e.r + range * 0.55), y = e.y + Math.sin(a + da) * (e.r + range * 0.55);
    const [cx, cy] = cellOf(S, x, y);
    if (gget(S, cx, cy) === 2) { gset(S, cx, cy, 0); const c = center(S, cx, cy); burst(S, c.x, c.y, TH[S.theme].rTop || "#a07a50", 22, 300, 6, 0.7, { g: 400 }); shakeIt(S, 5); sfx("boom"); S.onBreak && S.onBreak(S, cx, cy, c); }
  }
  if (n) { S.combo = Math.min(8, S.combo + 0.1 * n); S.comboT = 2.5; shakeIt(S, 3); }
  return n;
}
export function fire(S, from, a, o = {}) {
  const sp = o.speed || 950;
  S.shots.push({ x: from.x + Math.cos(a) * (from.r + 4), y: from.y + Math.sin(a) * (from.r + 4), vx: Math.cos(a) * sp, vy: Math.sin(a) * sp, r: o.r || 5, life: o.life || 1.2, foe: !!o.foe, dmg: o.dmg || 1, color: o.color || "#ffffff" });
}
export function updateShots(S, dt) {
  for (const b of S.shots) {
    b.x += b.vx * dt; b.y += b.vy * dt; b.life -= dt;
    if (b.acc) { b.vx *= 1 + b.acc * dt; b.vy *= 1 + b.acc * dt; }
    if (solidV(cellAt(S, b.x, b.y))) { b.life = 0; burst(S, b.x, b.y, b.color, 5, 160, 2.5, 0.3); continue; }
    if (b.foe) {
      const p = S.p; const d = Math.hypot(p.x - b.x, p.y - b.y);
      if (S.graze && !b.grazed && d < p.r + b.r + 18 && d > p.r * 0.55 + b.r) { b.grazed = true; S.score += 10; S.data.grazes = (S.data.grazes || 0) + 1; burst(S, b.x, b.y, "#ffffff", 3, 90, 2, 0.25); }
      if (d < (S.hitbox || p.r) + b.r) { b.life = 0; if (hurt(S, p, b.dmg, b)) S.onPlayerHit && S.onPlayerHit(S); }
    } else {
      for (const f of S.foes) { if (f.dead) continue; if (Math.hypot(f.x - b.x, f.y - b.y) < f.r + b.r) { b.life = 0; damageFoe(S, f, b.dmg, b, 120); break; } }
    }
  }
  S.shots = S.shots.filter((b) => b.life > 0);
}
export function meleeAI(S, f, dt, target, speedMul = 1) {
  if (f.wind > 0) { f.wind -= dt; moveActor(S, f, 0, 0, dt, 0); if (f.wind <= 0) { if (dist(f, target) < f.r + target.r + 16) hurt(S, target, f.dmg || 1, f); f.atk = f.atkCd || 1.1; } return; }
  const [dx, dy] = steer(S, f, target.x, target.y);
  moveActor(S, f, dx, dy, dt, f.speed * speedMul);
  if (dist(f, target) < f.r + target.r + 8 && f.atk <= 0 && f.stun <= 0) f.wind = f.windT || 0.32;
}

/* ---------- Dessin ---------- */
export function rr(g, x, y, w, h, r) { g.beginPath(); g.moveTo(x + r, y); g.arcTo(x + w, y, x + w, y + h, r); g.arcTo(x + w, y + h, x, y + h, r); g.arcTo(x, y + h, x, y, r); g.arcTo(x, y, x + w, y, r); g.closePath(); }

function floorCell(g, S, th, x, y) {
  const c = S.cell, px = x * c, py = y * c, h = hash(x, y), h2 = hash(y + 7, x + 3);
  if (S.theme === "party") {
    g.fillStyle = "#2b2340"; g.fillRect(px, py, c, c);
    g.fillStyle = th.tiles[(x + y * 3) % th.tiles.length]; g.globalAlpha = (x + y) % 2 ? 0.62 : 0.5; rr(g, px + 3, py + 3, c - 6, c - 6, 12); g.fill();
    g.globalAlpha = 0.28; g.fillStyle = "#fff"; rr(g, px + 9, py + 7, c - 18, 9, 4.5); g.fill(); g.globalAlpha = 1; return;
  }
  g.fillStyle = (x + y) % 2 ? th.f1 : th.f2; g.fillRect(px, py, c, c);
  g.fillStyle = `rgba(255,255,255,${0.01 + h * 0.028})`; g.fillRect(px, py, c, c);
  switch (S.theme) {
    case "neon": case "violet": case "circuit": {
      g.strokeStyle = th.grid; g.globalAlpha = 0.14; g.lineWidth = 1; g.strokeRect(px + 0.5, py + 0.5, c - 1, c - 1);
      if (S.theme === "circuit" && h > 0.72) { g.globalAlpha = 0.28; g.beginPath(); g.moveTo(px + 8, py + c * h2); g.lineTo(px + c * 0.5, py + c * h2); g.lineTo(px + c * 0.5, py + c - 8); g.stroke(); g.fillStyle = th.grid; g.beginPath(); g.arc(px + c * 0.5, py + c - 8, 3, 0, 7); g.fill(); }
      if (S.theme === "violet") { g.globalAlpha = 0.35; g.fillStyle = th.grid; g.fillRect(px - 1.5, py - 1.5, 3, 3); }
      g.globalAlpha = 1; break;
    }
    case "cave": case "moon": {
      for (let i = 0; i < 3; i++) { const a = hash(x * 3 + i, y * 5 - i); g.fillStyle = a > 0.5 ? "rgba(255,255,255,.035)" : "rgba(0,0,0,.18)"; g.beginPath(); g.ellipse(px + c * hash(x + i, y), py + c * hash(x, y + i), 2 + a * 5, 1.5 + a * 3, 0, 0, 7); g.fill(); }
      if (S.theme === "moon" && h > 0.85) { g.strokeStyle = "rgba(0,0,0,.25)"; g.lineWidth = 2; g.beginPath(); g.arc(px + c / 2, py + c / 2, 10 + h2 * 10, 0, 7); g.stroke(); g.strokeStyle = "rgba(255,255,255,.05)"; g.beginPath(); g.arc(px + c / 2 + 1, py + c / 2 + 2, 10 + h2 * 10, 0.3, 2.6); g.stroke(); }
      break;
    }
    case "ice": { g.strokeStyle = "rgba(255,255,255,.07)"; g.lineWidth = 2; g.beginPath(); g.moveTo(px + c * h, py); g.lineTo(px, py + c * h); g.stroke(); if (h2 > 0.8) { g.fillStyle = "rgba(255,255,255,.12)"; g.fillRect(px + c * h, py + c * h2, 3, 3); } break; }
    case "office": { g.fillStyle = "rgba(255,255,255,.025)"; for (let i = 0; i < c; i += 8) g.fillRect(px, py + i, c, 1); g.strokeStyle = "rgba(0,0,0,.25)"; g.strokeRect(px + 0.5, py + 0.5, c - 1, c - 1); break; }
    case "arena": { g.strokeStyle = "rgba(255,92,138,.08)"; g.lineWidth = 2; g.strokeRect(px + 4, py + 4, c - 8, c - 8); break; }
    case "castle": {
      const cx = S.cols / 2, cy = S.rows / 2; if (Math.hypot(x + 0.5 - cx, y + 0.5 - cy) < 4.2) { g.fillStyle = "#6e6a5e"; g.fillRect(px, py, c, c); g.fillStyle = "#7d7869"; for (let i = 0; i < 4; i++) { rr(g, px + (i % 2) * 32 + 2, py + (i >> 1) * 32 + 2, 28, 28, 6); g.fill(); } }
      else { g.strokeStyle = "rgba(160,220,120,.18)"; g.lineWidth = 1.5; for (let i = 0; i < 5; i++) { const bx = px + c * hash(x + i * 3, y), by = py + c * hash(x, y + i * 3); g.beginPath(); g.moveTo(bx, by); g.lineTo(bx + 2, by - 6); g.stroke(); } }
      break;
    }
    case "roof": { g.fillStyle = "rgba(0,0,0,.18)"; for (let i = 0; i < 7; i++) g.fillRect(px + c * hash(x + i, y * 2), py + c * hash(x * 2, y + i), 2, 2); g.strokeStyle = "rgba(0,0,0,.2)"; g.strokeRect(px + 0.5, py + 0.5, c - 1, c - 1); break; }
  }
}
function block(g, S, th, x, y, v) {
  const c = S.cell, px = x * c, py = y * c, h = 16;
  let top = th.wTop, side = th.wSide;
  if (v === 2) { top = th.rTop || "#8a6a48"; side = th.rSide || "#4a3422"; }
  g.fillStyle = side; g.fillRect(px, py + c - h, c, h);
  const gr = g.createLinearGradient(px, py - h, px, py + c - h); gr.addColorStop(0, shade(top.startsWith("#") ? top : "#888888", 0.12)); gr.addColorStop(1, top); g.fillStyle = gr; g.fillRect(px, py - h, c, c);
  g.fillStyle = "rgba(255,255,255,.08)"; g.fillRect(px, py - h, c, 2);
  g.fillStyle = "rgba(0,0,0,.22)"; g.fillRect(px, py + c - h, c, 2);
  const hh = hash(x, y);
  if (v === 2 && S.theme === "arena") { g.strokeStyle = "rgba(60,30,10,.6)"; g.lineWidth = 3; g.strokeRect(px + 6, py - h + 6, c - 12, c - 12); g.beginPath(); g.moveTo(px + 8, py - h + 8); g.lineTo(px + c - 8, py + c - h - 8); g.moveTo(px + c - 8, py - h + 8); g.lineTo(px + 8, py + c - h - 8); g.stroke(); }
  else if (v === 2) { g.strokeStyle = "rgba(0,0,0,.35)"; g.lineWidth = 2; g.beginPath(); g.moveTo(px + c * hh, py - h + 6); g.lineTo(px + c * 0.5, py - h + c * 0.45); g.lineTo(px + c * 0.8, py + c - h - 6); g.stroke(); for (let i = 0; i < 3; i++) { g.fillStyle = ["#54e7c4", "#ffd166", "#b197fc"][i]; g.globalAlpha = 0.65; g.fillRect(px + 10 + c * 0.6 * hash(x + i, y), py - h + 10 + c * 0.6 * hash(x, y + i), 4, 4); } g.globalAlpha = 1; }
  else if (S.theme === "neon" || S.theme === "violet" || S.theme === "circuit") { g.strokeStyle = th.grid; g.globalAlpha = 0.7; g.lineWidth = 1.5; g.strokeRect(px + 1, py - h + 1, c - 2, c - 2); g.globalAlpha = 1; }
  else if (S.theme === "castle") { g.strokeStyle = "rgba(0,0,0,.18)"; g.lineWidth = 1; for (let j = 0; j < 3; j++) { g.beginPath(); g.moveTo(px, py - h + j * 21 + 21); g.lineTo(px + c, py - h + j * 21 + 21); g.stroke(); } g.fillStyle = "rgba(0,0,0,.25)"; g.fillRect(px + 8, py + c - h + 4, 10, 8); g.fillRect(px + 40, py + c - h + 4, 10, 8); }
  else if (S.theme === "ice") { g.fillStyle = "rgba(255,255,255,.35)"; g.beginPath(); g.moveTo(px + 8, py - h + 8); g.lineTo(px + 24, py - h + 8); g.lineTo(px + 8, py - h + 24); g.fill(); }
  else if (S.theme === "roof") { g.fillStyle = "#6c6a78"; rr(g, px + 8, py - h + 8, c - 16, c - 16, 6); g.fill(); g.strokeStyle = "rgba(0,0,0,.35)"; g.lineWidth = 2; g.beginPath(); g.arc(px + c / 2, py - h + c / 2, 14, 0, 7); g.stroke(); g.beginPath(); g.moveTo(px + c / 2 - 12, py - h + c / 2); g.lineTo(px + c / 2 + 12, py - h + c / 2); g.moveTo(px + c / 2, py - h + c / 2 - 12); g.lineTo(px + c / 2, py - h + c / 2 + 12); g.stroke(); }
  else if (S.theme === "office") { g.fillStyle = "rgba(0,0,0,.08)"; g.fillRect(px, py - h + c / 2, c, 1); }
  else if (S.theme === "cave" || S.theme === "moon") { g.fillStyle = "rgba(0,0,0,.18)"; g.beginPath(); g.ellipse(px + c * hh, py - h + c * 0.5, 10, 6, hh * 3, 0, 7); g.fill(); }
}
export function buildMap(S) {
  const th = TH[S.theme], c = S.cell;
  const cv = S.mapCv || document.createElement("canvas"); cv.width = S.W; cv.height = S.H;
  const g = cv.getContext("2d"); g.clearRect(0, 0, cv.width, cv.height);
  for (let y = 0; y < S.rows; y++) for (let x = 0; x < S.cols; x++) if (gget(S, x, y) !== 3) floorCell(g, S, th, x, y);
  if (S.theme === "roof") {
    for (let y = 0; y < S.rows; y++) for (let x = 0; x < S.cols; x++) {
      if (gget(S, x, y) === 3 || y + 1 >= S.rows || S.grid[(y + 1) * S.cols + x] !== 3) continue;
      const px = x * c, py = (y + 1) * c; const gr = g.createLinearGradient(0, py, 0, py + 58); gr.addColorStop(0, "#2a2733"); gr.addColorStop(1, "rgba(20,16,30,0)"); g.fillStyle = gr; g.fillRect(px, py, c, 58);
      for (let i = 0; i < 3; i++) { g.fillStyle = hash(x * 3 + i, y) > 0.55 ? "rgba(255,210,120,.55)" : "rgba(0,0,0,.35)"; g.fillRect(px + 8 + i * 18, py + 12, 9, 12); }
      g.fillStyle = "#b8b5c4"; g.fillRect(px, py - 3, c, 3);
    }
  }
  g.fillStyle = "rgba(0,0,0,.3)";
  for (let y = 0; y < S.rows; y++) for (let x = 0; x < S.cols; x++) if (solidV(gget(S, x, y))) g.fillRect(x * c + 10, y * c + 6, c, c);
  for (let y = 0; y < S.rows; y++) for (let x = 0; x < S.cols; x++) { const v = gget(S, x, y); if (solidV(v)) block(g, S, th, x, y, v); }
  S.mapCv = cv; S.mapDirty = false;
}

export function drawActor(g, S, e, o = {}) {
  if (e.out && !o.force) return;
  const s = e.r * (o.scale || 1), t = S.t, sp = Math.hypot(e.vx, e.vy);
  const lift = o.lift || 0;
  g.fillStyle = "rgba(0,0,0,.35)"; g.beginPath(); g.ellipse(e.x, e.y + e.r * 0.8, s * (0.95 - lift * 0.01), s * 0.36, 0, 0, 7); g.fill();
  const bob = Math.sin(t * 15 + e.x * 0.02) * Math.min(1, sp / 220) * 2.5;
  g.save(); g.translate(e.x, e.y - bob - lift);
  if (o.spin) g.rotate(o.spin);
  if (e.inv > 0 && e === S.p && Math.floor(t * 18) % 2) g.globalAlpha = 0.45;
  if (o.alpha != null) g.globalAlpha *= o.alpha;
  const col = e.hitT > 0 ? "#ffffff" : e.wind > 0 && Math.floor(t * 24) % 2 ? "#ffffff" : e.color;
  if (o.aura) { g.strokeStyle = o.aura; g.globalAlpha *= 0.9; g.lineWidth = 3; g.beginPath(); g.arc(0, 0, s + 8 + Math.sin(t * 8) * 2, 0, 7); g.stroke(); g.globalAlpha = o.alpha ?? 1; }
  if (S.q > 0.5 && (o.glow || e === S.p)) { g.shadowColor = e.color; g.shadowBlur = 18; }
  const gr = g.createRadialGradient(-s * 0.35, -s * 0.45, s * 0.1, 0, 0, s * 1.15);
  const base = col.startsWith("#") ? col : "#ffffff";
  gr.addColorStop(0, shade(base, 0.45)); gr.addColorStop(0.55, base); gr.addColorStop(1, shade(base, -0.45));
  g.fillStyle = gr; g.strokeStyle = "rgba(0,0,0,.35)"; g.lineWidth = 2.5;
  const shape = e.shape;
  if (shape === "cube") { rr(g, -s, -s, s * 2, s * 2, s * 0.38); g.fill(); g.shadowBlur = 0; g.stroke(); }
  else if (shape === "drone") {
    g.beginPath(); for (let i = 0; i < 6; i++) { const a = i / 6 * Math.PI * 2 + t * 0.8; g.lineTo(Math.cos(a) * s, Math.sin(a) * s); } g.closePath(); g.fill(); g.shadowBlur = 0; g.stroke();
    g.strokeStyle = rgba(base, 0.6); g.lineWidth = 2; g.beginPath(); g.arc(0, 0, s * 1.35, t * 3, t * 3 + 2); g.stroke(); g.beginPath(); g.arc(0, 0, s * 1.35, t * 3 + 3.1, t * 3 + 5.1); g.stroke();
  } else if (shape === "bat") {
    const fl = Math.sin(t * 22 + e.x) * 0.6; g.fillStyle = shade(base, -0.25);
    for (const sd of [-1, 1]) { g.beginPath(); g.moveTo(sd * s * 0.4, 0); g.lineTo(sd * s * 2.1, -s * (0.5 + fl)); g.lineTo(sd * s * 1.5, s * 0.25); g.lineTo(sd * s * 1.0, -s * 0.05); g.closePath(); g.fill(); }
    g.fillStyle = gr; g.beginPath(); g.arc(0, 0, s, 0, 7); g.fill(); g.shadowBlur = 0;
  } else if (shape === "core") {
    for (let i = 0; i < 10; i++) { const a = i / 10 * Math.PI * 2 + t * 0.6; g.fillStyle = rgba(base, 0.75); g.beginPath(); g.moveTo(Math.cos(a - 0.12) * s, Math.sin(a - 0.12) * s); g.lineTo(Math.cos(a) * s * 1.35, Math.sin(a) * s * 1.35); g.lineTo(Math.cos(a + 0.12) * s, Math.sin(a + 0.12) * s); g.fill(); }
    g.fillStyle = gr; g.beginPath(); g.arc(0, 0, s, 0, 7); g.fill(); g.shadowBlur = 0;
    g.strokeStyle = "rgba(255,255,255,.35)"; g.lineWidth = 3; g.beginPath(); g.arc(0, 0, s * 0.72, -t * 2, -t * 2 + 4); g.stroke();
  } else { g.beginPath(); g.arc(0, 0, s, 0, 7); g.fill(); g.shadowBlur = 0; g.stroke(); }
  g.shadowBlur = 0;
  // détails
  if (shape === "knight") { g.fillStyle = "#6c757d"; g.beginPath(); g.arc(0, -s * 0.15, s * 0.95, Math.PI, 0); g.fill(); g.fillStyle = "#212529"; g.fillRect(-s * 0.6, -s * 0.3, s * 1.2, s * 0.22); g.fillStyle = e.plume || "#e03131"; g.beginPath(); g.ellipse(0, -s * 1.05, s * 0.18, s * 0.42, 0, 0, 7); g.fill(); }
  if (o.ears) { g.fillStyle = "#ff3b5c"; for (const sd of [-1, 1]) { g.beginPath(); g.moveTo(sd * s * 0.25, -s * 0.8); g.lineTo(sd * s * 0.85, -s * 1.45); g.lineTo(sd * s * 0.9, -s * 0.5); g.closePath(); g.fill(); } }
  if (o.crown) { g.fillStyle = "#ffd43b"; g.beginPath(); g.moveTo(-s * 0.6, -s * 0.85); g.lineTo(-s * 0.6, -s * 1.35); g.lineTo(-s * 0.3, -s * 1.1); g.lineTo(0, -s * 1.45); g.lineTo(s * 0.3, -s * 1.1); g.lineTo(s * 0.6, -s * 1.35); g.lineTo(s * 0.6, -s * 0.85); g.closePath(); g.fill(); }
  if (shape !== "core" && shape !== "knight" || shape === "knight") {
    const fx = Math.cos(e.face), fy = Math.sin(e.face);
    const eyeY = shape === "knight" ? -s * 0.2 : -s * 0.15;
    if (shape === "drone") { g.fillStyle = "#fff"; g.beginPath(); g.arc(fx * s * 0.25, fy * s * 0.25, s * 0.38, 0, 7); g.fill(); g.fillStyle = "#ff1744"; g.beginPath(); g.arc(fx * s * 0.38, fy * s * 0.38, s * 0.2, 0, 7); g.fill(); }
    else if (shape !== "knight") {
      for (const sd of [-1, 1]) {
        const ex = sd * s * 0.36 + fx * s * 0.22, ey = eyeY + fy * s * 0.16;
        g.fillStyle = "#fff"; g.beginPath(); g.ellipse(ex, ey, s * 0.22, s * 0.27, 0, 0, 7); g.fill();
        g.fillStyle = "#14141f"; g.beginPath(); g.arc(ex + fx * s * 0.08, ey + fy * s * 0.09, s * 0.12, 0, 7); g.fill();
        g.fillStyle = "#fff"; g.beginPath(); g.arc(ex + fx * s * 0.08 - s * 0.04, ey + fy * s * 0.09 - s * 0.05, s * 0.04, 0, 7); g.fill();
        if (e.angry) { g.strokeStyle = "#14141f"; g.lineWidth = 2.5; g.beginPath(); g.moveTo(ex - sd * s * 0.22, ey - s * 0.38); g.lineTo(ex + sd * s * 0.14, ey - s * 0.24); g.stroke(); }
      }
    }
  }
  if (shape === "core") { const a = S.p ? angTo(e, S.p) : 0; g.fillStyle = "#fff"; g.beginPath(); g.arc(0, 0, s * 0.42, 0, 7); g.fill(); g.fillStyle = "#14141f"; g.beginPath(); g.arc(Math.cos(a) * s * 0.18, Math.sin(a) * s * 0.18, s * 0.2, 0, 7); g.fill(); }
  g.fillStyle = "rgba(255,255,255,.28)"; g.beginPath(); g.ellipse(-s * 0.35, -s * 0.55, s * 0.28, s * 0.14, -0.6, 0, 7); g.fill();
  g.restore();
  if (o.name || (e.name && e !== S.p && o.name !== false)) {
    g.font = "700 13px system-ui, sans-serif"; g.textAlign = "center"; const nm = o.name || e.name; const w = g.measureText(nm).width + 12;
    g.fillStyle = "rgba(8,10,18,.6)"; rr(g, e.x - w / 2, e.y - s - 34 - lift, w, 19, 9.5); g.fill(); g.fillStyle = "#fff"; g.fillText(nm, e.x, e.y - s - 20 - lift);
  }
  if (o.hpBar && e.hp < e.maxHp) { const w = s * 2; g.fillStyle = "rgba(0,0,0,.5)"; g.fillRect(e.x - w / 2, e.y - s - 12, w, 4); g.fillStyle = e.color; g.fillRect(e.x - w / 2, e.y - s - 12, w * Math.max(0, e.hp / e.maxHp), 4); }
}

export function drawPick(g, S, pk) {
  const t = S.t + pk.x * 0.01, b = Math.sin(t * 4) * 4; const x = pk.x, y = pk.y - b;
  if (pk.life != null && pk.life < 3 && Math.floor(S.t * 8) % 2) return;
  g.fillStyle = "rgba(0,0,0,.3)"; g.beginPath(); g.ellipse(pk.x, pk.y + 14, 11 - b * 0.5, 4, 0, 0, 7); g.fill();
  g.save(); g.translate(x, y);
  const glow = (c) => { if (S.q > 0.5) { g.shadowColor = c; g.shadowBlur = 16; } };
  switch (pk.kind) {
    case "star": { glow("#ffd43b"); g.rotate(t * 1.5); g.fillStyle = "#ffd43b"; g.beginPath(); for (let i = 0; i < 10; i++) { const r = i % 2 ? 6 : 14, a = i / 10 * Math.PI * 2 - Math.PI / 2; g.lineTo(Math.cos(a) * r, Math.sin(a) * r); } g.closePath(); g.fill(); break; }
    case "crystal": case "gem": { const c = pk.color || "#7cf3ff"; glow(c); const w = 10 + Math.cos(t * 3) * 3; const gr = g.createLinearGradient(-w, -16, w, 16); gr.addColorStop(0, "#ffffff"); gr.addColorStop(0.4, c); gr.addColorStop(1, shade(c, -0.5)); g.fillStyle = gr; g.beginPath(); g.moveTo(0, -17); g.lineTo(w, -4); g.lineTo(0, 17); g.lineTo(-w, -4); g.closePath(); g.fill(); g.shadowBlur = 0; g.strokeStyle = "rgba(255,255,255,.6)"; g.lineWidth = 1.2; g.beginPath(); g.moveTo(-w, -4); g.lineTo(w, -4); g.stroke(); break; }
    case "heart": { glow("#ff4d6d"); g.fillStyle = "#ff4d6d"; g.beginPath(); g.moveTo(0, 12); g.bezierCurveTo(-18, -2, -10, -16, 0, -6); g.bezierCurveTo(10, -16, 18, -2, 0, 12); g.fill(); break; }
    case "coin": { glow("#ffd43b"); const w = Math.abs(Math.cos(t * 4)) * 12 + 2; g.fillStyle = "#f59f00"; g.beginPath(); g.ellipse(0, 0, w, 13, 0, 0, 7); g.fill(); g.fillStyle = "#ffd43b"; g.beginPath(); g.ellipse(0, 0, w * 0.75, 10, 0, 0, 7); g.fill(); break; }
    case "loot": { const c = pk.color || "#ffd43b"; glow(c); if (pk.style === "bar") { const gr = g.createLinearGradient(0, -10, 0, 10); gr.addColorStop(0, "#fff3bf"); gr.addColorStop(1, "#f08c00"); g.fillStyle = gr; g.beginPath(); g.moveTo(-16, 8); g.lineTo(-10, -8); g.lineTo(10, -8); g.lineTo(16, 8); g.closePath(); g.fill(); } else if (pk.style === "disk") { g.fillStyle = "#4dabf7"; rr(g, -12, -14, 24, 28, 4); g.fill(); g.fillStyle = "#e7f5ff"; g.fillRect(-7, -14, 14, 9); } else { g.fillStyle = c; g.beginPath(); g.moveTo(0, -14); g.lineTo(13, -3); g.lineTo(0, 14); g.lineTo(-13, -3); g.closePath(); g.fill(); g.fillStyle = "rgba(255,255,255,.6)"; g.fillRect(-6, -5, 12, 2); } break; }
    default: { const c = { rapid: "#ffd43b", triple: "#74c0fc", heal: "#ff6b6b", shield: "#63e6be" }[pk.kind] || "#ffffff"; glow(c); g.fillStyle = "rgba(10,12,20,.85)"; rr(g, -14, -14, 28, 28, 8); g.fill(); g.strokeStyle = c; g.lineWidth = 2.5; rr(g, -14, -14, 28, 28, 8); g.stroke(); g.shadowBlur = 0; g.fillStyle = c; g.font = "800 13px system-ui"; g.textAlign = "center"; g.textBaseline = "middle"; g.fillText({ rapid: "R", triple: "3", heal: "+", shield: "S" }[pk.kind] || "?", 0, 1); g.textBaseline = "alphabetic"; }
  }
  g.restore();
}

export function drawFx(g, S) {
  g.save(); g.globalCompositeOperation = "lighter";
  for (const f of S.fx) {
    const k = Math.max(0, f.life / f.max);
    if (f.ghost) { g.globalAlpha = k * 0.35; g.fillStyle = f.color; g.beginPath(); g.arc(f.x, f.y, f.size, 0, 7); g.fill(); continue; }
    g.globalAlpha = k; g.fillStyle = f.color; g.beginPath(); g.arc(f.x, f.y, f.size * (0.4 + k * 0.6), 0, 7); g.fill();
  }
  for (const r of S.rings) { const k = r.life / r.maxLife; g.globalAlpha = k; g.strokeStyle = r.color; g.lineWidth = 3 + k * 5; g.beginPath(); g.arc(r.x, r.y, r.r + (r.max - r.r) * (1 - k), 0, 7); g.stroke(); }
  for (const s of S.swings) { const k = s.life / s.max; g.globalAlpha = k * 0.85; g.strokeStyle = s.color; g.lineWidth = 14 * k + 2; g.beginPath(); g.arc(s.x, s.y, s.range * (0.75 + (1 - k) * 0.35), s.a - s.arc, s.a + s.arc); g.stroke(); }
  g.restore(); g.globalAlpha = 1;
  for (const t of S.txt) { const k = t.life / 1.1; g.globalAlpha = Math.min(1, k * 2); g.font = `800 ${t.size}px system-ui, sans-serif`; g.textAlign = "center"; g.lineWidth = 4; g.strokeStyle = "rgba(0,0,0,.55)"; g.strokeText(t.text, t.x, t.y - (1 - k) * 34); g.fillStyle = t.color; g.fillText(t.text, t.x, t.y - (1 - k) * 34); }
  g.globalAlpha = 1;
}
export function drawShots(g, S) {
  g.save(); g.globalCompositeOperation = "lighter";
  for (const b of S.shots) {
    const a = Math.atan2(b.vy, b.vx), l = Math.min(26, Math.hypot(b.vx, b.vy) * 0.028);
    g.strokeStyle = b.color; g.globalAlpha = 0.45; g.lineWidth = b.r * 2; g.lineCap = "round"; g.beginPath(); g.moveTo(b.x - Math.cos(a) * l, b.y - Math.sin(a) * l); g.lineTo(b.x, b.y); g.stroke();
    g.globalAlpha = 1; g.fillStyle = "#ffffff"; g.beginPath(); g.arc(b.x, b.y, b.r * 0.6, 0, 7); g.fill();
    g.fillStyle = b.color; g.globalAlpha = 0.6; g.beginPath(); g.arc(b.x, b.y, b.r * 1.3, 0, 7); g.fill();
  }
  g.restore(); g.globalAlpha = 1;
}
export function updateFx(S, dt) {
  for (const f of S.fx) { f.life -= dt; f.x += f.vx * dt; f.y += f.vy * dt; const d = Math.exp(-(f.drag || 0) * dt); f.vx *= d; f.vy *= d; f.vy += (f.g || 0) * dt; }
  S.fx = S.fx.filter((f) => f.life > 0);
  for (const t of S.txt) t.life -= dt; S.txt = S.txt.filter((t) => t.life > 0);
  for (const r of S.rings) r.life -= dt; S.rings = S.rings.filter((r) => r.life > 0);
  for (const s of S.swings) s.life -= dt; S.swings = S.swings.filter((s) => s.life > 0);
  S.shake *= Math.exp(-dt * 9); S.flash -= dt; S.msgT -= dt;
  if (S.comboT > 0) { S.comboT -= dt; if (S.comboT <= 0) S.combo = 1; }
}
export function drawLighting(ctx, S, sc, ox, oy, cw, ch, dark) {
  const lc = S.lightCv || (S.lightCv = document.createElement("canvas"));
  if (lc.width !== cw || lc.height !== ch) { lc.width = cw; lc.height = ch; }
  const g = lc.getContext("2d");
  g.globalCompositeOperation = "source-over"; g.clearRect(0, 0, cw, ch); g.fillStyle = `rgba(3,4,8,${dark})`; g.fillRect(0, 0, cw, ch);
  g.globalCompositeOperation = "destination-out";
  for (const L of S.lights) {
    const x = (L.x - ox) * sc, y = (L.y - oy) * sc, r = L.r * sc; if (x < -r || y < -r || x > cw + r || y > ch + r) continue;
    const gr = g.createRadialGradient(x, y, 0, x, y, r); const a = L.a ?? 1;
    gr.addColorStop(0, `rgba(0,0,0,${a})`); gr.addColorStop(0.5, `rgba(0,0,0,${a * 0.7})`); gr.addColorStop(1, "rgba(0,0,0,0)");
    g.fillStyle = gr; g.beginPath(); g.arc(x, y, r, 0, 7); g.fill();
  }
  for (const cone of S.cones) { g.fillStyle = "rgba(0,0,0,.55)"; g.beginPath(); cone.pts.forEach((p, i) => (i ? g.lineTo : g.moveTo).call(g, (p.x - ox) * sc, (p.y - oy) * sc)); g.closePath(); g.fill(); }
  g.globalCompositeOperation = "source-over";
  ctx.drawImage(lc, 0, 0);
  ctx.save(); ctx.globalCompositeOperation = "lighter";
  for (const L of S.lights) { if (!L.c) continue; const x = (L.x - ox) * sc, y = (L.y - oy) * sc, r = L.r * sc * 0.7; if (x < -r || y < -r || x > cw + r || y > ch + r) continue; const gr = ctx.createRadialGradient(x, y, 0, x, y, r); gr.addColorStop(0, rgba(L.c, 0.22)); gr.addColorStop(1, rgba(L.c, 0)); ctx.fillStyle = gr; ctx.beginPath(); ctx.arc(x, y, r, 0, 7); ctx.fill(); }
  ctx.restore();
}
export function visionCone(S, e, half, range, rays = 22) {
  const pts = [{ x: e.x, y: e.y }];
  for (let i = 0; i <= rays; i++) {
    const a = e.face - half + (half * 2 * i) / rays; let d = 0;
    while (d < range) { d += 12; if (solidV(cellAt(S, e.x + Math.cos(a) * d, e.y + Math.sin(a) * d))) break; }
    pts.push({ x: e.x + Math.cos(a) * d, y: e.y + Math.sin(a) * d });
  }
  return pts;
}
export function canSee(S, e, target, half, range) {
  const d = dist(e, target); if (d > range) return false;
  if (Math.abs(angDiff(e.face, angTo(e, target))) > half) return d < 46;
  return los(S, e, target);
}
