// @ts-nocheck
/* Les 11 jeux TheCombinedWebs Arcade — chaque mode : setup / update / dessins / HUD. */
import {
  R, RI, clamp, dist, angTo, pick, angDiff, fmtTime, newGrid, gget, gset, solidV, cellOf, cellAt, center, border, fillRect, pillars, randOpen, los, steer,
  move, moveActor, dash, actor, separate, burst, floatText, banner, shakeIt, sfx, hurt, damageFoe, killFoe, swing, fire, meleeAI, rr, rgba, shade, visionCone, canSee, drawActor,
} from "./core";

const PLAYER = "#4dabf7";
const BOTS = [{ name: "Nova", color: "#ff6b9d" }, { name: "Pixel", color: "#ffd43b" }, { name: "Zed", color: "#69db7c" }, { name: "Mika", color: "#b197fc" }];

export const INFO = {
  meteor: { title: "Meteor Mayhem", tag: "Survie arcade", accent: "#ff7a45", theme: "moon", goal: "Survis le plus longtemps possible sous la pluie de météores.", how: ["Les cercles rouges montrent où un météore va tomber", "Ramasse les étoiles pour faire grimper ton combo", "Bouclier : pulvérise les météores autour de toi"], act: "Bouclier" },
  tag: { title: "Neon Tag", tag: "Chat perché", accent: "#47d7ff", theme: "neon", goal: "Passe le moins de temps possible dans le rôle du chat.", how: ["Le chat porte des oreilles rouges", "Touche quelqu’un pour lui refiler le rôle", "Le dash te sauve au dernier moment"], act: null },
  crystal: { title: "Crystal Rush", tag: "Contre la montre", accent: "#7cf3ff", theme: "ice", goal: "Ramasse tous les cristaux avant la fin du chrono.", how: ["Chaque niveau ajoute des cristaux et des drones", "Toucher un drone coûte 3 secondes", "Aimant : attire les cristaux proches"], act: "Aimant" },
  mines: { title: "Mystic Mines", tag: "Exploration", accent: "#54e7c4", theme: "cave", goal: "Trouve les cristaux dans le noir puis rejoins le portail.", how: ["Ta lanterne éclaire les galeries", "Pioche : casse les roches, assomme les chauves-souris", "Certaines roches cachent des cristaux ou des cœurs"], act: "Pioche" },
  heist: { title: "Pixel Heist", tag: "Infiltration", accent: "#8b7cff", theme: "office", goal: "Vole tous les objets sans te faire repérer, puis file à la sortie.", how: ["Évite les cônes de vision des gardes", "La jauge d’alerte monte quand un garde te voit", "Leurre : fais du bruit pour attirer les gardes ailleurs"], act: "Leurre" },
  brawl: { title: "Block Brawl", tag: "Combat en vagues", accent: "#ff5c8a", theme: "arena", goal: "Repousse les vagues de blocs le plus longtemps possible.", how: ["Enchaîne les coups pour faire monter le combo", "Les caisses se cassent et cachent des cœurs", "Méfie-toi des blocs orange : ils chargent"], act: "Frapper" },
  castle: { title: "Castle Clash", tag: "Contrôle de zone", accent: "#f0b45a", theme: "castle", goal: "Capture le cercle central avant que les chevaliers ne le prennent.", how: ["Reste seul dans le cercle pour le capturer", "Les chevaliers le reprennent si tu t’éloignes", "Épée : frappe en arc devant toi"], act: "Épée" },
  cyber: { title: "Cyber Siege", tag: "Tir en arène", accent: "#00ffa3", theme: "circuit", goal: "Détruis les vagues de drones et tiens le plus longtemps possible.", how: ["Vise à la souris, tire avec clic ou Espace", "Sur mobile, le tir est automatique", "Bonus : tir rapide (R), triple (3), soin (+)"], act: "Tir" },
  arena: { title: "Neon Arena", tag: "Boss rush", accent: "#c86bff", theme: "violet", goal: "Abats les noyaux géants en esquivant leurs salves.", how: ["Seul le petit point blanc au centre peut être touché", "Frôler un projectile rapporte des points", "Le dash rend invincible un court instant"], act: "Tir" },
  party: { title: "Party Pals", tag: "4 mini-jeux", accent: "#ffd166", theme: "party", goal: "Termine premier au classement après 4 mini-jeux.", how: ["Pièces, sol qui s’effondre, roi de la colline, patate chaude", "Pousser : éjecte les joueurs proches", "3 points au 1er, 2 au 2e, 1 au 3e"], act: "Pousser" },
  rooftop: { title: "Rooftop Rivals", tag: "Course sur les toits", accent: "#ff9f43", theme: "roof", goal: "Capture 5 zones avant tes deux rivaux.", how: ["Le dash sert à sauter entre les toits", "Une chute te renvoie au dernier toit", "Pousser : envoie un rival dans le vide"], act: "Pousser" },
};

function aimAngle(S, I) {
  const p = S.p;
  if (I.aim && !I.touch) return angTo(p, I.aim);
  let best = null, bd = 700;
  for (const f of S.foes) { if (f.dead) continue; const d = dist(p, f); if (d < bd && los(S, p, f)) { bd = d; best = f; } }
  return best ? angTo(p, best) : p.face;
}
function playerMove(S, I, dt, mul = 1) {
  const p = S.p; const [ix, iy] = I.move();
  moveActor(S, p, ix, iy, dt, p.speed * mul);
  if (I.dashP) { const dx = ix || iy ? ix : Math.cos(p.face), dy = ix || iy ? iy : Math.sin(p.face); if (dash(S, p, dx, dy)) sfx("dash"); }
  return [ix, iy];
}
function newPlayer(S, x, y, o = {}) { S.p = actor(x, y, Object.assign({ color: PLAYER, name: S.username || "Toi", hp: 3, maxHp: 3, speed: 310, r: 18 }, o)); return S.p; }
function lightsPlayer(S, r = 240, c = null) { S.lights.push({ x: S.p.x, y: S.p.y, r: r * (0.97 + Math.sin(S.t * 9) * 0.03), c }); }

/* ===================== METEOR MAYHEM ===================== */
const meteor = {
  setup(S) {
    newGrid(S, 26, 17); border(S);
    for (let i = 0; i < 5; i++) { const c = randOpen(S, { x: S.W / 2, y: S.H / 2 }, 260); const [cx, cy] = cellOf(S, c.x, c.y); gset(S, cx, cy, 1); }
    newPlayer(S, S.W / 2, S.H / 2, { hp: 3, maxHp: 3 });
    S.data = { spawn: 1.4, stars: 0, mets: [] };
    for (let i = 0; i < 3; i++) S.picks.push({ ...randOpen(S, S.p, 160), kind: "star", r: 16, t: 0 });
    banner(S, "Survis", "Esquive les zones rouges");
  },
  update(S, I, dt) {
    const p = S.p, d = S.data;
    playerMove(S, I, dt);
    S.score += dt * 10;
    S.level = 1 + Math.floor(S.t / 20);
    if (I.actP && p.actCd <= 0) {
      p.actCd = 6; sfx("act"); S.rings.push({ x: p.x, y: p.y, r: 10, max: 190, life: 0.45, maxLife: 0.45, color: "#ffd166" });
      d.mets = d.mets.filter((m) => { if (Math.hypot(m.x - p.x, m.y - p.y) < 190 + m.r * 0.3) { burst(S, m.x, m.y, "#ffd166", 14, 240, 4, 0.5); S.score += 15; return false; } return true; });
    }
    d.spawn -= dt;
    if (d.spawn <= 0) {
      d.spawn = Math.max(0.2, 1.05 - S.t * 0.011);
      const n = S.t > 45 ? 2 : 1;
      for (let i = 0; i < n; i++) {
        const big = S.t > 30 && Math.random() < 0.14;
        const tx = Math.random() < 0.7 ? p.x + p.vx * 0.7 + R(-240, 240) : R(80, S.W - 80);
        const ty = Math.random() < 0.7 ? p.y + p.vy * 0.7 + R(-200, 200) : R(80, S.H - 80);
        const life = big ? 1.6 : 1.2;
        d.mets.push({ x: clamp(tx, 70, S.W - 70), y: clamp(ty, 70, S.H - 70), r: big ? R(120, 150) : R(48, 82), t: life, max: life });
      }
    }
    for (const m of d.mets) {
      m.t -= dt;
      if (m.t <= 0) {
        burst(S, m.x, m.y, "#ff7a45", 26, m.r * 4, 6, 0.8); burst(S, m.x, m.y, "#ffd166", 12, m.r * 3, 4, 0.5); burst(S, m.x, m.y, "#5c4a6e", 12, m.r * 2, 7, 1.2, { drag: 2 });
        S.rings.push({ x: m.x, y: m.y, r: m.r * 0.3, max: m.r * 1.3, life: 0.35, maxLife: 0.35, color: "#ff922b" });
        shakeIt(S, m.r > 100 ? 16 : 8); sfx("boom");
        S.decals.push({ x: m.x, y: m.y, r: m.r * 0.55, life: 14 }); if (S.decals.length > 30) S.decals.shift();
        if (Math.hypot(p.x - m.x, p.y - m.y) < m.r + p.r * 0.5 && hurt(S, p, 1, m) && p.hp <= 0) S.end(false, "Écrasé", [`Temps de survie : ${fmtTime(S.t)}`, `Étoiles : ${d.stars}`]);
      }
    }
    d.mets = d.mets.filter((m) => m.t > 0);
    for (const dc of S.decals) dc.life -= dt; S.decals = S.decals.filter((x) => x.life > 0);
    for (const pk of S.picks) {
      if (Math.hypot(pk.x - p.x, pk.y - p.y) < p.r + pk.r) {
        d.stars++; const pts = Math.round(50 * S.combo); S.score += pts; S.combo = Math.min(6, S.combo + 0.5); S.comboT = 4;
        floatText(S, pk.x, pk.y - 10, `+${pts}`, "#ffd43b"); burst(S, pk.x, pk.y, "#ffd43b", 16, 220, 4, 0.5); sfx("pick");
        Object.assign(pk, randOpen(S, p, 220));
      }
    }
  },
  under(g, S) {
    for (const dc of S.decals) { g.globalAlpha = Math.min(1, dc.life / 3) * 0.6; g.fillStyle = "#130d1c"; g.beginPath(); g.ellipse(dc.x, dc.y, dc.r, dc.r * 0.7, 0, 0, 7); g.fill(); g.strokeStyle = "rgba(255,140,80,.18)"; g.lineWidth = 3; g.stroke(); }
    g.globalAlpha = 1;
    for (const m of S.data.mets) {
      const k = 1 - m.t / m.max, pulse = 0.5 + Math.sin(S.t * 18) * 0.5;
      g.fillStyle = `rgba(255,60,60,${0.08 + k * 0.22})`; g.beginPath(); g.ellipse(m.x, m.y, m.r, m.r * 0.72, 0, 0, 7); g.fill();
      g.strokeStyle = `rgba(255,80,80,${0.5 + pulse * 0.4})`; g.lineWidth = 3; g.stroke();
      g.fillStyle = `rgba(255,120,80,${0.25 + k * 0.3})`; g.beginPath(); g.ellipse(m.x, m.y, m.r * k, m.r * 0.72 * k, 0, 0, 7); g.fill();
    }
  },
  over(g, S) {
    for (const m of S.data.mets) {
      const k = 1 - m.t / m.max, off = (1 - k);
      const x = m.x + off * 520, y = m.y - off * 760, rr2 = m.r * 0.32;
      g.save(); g.globalCompositeOperation = "lighter";
      for (let i = 1; i <= 6; i++) { g.globalAlpha = 0.18 * (1 - i / 7); g.fillStyle = i < 3 ? "#ffd166" : "#ff6b3d"; g.beginPath(); g.arc(x + i * 22, y - i * 32, rr2 * (1 - i * 0.1), 0, 7); g.fill(); }
      g.restore(); g.globalAlpha = 1;
      const gr = g.createRadialGradient(x - rr2 * 0.3, y - rr2 * 0.3, 2, x, y, rr2); gr.addColorStop(0, "#ffe8a3"); gr.addColorStop(0.4, "#ff7a45"); gr.addColorStop(1, "#5a2a1a");
      g.fillStyle = gr; g.beginPath(); g.arc(x, y, rr2, 0, 7); g.fill();
    }
  },
  hud(S) { return { obj: `Survie · ${fmtTime(S.t)}`, left: `Intensité ${S.level}`, right: `${Math.floor(S.score)} pts`, combo: S.combo }; },
};

/* ===================== NEON TAG ===================== */
function fleeDir(S, a, threat) {
  let best = null, bs = -1e9;
  for (let i = 0; i < 12; i++) {
    const ang = i / 12 * Math.PI * 2, dx = Math.cos(ang), dy = Math.sin(ang);
    const px = a.x + dx * 80, py = a.y + dy * 80;
    if (solidV(cellAt(S, px, py)) || solidV(cellAt(S, a.x + dx * 40, a.y + dy * 40))) continue;
    let sc = Math.hypot(px - threat.x, py - threat.y) + (dx * a.vx + dy * a.vy) * 0.08 + R(0, 18);
    const edge = Math.min(px, py, S.W - px, S.H - py); if (edge < 160) sc -= (160 - edge) * 1.2;
    if (sc > bs) { bs = sc; best = [dx, dy]; }
  }
  return best || [0, 0];
}
const tag = {
  setup(S) {
    newGrid(S, 24, 15); border(S); pillars(S, 7, 2, { x: S.W / 2, y: S.H / 2 }, 180);
    newPlayer(S, S.W / 2, S.H / 2, { speed: 320 });
    S.bots = BOTS.map((b, i) => { const c = randOpen(S, S.p, 300); return actor(c.x, c.y, { ...b, speed: 300, itTime: 0, imm: 0 }); });
    S.p.itTime = 0; S.p.imm = 0;
    S.data = { time: 75, all: [S.p, ...S.bots], it: 1 + RI(0, 3) };
    S.data.all[S.data.it].freeze = 1.2;
    banner(S, "Fuis le chat", `${S.data.all[S.data.it].name} est le chat`);
  },
  update(S, I, dt) {
    const d = S.data, p = S.p, it = d.all[d.it];
    d.time -= dt; S.timeLeft = d.time;
    for (const a of d.all) a.imm -= dt;
    playerMove(S, I, dt, d.it === 0 ? 1.06 : 1);
    for (const b of S.bots) {
      b.dashCd = b.dashCd; // timers via tickActor
      if (b === it) {
        let tgt = null, td = 1e9; for (const o of d.all) { if (o === b || o.imm > 0) continue; const dd = dist(b, o); if (dd < td) { td = dd; tgt = o; } }
        if (tgt) { const lead = { x: tgt.x + tgt.vx * 0.25, y: tgt.y + tgt.vy * 0.25 }; const [dx, dy] = steer(S, b, lead.x, lead.y); moveActor(S, b, dx, dy, dt, b.speed * 1.07); if (td < 170 && Math.random() < 0.04) dash(S, b, dx, dy); }
      } else {
        const dd = dist(b, it);
        if (dd < 420) { const [dx, dy] = fleeDir(S, b, it); moveActor(S, b, dx, dy, dt, b.speed); if (dd < 110 && Math.random() < 0.08) dash(S, b, dx, dy); }
        else { b.wT = (b.wT || 0) - dt; if (b.wT <= 0) { b.wT = R(0.8, 2); b.wa = R(0, 7); } moveActor(S, b, Math.cos(b.wa) * 0.5, Math.sin(b.wa) * 0.5, dt, b.speed); }
      }
    }
    it.itTime += dt;
    if (it.freeze <= 0) for (let i = 0; i < d.all.length; i++) {
      const o = d.all[i]; if (o === it || o.imm > 0) continue;
      if (dist(it, o) < it.r + o.r) {
        d.it = i; it.imm = 1.3; o.freeze = 0.8; burst(S, o.x, o.y, "#ff3b5c", 24, 320, 5, 0.6); floatText(S, o.x, o.y - 30, "CHAT !", "#ff3b5c", 22); sfx("hit");
        if (o === p || it === p) { shakeIt(S, 10); banner(S, o === p ? "Tu es le chat" : "Bien joué", o === p ? "Touche quelqu’un vite" : "Fuis maintenant", 1.4); }
        break;
      }
    }
    S.score = Math.max(0, Math.round((S.t - p.itTime) * 20));
    if (d.time <= 0) {
      const rk = [...d.all].sort((a, b) => a.itTime - b.itTime); const pos = rk.indexOf(p);
      S.end(pos === 0, pos === 0 ? "Victoire" : `${pos + 1}e place`, rk.map((a, i) => `${i + 1}. ${a === p ? "Toi" : a.name} — ${a.itTime.toFixed(1)} s en chat`));
    }
  },
  actorOpts(S, a) { return a === S.data.all[S.data.it] ? { ears: true, aura: "#ff3b5c", glow: true } : a.imm > 0 ? { alpha: 0.7 } : {}; },
  hud(S) { const d = S.data, it = d.all[d.it]; return { obj: it === S.p ? "Tu es le chat — touche quelqu’un" : `Fuis ${it.name}`, left: fmtTime(d.time), right: `${S.p.itTime.toFixed(1)} s en chat`, urgent: it === S.p }; },
};

/* ===================== CRYSTAL RUSH ===================== */
const crystal = {
  setup(S, keep) {
    newGrid(S, 28, 17); border(S);
    const mid = { x: S.W / 2, y: S.H / 2 };
    for (let i = 0; i < 14 + S.level * 2; i++) { const c = randOpen(S, mid, 150); const [cx, cy] = cellOf(S, c.x, c.y); gset(S, cx, cy, 1); }
    pillars(S, 3, 2, mid, 200);
    if (!keep) { newPlayer(S, mid.x, mid.y, { speed: 330 }); S.data = { time: 45, got: 0 }; } else { S.p.x = mid.x; S.p.y = mid.y; S.data.time += 20; }
    const need = 8 + S.level * 2; S.data.need = need; S.data.got = 0; S.picks = [];
    for (let i = 0; i < need; i++) S.picks.push({ ...randOpen(S, S.p, 160), kind: "crystal", r: 16, t: R(0, 5), color: pick(["#7cf3ff", "#a5d8ff", "#d0bfff"]) });
    S.foes = [];
    for (let i = 0; i < 2 + S.level; i++) { const c = randOpen(S, S.p, 380); const a = R(0, 7), sp = 120 + S.level * 18; S.foes.push(actor(c.x, c.y, { shape: "drone", color: "#ff4d6d", r: 15, speed: sp, vx: Math.cos(a) * sp, vy: Math.sin(a) * sp, accel: 3 })); }
    banner(S, `Niveau ${S.level}`, `${need} cristaux à ramasser`);
  },
  update(S, I, dt) {
    const p = S.p, d = S.data;
    d.time -= dt; S.timeLeft = d.time;
    playerMove(S, I, dt);
    if (I.actP && p.actCd <= 0) { p.actCd = 8; p.mag = 2.5; sfx("act"); S.rings.push({ x: p.x, y: p.y, r: 20, max: 280, life: 0.5, maxLife: 0.5, color: "#7cf3ff" }); }
    p.mag = (p.mag || 0) - dt;
    for (const f of S.foes) {
      const dd = dist(f, p);
      if (dd < 230 && los(S, f, p)) { const [dx, dy] = steer(S, f, p.x, p.y); moveActor(S, f, dx, dy, dt, f.speed * 0.95); }
      else { const sp = Math.hypot(f.vx, f.vy) || 1; const hit = moveActor(S, f, f.vx / sp, f.vy / sp, dt, f.speed); if (hit) { const a = R(0, 7); f.vx = Math.cos(a) * f.speed; f.vy = Math.sin(a) * f.speed; } }
      f.face = Math.atan2(f.vy, f.vx);
      if (dd < f.r + p.r && p.inv <= 0) { p.inv = 1.2; p.stun = 0.45; d.time -= 3; const a = angTo(f, p); p.vx = Math.cos(a) * 520; p.vy = Math.sin(a) * 520; floatText(S, p.x, p.y - 30, "-3 s", "#ff4d6d", 22); shakeIt(S, 10); S.flash = 0.2; S.flashC = "#ff2e4d"; sfx("hurt"); S.combo = 1; burst(S, p.x, p.y, "#ff4d6d", 14, 260, 4, 0.5); }
    }
    for (const pk of S.picks) {
      if (p.mag > 0 && Math.hypot(pk.x - p.x, pk.y - p.y) < 300) { const a = angTo(pk, p); pk.x += Math.cos(a) * 520 * dt; pk.y += Math.sin(a) * 520 * dt; }
      if (Math.hypot(pk.x - p.x, pk.y - p.y) < p.r + pk.r) { pk.dead = true; d.got++; const pts = Math.round(100 * S.combo); S.score += pts; S.combo = Math.min(6, S.combo + 0.3); S.comboT = 2.2; floatText(S, pk.x, pk.y - 12, `+${pts}`, "#7cf3ff"); burst(S, pk.x, pk.y, pk.color, 18, 260, 4, 0.55); sfx("pick"); }
    }
    S.picks = S.picks.filter((x) => !x.dead);
    if (d.got >= d.need) { S.score += Math.ceil(d.time) * 10; S.level++; sfx("win"); crystal.setup(S, true); }
    if (d.time <= 0) S.end(false, "Temps écoulé", [`Niveau atteint : ${S.level}`, `Cristaux du niveau : ${d.got}/${d.need}`]);
  },
  hud(S) { const d = S.data; return { obj: `Cristaux ${d.got}/${d.need}`, left: `Niveau ${S.level}`, right: `${Math.floor(S.score)} pts`, timer: d.time, urgent: d.time < 10, combo: S.combo }; },
};

/* ===================== MYSTIC MINES ===================== */
const mines = {
  setup(S, keep) {
    newGrid(S, 36, 22, 1);
    const sx = 4, sy = (S.rows / 2) | 0;
    for (let w = 0; w < 5; w++) { let x = sx, y = sy; for (let i = 0; i < 260; i++) { fillRect(S, x, y, 2, 2, 0); const dd = pick([[1, 0], [1, 0], [-1, 0], [0, 1], [0, -1]]); x = clamp(x + dd[0], 1, S.cols - 3); y = clamp(y + dd[1], 1, S.rows - 3); } }
    fillRect(S, sx - 1, sy - 1, 4, 4, 0); border(S);
    const start = center(S, sx, sy);
    S.data = Object.assign(S.data || {}, { need: 6 + S.level * 2, got: 0, rockGem: new Set(), portal: { x: start.x + 32, y: start.y + 32 }, torches: [] });
    for (let y = 1; y < S.rows - 1; y++) for (let x = 1; x < S.cols - 1; x++) { const c = center(S, x, y); if (S.grid[y * S.cols + x] === 0 && Math.hypot(c.x - start.x, c.y - start.y) > 240 && Math.random() < 0.08) S.grid[y * S.cols + x] = 2; }
    S.mapDirty = true; S.flows.clear();
    if (!keep) newPlayer(S, start.x + 32, start.y + 32, { hp: 4, maxHp: 4, speed: 290 }); else { S.p.x = start.x + 32; S.p.y = start.y + 32; }
    S.picks = []; const colors = ["#54e7c4", "#ffd166", "#b197fc", "#ff8fab"];
    for (let i = 0; i < S.data.need + 2; i++) S.picks.push({ ...randOpen(S, S.p, 300), kind: "gem", r: 15, t: R(0, 5), color: pick(colors) });
    let hid = 0; for (let y = 1; y < S.rows - 1 && hid < 3; y++) for (let x = 1; x < S.cols - 1 && hid < 3; x++) if (S.grid[y * S.cols + x] === 2 && Math.random() < 0.08) { S.data.rockGem.add(y * S.cols + x); hid++; }
    for (let i = 0; i < 9; i++) S.data.torches.push(randOpen(S, null, 0));
    S.foes = [];
    for (let i = 0; i < 3 + S.level; i++) { const c = randOpen(S, S.p, 450); S.foes.push(actor(c.x, c.y, { shape: "bat", color: "#9775fa", r: 13, hp: 1, maxHp: 1, speed: 165 + S.level * 8, score: 60, drops: 0.15, dropKinds: ["heart"], accel: 6 })); }
    S.onBreak = (S2, cx, cy, c) => { const k = cy * S2.cols + cx; if (S2.data.rockGem.has(k)) { S2.data.rockGem.delete(k); S2.picks.push({ x: c.x, y: c.y, kind: "gem", r: 15, t: 0, color: "#ffd166" }); floatText(S2, c.x, c.y - 20, "Cristal caché", "#ffd166"); } else if (Math.random() < 0.08) S2.picks.push({ x: c.x, y: c.y, kind: "heart", r: 14, t: 0 }); S2.score += 5; };
    banner(S, `Galerie ${S.level}`, `${S.data.need} cristaux à trouver`);
  },
  update(S, I, dt) {
    const p = S.p, d = S.data;
    playerMove(S, I, dt);
    if (I.aim && !I.touch) p.face = angTo(p, I.aim);
    if (I.actP && p.actCd <= 0) { p.actCd = 0.32; swing(S, p, 0.9, 70, 1, 380, "#54e7c4"); sfx("act"); }
    for (const f of S.foes) {
      if (f.stun > 0) { moveActor(S, f, 0, 0, dt, 0); continue; }
      const dd = dist(f, p);
      if (dd < 340 && los(S, f, p)) { const [dx, dy] = steer(S, f, p.x, p.y); moveActor(S, f, dx + Math.sin(S.t * 6 + f.x) * 0.4, dy + Math.cos(S.t * 5 + f.y) * 0.4, dt, f.speed); }
      else { f.wT = (f.wT || 0) - dt; if (f.wT <= 0) { f.wT = R(1, 2.5); f.wa = R(0, 7); } if (moveActor(S, f, Math.cos(f.wa), Math.sin(f.wa), dt, f.speed * 0.45)) f.wa += Math.PI; }
      if (dd < f.r + p.r && hurt(S, p, 1, f)) { const a = angTo(p, f); f.vx = Math.cos(a) * 400; f.vy = Math.sin(a) * 400; f.stun = 0.6; if (p.hp <= 0) S.end(false, "Perdu dans les mines", [`Galerie atteinte : ${S.level}`, `Cristaux : ${d.got}/${d.need}`]); }
    }
    S.foes = S.foes.filter((f) => !f.dead);
    for (const pk of S.picks) if (Math.hypot(pk.x - p.x, pk.y - p.y) < p.r + pk.r) {
      pk.dead = true; burst(S, pk.x, pk.y, pk.color || "#ff4d6d", 18, 240, 4, 0.5); sfx("pick");
      if (pk.kind === "heart") { p.hp = Math.min(p.maxHp, p.hp + 1); floatText(S, pk.x, pk.y - 12, "+1 PV", "#ff6b6b"); }
      else { d.got++; S.score += 100; floatText(S, pk.x, pk.y - 12, "+100", pk.color); if (d.got === d.need) { banner(S, "Portail ouvert", "Retourne au point de départ", 2.5); sfx("win"); } }
    }
    S.picks = S.picks.filter((x) => !x.dead);
    if (d.got >= d.need && dist(p, d.portal) < 44) { S.score += 500 + p.hp * 50; S.level++; mines.setup(S, true); }
    lightsPlayer(S, 270, "#ffe8a3");
    for (const t of d.torches) S.lights.push({ x: t.x, y: t.y, r: 150 + Math.sin(S.t * 11 + t.x) * 8, c: "#ff922b" });
    for (const pk of S.picks) if (pk.kind === "gem") S.lights.push({ x: pk.x, y: pk.y, r: 70, a: 0.8, c: pk.color });
    S.lights.push({ x: d.portal.x, y: d.portal.y, r: d.got >= d.need ? 220 : 90, c: "#54e7c4" });
  },
  under(g, S) {
    const d = S.data, open = d.got >= d.need, P = d.portal;
    g.save(); g.translate(P.x, P.y); g.globalCompositeOperation = "lighter";
    for (let i = 0; i < 3; i++) { g.strokeStyle = open ? "#54e7c4" : "rgba(84,231,196,.25)"; g.globalAlpha = open ? 0.8 - i * 0.2 : 0.4; g.lineWidth = 4; g.beginPath(); g.ellipse(0, 0, 34 - i * 8, 22 - i * 5, 0, S.t * (2 + i), S.t * (2 + i) + 4.5); g.stroke(); }
    g.restore(); g.globalAlpha = 1;
    for (const t of d.torches) { g.fillStyle = "#3b2a1e"; g.fillRect(t.x - 3, t.y - 6, 6, 18); g.save(); g.globalCompositeOperation = "lighter"; g.fillStyle = "#ffb347"; g.globalAlpha = 0.9; g.beginPath(); g.ellipse(t.x, t.y - 10 + Math.sin(S.t * 14 + t.x) * 1.5, 5, 9, 0, 0, 7); g.fill(); g.restore(); g.globalAlpha = 1; }
  },
  hud(S) { const d = S.data; return { obj: d.got >= d.need ? "Rejoins le portail" : `Cristaux ${d.got}/${d.need}`, left: `Galerie ${S.level}`, right: `${Math.floor(S.score)} pts` }; },
  dark: 0.93,
};

/* ===================== PIXEL HEIST ===================== */
function guardNext(S, g2) {
  const [cx, cy] = cellOf(S, g2.x, g2.y); const opts = [];
  for (const [ox, oy] of [[1, 0], [-1, 0], [0, 1], [0, -1]]) if (!solidV(gget(S, cx + ox, cy + oy))) opts.push([ox, oy]);
  let dir = g2.dir || [1, 0]; const straight = opts.find((o) => o[0] === dir[0] && o[1] === dir[1]);
  const nonBack = opts.filter((o) => !(o[0] === -dir[0] && o[1] === -dir[1]));
  if (straight && Math.random() < 0.72) dir = straight; else if (nonBack.length) dir = pick(nonBack); else if (opts.length) dir = opts[0];
  g2.dir = dir; g2.tgt = center(S, cx + dir[0], cy + dir[1]);
}
const heist = {
  setup(S, keep) {
    newGrid(S, 31, 19); border(S);
    const vx = [8, 15, 23], hy = [9];
    for (const x of vx) for (let y = 1; y < S.rows - 1; y++) gset(S, x, y, 1);
    for (const y of hy) for (let x = 1; x < S.cols - 1; x++) gset(S, x, y, 1);
    const xs = [0, ...vx, S.cols - 1], ys = [0, ...hy, S.rows - 1];
    for (const x of vx) for (let j = 0; j < ys.length - 1; j++) { const y = RI(ys[j] + 2, ys[j + 1] - 3); gset(S, x, y, 0); gset(S, x, y + 1, 0); }
    for (const y of hy) for (let i = 0; i < xs.length - 1; i++) { const x = RI(xs[i] + 2, xs[i + 1] - 3); gset(S, x, y, 0); gset(S, x + 1, y, 0); }
    for (let i = 0; i < xs.length - 1; i++) for (let j = 0; j < ys.length - 1; j++) {
      const x0 = xs[i] + 3, x1 = xs[i + 1] - 3, y0 = ys[j] + 3, y1 = ys[j + 1] - 3; if (x1 <= x0 || y1 <= y0) continue;
      for (let k = 0; k < 2; k++) { const x = RI(x0, x1), y = RI(y0, y1); gset(S, x, y, 1); if (Math.random() < 0.5 && x + 1 <= x1) gset(S, x + 1, y, 1); }
    }
    const start = center(S, 3, S.rows - 3);
    S.data = Object.assign(S.data || {}, { exit: start, need: 4 + S.level, got: 0, alert: 0, lamps: [], lives: keep ? S.data.lives : 3 });
    for (let i = 0; i < xs.length - 1; i++) for (let j = 0; j < ys.length - 1; j++) S.data.lamps.push({ x: (xs[i] + xs[i + 1] + 1) / 2 * S.cell, y: (ys[j] + ys[j + 1] + 1) / 2 * S.cell });
    if (!keep) newPlayer(S, start.x, start.y, { speed: 260, hp: 3, maxHp: 3 }); else { S.p.x = start.x; S.p.y = start.y; }
    S.data.start = { ...start };
    S.picks = []; const styles = ["bar", "disk", "gem"];
    for (let i = 0; i < S.data.need; i++) S.picks.push({ ...randOpen(S, S.p, 520), kind: "loot", style: pick(styles), r: 16, t: R(0, 5), color: pick(["#ffd43b", "#74c0fc", "#ff8fab"]) });
    S.bots = [];
    for (let i = 0; i < 2 + S.level; i++) { const c = randOpen(S, S.p, 480); const gd = actor(c.x, c.y, { name: "", color: "#364fc7", r: 17, speed: 92, state: "patrol", dir: [1, 0] }); guardNext(S, gd); S.bots.push(gd); }
    banner(S, `Casse ${S.level}`, `${S.data.need} objets à voler`);
  },
  caught(S) {
    const d = S.data; d.lives--; d.alert = 0; shakeIt(S, 14); S.flash = 0.35; S.flashC = "#ff2e4d"; sfx("hurt");
    if (d.lives <= 0) { S.end(false, "Arrêté", [`Casse atteint : ${S.level}`, `Objets volés : ${d.got}/${d.need}`]); return; }
    S.p.x = d.start.x; S.p.y = d.start.y; S.p.vx = S.p.vy = 0; S.p.inv = 1.5;
    for (const gd of S.bots) { gd.state = "patrol"; guardNext(S, gd); }
    banner(S, "Repéré", `Retour à l’entrée · ${d.lives} vie${d.lives > 1 ? "s" : ""}`, 2);
  },
  update(S, I, dt) {
    const p = S.p, d = S.data;
    playerMove(S, I, dt);
    if (I.actP && p.actCd <= 0) {
      p.actCd = 6; const a = I.aim && !I.touch ? angTo(p, I.aim) : p.face; const r = I.aim && !I.touch ? Math.min(300, dist(p, I.aim)) : 240;
      let nx = p.x, ny = p.y; for (let k = 0; k < r; k += 12) { const tx = p.x + Math.cos(a) * k, ty = p.y + Math.sin(a) * k; if (solidV(cellAt(S, tx, ty))) break; nx = tx; ny = ty; }
      const noise = { x: nx, y: ny }; S.rings.push({ x: nx, y: ny, r: 8, max: 120, life: 0.6, maxLife: 0.6, color: "#8b7cff" }); burst(S, nx, ny, "#8b7cff", 12, 200, 3, 0.5); sfx("act");
      for (const gd of S.bots) if (gd.state !== "chase" && dist(gd, noise) < 460) { gd.state = "investigate"; gd.inv2 = 4; gd.noise = noise; }
    }
    let seen = false;
    for (const gd of S.bots) {
      const range = gd.state === "chase" ? 330 : 250, half = gd.state === "chase" ? 0.85 : 0.7;
      const sees = p.inv <= 0 && canSee(S, gd, p, half, range);
      if (sees) { seen = true; gd.state = "chase"; gd.lost = 2.2; d.alert += dt * (1.1 + (1 - dist(gd, p) / range) * 1.8); }
      if (gd.state === "chase") {
        gd.lost -= sees ? 0 : dt; const [dx, dy] = steer(S, gd, p.x, p.y); moveActor(S, gd, dx, dy, dt, 150); gd.face = Math.atan2(gd.vy, gd.vx);
        if (gd.lost <= 0) { gd.state = "patrol"; guardNext(S, gd); }
        if (dist(gd, p) < gd.r + p.r) { heist.caught(S); return; }
      } else if (gd.state === "investigate") {
        gd.inv2 -= dt; const [dx, dy] = steer(S, gd, gd.noise.x, gd.noise.y); if (dist(gd, gd.noise) > 30) { moveActor(S, gd, dx, dy, dt, 130); gd.face = Math.atan2(gd.vy, gd.vx); } else { moveActor(S, gd, 0, 0, dt, 0); gd.face += dt * 2.2; }
        if (gd.inv2 <= 0) { gd.state = "patrol"; guardNext(S, gd); }
      } else {
        if (!gd.tgt || dist(gd, gd.tgt) < 6) guardNext(S, gd);
        const dx = gd.tgt.x - gd.x, dy = gd.tgt.y - gd.y, l = Math.hypot(dx, dy) || 1; moveActor(S, gd, dx / l, dy / l, dt, gd.speed + S.level * 6);
      }
      S.cones.push({ pts: visionCone(S, gd, half, range), alert: gd.state === "chase" });
      S.lights.push({ x: gd.x, y: gd.y, r: 60, a: 0.6 });
    }
    if (!seen) d.alert = Math.max(0, d.alert - dt * 0.3);
    if (d.alert >= 1) { heist.caught(S); return; }
    for (const pk of S.picks) if (Math.hypot(pk.x - p.x, pk.y - p.y) < p.r + pk.r) { pk.dead = true; d.got++; S.score += 150; floatText(S, pk.x, pk.y - 14, "+150", "#ffd43b"); burst(S, pk.x, pk.y, pk.color, 18, 220, 4, 0.5); sfx("pick"); if (d.got === d.need) banner(S, "Butin complet", "File vers la sortie", 2.2); }
    S.picks = S.picks.filter((x) => !x.dead);
    if (d.got >= d.need && dist(p, d.exit) < 50) { S.score += 400 + d.lives * 100; S.level++; sfx("win"); heist.setup(S, true); return; }
    lightsPlayer(S, 170);
    for (const l of d.lamps) S.lights.push({ x: l.x, y: l.y, r: 230, a: 0.75, c: "#a5b4fc" });
    for (const pk of S.picks) S.lights.push({ x: pk.x, y: pk.y, r: 60, a: 0.9, c: pk.color });
    S.lights.push({ x: d.exit.x, y: d.exit.y, r: 110, c: d.got >= d.need ? "#69db7c" : null });
  },
  under(g, S) {
    const d = S.data, ex = d.exit, ok = d.got >= d.need;
    g.fillStyle = ok ? "rgba(105,219,124,.25)" : "rgba(255,255,255,.06)"; rr(g, ex.x - 40, ex.y - 40, 80, 80, 12); g.fill();
    g.strokeStyle = ok ? "#69db7c" : "rgba(255,255,255,.25)"; g.setLineDash([8, 6]); g.lineWidth = 3; rr(g, ex.x - 40, ex.y - 40, 80, 80, 12); g.stroke(); g.setLineDash([]);
    g.fillStyle = ok ? "#69db7c" : "rgba(255,255,255,.4)"; g.font = "800 13px system-ui"; g.textAlign = "center"; g.fillText("SORTIE", ex.x, ex.y + 5);
    for (const c of S.cones) { g.fillStyle = c.alert ? "rgba(255,70,70,.2)" : "rgba(255,230,120,.12)"; g.beginPath(); c.pts.forEach((p, i) => (i ? g.lineTo(p.x, p.y) : g.moveTo(p.x, p.y))); g.closePath(); g.fill(); }
  },
  actorOpts(S, a) { return a.state === "chase" ? { aura: "#ff4d4d" } : a.state === "investigate" ? { aura: "#ffd43b" } : {}; },
  hud(S) { const d = S.data; return { obj: d.got >= d.need ? "Rejoins la sortie" : `Butin ${d.got}/${d.need}`, left: `Casse ${S.level} · ${d.lives} vie${d.lives > 1 ? "s" : ""}`, right: `${Math.floor(S.score)} pts`, bar: { v: d.alert, label: "Alerte", color: d.alert > 0.6 ? "#ff4d4d" : "#ffd43b" } }; },
  dark: 0.72,
};

/* ===================== BLOCK BRAWL ===================== */
const BRAWL_FOES = {
  grunt: { r: 17, hp: 2, speed: 150, color: "#ff5c8a", shape: "cube", score: 50, angry: true, drops: 0.08 },
  dasher: { r: 16, hp: 2, speed: 125, color: "#ff922b", shape: "cube", score: 80, angry: true, charge: true, drops: 0.1 },
  brute: { r: 28, hp: 8, speed: 92, color: "#c2255c", shape: "cube", score: 200, angry: true, dmg: 2, mass: 2.5, drops: 0.5 },
};
function spawnWave(S, kinds) {
  S.data.queue = kinds.map((k) => { const c = randOpen(S, S.p, 380); return { ...c, kind: k, t: 0.9 }; });
}
const brawl = {
  setup(S) {
    newGrid(S, 24, 15); border(S);
    for (let i = 0; i < 12; i++) { const c = randOpen(S, { x: S.W / 2, y: S.H / 2 }, 200); const [cx, cy] = cellOf(S, c.x, c.y); gset(S, cx, cy, 2); }
    pillars(S, 2, 2, { x: S.W / 2, y: S.H / 2 }, 260);
    newPlayer(S, S.W / 2, S.H / 2, { hp: 6, maxHp: 6, speed: 300 });
    S.data = { wave: 0, next: 1.2, queue: [] };
    S.onBreak = (S2, cx, cy, c) => { if (Math.random() < 0.18) S2.picks.push({ x: c.x, y: c.y, kind: "heart", r: 14, t: 0, life: 12 }); S2.score += 10; };
  },
  update(S, I, dt) {
    const p = S.p, d = S.data;
    playerMove(S, I, dt);
    if (I.aim && !I.touch) p.face = angTo(p, I.aim); else if (I.touch) { const a = aimAngle(S, I); if (S.foes.length) p.face = a; }
    if (I.actP && p.actCd <= 0) { p.actCd = 0.26; const n = swing(S, p, 1.0, 76, S.combo >= 3 ? 2 : 1, 480, "#ff5c8a"); sfx(n ? "hit" : "act"); }
    if (!S.foes.length && !d.queue.length) {
      d.next -= dt;
      if (d.next <= 0) {
        d.wave++; S.level = d.wave; const k = [];
        for (let i = 0; i < 2 + Math.floor(d.wave * 1.6); i++) k.push("grunt");
        for (let i = 0; i < Math.floor(d.wave / 2); i++) k.push("dasher");
        for (let i = 0; i < Math.floor(d.wave / 3); i++) k.push("brute");
        spawnWave(S, k); banner(S, `Vague ${d.wave}`, `${k.length} blocs arrivent`, 1.6); d.next = 2.2;
        if (d.wave > 1) { p.hp = Math.min(p.maxHp, p.hp + 1); }
      }
    }
    for (const q of d.queue) { q.t -= dt; if (q.t <= 0) { const b = BRAWL_FOES[q.kind]; S.foes.push(actor(q.x, q.y, { ...b, maxHp: b.hp, dropKinds: ["heart"] })); burst(S, q.x, q.y, b.color, 18, 260, 5, 0.5); } }
    d.queue = d.queue.filter((q) => q.t > 0);
    for (const f of S.foes) {
      if (f.stun > 0) { moveActor(S, f, 0, 0, dt, 0); continue; }
      if (f.charge) {
        f.cc = (f.cc || 2) - dt;
        if (f.charging > 0) { f.charging -= dt; move(S, f, f.vx * dt, f.vy * dt); if (dist(f, p) < f.r + p.r + 4) hurt(S, p, 1, f); if (f.charging <= 0) { f.vx *= 0.2; f.vy *= 0.2; } f.face = Math.atan2(f.vy, f.vx); continue; }
        if (f.cw > 0) { f.cw -= dt; f.wind = f.cw; moveActor(S, f, 0, 0, dt, 0); f.face = angTo(f, p); if (f.cw <= 0) { const a = angTo(f, p); f.vx = Math.cos(a) * 720; f.vy = Math.sin(a) * 720; f.charging = 0.4; f.cc = 2.6; } continue; }
        if (f.cc <= 0 && dist(f, p) < 300 && los(S, f, p)) { f.cw = 0.5; continue; }
      }
      meleeAI(S, f, dt, p);
      f.face = angTo(f, p);
    }
    separate(S.foes, 0.5);
    S.foes = S.foes.filter((f) => !f.dead);
    for (const pk of S.picks) { pk.life -= dt; if (Math.hypot(pk.x - p.x, pk.y - p.y) < p.r + pk.r) { pk.dead = true; p.hp = Math.min(p.maxHp, p.hp + 1); floatText(S, pk.x, pk.y - 12, "+1 PV", "#ff6b6b"); sfx("pick"); } }
    S.picks = S.picks.filter((x) => !x.dead && x.life > 0);
    if (p.hp <= 0) S.end(false, "K.O.", [`Vague atteinte : ${d.wave}`, `Blocs détruits : ${S.kills}`]);
  },
  under(g, S) { for (const q of S.data.queue) { const k = q.t / 0.9; g.strokeStyle = `rgba(255,92,138,${1 - k})`; g.lineWidth = 3; g.beginPath(); g.arc(q.x, q.y, 10 + k * 30, 0, 7); g.stroke(); g.fillStyle = "rgba(255,92,138,.15)"; g.beginPath(); g.arc(q.x, q.y, 20, 0, 7); g.fill(); } },
  actorOpts(S, a) { return a === S.p ? {} : { hpBar: true }; },
  hud(S) { return { obj: S.data.queue.length || S.foes.length ? `Vague ${S.data.wave} · ${S.foes.length + S.data.queue.length} blocs` : "Prépare-toi", left: `Vague ${S.data.wave}`, right: `${Math.floor(S.score)} pts`, combo: S.combo }; },
};

/* ===================== CASTLE CLASH ===================== */
const castle = {
  setup(S, keep) {
    newGrid(S, 27, 17); border(S);
    const cx = S.W / 2, cy = S.H / 2;
    for (const [ox, oy] of [[-5, -4], [4, -4], [-5, 3], [4, 3]]) fillRect(S, ((S.cols / 2) | 0) + ox, ((S.rows / 2) | 0) + oy, 1, 1, 1);
    pillars(S, 4, 2, { x: cx, y: cy }, 380);
    S.data = Object.assign(S.data || {}, { ctrl: 0, spawn: 1.5, zone: { x: cx, y: cy, r: 150 }, gates: [center(S, 1, (S.rows / 2) | 0), center(S, S.cols - 2, (S.rows / 2) | 0), center(S, (S.cols / 2) | 0, 1), center(S, (S.cols / 2) | 0, S.rows - 2)] });
    if (!keep) newPlayer(S, cx, cy + 40, { hp: 5, maxHp: 5, speed: 290 }); else { S.p.hp = Math.min(S.p.maxHp, S.p.hp + 2); }
    S.foes = []; S.shots = [];
    banner(S, `Bataille ${S.level}`, "Capture le cercle central");
  },
  update(S, I, dt) {
    const p = S.p, d = S.data, Z = d.zone;
    playerMove(S, I, dt);
    if (I.aim && !I.touch) p.face = angTo(p, I.aim); else if (I.touch && S.foes.length) p.face = aimAngle(S, I);
    if (I.actP && p.actCd <= 0) { p.actCd = 0.36; const n = swing(S, p, 1.35, 86, 1.5, 460, "#f0b45a"); sfx(n ? "hit" : "act"); }
    d.spawn -= dt;
    if (d.spawn <= 0 && S.foes.length < 6 + S.level * 2) {
      d.spawn = Math.max(0.8, 2.6 - S.level * 0.3); const gt = pick(d.gates); const archer = S.level >= 2 && Math.random() < 0.28;
      S.foes.push(actor(gt.x, gt.y, archer ? { shape: "knight", color: "#82c91e", plume: "#2b8a3e", r: 16, hp: 2, maxHp: 2, speed: 95, ranged: true, score: 90, drops: 0.12 } : { shape: "knight", color: "#adb5bd", r: 18, hp: 3, maxHp: 3, speed: 105 + S.level * 6, score: 70, drops: 0.08 }));
      burst(S, gt.x, gt.y, "#f0b45a", 10, 180, 4, 0.5);
    }
    for (const f of S.foes) {
      if (f.stun > 0) { moveActor(S, f, 0, 0, dt, 0); continue; }
      if (f.ranged) {
        const dd = dist(f, p); f.sh = (f.sh || 1.5) - dt;
        if (dd > 320 || !los(S, f, p)) { const [dx, dy] = steer(S, f, p.x, p.y); moveActor(S, f, dx, dy, dt, f.speed); }
        else if (dd < 200) { const a = angTo(p, f); moveActor(S, f, Math.cos(a), Math.sin(a), dt, f.speed); } else moveActor(S, f, 0, 0, dt, 0);
        f.face = angTo(f, p); if (f.sh <= 0 && los(S, f, p) && dd < 420) { f.sh = 1.9; fire(S, f, angTo(f, { x: p.x + p.vx * 0.3, y: p.y + p.vy * 0.3 }), { foe: true, speed: 420, color: "#c0eb75", r: 5 }); }
        continue;
      }
      const target = dist(f, p) < 190 ? p : Z;
      if (target === p) { meleeAI(S, f, dt, p); f.face = angTo(f, p); }
      else { const jitter = { x: Z.x + Math.cos(f.x) * 60, y: Z.y + Math.sin(f.y) * 50 }; const [dx, dy] = steer(S, f, jitter.x, jitter.y); moveActor(S, f, dx, dy, dt, dist(f, Z) < Z.r * 0.6 ? 0 : f.speed); }
    }
    separate([p, ...S.foes], 0.4);
    S.foes = S.foes.filter((f) => !f.dead);
    const pin = dist(p, Z) < Z.r, ein = S.foes.filter((f) => dist(f, Z) < Z.r).length;
    if (pin && !ein) d.ctrl += dt * 8.5; else if (!pin && ein) d.ctrl -= dt * (3 + ein * 2); else if (!pin && !ein) d.ctrl += (0 - d.ctrl) * 0 ;
    d.ctrl = clamp(d.ctrl, -100, 100);
    for (const pk of S.picks) { pk.life -= dt; if (Math.hypot(pk.x - p.x, pk.y - p.y) < p.r + pk.r) { pk.dead = true; p.hp = Math.min(p.maxHp, p.hp + 1); floatText(S, pk.x, pk.y - 12, "+1 PV", "#ff6b6b"); sfx("pick"); } }
    S.picks = S.picks.filter((x) => !x.dead && x.life > 0);
    if (d.ctrl >= 100) { for (const f of S.foes) burst(S, f.x, f.y, "#f0b45a", 16, 260, 4, 0.6); S.score += 600 + S.level * 200; S.level++; sfx("win"); shakeIt(S, 12); castle.setup(S, true); return; }
    if (d.ctrl <= -100) S.end(false, "Le château est tombé", [`Bataille atteinte : ${S.level}`, `Chevaliers vaincus : ${S.kills}`]);
    if (p.hp <= 0) S.end(false, "Tombé au combat", [`Bataille atteinte : ${S.level}`, `Chevaliers vaincus : ${S.kills}`]);
  },
  under(g, S) {
    const Z = S.data.zone, c = S.data.ctrl, col = c >= 0 ? "#4dabf7" : "#ff6b6b";
    g.fillStyle = rgba(c >= 0 ? "#4dabf7" : "#ff6b6b", 0.08 + Math.abs(c) / 100 * 0.18); g.beginPath(); g.arc(Z.x, Z.y, Z.r, 0, 7); g.fill();
    g.strokeStyle = "rgba(255,255,255,.25)"; g.lineWidth = 3; g.setLineDash([12, 10]); g.beginPath(); g.arc(Z.x, Z.y, Z.r, S.t * 0.3, S.t * 0.3 + 7); g.stroke(); g.setLineDash([]);
    g.strokeStyle = col; g.lineWidth = 8; g.lineCap = "round"; g.beginPath(); g.arc(Z.x, Z.y, Z.r + 10, -Math.PI / 2, -Math.PI / 2 + Math.abs(c) / 100 * Math.PI * 2 * (c >= 0 ? 1 : -1), c < 0); g.stroke();
    g.fillStyle = "#5c4033"; g.fillRect(Z.x - 2, Z.y - 50, 4, 50); g.fillStyle = col; g.beginPath(); g.moveTo(Z.x + 2, Z.y - 50); g.lineTo(Z.x + 30 + Math.sin(S.t * 5) * 3, Z.y - 42); g.lineTo(Z.x + 2, Z.y - 32); g.fill();
    for (const gt of S.data.gates) { g.fillStyle = "rgba(0,0,0,.35)"; g.beginPath(); g.arc(gt.x, gt.y, 26, 0, 7); g.fill(); g.strokeStyle = "#f0b45a"; g.lineWidth = 2; g.stroke(); }
  },
  actorOpts(S, a) { return a === S.p ? { crown: true } : { hpBar: true }; },
  hud(S) { const c = Math.round(S.data.ctrl); return { obj: c >= 0 ? `Contrôle ${c} %` : `Les chevaliers capturent : ${-c} %`, left: `Bataille ${S.level}`, right: `${Math.floor(S.score)} pts`, bar: { v: (c + 100) / 200, label: "Contrôle", color: c >= 0 ? "#4dabf7" : "#ff6b6b", center: true } }; },
};

/* ===================== CYBER SIEGE ===================== */
const CY = {
  drone: { shape: "drone", r: 14, hp: 2, speed: 175, color: "#ff4d6d", score: 40, drops: 0.08 },
  turret: { shape: "drone", r: 18, hp: 4, speed: 90, color: "#ffd43b", score: 90, ranged: true, drops: 0.15 },
  tank: { shape: "drone", r: 27, hp: 14, speed: 62, color: "#f06595", score: 220, tank: true, mass: 3, drops: 0.5 },
};
function autoFire(S, I, dt, opt = {}) {
  const p = S.p; p.fc = (p.fc || 0) - dt; p.rapid = (p.rapid || 0) - dt; p.triple = (p.triple || 0) - dt;
  const firing = I.touch ? S.foes.length > 0 : I.act;
  const a = aimAngle(S, I); p.face = a; p.lockFace = true;
  if (firing && p.fc <= 0) {
    p.fc = p.rapid > 0 ? 0.065 : (opt.rate || 0.13);
    const col = opt.color || "#00ffa3";
    fire(S, p, a + R(-0.03, 0.03), { color: col, dmg: opt.dmg || 1 });
    if (p.triple > 0) { fire(S, p, a - 0.16, { color: col }); fire(S, p, a + 0.16, { color: col }); }
    burst(S, p.x + Math.cos(a) * 22, p.y + Math.sin(a) * 22, col, 3, 120, 2.5, 0.15, { a, spread: 0.4 });
    p.vx -= Math.cos(a) * 14; p.vy -= Math.sin(a) * 14; sfx("shoot");
  }
}
function collectPower(S) {
  const p = S.p;
  for (const pk of S.picks) {
    pk.life -= 1 / 60;
    if (Math.hypot(pk.x - p.x, pk.y - p.y) < p.r + pk.r) {
      pk.dead = true; sfx("pick"); burst(S, pk.x, pk.y, "#ffffff", 14, 220, 4, 0.5);
      if (pk.kind === "rapid") { p.rapid = 7; floatText(S, pk.x, pk.y - 14, "Tir rapide", "#ffd43b"); }
      else if (pk.kind === "triple") { p.triple = 7; floatText(S, pk.x, pk.y - 14, "Tir triple", "#74c0fc"); }
      else { p.hp = Math.min(p.maxHp, p.hp + 1); floatText(S, pk.x, pk.y - 14, "+1 PV", "#ff6b6b"); }
    }
  }
  S.picks = S.picks.filter((x) => !x.dead && x.life > 0);
}
const cyber = {
  setup(S) {
    newGrid(S, 30, 18); border(S);
    const mid = { x: S.W / 2, y: S.H / 2 };
    for (let i = 0; i < 9; i++) { const c = randOpen(S, mid, 230); const [cx, cy] = cellOf(S, c.x, c.y); const horiz = Math.random() < 0.5, len = RI(2, 4); for (let k = 0; k < len; k++) gset(S, cx + (horiz ? k : 0), cy + (horiz ? 0 : k), 1); }
    newPlayer(S, mid.x, mid.y, { hp: 5, maxHp: 5, speed: 300 });
    S.data = { wave: 0, next: 1.2, queue: [] };
  },
  update(S, I, dt) {
    const p = S.p, d = S.data;
    playerMove(S, I, dt); autoFire(S, I, dt);
    if (!S.foes.length && !d.queue.length) {
      d.next -= dt;
      if (d.next <= 0) {
        d.wave++; S.level = d.wave; const k = [];
        for (let i = 0; i < 3 + d.wave * 2; i++) k.push("drone");
        for (let i = 0; i < Math.floor(d.wave / 1.5); i++) k.push("turret");
        for (let i = 0; i < Math.floor(d.wave / 4); i++) k.push("tank");
        d.queue = k.map((kind) => ({ ...randOpen(S, p, 420), kind, t: R(0.6, 1.6) })); banner(S, `Vague ${d.wave}`, `${k.length} unités hostiles`, 1.6); d.next = 2;
      }
    }
    for (const q of d.queue) { q.t -= dt; if (q.t <= 0) { const b = CY[q.kind]; S.foes.push(actor(q.x, q.y, { ...b, maxHp: b.hp, dropKinds: ["rapid", "triple", "heal"] })); burst(S, q.x, q.y, b.color, 16, 260, 4, 0.5); } }
    d.queue = d.queue.filter((q) => q.t > 0);
    for (const f of S.foes) {
      const dd = dist(f, p); f.face = angTo(f, p); f.sh = (f.sh ?? R(1, 2)) - dt;
      if (f.ranged) {
        if (dd > 340 || !los(S, f, p)) { const [dx, dy] = steer(S, f, p.x, p.y); moveActor(S, f, dx, dy, dt, f.speed); }
        else { const a = angTo(p, f) + Math.PI / 2; moveActor(S, f, Math.cos(a) * 0.6 + (dd < 240 ? Math.cos(a - Math.PI / 2) : 0), Math.sin(a) * 0.6 + (dd < 240 ? Math.sin(a - Math.PI / 2) : 0), dt, f.speed); }
        if (f.sh <= 0 && dd < 520 && los(S, f, p)) { f.sh = 1.5; fire(S, f, angTo(f, { x: p.x + p.vx * 0.35, y: p.y + p.vy * 0.35 }), { foe: true, speed: 400, color: "#ffd43b", r: 6, life: 2 }); }
      } else {
        const [dx, dy] = steer(S, f, p.x, p.y); moveActor(S, f, dx, dy, dt, f.speed);
        if (f.tank && f.sh <= 0 && dd < 600) { f.sh = 3; for (let i = 0; i < 10; i++) fire(S, f, i / 10 * Math.PI * 2 + S.t, { foe: true, speed: 260, color: "#f06595", r: 7, life: 3 }); }
        if (dd < f.r + p.r && hurt(S, p, f.tank ? 2 : 1, f)) { const a = angTo(p, f); f.vx = Math.cos(a) * 400; f.vy = Math.sin(a) * 400; }
      }
    }
    separate(S.foes, 0.5);
    S.foes = S.foes.filter((f) => !f.dead);
    collectPower(S);
    if (p.hp <= 0) S.end(false, "Système détruit", [`Vague atteinte : ${d.wave}`, `Unités détruites : ${S.kills}`]);
  },
  under(g, S) { for (const q of S.data.queue) { g.strokeStyle = "rgba(0,255,163,.6)"; g.lineWidth = 2; g.beginPath(); g.arc(q.x, q.y, 12 + Math.sin(S.t * 12) * 4, 0, 7); g.stroke(); } },
  actorOpts(S, a) { return a === S.p ? { glow: true } : { hpBar: true, glow: true }; },
  hud(S) { const p = S.p; const pw = [p.rapid > 0 ? `Rapide ${Math.ceil(p.rapid)} s` : "", p.triple > 0 ? `Triple ${Math.ceil(p.triple)} s` : ""].filter(Boolean).join(" · "); return { obj: pw || `Vague ${S.data.wave} · ${S.foes.length + S.data.queue.length} hostiles`, left: `Vague ${S.data.wave}`, right: `${Math.floor(S.score)} pts`, combo: S.combo }; },
};

/* ===================== NEON ARENA ===================== */
const arena = {
  setup(S, keep) {
    newGrid(S, 22, 15); border(S);
    if (!keep) { newPlayer(S, S.W / 2, S.H - 200, { hp: 5, maxHp: 5, speed: 300, r: 14, dashCdMax: 0.7 }); S.hitbox = 6; S.graze = true; S.data = { grazes: 0 }; }
    else { S.p.hp = Math.min(S.p.maxHp, S.p.hp + 1); }
    const hp = 70 + S.level * 55;
    S.foes = [actor(S.W / 2, 260, { shape: "core", color: pick(["#c86bff", "#ff6bcb", "#5cf2ff", "#ffb347"]), r: 46, hp, maxHp: hp, speed: 0, score: 1500, boss: true, mass: 50 })];
    S.shots = []; S.data.pat = 0; S.data.patT = 0; S.data.emit = 0; S.data.spin = 0;
    banner(S, `Noyau ${S.level}`, "Esquive et riposte");
  },
  update(S, I, dt) {
    const p = S.p, d = S.data, b = S.foes.find((f) => f.boss);
    playerMove(S, I, dt); autoFire(S, I, dt, { color: "#c86bff", rate: 0.11 });
    for (const f of S.foes) if (!f.boss) { const [dx, dy] = steer(S, f, p.x, p.y); moveActor(S, f, dx, dy, dt, f.speed); if (dist(f, p) < f.r + S.hitbox + 4) hurt(S, p, 1, f); }
    if (b) {
      b.x += ((S.W / 2 + Math.sin(S.t * 0.45) * 320) - b.x) * dt * 1.2; b.y += ((300 + Math.sin(S.t * 0.9) * 110) - b.y) * dt * 1.2; b.vx = b.vy = 0;
      const rage = b.hp < b.maxHp / 2 ? 1.35 : 1, sp = (170 + S.level * 18) * (rage > 1 ? 1.1 : 1);
      d.patT += dt; if (d.patT > 5.5) { d.patT = 0; d.pat = (d.pat + 1) % 4; }
      d.emit -= dt * rage;
      const col = b.color;
      if (d.emit <= 0) {
        if (d.pat === 0) { d.emit = 0.075; d.spin += 0.23; for (const o of [0, Math.PI]) fire(S, b, d.spin + o, { foe: true, speed: sp, color: col, r: 7, life: 5 }); }
        else if (d.pat === 1) { d.emit = 0.85; const n = 18 + S.level * 3, off = R(0, 1); for (let i = 0; i < n; i++) fire(S, b, (i + off) / n * Math.PI * 2, { foe: true, speed: sp * 0.9, color: "#ffffff", r: 7, life: 5 }); }
        else if (d.pat === 2) { d.emit = 0.5; const a = angTo(b, p); for (let i = -2; i <= 2; i++) fire(S, b, a + i * 0.14, { foe: true, speed: sp * 1.35, color: "#ff6bcb", r: 6, life: 4 }); }
        else { d.emit = 0.13; for (let i = 0; i < 4; i++) fire(S, b, S.t * 1.6 + i * Math.PI / 2, { foe: true, speed: sp * 0.8, color: "#5cf2ff", r: 8, life: 6 }); }
      }
      if (rage > 1) { b.mT = (b.mT || 4) - dt; if (b.mT <= 0) { b.mT = 6; for (let i = 0; i < 2; i++) S.foes.push(actor(b.x + R(-60, 60), b.y + 60, { shape: "drone", color: "#ff4d6d", r: 13, hp: 2, maxHp: 2, speed: 150, score: 40, drops: 0.25, dropKinds: ["heal", "rapid", "triple"] })); } }
    }
    S.foes = S.foes.filter((f) => !f.dead);
    collectPower(S);
    if (!S.foes.some((f) => f.boss)) { burst(S, S.W / 2, 300, "#ffffff", 60, 600, 6, 1.2); shakeIt(S, 20); S.score += 1000 * S.level; S.level++; sfx("win"); arena.setup(S, true); return; }
    if (p.hp <= 0) S.end(false, "Désintégré", [`Noyaux détruits : ${S.level - 1}`, `Frôlements : ${d.grazes || 0}`]);
  },
  over(g, S) { const p = S.p; g.fillStyle = "#ffffff"; g.beginPath(); g.arc(p.x, p.y, S.hitbox, 0, 7); g.fill(); g.strokeStyle = "#c86bff"; g.lineWidth = 2; g.stroke(); },
  actorOpts(S, a) { return a.boss ? { glow: true } : a === S.p ? { glow: true } : { hpBar: true }; },
  hud(S) { const b = S.foes.find((f) => f.boss); return { obj: `Noyau ${S.level}`, left: `Frôlements ${S.data.grazes || 0}`, right: `${Math.floor(S.score)} pts`, bar: b ? { v: b.hp / b.maxHp, label: "Noyau", color: b.color } : null }; },
};

/* ===================== PARTY PALS ===================== */
const ROUNDS = [
  { id: "coins", name: "Pluie de pièces", rule: "Ramasse un maximum de pièces" },
  { id: "floor", name: "Sol qui s’effondre", rule: "Ne reste pas sur les cases orange" },
  { id: "king", name: "Roi de la colline", rule: "Reste seul dans la couronne" },
  { id: "bomb", name: "Patate chaude", rule: "Refile la bombe avant qu’elle n’explose" },
];
function shove(S, a, all) {
  if (a.actCd > 0) return; a.actCd = 1.2; S.rings.push({ x: a.x, y: a.y, r: a.r, max: 95, life: 0.3, maxLife: 0.3, color: a.color });
  for (const o of all) { if (o === a || o.out) continue; const d = dist(a, o); if (d < 95) { const an = angTo(a, o); o.vx += Math.cos(an) * 820; o.vy += Math.sin(an) * 820; o.stun = Math.max(o.stun, 0.25); burst(S, o.x, o.y, "#ffffff", 8, 200, 3, 0.3); } }
  if (a === S.p) sfx("act");
}
const party = {
  setup(S) {
    newGrid(S, 20, 13); border(S);
    newPlayer(S, 0, 0, { speed: 300 });
    S.bots = BOTS.slice(0, 3).map((b) => actor(0, 0, { ...b, speed: 285 }));
    S.data = { round: -1, all: [S.p, ...S.bots], pts: new Map(), phase: "intro" };
    for (const a of S.data.all) S.data.pts.set(a, 0);
    party.next(S);
  },
  next(S) {
    const d = S.data; d.round++;
    if (d.round >= ROUNDS.length) {
      const rk = [...d.all].sort((a, b) => d.pts.get(b) - d.pts.get(a)); const pos = rk.indexOf(S.p);
      S.score = d.pts.get(S.p) * 100 + (pos === 0 ? 500 : 0);
      S.end(pos === 0, pos === 0 ? "Champion de la fête" : `${pos + 1}e place`, rk.map((a, i) => `${i + 1}. ${a === S.p ? "Toi" : a.name} — ${d.pts.get(a)} pts`)); return;
    }
    const R0 = ROUNDS[d.round]; d.cur = R0; d.phase = "intro"; d.pt = 2.6; d.rt = R0.id === "bomb" ? 60 : 25; d.order = [];
    newGrid(S, 20, 13); border(S);
    const spots = [[5, 4], [14, 4], [5, 8], [14, 8]];
    d.all.forEach((a, i) => { const c = center(S, spots[i][0], spots[i][1]); a.x = c.x; a.y = c.y; a.vx = a.vy = 0; a.out = false; a.metric = 0; a.fallT = 0; a.imm = 0; });
    S.picks = []; d.tiles = new Float32Array(S.cols * S.rows); d.fallT = 1.4; d.coinT = 0;
    d.zone = { x: S.W / 2, y: S.H / 2, r: 95 }; d.zoneT = 6;
    d.bombHolder = pick(d.all); d.bomb = R(7, 10);
    banner(S, `Manche ${d.round + 1} · ${R0.name}`, R0.rule, 2.6);
  },
  finishRound(S) {
    const d = S.data, id = d.cur.id; let rk;
    if (id === "coins" || id === "king") rk = [...d.all].sort((a, b) => b.metric - a.metric);
    else { const alive = d.all.filter((a) => !a.out); rk = [...alive, ...[...d.order].reverse()]; }
    const award = [3, 2, 1, 0]; rk.forEach((a, i) => d.pts.set(a, d.pts.get(a) + award[i]));
    d.lastRank = rk; d.phase = "outro"; d.pt = 3;
    const pos = rk.indexOf(S.p); banner(S, pos === 0 ? "Manche gagnée" : `${pos + 1}e de la manche`, rk.map((a, i) => `${i + 1}. ${a === S.p ? "Toi" : a.name}`).join("   "), 3);
    if (pos === 0) sfx("win");
  },
  eliminate(S, a, why) { const d = S.data; if (a.out) return; a.out = true; d.order.push(a); burst(S, a.x, a.y, a.color, 26, 320, 5, 0.8); floatText(S, a.x, a.y - 30, why, "#ffffff", 18); sfx(why === "Boum" ? "boom" : "fall"); if (a === S.p) shakeIt(S, 12); },
  botAI(S, b, dt) {
    const d = S.data, id = d.cur.id, all = d.all;
    let tx = b.x, ty = b.y;
    if (id === "coins") { let best = null, bd = 1e9; for (const c of S.picks) { const dd = dist(b, c) + R(0, 40); if (dd < bd) { bd = dd; best = c; } } if (best) { tx = best.x; ty = best.y; } }
    else if (id === "floor") {
      const [cx, cy] = cellOf(S, b.x, b.y); const bad = (x, y) => solidV(gget(S, x, y)) || d.tiles[y * S.cols + x] !== 0;
      if (bad(cx, cy) || b.goal == null || bad(b.goal[0], b.goal[1])) { let best = null, bd = 1e9; for (let y = 1; y < S.rows - 1; y++) for (let x = 1; x < S.cols - 1; x++) { if (bad(x, y)) continue; const dd = Math.hypot(x - cx, y - cy) + R(0, 1.5); if (dd < bd) { bd = dd; best = [x, y]; } } b.goal = best; }
      if (b.goal) { const c = center(S, b.goal[0], b.goal[1]); tx = c.x; ty = c.y; }
    }
    else if (id === "king") { tx = d.zone.x + Math.cos(S.t + b.x) * 40; ty = d.zone.y + Math.sin(S.t * 1.3 + b.y) * 40; if (dist(b, d.zone) < d.zone.r) for (const o of all) if (o !== b && !o.out && dist(o, b) < 80 && Math.random() < 0.03) shove(S, b, all); }
    else if (id === "bomb") {
      if (d.bombHolder === b) { let best = null, bd = 1e9; for (const o of all) { if (o === b || o.out || o.imm > 0) continue; const dd = dist(o, b); if (dd < bd) { bd = dd; best = o; } } if (best) { tx = best.x; ty = best.y; if (bd < 150 && Math.random() < 0.05) dash(S, b, best.x - b.x, best.y - b.y); } }
      else { const [dx, dy] = fleeDir(S, b, d.bombHolder); moveActor(S, b, dx, dy, dt, b.speed); return; }
    }
    const [dx, dy] = Math.hypot(tx - b.x, ty - b.y) > 8 ? steer(S, b, tx, ty) : [0, 0];
    moveActor(S, b, dx, dy, dt, b.speed);
  },
  update(S, I, dt) {
    const d = S.data, p = S.p, all = d.all;
    if (d.phase === "intro") { d.pt -= dt; for (const a of all) moveActor(S, a, 0, 0, dt, 0); if (d.pt <= 0) d.phase = "play"; return; }
    if (d.phase === "outro") { d.pt -= dt; for (const a of all) moveActor(S, a, 0, 0, dt, 0); if (d.pt <= 0) party.next(S); return; }
    d.rt -= dt; S.timeLeft = d.rt;
    if (!p.out) { playerMove(S, I, dt); if (I.actP) shove(S, p, all); } else { moveActor(S, p, 0, 0, dt, 0); }
    for (const b of S.bots) if (!b.out) party.botAI(S, b, dt);
    for (const a of all) a.imm -= dt;
    separate(all.filter((a) => !a.out), 0.45);
    const id = d.cur.id;
    if (id === "coins") {
      d.coinT -= dt; if (d.coinT <= 0) { d.coinT = 0.32; S.picks.push({ ...randOpen(S, null, 0), kind: "coin", r: 15, t: 0, life: 7 }); }
      for (const c of S.picks) { c.life -= dt; for (const a of all) if (!c.dead && Math.hypot(a.x - c.x, a.y - c.y) < a.r + c.r) { c.dead = true; a.metric++; burst(S, c.x, c.y, "#ffd43b", 10, 200, 3, 0.4); if (a === p) { sfx("pick"); floatText(S, c.x, c.y - 12, "+1", "#ffd43b"); } } }
      S.picks = S.picks.filter((c) => !c.dead && c.life > 0);
    } else if (id === "floor") {
      d.fallT -= dt;
      if (d.fallT <= 0) { d.fallT = Math.max(0.45, 1.4 - (25 - d.rt) * 0.04); const n = 3 + Math.floor((25 - d.rt) / 5); for (let i = 0; i < n; i++) { const x = RI(1, S.cols - 2), y = RI(1, S.rows - 2), k = y * S.cols + x; if (d.tiles[k] === 0) d.tiles[k] = 1.1; } }
      for (let k = 0; k < d.tiles.length; k++) { const v = d.tiles[k]; if (v > 0) { d.tiles[k] = v - dt; if (d.tiles[k] <= 0) { d.tiles[k] = -2.6; const c = center(S, k % S.cols, (k / S.cols) | 0); burst(S, c.x, c.y, "#ff922b", 6, 140, 4, 0.5); } } else if (v < 0) { d.tiles[k] = v + dt; if (d.tiles[k] >= 0) d.tiles[k] = 0; } }
      for (const a of all) { if (a.out || a.dashT > 0) continue; const [cx, cy] = cellOf(S, a.x, a.y); if (d.tiles[cy * S.cols + cx] < 0) party.eliminate(S, a, "Chute"); }
      if (all.filter((a) => !a.out).length <= 1) d.rt = 0;
    } else if (id === "king") {
      d.zoneT -= dt; if (d.zoneT <= 0) { d.zoneT = 6; const c = randOpen(S, d.zone, 260, 0, 2); d.zone.x = c.x; d.zone.y = c.y; }
      const inside = all.filter((a) => !a.out && dist(a, d.zone) < d.zone.r); if (inside.length === 1) inside[0].metric += dt;
    } else if (id === "bomb") {
      const h = d.bombHolder; d.bomb -= dt;
      if (!h.out) for (const o of all) { if (o === h || o.out || o.imm > 0 || h.imm > 0.5) continue; if (dist(o, h) < o.r + h.r + 2) { d.bombHolder = o; h.imm = 0.9; o.imm = 0.3; burst(S, o.x, o.y, "#ff922b", 12, 200, 3, 0.4); if (o === p || h === p) sfx("hit"); break; } }
      if (d.bomb <= 0) { party.eliminate(S, d.bombHolder, "Boum"); S.rings.push({ x: d.bombHolder.x, y: d.bombHolder.y, r: 10, max: 160, life: 0.5, maxLife: 0.5, color: "#ff922b" }); shakeIt(S, 14); const alive = all.filter((a) => !a.out); if (alive.length <= 1) d.rt = 0; else { d.bombHolder = pick(alive); d.bomb = R(6, 9); d.bombHolder.imm = 0.2; } }
    }
    if (d.rt <= 0) party.finishRound(S);
    S.score = d.pts.get(p) * 100;
  },
  under(g, S) {
    const d = S.data;
    if (d.cur?.id === "floor") for (let k = 0; k < d.tiles.length; k++) {
      const v = d.tiles[k]; if (!v) continue; const x = (k % S.cols) * S.cell, y = ((k / S.cols) | 0) * S.cell;
      if (v > 0) { g.fillStyle = `rgba(255,146,43,${0.35 + (Math.sin(S.t * 30) * 0.5 + 0.5) * 0.4})`; rr(g, x + 3, y + 3, S.cell - 6, S.cell - 6, 12); g.fill(); }
      else { const gr = g.createLinearGradient(0, y, 0, y + S.cell); gr.addColorStop(0, "#05030a"); gr.addColorStop(1, "#1b1430"); g.fillStyle = gr; g.fillRect(x, y, S.cell, S.cell); }
    }
    if (d.cur?.id === "king") { const Z = d.zone; g.fillStyle = "rgba(255,212,59,.16)"; g.beginPath(); g.arc(Z.x, Z.y, Z.r, 0, 7); g.fill(); g.strokeStyle = "#ffd43b"; g.lineWidth = 4; g.setLineDash([14, 10]); g.beginPath(); g.arc(Z.x, Z.y, Z.r, S.t, S.t + 7); g.stroke(); g.setLineDash([]); }
  },
  over(g, S) {
    const d = S.data; if (d.cur?.id !== "bomb" || d.bombHolder.out) return;
    const h = d.bombHolder, x = h.x, y = h.y - h.r - 26; g.fillStyle = "#212529"; g.beginPath(); g.arc(x, y, 13, 0, 7); g.fill(); g.strokeStyle = "#868e96"; g.lineWidth = 2; g.beginPath(); g.moveTo(x + 6, y - 10); g.quadraticCurveTo(x + 14, y - 22, x + 8, y - 26); g.stroke();
    g.fillStyle = Math.floor(S.t * 12) % 2 ? "#ffd43b" : "#ff6b3d"; g.beginPath(); g.arc(x + 8, y - 26, 4, 0, 7); g.fill();
    g.fillStyle = "#fff"; g.font = "800 11px system-ui"; g.textAlign = "center"; g.fillText(Math.ceil(d.bomb), x, y + 4);
  },
  actorOpts(S, a) { const d = S.data; if (d.cur?.id === "king" && d.zone && dist(a, d.zone) < d.zone.r) return { crown: true }; return {}; },
  hud(S) {
    const d = S.data, id = d.cur?.id; const p = S.p;
    const obj = d.phase === "play" ? (p.out ? "Éliminé — attends la fin de la manche" : id === "coins" ? `Pièces : ${p.metric}` : id === "king" ? `Temps de roi : ${p.metric.toFixed(1)} s` : id === "bomb" ? (d.bombHolder === p ? "Tu as la bombe — refile-la" : "Évite la bombe") : "Évite les cases orange") : d.cur?.name;
    return { obj, left: `Manche ${d.round + 1}/4`, right: `${d.pts.get(p)} pts`, timer: id === "bomb" ? null : d.phase === "play" ? d.rt : null, board: d.all.map((a) => ({ name: a === p ? "Toi" : a.name, color: a.color, v: d.pts.get(a), m: id === "coins" ? a.metric : id === "king" ? a.metric.toFixed(1) : a.out ? "out" : "" })), urgent: id === "bomb" && d.bombHolder === p };
  },
};

/* ===================== ROOFTOP RIVALS ===================== */
const roof = {
  setup(S) {
    newGrid(S, 36, 22, 3);
    let y = 1; while (y < S.rows - 3) { const h = RI(4, 6); let x = 1; while (x < S.cols - 3) { const w = RI(4, 7); fillRect(S, x, y, Math.min(w, S.cols - 1 - x), Math.min(h, S.rows - 1 - y), 0); if (Math.random() < 0.55) { const ax = x + RI(1, Math.max(1, w - 2)), ay = y + RI(1, Math.max(1, h - 2)); if (ax < S.cols - 1 && ay < S.rows - 1) gset(S, ax, ay, 1); } x += w + RI(1, 2); } y += h + RI(1, 2); }
    newPlayer(S, 0, 0, { speed: 310, dashDur: 0.22, dashCdMax: 0.7 }); Object.assign(S.p, randOpen(S, null, 0, 0));
    S.bots = [{ name: "Rex", color: "#ff922b" }, { name: "Luna", color: "#f783ac" }].map((b) => { const a = actor(0, 0, { ...b, speed: 285, dashDur: 0.22, dashCdMax: 0.9 }); Object.assign(a, randOpen(S, S.p, 300, 0)); return a; });
    S.data = { all: [S.p, ...S.bots], zone: null, goal: 5, city: Array.from({ length: 260 }, () => ({ x: R(-400, S.W + 400), y: R(-400, S.H + 400), w: R(2, 5), h: R(3, 7), c: pick(["#ffd8a8", "#ffe066", "#a5d8ff", "#ffc9c9"]), a: R(0.25, 0.8) })) };
    for (const a of S.data.all) { a.caps = 0; a.prog = 0; a.safe = { x: a.x, y: a.y }; a.fallT = 0; }
    roof.newZone(S);
    banner(S, "Capture 5 zones", "Dash pour sauter entre les toits");
  },
  newZone(S) { const prev = S.data.zone; let c; for (let i = 0; i < 50; i++) { c = randOpen(S, prev || S.p, 520, 0, 1); const [cx, cy] = cellOf(S, c.x, c.y); let ok = true; for (let j = -1; j <= 1; j++) for (let k = -1; k <= 1; k++) if (gget(S, cx + k, cy + j) !== 0) ok = false; if (ok) break; } S.data.zone = { x: c.x, y: c.y, r: 64 }; for (const a of S.data.all) a.prog = 0; },
  botAI(S, b, dt) {
    const Z = S.data.zone; let [dx, dy] = steer(S, b, Z.x, Z.y);
    const ahead = cellAt(S, b.x + dx * 46, b.y + dy * 46);
    if (ahead === 3 && b.dashT <= 0) { if (b.dashCd <= 0) dash(S, b, dx, dy); else { dx = 0; dy = 0; } }
    const p = S.p; if (dist(b, p) < 80 && b.actCd <= 0 && Math.random() < 0.04) shove(S, b, S.data.all);
    moveActor(S, b, dx, dy, dt, b.speed);
  },
  update(S, I, dt) {
    const d = S.data, p = S.p, Z = d.zone;
    if (p.fallT <= 0) { playerMove(S, I, dt); if (I.actP) shove(S, p, d.all); }
    for (const b of S.bots) if (b.fallT <= 0) roof.botAI(S, b, dt);
    separate(d.all.filter((a) => a.fallT <= 0), 0.4);
    for (const a of d.all) {
      if (a.fallT > 0) { a.fallT -= dt; if (a.fallT <= 0) { a.x = a.safe.x; a.y = a.safe.y; a.vx = a.vy = 0; a.stun = 0.5; a.inv = 1; burst(S, a.x, a.y, "#ffffff", 12, 200, 4, 0.4); } continue; }
      const v = cellAt(S, a.x, a.y);
      if (v === 3 && a.dashT <= 0) { a.fallT = 0.8; a.prog = 0; sfx(a === p ? "fall" : "tick"); if (a === p) { shakeIt(S, 8); floatText(S, a.x, a.y - 26, "Chute", "#ffffff"); } continue; }
      if (v === 0 && a.dashT <= 0) { const [cx, cy] = cellOf(S, a.x, a.y); let edge = false; for (const [ox, oy] of [[1, 0], [-1, 0], [0, 1], [0, -1]]) if (gget(S, cx + ox, cy + oy) === 3) edge = true; if (!edge) a.safe = center(S, cx, cy); }
    }
    const inside = d.all.filter((a) => a.fallT <= 0 && dist(a, Z) < Z.r);
    if (inside.length === 1) { const a = inside[0]; a.prog += dt / 2.4; if (a.prog >= 1) { a.caps++; S.rings.push({ x: Z.x, y: Z.y, r: 20, max: 160, life: 0.5, maxLife: 0.5, color: a.color }); burst(S, Z.x, Z.y, a.color, 30, 360, 5, 0.8); if (a === p) { S.score += 300; sfx("win"); banner(S, "Zone capturée", `${p.caps}/${d.goal}`, 1.4); } else banner(S, `${a.name} capture`, `${a.caps}/${d.goal}`, 1.2); if (a.caps >= d.goal) { const rk = [...d.all].sort((x, y) => y.caps - x.caps); S.end(a === p, a === p ? "Maître des toits" : `${a.name} gagne`, rk.map((x, i) => `${i + 1}. ${x === p ? "Toi" : x.name} — ${x.caps} zones`)); return; } roof.newZone(S); } }
    S.score = Math.max(S.score, p.caps * 300);
  },
  bg(ctx, S, sc, ox, oy) {
    for (const c of S.data.city) { const x = (c.x - ox * 0.55) * sc * 0.6 + ctx.canvas.width * 0.2, y = (c.y - oy * 0.55) * sc * 0.6 + ctx.canvas.height * 0.2; ctx.globalAlpha = c.a * (0.7 + Math.sin(S.t * 2 + c.x) * 0.1); ctx.fillStyle = c.c; ctx.fillRect(x, y, c.w * sc, c.h * sc); }
    ctx.globalAlpha = 1;
  },
  under(g, S) {
    const Z = S.data.zone; const lead = S.data.all.reduce((m, a) => (a.prog > (m?.prog || 0) ? a : m), null);
    g.save(); g.globalCompositeOperation = "lighter"; const gr = g.createRadialGradient(Z.x, Z.y, 4, Z.x, Z.y, Z.r * 1.4); gr.addColorStop(0, "rgba(255,159,67,.45)"); gr.addColorStop(1, "rgba(255,159,67,0)"); g.fillStyle = gr; g.beginPath(); g.arc(Z.x, Z.y, Z.r * 1.4, 0, 7); g.fill(); g.restore();
    g.strokeStyle = "#ff9f43"; g.lineWidth = 3; g.setLineDash([10, 8]); g.beginPath(); g.arc(Z.x, Z.y, Z.r, -S.t, -S.t + 7); g.stroke(); g.setLineDash([]);
    if (lead && lead.prog > 0) { g.strokeStyle = lead.color; g.lineWidth = 8; g.lineCap = "round"; g.beginPath(); g.arc(Z.x, Z.y, Z.r + 10, -Math.PI / 2, -Math.PI / 2 + lead.prog * Math.PI * 2); g.stroke(); }
  },
  over(g, S) { const Z = S.data.zone; g.save(); g.globalCompositeOperation = "lighter"; const gr = g.createLinearGradient(0, Z.y - 260, 0, Z.y); gr.addColorStop(0, "rgba(255,159,67,0)"); gr.addColorStop(1, "rgba(255,159,67,.28)"); g.fillStyle = gr; g.fillRect(Z.x - 18, Z.y - 260, 36, 260); g.restore(); },
  actorOpts(S, a) { if (a.fallT > 0) return { scale: Math.max(0.05, a.fallT / 0.8), spin: (0.8 - a.fallT) * 8, alpha: a.fallT / 0.8 }; if (a.dashT > 0) return { lift: 14 }; return {}; },
  hud(S) { const d = S.data; return { obj: `Zones ${S.p.caps}/${d.goal}`, left: "Rooftop Rivals", right: `${Math.floor(S.score)} pts`, board: d.all.map((a) => ({ name: a === S.p ? "Toi" : a.name, color: a.color, v: a.caps, m: "" })) }; },
};

export const MODES = { meteor, tag, crystal, mines, heist, brawl, castle, cyber, arena, party, rooftop: roof };
