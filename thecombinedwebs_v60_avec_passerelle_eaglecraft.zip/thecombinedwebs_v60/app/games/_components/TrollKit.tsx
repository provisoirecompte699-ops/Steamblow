"use client";
import { useCallback, useEffect, useRef, useState } from "react";
import type { Socket } from "socket.io-client";

/**
 * TrollKit — panneau admin de l'hôte + effets reçus par les joueurs.
 * Monté une seule fois par jeu avec <TrollKit socket={socket} />.
 *  - Hôte : bouton 🎭 → choisit une cible (tous / un joueur) et un effet.
 *  - Joueurs : reçoivent l'effet par-dessus le jeu. Échap = tout arrêter.
 *  - Sécurité : opt-out « bloquer les trolls » (envoyé au serveur), prefers-reduced-motion respecté,
 *    pas de stroboscope, son plafonné, toast de transparence « 🎭 X t'a troll ».
 */
export const TROLLS: { id: string; icon: string; label: string; ms: number; calm?: boolean }[] = [
  { id: "jumpscare", icon: "👹", label: "Jumpscare", ms: 1400 },
  { id: "fakecrash", icon: "💥", label: "Faux plantage", ms: 4500, calm: true },
  { id: "disconnect", icon: "📡", label: "Fausse déconnexion", ms: 4000, calm: true },
  { id: "flip", icon: "🙃", label: "Écran à l'envers", ms: 7000 },
  { id: "mirror", icon: "🪞", label: "Miroir", ms: 8000 },
  { id: "drunk", icon: "🥴", label: "Ivre", ms: 7000 },
  { id: "spin", icon: "🌀", label: "Tourniquet", ms: 5000 },
  { id: "shake", icon: "🫨", label: "Tremblement", ms: 4000 },
  { id: "zoom", icon: "🔍", label: "Zoom énorme", ms: 6000 },
  { id: "invert", icon: "🎨", label: "Couleurs inversées", ms: 7000, calm: true },
  { id: "darkness", icon: "🔦", label: "Lampe torche", ms: 8000, calm: true },
  { id: "rain", icon: "🍕", label: "Pluie d'emojis", ms: 5000, calm: true },
  { id: "honk", icon: "📢", label: "Klaxon", ms: 1200, calm: true },
];
const CSS_ID = "sbx-troll-css";
const CSS = `
@keyframes sbxFlip{to{transform:rotate(180deg)}}
@keyframes sbxSpin{to{transform:rotate(360deg)}}
@keyframes sbxShake{0%,100%{transform:translate(0,0)}25%{transform:translate(-14px,8px)}50%{transform:translate(12px,-10px)}75%{transform:translate(-8px,-6px)}}
@keyframes sbxDrunk{0%,100%{transform:rotate(-2deg) scale(1.03);filter:blur(1.5px)}50%{transform:rotate(2deg) scale(1.06) translateX(14px);filter:blur(3px)}}
@keyframes sbxPop{0%{transform:translate(-50%,-50%) scale(.2)}35%{transform:translate(-50%,-50%) scale(1.25)}100%{transform:translate(-50%,-50%) scale(1.05)}}
@keyframes sbxFall{to{transform:translateY(110vh) rotate(360deg)}}
@keyframes sbxFlash{0%{opacity:0}10%{opacity:.9}100%{opacity:0}}
.sbx-fx-flip{transform:rotate(180deg)!important;transition:transform .5s}
.sbx-fx-mirror{transform:scaleX(-1)!important}
.sbx-fx-spin{animation:sbxSpin 2.5s linear infinite}
.sbx-fx-shake{animation:sbxShake .25s linear infinite}
.sbx-fx-drunk{animation:sbxDrunk 2.4s ease-in-out infinite}
.sbx-fx-zoom{transform:scale(1.7)!important;transition:transform .4s}
.sbx-fx-invert{filter:invert(1) hue-rotate(180deg)!important}
.sbx-troll-btn{position:fixed;right:12px;bottom:70px;z-index:2147483000;background:#7c3aed;color:#fff;border:0;border-radius:999px;padding:10px 14px;font-weight:800;cursor:pointer;box-shadow:0 4px 18px #0008}
.sbx-troll-panel{position:fixed;right:12px;bottom:118px;z-index:2147483000;width:min(340px,92vw);max-height:70vh;overflow:auto;background:#12121c;border:1px solid #ffffff22;border-radius:14px;padding:12px;color:#fff;font:13px system-ui;box-shadow:0 10px 40px #000a}
.sbx-troll-panel h4{margin:0 0 8px;font-size:14px}
.sbx-troll-grid{display:grid;grid-template-columns:1fr 1fr;gap:6px}
.sbx-troll-grid button,.sbx-troll-targets button{background:#ffffff12;color:#fff;border:1px solid #ffffff1f;border-radius:10px;padding:8px;cursor:pointer;font-weight:700;text-align:left}
.sbx-troll-grid button:hover{background:#7c3aed55}
.sbx-troll-grid button:disabled{opacity:.4;cursor:not-allowed}
.sbx-troll-targets{display:flex;flex-wrap:wrap;gap:6px;margin-bottom:10px}
.sbx-troll-targets button.on{background:#7c3aed;border-color:#a78bfa}
.sbx-troll-targets button.prot{opacity:.5;text-decoration:line-through}
.sbx-toast{position:fixed;left:50%;top:14px;transform:translateX(-50%);z-index:2147483001;background:#000c;color:#fff;border:1px solid #ffffff33;border-radius:999px;padding:8px 16px;font:700 13px system-ui;pointer-events:none}
`;

type Pl = { id: string; name: string; troll?: boolean };

function gameEls(): HTMLElement[] {
  return Array.from(document.querySelectorAll<HTMLElement>("canvas, iframe")).filter((e) => e.offsetWidth > 200 && e.offsetHeight > 150);
}
function playSound(kind: "scream" | "honk") {
  try {
    const AC = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
    const ac = new AC(); const g = ac.createGain(); g.gain.value = 0.3; g.connect(ac.destination); // plafonné
    const t = ac.currentTime;
    if (kind === "scream") {
      for (const f of [330, 497, 701]) { const o = ac.createOscillator(); o.type = "sawtooth"; o.frequency.setValueAtTime(f, t); o.frequency.exponentialRampToValueAtTime(f * 1.9, t + 0.9); o.connect(g); o.start(t); o.stop(t + 1.1); }
      const n = ac.createBufferSource(), b = ac.createBuffer(1, ac.sampleRate, ac.sampleRate), d = b.getChannelData(0);
      for (let i = 0; i < d.length; i++) d[i] = (Math.random() * 2 - 1) * (1 - i / d.length); n.buffer = b; n.connect(g); n.start(t);
    } else {
      for (const f of [392, 311]) { const o = ac.createOscillator(); o.type = "square"; o.frequency.value = f; o.connect(g); o.start(t); o.stop(t + 0.6); }
    }
    g.gain.exponentialRampToValueAtTime(0.001, t + 1.15);
    setTimeout(() => ac.close().catch(() => {}), 1500);
  } catch {}
}

export default function TrollKit({ socket }: { socket: Socket | null }) {
  const [players, setPlayers] = useState<Pl[]>([]);
  const [hostId, setHostId] = useState<string | null>(null);
  const [open, setOpen] = useState(false);
  const [target, setTarget] = useState<string>("all");
  const [blocked, setBlocked] = useState(false);
  const [toast, setToast] = useState("");
  const [overlay, setOverlay] = useState<{ kind: string; key: number; msg?: string } | null>(null);
  const [cool, setCool] = useState(false);
  const active = useRef<{ stop: () => void }[]>([]);
  const blockedRef = useRef(false);
  const myId = socket?.id;
  const isHost = !!socket && hostId === myId;

  useEffect(() => {
    if (!document.getElementById(CSS_ID)) { const s = document.createElement("style"); s.id = CSS_ID; s.textContent = CSS; document.head.appendChild(s); }
    try { const b = localStorage.getItem("steamblox:troll:block") === "1"; setBlocked(b); blockedRef.current = b; } catch {}
  }, []);
  useEffect(() => { blockedRef.current = blocked; socket?.emit("troll:optout", blocked); try { localStorage.setItem("steamblox:troll:block", blocked ? "1" : "0"); } catch {} }, [blocked, socket]);

  const stopAll = useCallback(() => { active.current.forEach((a) => a.stop()); active.current = []; setOverlay(null); }, []);

  const classFx = useCallback((cls: string, ms: number) => {
    const els = gameEls(); els.forEach((e) => e.classList.add(cls));
    const stop = () => els.forEach((e) => e.classList.remove(cls));
    active.current.push({ stop }); setTimeout(stop, ms);
  }, []);

  const run = useCallback((effect: string, ms: number, from: string) => {
    if (blockedRef.current) return;
    const reduce = window.matchMedia?.("(prefers-reduced-motion: reduce)").matches;
    setToast(`🎭 ${from} t'a troll : ${TROLLS.find((t) => t.id === effect)?.label || effect}  ·  Échap pour arrêter`);
    setTimeout(() => setToast(""), Math.min(ms, 3500));
    const key = Date.now();
    const timed = (kind: string, msg?: string) => { setOverlay({ kind, key, msg }); const to = setTimeout(() => setOverlay((o) => (o && o.key === key ? null : o)), ms); active.current.push({ stop: () => clearTimeout(to) }); };
    switch (effect) {
      case "jumpscare": if (reduce) return timed("calm", "👹 BOO !"); playSound("scream"); timed("jumpscare"); break;
      case "fakecrash": timed("crash"); break;
      case "disconnect": timed("disc"); break;
      case "darkness": timed("dark"); break;
      case "rain": timed("rain"); break;
      case "honk": playSound("honk"); break;
      case "invert": classFx("sbx-fx-invert", ms); break;
      case "flip": classFx("sbx-fx-flip", ms); break;
      case "mirror": classFx("sbx-fx-mirror", ms); break;
      case "zoom": classFx("sbx-fx-zoom", ms); break;
      case "spin": if (!reduce) classFx("sbx-fx-spin", ms); break;
      case "shake": if (!reduce) classFx("sbx-fx-shake", ms); break;
      case "drunk": if (!reduce) classFx("sbx-fx-drunk", ms); break;
    }
  }, [classFx]);

  useEffect(() => {
    if (!socket) return;
    const st = (m: { hostId: string | null; players: Pl[] }) => { setHostId(m.hostId); setPlayers(m.players || []); };
    const fx = (m: { effect: string; ms: number; from: string }) => run(String(m.effect), Math.min(10000, Math.max(500, Number(m.ms) || 3000)), String(m.from || "L'hôte"));
    const key = (e: KeyboardEvent) => { if (e.key === "Escape") stopAll(); };
    socket.on("room:state", st); socket.on("troll:fx", fx); window.addEventListener("keydown", key);
    socket.emit("troll:optout", blockedRef.current);
    return () => { socket.off("room:state", st); socket.off("troll:fx", fx); window.removeEventListener("keydown", key); stopAll(); };
  }, [socket, run, stopAll]);

  const send = (effect: string) => {
    if (!socket || !isHost || cool) return;
    const t = TROLLS.find((x) => x.id === effect)!;
    socket.emit("host:troll", { effect, target, ms: t.ms });
    setCool(true); setTimeout(() => setCool(false), 1200);
  };

  if (!socket) return null;
  const others = players.filter((p) => p.id !== myId);
  return (
    <>
      {toast && <div className="sbx-toast">{toast}</div>}
      {overlay?.kind === "jumpscare" && (
        <div onClick={stopAll} style={{ position: "fixed", inset: 0, zIndex: 2147483600, background: "#000", display: "grid", placeItems: "center" }}>
          <div style={{ position: "absolute", inset: 0, background: "#fff", animation: "sbxFlash .35s ease-out forwards" }} />
          <div key={overlay.key} style={{ position: "absolute", left: "50%", top: "50%", fontSize: "min(70vw,70vh)", lineHeight: 1, animation: "sbxPop .25s ease-out forwards", filter: "drop-shadow(0 0 40px #f00)" }}>👹</div>
        </div>
      )}
      {overlay?.kind === "calm" && <div className="sbx-toast" style={{ top: "40%", fontSize: 40 }}>{overlay.msg}</div>}
      {overlay?.kind === "crash" && (
        <div onClick={stopAll} style={{ position: "fixed", inset: 0, zIndex: 2147483600, background: "#0b57d0", color: "#fff", font: "18px system-ui", padding: "10vh 8vw" }}>
          <div style={{ fontSize: 90 }}>:(</div>
          <p style={{ fontSize: 24, maxWidth: 640 }}>Le jeu a rencontré un problème et doit redémarrer.</p>
          <p style={{ opacity: .8 }}>Collecte d'informations… (c'est une blague de l'hôte, ça revient tout seul)</p>
        </div>
      )}
      {overlay?.kind === "disc" && (
        <div style={{ position: "fixed", inset: 0, zIndex: 2147483600, background: "#000d", color: "#fff", display: "grid", placeItems: "center", font: "700 22px system-ui", textAlign: "center" }}>
          <div>📡 Connexion perdue…<br /><small style={{ opacity: .7 }}>Reconnexion en cours (fausse alerte)</small></div>
        </div>
      )}
      {overlay?.kind === "dark" && <div style={{ position: "fixed", inset: 0, zIndex: 2147483000, pointerEvents: "none", background: "radial-gradient(circle at 50% 50%, transparent 0, transparent 70px, rgba(0,0,0,.97) 190px)" }} />}
      {overlay?.kind === "rain" && (
        <div style={{ position: "fixed", inset: 0, zIndex: 2147483000, pointerEvents: "none", overflow: "hidden" }}>
          {Array.from({ length: 28 }, (_, i) => (
            <span key={i} style={{ position: "absolute", top: -60, left: `${(i * 37) % 100}%`, fontSize: 30 + (i % 4) * 8, animation: `sbxFall ${2.2 + (i % 5) * 0.5}s linear ${(i % 7) * 0.2}s infinite` }}>{["🍕", "🦆", "💩", "🐸", "🍌", "👻"][i % 6]}</span>
          ))}
        </div>
      )}

      <button className="sbx-troll-btn" onClick={() => setOpen((o) => !o)} aria-label="Troll / sécurité">{isHost ? "🎭 Admin" : "🛡️"}</button>
      {open && (
        <div className="sbx-troll-panel">
          {isHost ? (
            <>
              <h4>🎭 Panneau admin de l'hôte</h4>
              <div className="sbx-troll-targets">
                <button className={target === "all" ? "on" : ""} onClick={() => setTarget("all")}>👥 Tous</button>
                {others.map((p) => (
                  <button key={p.id} className={`${target === p.id ? "on" : ""} ${p.troll === false ? "prot" : ""}`} onClick={() => setTarget(p.id)} title={p.troll === false ? "A bloqué les trolls" : ""}>
                    {p.troll === false ? "🛡️ " : ""}{p.name}
                  </button>
                ))}
              </div>
              {others.length === 0 && <p style={{ opacity: .7 }}>Personne d'autre dans le salon pour l'instant.</p>}
              <div className="sbx-troll-grid">
                {TROLLS.map((t) => <button key={t.id} disabled={cool || others.length === 0} onClick={() => send(t.id)}>{t.icon} {t.label}</button>)}
              </div>
              <p style={{ opacity: .6, fontSize: 11, margin: "8px 0 0" }}>Les joueurs qui ont activé 🛡️ ne reçoivent rien. Échap arrête les effets côté victime.</p>
            </>
          ) : <h4>🛡️ Sécurité anti-troll</h4>}
          <label style={{ display: "flex", gap: 8, alignItems: "center", marginTop: 10, cursor: "pointer" }}>
            <input type="checkbox" checked={blocked} onChange={(e) => setBlocked(e.target.checked)} /> Bloquer les trolls de l'hôte sur mon écran
          </label>
        </div>
      )}
    </>
  );
}
