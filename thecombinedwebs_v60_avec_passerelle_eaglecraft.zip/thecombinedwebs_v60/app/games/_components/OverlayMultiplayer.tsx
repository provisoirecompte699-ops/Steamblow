"use client";
import { useEffect, useRef, useState } from "react";
import { connectMultiplayer, MONSTER_TYPES, HOST_ACTIONS, type Multiplayer, type RoomMeta, type HostOptions } from "@/lib/multiplayer";
import type { Socket } from "socket.io-client";
import { roomFromUrl, copyInvite } from "@/lib/invite";
import TrollKit from "@/app/games/_components/TrollKit";
import VoiceChat from "@/app/VoiceChat";
import CompactGameVoice from "@/app/games/_components/CompactGameVoice";

type Props = {
  username: string;
  gameId: string;
};

/**
 * Panneau multijoueur pour les jeux en iframe (Baldi, Hello Neighbor, Ultrakill).
 * S'affiche en overlay par-dessus l'iframe.
 * Permet : salon partagé, liste de joueurs, chat, vocal, et contrôles d'hôte
 * (invoquer des monstres virtuels/effets visuels, modifier des options, actions).
 */
export default function OverlayMultiplayer({ username, gameId }: Props) {
  const [room, setRoom] = useState("");
  useEffect(() => { const r = roomFromUrl(); if (r) setRoom(r); }, []);
  const [copied, setCopied] = useState(false);
  const [joined, setJoined] = useState(false);
  const [meta, setMeta] = useState<RoomMeta | null>(null);
  const [status, setStatus] = useState("");
  const [chat, setChat] = useState<{ id: string; name: string; text: string; at: number }[]>([]);
  const [chatInput, setChatInput] = useState("");
  const [showPanel, setShowPanel] = useState(false);
  const [showHostPanel, setShowHostPanel] = useState(false);
  const [fxList, setFxList] = useState<{ id: string; type: string; icon: string; text: string; at: number }[]>([]);
  const mpRef = useRef<Multiplayer | null>(null);
  const [socket, setSocket] = useState<Socket | null>(null);

  const isHost = meta?.hostId === mpRef.current?.socket.id;

  const join = () => {
    const code = room || Math.random().toString(36).slice(2, 8).toUpperCase();
    setRoom(code);
    mpRef.current?.close();
    const mp = connectMultiplayer(code, username, gameId);
    if (!mp) { setStatus("Multijoueur en ligne indisponible : serveur non configuré (voir DEPLOY_MULTIPLAYER.md)."); return; }
    mpRef.current = mp;
    setSocket(mp.socket);
    (window as unknown as { __sbxMP?: unknown }).__sbxMP = { socket: mp.socket, room: code, username, gameId };
    setJoined(true);
    setStatus(`Connexion au salon ${code}…`);

    mp.socket.on("connect", () => setStatus(`Salon ${code} · en ligne`));
    mp.socket.on("disconnect", () => setStatus(`Déconnecté du salon ${code}`));
    mp.socket.on("room:state", (m: RoomMeta) => setMeta(m));
    mp.socket.on("room:error", (m: { message: string }) => setStatus(m?.message || "Erreur"));
    mp.socket.on("room:promoted", () => setStatus("Tu es maintenant l'hôte du salon !"));
    mp.socket.on("room:kicked", (m: { message: string }) => {
      setStatus(m?.message || "Exclu du salon");
      mpRef.current?.close(); mpRef.current = null; delete (window as unknown as { __sbxMP?: unknown }).__sbxMP; setJoined(false); setMeta(null);
    });
    mp.socket.on("room:chat", (m: { id: string; name: string; text: string; at: number }) => {
      setChat((c) => [...c.slice(-30), m]);
    });

    // Host events → effets visuels overlay
    mp.socket.on("host:spawn", (m: { monster: { type: string; count: number } }) => {
      const monster = m.monster;
      const icon = MONSTER_TYPES.find((t) => t.type === monster.type)?.icon || "👾";
      const fx = { id: Math.random().toString(36).slice(2), type: monster.type, icon, text: `${icon} Monstre invoqué : ${monster.type} !`, at: Date.now() };
      setFxList((f) => [...f, fx]);
      setTimeout(() => setFxList((f) => f.filter((x) => x.id !== fx.id)), 4000);
    });
    mp.socket.on("host:action", (m: { action: string }) => {
      const act = HOST_ACTIONS.find((a) => a.action === m.action);
      const icon = act?.icon || "⚡";
      const fx = { id: Math.random().toString(36).slice(2), type: m.action, icon, text: `${icon} ${act?.label || m.action} !`, at: Date.now() };
      setFxList((f) => [...f, fx]);
      setTimeout(() => setFxList((f) => f.filter((x) => x.id !== fx.id)), 4000);
    });
    mp.socket.on("host:clear", () => {
      const fx = { id: Math.random().toString(36).slice(2), type: "clear", icon: "🧹", text: "🧹 Monstres effacés !", at: Date.now() };
      setFxList((f) => [...f, fx]);
      setTimeout(() => setFxList((f) => f.filter((x) => x.id !== fx.id)), 3000);
    });
  };

  const leave = () => {
    mpRef.current?.close(); mpRef.current = null; delete (window as unknown as { __sbxMP?: unknown }).__sbxMP;
    setSocket(null); setJoined(false); setMeta(null); setChat([]);
    setStatus(""); setShowPanel(false); setShowHostPanel(false);
  };

  useEffect(() => () => { mpRef.current?.close(); }, []);

  const sendChat = () => {
    const text = chatInput.trim();
    if (!text || !mpRef.current) return;
    mpRef.current.socket.emit("room:chat", { text });
    setChatInput("");
  };

  const hostSpawn = (type: string, count: number = 1) => {
    mpRef.current?.socket.emit("host:spawn", { type, count, x: 0, y: 0 });
  };
  const hostAction = (action: string) => {
    mpRef.current?.socket.emit("host:action", { action });
  };
  const hostClear = () => {
    mpRef.current?.socket.emit("host:clear", {});
  };

  const playerCount = meta?.players?.length || 0;
  const playerList = meta?.players || [];

  return (
    <>
      {socket && <TrollKit socket={socket} />}
      {/* Effets visuels overlay (jump-scares, monstres, etc.) */}
      {fxList.length > 0 && (
        <div className="mp-fx-overlay">
          {fxList.map((fx) => (
            <div key={fx.id} className="mp-fx-item">{fx.text}</div>
          ))}
        </div>
      )}

      {/* Panneau multijoueur */}
      <div className="mp-panel mp-overlay-host">
        {!joined ? (
          <div className="mp-join">
            <div className="mp-join-row">
              <input
                value={room}
                onChange={(e) => setRoom(e.target.value.toUpperCase().replace(/[^A-Z0-9_-]/g, "").slice(0, 20))}
                placeholder="CODE SALON"
                className="mp-input"
                onKeyDown={(e) => e.key === "Enter" && join()}
              />
              <button onClick={join} className="mp-btn-join">Rejoindre</button>
{room && <button className="mp-btn-join" onClick={async () => { if (await copyInvite(room)) { setCopied(true); setTimeout(() => setCopied(false), 2000); } }}>{copied ? "✓ Copié" : "🔗 Inviter"}</button>}
            </div>
            {status && <small className="mp-status">{status}</small>}
          </div>
        ) : (
          <>
            <button className="mp-toggle" onClick={() => setShowPanel(!showPanel)}>
              🎮 {room} · {playerCount} joueur{playerCount > 1 ? "s" : ""} {isHost ? "👑" : ""} {showPanel ? "▲" : "▼"}
            </button>
            {status && <small className="mp-status">{status}</small>}

            {showPanel && (
              <div className="mp-body">
                <div className="mp-players">
                  {playerList.map((p) => (
                    <div key={p.id} className="mp-player">
                      <span className="mp-player-name">{p.name}{p.id === meta?.hostId ? " 👑" : ""}</span>
                      {p.score > 0 && <span className="mp-player-score">{p.score}</span>}
                    </div>
                  ))}
                </div>

                {isHost && (
                  <button className="mp-host-toggle" onClick={() => setShowHostPanel(!showHostPanel)}>
                    ⚙️ Contrôles hôte {showHostPanel ? "▲" : "▼"}
                  </button>
                )}

                {isHost && showHostPanel && (
                  <div className="mp-host-controls">
                    <div className="mp-host-section">
                      <b>👹 Invoquer des monstres (effet visuel)</b>
                      <div className="mp-monster-grid">
                        {MONSTER_TYPES.map((m) => (
                          <button key={m.type} className="mp-monster-btn" onClick={() => hostSpawn(m.type, m.type === "swarm" ? 5 : 1)} title={m.desc}>
                            <span className="mp-monster-icon">{m.icon}</span>
                            <span className="mp-monster-label">{m.label}</span>
                          </button>
                        ))}
                      </div>
                      <button className="mp-clear-btn" onClick={hostClear}>🧹 Effacer les effets</button>
                    </div>

                    <div className="mp-host-section">
                      <b>⚡ Actions instantanées</b>
                      <div className="mp-action-grid">
                        {HOST_ACTIONS.map((a) => (
                          <button key={a.action} className="mp-action-btn" onClick={() => hostAction(a.action)} title={a.label}>
                            <span>{a.icon}</span>
                            <small>{a.label}</small>
                          </button>
                        ))}
                      </div>
                    </div>
                    <p className="mp-modal-sub" style={{ fontSize: 11 }}>Les effets apparaissent en superposition sur le jeu. Idéal pour animer une session entre amis.</p>
                  </div>
                )}

                <div className="mp-chat">
                  <div className="mp-chat-list">
                    {chat.map((c, i) => (
                      <div key={i} className="mp-chat-msg"><b>{c.name}:</b> {c.text}</div>
                    ))}
                  </div>
                  <div className="mp-chat-input-row">
                    <input
                      value={chatInput}
                      onChange={(e) => setChatInput(e.target.value.slice(0, 180))}
                      onKeyDown={(e) => e.key === "Enter" && sendChat()}
                      placeholder="Message…"
                      className="mp-input mp-chat-input"
                    />
                    <button onClick={sendChat} className="mp-btn-send">➤</button>
                  </div>
                </div>

                <button className="mp-leave" onClick={leave}>Quitter le salon</button>
                {socket && <VoiceChat socket={socket} username={username} compact />}
              </div>
            )}
          </>
        )}
      </div>
      {/* CompactGameVoice est en dehors du panneau repliable pour rester visible */}
      <CompactGameVoice username={username} />
    </>
  );
}
