"use client";

import Link from "next/link";
import { useEffect, useState } from "react";

type SavedServer = { name: string; address: string; wsUrl?: string };
const STORAGE_KEY = "tcw-eaglecraft-servers-v2";
const CLIENT_URL = "https://eaglercraft.com/play/";
const DEFAULT_GATEWAY_URL = (process.env.NEXT_PUBLIC_EAGLECRAFT_GATEWAY_URL || "").trim();

export default function EagleCraftPage() {
  const [servers, setServers] = useState<SavedServer[]>([]);
  const [name, setName] = useState("");
  const [address, setAddress] = useState("");
  const [wsUrl, setWsUrl] = useState("");
  const [loaded, setLoaded] = useState(false);
  const [testResult, setTestResult] = useState<Record<string, string>>({});

  useEffect(() => {
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      if (raw) {
        const parsed: unknown = JSON.parse(raw);
        if (Array.isArray(parsed)) {
          setServers(parsed.filter((x): x is SavedServer =>
            x && typeof x.name === "string" && typeof x.address === "string"
          ));
        }
      } else {
        // Migrate the previous page's local server list.
        const old = localStorage.getItem("tcw-eaglecraft-servers-v1");
        if (old) {
          const parsed: unknown = JSON.parse(old);
          if (Array.isArray(parsed)) setServers(parsed.filter((x): x is SavedServer =>
            x && typeof x.name === "string" && typeof x.address === "string"
          ));
        } else {
          setServers([{ name: "Mon serveur Eaglercraft", address: "youknowbro.eagler.host", wsUrl: DEFAULT_GATEWAY_URL || undefined }]);
        }
      }
    } catch { /* ignore damaged local storage */ }
    setLoaded(true);
  }, []);

  useEffect(() => {
    if (loaded) {
      try { localStorage.setItem(STORAGE_KEY, JSON.stringify(servers)); } catch {}
    }
  }, [servers, loaded]);

  function addServer(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const cleanAddress = address.trim().replace(/^https?:\/\//i, "").replace(/\/+$/, "");
    const cleanWs = wsUrl.trim();
    if (!cleanAddress || /\s/.test(cleanAddress)) return;
    if (cleanWs && !/^wss?:\/\/[^ ]+$/i.test(cleanWs)) {
      alert("L’adresse WebSocket doit commencer par ws:// ou wss://.");
      return;
    }
    if (servers.some(s => s.address.toLowerCase() === cleanAddress.toLowerCase())) {
      alert("Cette adresse est déjà enregistrée.");
      return;
    }
    setServers(current => [...current, { name: name.trim() || cleanAddress, address: cleanAddress, wsUrl: cleanWs || undefined }]);
    setName(""); setAddress(""); setWsUrl("");
  }

  async function copy(text: string) {
    try { await navigator.clipboard.writeText(text); }
    catch { window.prompt("Copie cette adresse :", text); }
  }

  function testWebSocket(url: string, key: string) {
    if (!/^wss?:\/\/[^ ]+$/i.test(url)) {
      setTestResult(r => ({ ...r, [key]: "Adresse invalide : utilise ws:// ou wss://." }));
      return;
    }
    setTestResult(r => ({ ...r, [key]: "Test en cours…" }));
    let socket: WebSocket;
    try { socket = new WebSocket(url, "binary"); }
    catch {
      setTestResult(r => ({ ...r, [key]: "Échec : adresse WebSocket invalide ou inaccessible." }));
      return;
    }
    let finished = false;
    const timeout = window.setTimeout(() => {
      if (finished) return;
      finished = true;
      try { socket.close(); } catch {}
      setTestResult(r => ({ ...r, [key]: "Aucune réponse WebSocket. Vérifie que le proxy est démarré et que l’URL est exacte." }));
    }, 7000);
    socket.onopen = () => {
      if (finished) return;
      finished = true; window.clearTimeout(timeout);
      setTestResult(r => ({ ...r, [key]: "WebSocket joignable. Cela ne confirme pas encore que l’authentification Minecraft/EagleCraft fonctionne." }));
      socket.close();
    };
    socket.onerror = () => {
      if (finished) return;
      finished = true; window.clearTimeout(timeout);
      setTestResult(r => ({ ...r, [key]: "Échec WebSocket. Vérifie l’URL, le certificat HTTPS/WSS et le service proxy." }));
    };
    socket.onclose = () => {
      if (!finished) {
        finished = true; window.clearTimeout(timeout);
        setTestResult(r => ({ ...r, [key]: "Connexion fermée avant ouverture. Le proxy ou le protocole n’est probablement pas compatible." }));
      }
    };
  }

  return (
    <main style={{minHeight:"100dvh",background:"#0b1020",color:"#f5f7ff",padding:"24px 16px",fontFamily:"system-ui,sans-serif"}}>
      <div style={{maxWidth:940,margin:"0 auto"}}>
        <nav style={{display:"flex",justifyContent:"space-between",alignItems:"center",gap:12,flexWrap:"wrap",marginBottom:28}}>
          <Link href="/steamblox" style={{color:"#a8c7ff"}}>← TheCombinedWebs</Link>
          <div style={{display:"flex",alignItems:"center",justifyContent:"flex-end",gap:8,flexWrap:"wrap",marginLeft:"auto"}}>
            <div style={{display:"grid",gap:3,padding:"8px 11px",border:"1px solid #28634c",borderRadius:10,background:"#10251d",maxWidth:"100%"}}>
              <span style={{color:"#8fe3b0",fontSize:10,fontWeight:800,letterSpacing:1}}>MON SERVEUR EAGLERCRAFT</span>
              <span style={{color:"#f5fff9",fontSize:13,fontWeight:800,overflowWrap:"anywhere"}}>youknowbro.eagler.host</span>
            </div>
            <button type="button" onClick={()=>void copy("youknowbro.eagler.host")} style={{padding:"9px 11px",border:"1px solid #28634c",borderRadius:9,background:"#173729",color:"#d8ffeb",fontWeight:700,cursor:"pointer"}}>Copier l’adresse</button>
          </div>
        </nav>
        <header style={{padding:24,border:"1px solid #293451",borderRadius:20,background:"linear-gradient(135deg,#182647,#101728)"}}>
          <p style={{color:"#8fe3b0",fontWeight:700,letterSpacing:2,margin:"0 0 8px"}}>PASSERELLE DE COMPATIBILITÉ</p>
          <h1 style={{fontSize:"clamp(30px,6vw,48px)",margin:"0 0 12px"}}>EagleCraft + Aternos</h1>
          <p style={{color:"#c5cce0",lineHeight:1.65}}>Enregistre tes serveurs et, si tu disposes d’une passerelle compatible, teste son point d’accès WebSocket avant de lancer le client.</p>
          <a href={CLIENT_URL} target="_blank" rel="noopener noreferrer" style={{display:"inline-block",background:"#8fe3b0",color:"#08130d",fontWeight:800,padding:"12px 18px",borderRadius:10,textDecoration:"none"}}>Lancer EagleCraft ↗</a>
        </header>

        <section style={{marginTop:22,padding:22,border:"1px solid #293451",borderRadius:16,background:"#111a2c"}}>
          <h2 style={{marginTop:0}}>Ajouter un serveur</h2>
          <p style={{color:"#c5cce0",lineHeight:1.6}}>La passerelle TCB relaie le protocole WebSocket vers le point d’accès EaglerXServer configuré. Après déploiement du service gateway-eaglercraft, utilise son URL wss://…/websocket. L’adresse Minecraft seule n’est pas toujours une URL WebSocket.</p>
          <form onSubmit={addServer} style={{display:"grid",gridTemplateColumns:"repeat(auto-fit,minmax(210px,1fr))",gap:10}}>
            <label style={{display:"grid",gap:6}}>Nom du serveur
              <input value={name} onChange={e=>setName(e.target.value)} placeholder="Mon serveur" style={fieldStyle}/>
            </label>
            <label style={{display:"grid",gap:6}}>Adresse Minecraft / Aternos
              <input required value={address} onChange={e=>setAddress(e.target.value)} placeholder="monserveur.aternos.me" style={fieldStyle}/>
            </label>
            <label style={{display:"grid",gap:6}}>URL WebSocket de la passerelle (facultatif)
              <input value={wsUrl} onChange={e=>setWsUrl(e.target.value)} placeholder="wss://proxy.exemple/ws" style={fieldStyle}/>
            </label>
            <button type="submit" style={{alignSelf:"end",padding:13,border:0,borderRadius:10,background:"#a8c7ff",color:"#0b1020",fontWeight:800,cursor:"pointer"}}>Enregistrer</button>
          </form>
          {servers.length === 0 ? <p style={{color:"#9da9c5",marginBottom:0}}>Aucun serveur enregistré pour le moment.</p> :
            <div style={{display:"grid",gap:12,marginTop:18}}>
              {servers.map((server,index)=><div key={server.address} style={{padding:14,border:"1px solid #293451",borderRadius:12}}>
                <div style={{display:"flex",gap:12,alignItems:"center",justifyContent:"space-between",flexWrap:"wrap"}}>
                  <div><strong>{server.name}</strong><div style={{color:"#aab4d0",overflowWrap:"anywhere"}}>{server.address}</div></div>
                  <div style={{display:"flex",gap:8,flexWrap:"wrap"}}>
                    <button onClick={()=>void copy(server.address)} style={smallButton}>Copier l’adresse</button>
                    {server.wsUrl && <button onClick={()=>void copy(server.wsUrl!)} style={smallButton}>Copier l’URL WS</button>}
                    <button onClick={()=>setServers(current=>current.filter((_,i)=>i!==index))} style={{...smallButton,borderColor:"#75404a",color:"#ffb7c0"}}>Supprimer</button>
                  </div>
                </div>
                {server.wsUrl ? <div style={{marginTop:12}}>
                  <button onClick={()=>testWebSocket(server.wsUrl!,server.address)} style={smallButton}>Tester la passerelle WebSocket</button>
                  {testResult[server.address] && <p role="status" style={{color:"#d5def4",lineHeight:1.5,overflowWrap:"anywhere"}}>{testResult[server.address]}</p>}
                </div> : <p style={{color:"#9da9c5",fontSize:13,marginBottom:0}}>Aucune passerelle WebSocket configurée.</p>}
              </div>)}
            </div>
          }
        </section>

        <section style={{marginTop:22,padding:22,border:"1px solid #6b5630",borderRadius:16,background:"#211b12"}}>
          <h2 style={{marginTop:0,color:"#ffd58b"}}>Ce qui est nécessaire pour le vrai protocole</h2>
          <ol style={{color:"#f0dfc0",lineHeight:1.75,paddingLeft:22}}>
            <li>Le client EagleCraft utilisé doit prendre en charge le protocole et la version du serveur cible.</li>
            <li>Un serveur Java Aternos standard n’expose généralement pas le point d’accès WebSocket attendu par le client Eaglercraft.</li>
            <li>Le service gateway-eaglercraft de ce dépôt relaie les connexions vers un point d’accès EaglerXServer existant. Il ne convertit pas un backend TCP ordinaire si EaglerXServer n’est pas installé/configuré côté serveur.</li>
            <li>Après avoir déployé la passerelle, utilise son URL `wss://NOM-DU-SERVICE.onrender.com/websocket` ici. Le test vérifie uniquement si le WebSocket s’ouvre ; seul un essai dans le jeu confirme la compatibilité du protocole et la connexion au serveur.</li>
          </ol>
          <p style={{color:"#f0dfc0",lineHeight:1.6,marginBottom:0}}>Ne saisis jamais ton mot de passe Aternos dans cette page. Elle ne démarre pas ton serveur et ne crée pas automatiquement la passerelle.</p>
        </section>
        <section style={{marginTop:18,color:"#9da9c5",fontSize:13,lineHeight:1.6}}>
          <strong>Modpacks :</strong> les modpacks Java/Forge/Fabric ne deviennent pas compatibles avec EagleCraft via cette passerelle. Les mods, versions et fonctionnalités doivent être compatibles à la fois avec le serveur et le client.
        </section>
      </div>
    </main>
  );
}

const fieldStyle: React.CSSProperties = {width:"100%",boxSizing:"border-box",padding:12,border:"1px solid #354363",borderRadius:9,background:"#0b1020",color:"#f5f7ff"};
const smallButton: React.CSSProperties = {padding:"9px 12px",border:"1px solid #52658c",borderRadius:9,background:"#182647",color:"#f5f7ff",cursor:"pointer"};
