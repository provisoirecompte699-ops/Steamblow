import Link from "next/link";
import { redirect } from "next/navigation";
import { currentUser } from "@/lib/auth";
import { catalog, hasGameAccess } from "@/lib/store";
import ProxyFrame from "@/app/proxy/ProxyFrame";

export const dynamic = "force-dynamic";
export const metadata = { title: "Snokido · TheCombinedWebs" };

export default async function SnokidoPage() {
  const user = await currentUser();
  if (!user) { redirect("/login?next=/games/snokido"); return null; }
  const game = catalog.find((g) => g.id === "snokido");
  if (!game) redirect("/");
  if (!hasGameAccess(user, game.id)) redirect(`/steamblox?purchase=${game.id}`);
  return (
    <main style={{ minHeight: "100dvh", background: "#0a0b0f", color: "#eef0f4" }}>
      <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", gap: 12, flexWrap: "wrap", padding: "10px 14px", borderBottom: "1px solid #1e212a", background: "rgba(10,11,15,.92)" }}>
        <div><div style={{ fontSize: 11, fontWeight: 800, letterSpacing: "0.12em", textTransform: "uppercase", color: "#8b7cff" }}>Portail de jeux · via le proxy TCB</div><h1 style={{ margin: 0, fontSize: 18, fontWeight: 800 }}>Snokido</h1></div>
        <Link href="/steamblox#bibliotheque" style={{ padding: "8px 12px", borderRadius: 9, background: "#181b22", border: "1px solid #2a2e38", color: "#fff", fontSize: 13, fontWeight: 650 }}>← Catalogue</Link>
      </div>
      <ProxyFrame site="snokido" label="Snokido" fallbackUrl="https://snokido.fr" />
      <p style={{ margin: 0, padding: "8px 14px", fontSize: 12, color: "#8b909c" }}>Contenu hébergé par snokido.fr (non affilié). Si un jeu ne se charge pas, ouvre la console du navigateur : les hôtes non autorisés y sont signalés et s’ajoutent dans PROXY_ALLOW.</p>
    </main>
  );
}
