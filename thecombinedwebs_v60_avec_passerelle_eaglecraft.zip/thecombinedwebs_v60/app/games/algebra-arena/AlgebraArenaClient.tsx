"use client";
import { useEffect, useRef, useState, useCallback } from "react";
import Link from "next/link";
import useCloudRecord from "@/app/useCloudRecord";
import {gameMemory as localStorage} from "@/app/game-memory";
import { generateExercise, checkAnswer, type Exercise } from "@/lib/algebra";
import MultiplayerPanel from "@/app/games/_components/MultiplayerPanel";

type GameState = "menu" | "playing" | "over";
type Card = { ex: Exercise; correct: boolean; x: number; y: number; speed: number; id: number };

export default function AlgebraArenaClient({ username }: { username: string }) {
  const [phase, setPhase] = useState<GameState>("menu");
  const [score, setScore] = useState(0);
  const [hp, setHp] = useState(3);
  const [combo, setCombo] = useState(1);
  const [best, setBest] = useState(0);
  useCloudRecord("algebra-arena",best,setBest);
  const [cards, setCards] = useState<Card[]>([]);
  const [selected, setSelected] = useState<string>("");
  const idRef = useRef(0);
  const rafRef = useRef(0);
  const lastRef = useRef(0);
  const phaseRef = useRef<GameState>("menu");
  phaseRef.current = phase;
  const [mpScores, setMpScores] = useState<{ id: string; name: string; score: number }[]>([]);
  const remotesRef = useRef<Map<string, { name: string; score: number }>>(new Map());
  const sendStateRef = useRef<((state: Record<string, number>) => void) | null>(null);
  const [hostOpts, setHostOpts] = useState<Record<string, unknown>>({});

  useEffect(() => { setBest(Number(localStorage.getItem("steamblox:arena:best") || 0)); }, []);

  const start = useCallback(() => {
    setPhase("playing"); setScore(0); setHp(3); setCombo(1); setCards([]); setSelected("");
    phaseRef.current = "playing";
    idRef.current = 0; lastRef.current = performance.now();
    spawnCards();
  }, []);

  const spawnCards = useCallback(() => {
    const newCards: Card[] = [];
    const count = (hostOpts.chaos as number) ? 8 : 4;
    for (let i = 0; i < count; i++) {
      const ex = generateExercise((1 + Math.floor(Math.random() * 3)) as 1 | 2 | 3);
      const isCorrect = Math.random() < 0.5;
      newCards.push({
        ex, correct: isCorrect,
        x: 20 + Math.random() * 60, y: -10 - i * 25,
        speed: 15 + Math.random() * 20, id: idRef.current++,
      });
    }
    setCards(prev => [...prev, ...newCards]);
  }, [hostOpts]);

  useEffect(() => {
    if (phase !== "playing") return;
    const loop = (now: number) => {
      const dt = Math.min(0.05, (now - lastRef.current) / 1000);
      lastRef.current = now;
      const speedMul = (hostOpts.speed as number) || 1;
      setCards(prev => {
        const updated = prev.map(c => ({ ...c, y: c.y + c.speed * speedMul * dt }));
        const fallen = updated.filter(c => c.y > 100);
        if (fallen.length > 0) {
          const damage = fallen.filter(c => c.correct).length;
          if (damage > 0) {
            setHp(h => { const nh = h - damage; if (nh <= 0) { setPhase("over"); phaseRef.current = "over"; } return Math.max(0, nh); });
            setCombo(1);
          }
        }
        return updated.filter(c => c.y <= 100);
      });
      rafRef.current = requestAnimationFrame(loop);
    };
    rafRef.current = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(rafRef.current);
  }, [phase, hostOpts.speed]);

  useEffect(() => {
    if (phase !== "playing") return;
    const interval = (hostOpts.monsterRate as number) ? Math.max(1000, 3000 / (hostOpts.monsterRate as number)) : 3000;
    const t = setInterval(() => { if (phaseRef.current === "playing") spawnCards(); }, interval);
    return () => clearInterval(t);
  }, [phase, spawnCards, hostOpts.monsterRate]);

  const handleCard = (card: Card) => {
    if (card.correct) {
      const pts = Math.round(10 * combo);
      setScore(s => { sendStateRef.current?.({ score: s + pts }); return s + pts; });
      setCombo(c => Math.min(8, c + 0.5));
      setCards(prev => prev.filter(c => c.id !== card.id));
    } else {
      setHp(h => { const nh = h - 1; if (nh <= 0) { setPhase("over"); } return Math.max(0, nh); });
      setCombo(1);
      setCards(prev => prev.filter(c => c.id !== card.id));
    }
  };

  const endGame = () => {
    const prev = Number(localStorage.getItem("steamblox:arena:best") || 0);
    if (score > prev) { localStorage.setItem("steamblox:arena:best", String(score)); setBest(score); }
    setPhase("over");
  };

  useEffect(() => { if (hp <= 0 && phase === "playing") endGame(); }, [hp, phase]);

  // Envoyer le score en multijoueur
  useEffect(() => {
    if (phase === "playing") {
      const t = setInterval(() => {
        // Le MultiplayerPanel gère l'envoi via les callbacks
      }, 1000);
      return () => clearInterval(t);
    }
  }, [phase]);

  return <div className="aa-wrap">
    <MultiplayerPanel
      username={username}
      gameId="algebra-arena"
      compact
      onPlayerState={(p) => { remotesRef.current.set(p.id, { name: p.username, score: p.state.score || 0 }); setMpScores([...remotesRef.current.values()].map((v, i) => ({ id: String(i), name: v.name, score: v.score }))); }}
      onPlayerLeft={(id) => { remotesRef.current.delete(id); setMpScores([...remotesRef.current.values()].map((v, i) => ({ id: String(i), name: v.name, score: v.score }))); }}
      onRoomState={(meta) => { remotesRef.current.clear(); for (const p of meta.players) remotesRef.current.set(p.id, { name: p.name, score: p.score }); setMpScores([...remotesRef.current.values()].map((v, i) => ({ id: String(i), name: v.name, score: v.score }))); }}
      onHostModify={(opts) => setHostOpts(opts)}
      onHostAction={(action) => {
        if (action === "heal") setHp(3);
        else if (action === "chaos") { for (let i = 0; i < 4; i++) { const ex = generateExercise(3); setCards(prev => [...prev, { ex, correct: Math.random() < 0.3, x: 10 + Math.random() * 80, y: -10, speed: 30, id: idRef.current++ }]); } }
        else if (action === "rain") { for (let i = 0; i < 6; i++) { const ex = generateExercise(1); setCards(prev => [...prev, { ex, correct: true, x: 10 + Math.random() * 80, y: -10 - i * 20, speed: 15, id: idRef.current++ }]); } }
        else if (action === "jumpscare") { document.body.style.background = "#ff2e4d"; setTimeout(() => document.body.style.background = "", 200); }
      }}
      onHostSpawn={() => { /* spawn bonus card */ const ex = generateExercise(1); setCards(prev => [...prev, { ex, correct: true, x: 20 + Math.random() * 60, y: -10, speed: 20, id: idRef.current++ }]); }}
      onHostClear={() => { setCards([]); }}
      sendStateRef={sendStateRef}
    />

    {mpScores.length > 0 && (
      <div className="mp-score-board" style={{ position: "static", marginBottom: 8 }}>
        {mpScores.map((p, i) => <div key={i} className="mp-score-row"><span>👤 {p.name}</span><b>{p.score}</b></div>)}
      </div>
    )}

    <div className="arc-nav" style={{ width: "100%", maxWidth: 600 }}>
      <Link href="/steamblox#bibliotheque" className="arc-back">← Bibliothèque</Link>
      <div className="arc-nav-title"><b>Algèbre Arena</b><span>Révisions ludiques</span></div>
    </div>

    {phase === "menu" && <div className="aa-canvas-wrap">
      <div className="aa-overlay" style={{ background: "#0a0b10" }}>
        <div>
          <h2>📐 Algèbre Arena</h2>
          <p>Des équations tombent du ciel. Touche les vraies, évite les fausses !<br/>3 vies, combo croissant, défie ton record.<br/><small style={{ color: "#8b7cff" }}>🎮 Multijoueur : rejoins un salon pour comparer tes scores en temps réel. L'hôte peut modifier la partie.</small></p>
          <button className="arc-play" onClick={start}>Jouer</button>
          {best > 0 && <div className="arc-best">Ton record : {best} pts</div>}
        </div>
      </div>
      <div style={{ height: 400 }} />
    </div>}

    {phase === "playing" && <>
      <div className="aa-hud">
        <span>❤️ {"❤️".repeat(Math.max(0, hp))}</span>
        <span>Score : <b>{score}</b></span>
        <span>Combo : <b>×{combo.toFixed(1)}</b></span>
      </div>
      <div className="aa-canvas-wrap" style={{ minHeight: 400, background: "#0a0b10", borderRadius: 12, border: "1px solid #ffffff14", padding: 12, overflow: "hidden", position: "relative" }}>
        {cards.map(card => (
          <div key={card.id} className="aa-card" style={{
            position: "absolute",
            left: `${card.x}%`,
            top: `${card.y * 3}px`,
            transform: "translateX(-50%)",
            borderColor: "#ffffff33",
            width: "auto",
            minWidth: 200,
          }} onClick={() => handleCard(card)}>
            <span className="aa-eq">{card.ex.text}</span>
            <span className="aa-val">{card.correct ? "✓ Vraie" : "✗ Fausse"}</span>
          </div>
        ))}
      </div>
    </>}

    {phase === "over" && <div className="aa-canvas-wrap">
      <div className="aa-overlay" style={{ background: "#0a0b10ee" }}>
        <div>
          <h2>Partie terminée</h2>
          <p>Score final : <b style={{ color: "#ffd43b", fontSize: 24 }}>{score}</b><br/>
          {score > best ? "Nouveau record ! 🎉" : `Record : ${best}`}</p>
          <button className="arc-play" onClick={start}>Rejouer</button>
        </div>
      </div>
      <div style={{ height: 400 }} />
    </div>}
  </div>;
}
