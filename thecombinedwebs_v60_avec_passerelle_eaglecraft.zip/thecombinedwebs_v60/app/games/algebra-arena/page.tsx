import { currentUser } from "@/lib/auth";
import { redirect } from "next/navigation";
import AlgebraArenaClient from "./AlgebraArenaClient";

export default async function AlgebraArenaPage() {
  const user = await currentUser();
  if (!user) { redirect("/login?next=/games/algebra-arena"); return null; }
  return <AlgebraArenaClient username={user.username} />;
}
