import Link from "next/link";
import { redirect } from "next/navigation";
import { currentUser } from "@/lib/auth";
import EcosystemBar from "../../EcosystemBar";
import OverlayMultiplayer from "../_components/OverlayMultiplayer";

export const dynamic = "force-dynamic";

export default async function BaldiBasics3DPage() {
  const user = await currentUser();
  if (!user) { redirect("/login?next=/games/baldi-basics-3d"); return null; }
  return (
    <main style={{ minHeight: "100dvh", background: "#000", color: "#fff" }}>
      <EcosystemBar current="baldi" />
      <div style={{ position: "fixed", bottom: 10, left: 10, zIndex: 30000, display: "flex", gap: 8 }}>
        <Link href="/steamblox#bibliotheque" className="eco-float-btn">← TheCombinedWebs</Link>
        <Link href="/cinestream" className="eco-float-btn">🍿 CinéStream</Link>
      </div>
      <OverlayMultiplayer username={user.username} gameId="baldi-basics-3d" />
      <iframe
        title="Baldi's Basics 3D"
        src="/games/baldi-basics-3d/index.html"
        style={{ width: "100%", height: "100dvh", border: 0, display: "block" }}
        allow="autoplay; fullscreen; gamepad"
        allowFullScreen
      />
      <div className="eco-credit-badge">Écosystème TheCombinedWebs · Crédits : Walid</div>
    </main>
  );
}
