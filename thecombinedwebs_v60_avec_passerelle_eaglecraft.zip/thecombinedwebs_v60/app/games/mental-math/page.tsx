import { currentUser } from "@/lib/auth";
import { redirect } from "next/navigation";
import MentalMathClient from "./MentalMathClient";

export default async function MentalMathPage() {
  const user = await currentUser();
  if (!user) { redirect("/login?next=/games/mental-math"); return null; }
  return <MentalMathClient username={user.username} />;
}
