"use client";
import { useEffect, useRef, useState } from "react";
import Link from "next/link";
import useCloudRecord from "@/app/useCloudRecord";
import {gameMemory as localStorage} from "@/app/game-memory";
import MultiplayerPanel from "@/app/games/_components/MultiplayerPanel";

type GameState = "menu" | "playing" | "over";

export default function MentalMathClient({ username }: { username: string }) {
  const [phase, setPhase] = useState<GameState>("menu");
  const [score, setScore] = useState(0);
  const [timeLeft, setTimeLeft] = useState(30);
  const [question, setQuestion] = useState("");
  const [answer, setAnswer] = useState("");
  const [correctAnswer, setCorrectAnswer] = useState(0);
  const [best, setBest] = useState(0);
  useCloudRecord("mental-math",best,setBest);
  const [streak, setStreak] = useState(0);
  const [mpScores, setMpScores] = useState<{ id: string; name: string; score: number }[]>([]);
  const remotesRef = useRef<Map<string, { name: string; score: number }>>(new Map());
  const sendStateRef = useRef<((state: Record<string, number>) => void) | null>(null);
  const [hostOpts, setHostOpts] = useState<Record<string, unknown>>({});
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => { setBest(Number(localStorage.getItem("steamblox:mental:best") || 0)); }, []);
  useEffect(() => { if (phase === "playing") inputRef.current?.focus(); }, [phase]);

  const generate = () => {
    const ops = ["+", "-", "×"];
    const op = ops[Math.floor(Math.random() * ops.length)];
    let a = Math.floor(Math.random() * 20) + 1;
    let b = Math.floor(Math.random() * 20) + 1;
    if (op === "−" && b > a) [a, b] = [b, a];
    if (op === "×") { a = Math.floor(Math.random() * 12) + 1; b = Math.floor(Math.random() * 12) + 1; }
    const result = op === "+" ? a + b : op === "−" ? a - b : a * b;
    setQuestion(`${a} ${op} ${b} = ?`);
    setCorrectAnswer(result);
    setAnswer("");
  };

  const start = () => { setPhase("playing"); setScore(0); setStreak(0); setTimeLeft(hostOpts.chaos ? 15 : 30); generate(); };

  useEffect(() => {
    if (phase !== "playing") return;
    const t = setInterval(() => {
      setTimeLeft(s => { if (s <= 1) { setPhase("over"); const prev = Number(localStorage.getItem("steamblox:mental:best") || 0); if (score > prev) { localStorage.setItem("steamblox:mental:best", String(score)); setBest(score); } return 0; } return s - 1; });
    }, 1000);
    return () => clearInterval(t);
  }, [phase, score]);

  const check = () => {
    if (Number(answer) === correctAnswer) {
      const pts = 10 + Math.min(20, streak * 2);
      setScore(s => { sendStateRef.current?.({ score: s + pts }); return s + pts; });
      setStreak(s => s + 1);
      generate();
    } else {
      setStreak(0);
      setAnswer("");
    }
  };

  return <div className="aa-wrap">
    <MultiplayerPanel
      username={username}
      gameId="mental-math"
      compact
      onPlayerState={(p) => { remotesRef.current.set(p.id, { name: p.username, score: p.state.score || 0 }); setMpScores([...remotesRef.current.values()].map((v, i) => ({ id: String(i), name: v.name, score: v.score }))); }}
      onPlayerLeft={(id) => { remotesRef.current.delete(id); setMpScores([...remotesRef.current.values()].map((v, i) => ({ id: String(i), name: v.name, score: v.score }))); }}
      onRoomState={(meta) => { remotesRef.current.clear(); for (const p of meta.players) remotesRef.current.set(p.id, { name: p.name, score: p.score }); setMpScores([...remotesRef.current.values()].map((v, i) => ({ id: String(i), name: v.name, score: v.score }))); }}
      onHostModify={(opts) => setHostOpts(opts)}
      onHostAction={(action) => { if (action === "heal") setTimeLeft(t => t + 10); else if (action === "chaos") setTimeLeft(10); else if (action === "jumpscare") { document.body.style.background = "#ff2e4d"; setTimeout(() => document.body.style.background = "", 200); } }}
      onHostSpawn={() => { setScore(s => s + 50); }}
      onHostClear={() => { setStreak(0); }}
      sendStateRef={sendStateRef}
    />

    {mpScores.length > 0 && (
      <div className="mp-score-board" style={{ position: "static", marginBottom: 8 }}>
        {mpScores.map((p, i) => <div key={i} className="mp-score-row"><span>👤 {p.name}</span><b>{p.score}</b></div>)}
      </div>
    )}

    <div className="arc-nav" style={{ width: "100%", maxWidth: 500 }}>
      <Link href="/steamblox#bibliotheque" className="arc-back">← Bibliothèque</Link>
      <div className="arc-nav-title"><b>Calcul Mental</b><span>30 secondes chrono</span></div>
    </div>
    {phase === "menu" && <div className="aa-canvas-wrap">
      <div className="aa-overlay" style={{ background: "#0a0b10" }}>
        <div><h2>🧮 Calcul Mental</h2>
        <p>Additions, soustractions et multiplications.<br/>30 secondes pour faire le maximum de bonnes réponses.<br/>Combo : chaque bonne réponse augmente ton bonus.<br/><small style={{ color: "#8b7cff" }}>🎮 Multijoueur : compare tes scores en temps réel. L'hôte peut modifier la partie.</small></p>
        <button className="arc-play" onClick={start}>Jouer</button>
        {best > 0 && <div className="arc-best">Record : {best} pts</div>}</div>
      </div>
      <div style={{ height: 300 }} />
    </div>}
    {phase === "playing" && <div className="aa-canvas-wrap" style={{ padding: 20, background: "#0a0b10", borderRadius: 12, border: "1px solid #ffffff14" }}>
      <div className="aa-hud"><span>⏱ {timeLeft}s</span><span>Score : <b>{score}</b></span><span>Combo : ×{streak}</span></div>
      <div className="af-ex-eq" style={{ fontSize: 32, textAlign: "center", margin: "20px 0" }}>{question}</div>
      <form className="af-row" style={{ justifyContent: "center" }} onSubmit={e => { e.preventDefault(); check(); }}>
        <input ref={inputRef} className="af-input af-input-math" style={{ fontSize: 24, width: 120, textAlign: "center" }} value={answer} onChange={e => setAnswer(e.target.value)} placeholder="?" inputMode="numeric" />
        <button className="af-btn">Valider</button>
      </form>
    </div>}
    {phase === "over" && <div className="aa-canvas-wrap">
      <div className="aa-overlay" style={{ background: "#0a0b10ee" }}>
        <div><h2>Temps écoulé !</h2>
        <p>Score : <b style={{ color: "#ffd43b", fontSize: 24 }}>{score}</b><br/>{score > best ? "Nouveau record ! 🎉" : `Record : ${best}`}</p>
        <button className="arc-play" onClick={start}>Rejouer</button></div>
      </div>
      <div style={{ height: 300 }} />
    </div>}
  </div>;
}
