import { currentUser } from "@/lib/auth";
import { redirect } from "next/navigation";
import UltrakillClient from "./UltrakillClient";

export default async function UltrakillPage() {
  const user = await currentUser();
  if (!user) { redirect("/login?next=/games/ultrakill"); return null; }
  return <UltrakillClient username={user.username} />;
}
