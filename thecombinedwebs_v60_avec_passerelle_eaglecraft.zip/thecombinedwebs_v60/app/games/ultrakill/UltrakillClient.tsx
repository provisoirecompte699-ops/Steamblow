"use client";
import Link from "next/link";
import {useEffect,useState} from "react";
import EcosystemBar from "../../EcosystemBar";
import OverlayMultiplayer from "../_components/OverlayMultiplayer";

export default function UltrakillClient({username}:{username:string}){
  const [fileName,setFileName]=useState("");
  const [size,setSize]=useState<number|null>(null);
  useEffect(()=>{try{setFileName(localStorage.getItem("steamblox:ultrakill:file")||"")}catch{}} ,[]);
  const pick=(file:File|null)=>{
    if(!file)return;
    setFileName(file.name);setSize(file.size);
    try{localStorage.setItem("steamblox:ultrakill:file",file.name)}catch{}
  };
  return <main className="external-game-page">
    <EcosystemBar current="ultrakill" />
    <OverlayMultiplayer username={username} gameId="ultrakill-local" />
    <div className="external-game-shell">
      <Link href="/steamblox" className="button secondary">← Bibliothèque TheCombinedWebs</Link>
      <div className="external-game-hero">
        <div className="external-game-badge">PC · JEU EXTERNE</div>
        <h1>ULTRAKILL</h1>
        <p>Ajoute ton exemplaire local à ton espace TheCombinedWebs. Le site ne téléverse pas et n'exécute pas ton fichier.</p>
      </div>
      <section className="card external-game-card">
        <h2>🔗 Connecter ton exemplaire</h2>
        <p className="muted">Sélectionne ton <code>ULTRAKILL.exe</code>. Seul le nom du fichier est mémorisé dans ce navigateur.</p>
        <label className="button" htmlFor="ultrakill-file">Sélectionner ULTRAKILL.exe</label>
        <input id="ultrakill-file" type="file" accept=".exe,application/vnd.microsoft.portable-executable" hidden onChange={e=>pick(e.target.files?.[0]||null)} />
        {fileName&&<div className="external-file-state"><b>✓ Fichier associé</b><span>{fileName}{size!==null?` · ${(size/1024/1024).toFixed(2)} Mo`:""}</span></div>}
        <div className="external-note">Un navigateur ne peut pas lancer directement un programme Windows local. Pour le lancement automatique, il faut une application compagnon de bureau ou un protocole personnalisé installé sur le PC.</div>
      </section>
      <section className="card external-game-card">
        <h2>🌐 Écosystème TheCombinedWebs</h2>
        <p className="muted">Ton compte TheCombinedWebs fonctionne aussi sur CinéStream et Vortex. Les deux surfaces partagent l'état local de l'écosystème, notamment la dernière section visitée.</p>
        <div style={{display:"flex",gap:8,flexWrap:"wrap"}}><Link href="/cinestream" className="button">Ouvrir CinéStream →</Link><Link href="/vortex" className="button secondary">Ouvrir Vortex →</Link></div>
      </section>
    </div>
  </main>;
}
