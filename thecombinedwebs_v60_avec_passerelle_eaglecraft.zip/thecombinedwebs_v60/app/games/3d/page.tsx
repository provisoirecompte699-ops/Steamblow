import Link from "next/link";
import { redirect } from "next/navigation";
import { catalog } from "@/lib/store";
import { currentUser } from "@/lib/auth";
import GameGallery from "../../GameGallery";

export const dynamic = "force-dynamic";
export default async function ThreeDGamesPage(){
  const user = await currentUser();
  if(!user) { redirect("/special"); return null; }
  const games = catalog.filter((game) => game.is3D);
  const privileged = ["creator", "vice_creator"].includes(user.role);
  const effectiveOwned = privileged ? catalog.map((game) => game.id) : (user.owned || []);
  return (
    <main className="wrap">
      <nav className="nav">
        <Link href="/steamblox" className="brand">TheCombinedWebs</Link>
        <Link href="/steamblox#bibliotheque" className="button secondary">Bibliothèque</Link>
      </nav>
      <section className="card" style={{marginBottom:18}}>
        <div className="eyebrow">JEUX 3D</div>
        <h1>Les expériences 3D</h1>
        <p className="muted">Retrouve tous les jeux 3D de TheCombinedWebs. Tu peux les acheter ici puis les lancer directement depuis ta bibliothèque.</p>
      </section>
      <GameGallery games={games} owned={effectiveOwned} privileged={privileged} />
    </main>
  );
}
