"use client";

import { useEffect, useRef, useState, type PointerEvent } from "react";
import GameTools from "@/app/GameTools";
import useCloudRecord from "@/app/useCloudRecord";
import {gameMemory as localStorage} from "@/app/game-memory";
import MultiplayerPanel from "@/app/games/_components/MultiplayerPanel";
import { connectMultiplayer } from "@/lib/multiplayer";

const W = 960;
const H = 600;
const PLAYER_W = 28;
const PLAYER_H = 38;
const PLATFORM_H = 16;

type Platform = { x: number; y: number; w: number; h: number; moving: boolean; vx: number; spike: boolean; id: number };
type Enemy = { x: number; y: number; vx: number; size: number; id: number };

function clamp(n: number, min: number, max: number) { return Math.max(min, Math.min(max, n)); }

export default function InfiniteAscentClient({ username }: { username: string }) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [score, setScore] = useState(0);
  const [best, setBest] = useState(0);
  useCloudRecord("infinite-ascent",best,setBest);
  const [run, setRun] = useState(0);
  const [dead, setDead] = useState(false);
  const [difficulty, setDifficulty] = useState(1);
  const remotesRef = useRef<Map<string, { name: string; x: number; y: number; score: number }>>(new Map());
  const [mpOverlay, setMpOverlay] = useState<{ name: string; x: number; y: number; score: number }[]>([]);
  const [hostOpts, setHostOpts] = useState<Record<string, unknown>>({});
  // Refs pour exposer l'état du jeu aux callbacks d'hôte
  const enemiesRef = useRef<Enemy[]>([]);
  const playerRef = useRef({ x: 0, y: 0, inv: 0 });
  const cameraYRef = useRef(0);
  const nextIdRef = useRef(1);
  const ctxRef = useRef<CanvasRenderingContext2D | null>(null);
  const scoreRef = useRef(0);
  const sendStateRef = useRef<((state: Record<string, number>) => void) | null>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const context = canvas.getContext("2d", { alpha: false, desynchronized: true });
    if (!context) return;
    const ctx: CanvasRenderingContext2D = context;
    ctxRef.current = ctx;

    let dpr = Math.min(window.devicePixelRatio || 1, 2);
    let raf = 0;
    let last = performance.now();
    let time = 0;
    let deadState = false;
    let started = false;
    let cameraY = 0;
    let distance = 0;
    let scoreValue = 0;
    let bestValue = Number(localStorage.getItem("steamblox:infinite-ascent:best") || 0);
    setBest(bestValue);

    const keys = new Set<string>();
    const platforms: Platform[] = [];
    const enemies: Enemy[] = [];
    enemiesRef.current = enemies;
    let nextId = 1;
    nextIdRef.current = nextId;
    let highestY = H - 70;
    let platformSeed = 7;

    const player = { x: W * 0.5 - PLAYER_W / 2, y: H - 130, vx: 0, vy: 0, onGround: false, coyote: 0, jumpBuffer: 0, inv: 0 };
    playerRef.current = player;

    const rand = () => {
      platformSeed = (platformSeed * 1664525 + 1013904223) >>> 0;
      return platformSeed / 4294967296;
    };

    function resize() {
      dpr = Math.min(window.devicePixelRatio || 1, 2);
      const canvasEl = canvasRef.current;
      if (!canvasEl) return;
      const resizeContext = canvasEl.getContext("2d", { alpha: false, desynchronized: true });
      if (!resizeContext) return;
      canvasEl.width = W * dpr;
      canvasEl.height = H * dpr;
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    }

    function seedWorld() {
      platforms.length = 0;
      enemies.length = 0;
      nextId = 1;
      platformSeed = 7 + Math.floor(Math.random() * 900000);
      const baseY = H - 55;
      platforms.push({ x: 0, y: baseY, w: W, h: PLATFORM_H, moving: false, vx: 0, spike: false, id: nextId++ });
      let x = 430;
      let y = baseY - 105;
      for (let i = 0; i < 18; i++) {
        addPlatform(x, y, i);
        const gap = 78 + rand() * 50;
        y -= 85 + rand() * 55;
        x = clamp(x + (rand() - 0.5) * (230 + i * 4), 40, W - 220);
        if (rand() < 0.08 + i * 0.006) addEnemy(x + 70, y - 28, i);
      }
      highestY = y;
      player.x = W * 0.5 - PLAYER_W / 2;
      player.y = baseY - PLAYER_H - 4;
      player.vx = 0;
      player.vy = -580;
      player.onGround = false;
      player.inv = 1;
      cameraY = 0;
      distance = 0;
      scoreValue = 0;
      deadState = false;
      started = true;
      setDead(false);
      setScore(0);
      setRun(0);
      setDifficulty(1);
    }

    function addPlatform(x: number, y: number, index: number) {
      const diff = Math.min(7, 1 + Math.max(0, distance) / 1400);
      const width = Math.max(78, 175 - diff * 10 + rand() * 50 - Math.min(index, 10) * 1.5);
      const moving = rand() < Math.min(0.08 + diff * 0.055, 0.48);
      const spike = rand() < Math.min(0.04 + diff * 0.018, 0.18);
      platforms.push({ x: clamp(x, 20, W - width - 20), y, w: width, h: PLATFORM_H, moving, vx: moving ? (rand() < 0.5 ? -1 : 1) * (35 + diff * 10) : 0, spike, id: nextId++ });
    }

    function addEnemy(x: number, y: number, index: number) {
      const diff = Math.min(7, 1 + Math.max(0, distance) / 1400);
      if (index < 4 && rand() < 0.55) return;
      enemies.push({ x, y, vx: (rand() < 0.5 ? -1 : 1) * (45 + diff * 12), size: 18 + rand() * 8, id: nextId++ });
    }

    function generateAhead() {
      const diff = Math.min(7, 1 + Math.max(0, distance) / 1400);
      while (highestY > cameraY - 900) {
        const previous = platforms[platforms.length - 1];
        const maxGap = 125 + diff * 9;
        const gapY = 78 + rand() * maxGap;
        const y = previous.y - gapY;
        const horizontalReach = 180 + Math.min(90, diff * 16);
        const x = clamp(previous.x + (rand() - 0.5) * horizontalReach, 25, W - 200);
        addPlatform(x, y, platforms.length);
        if (rand() < 0.14 + diff * 0.035) addEnemy(x + rand() * Math.max(30, previous.w), y - 25, platforms.length);
        highestY = y;
      }
    }

    function reset() {
      if (scoreValue > bestValue) {
        bestValue = scoreValue;
        localStorage.setItem("steamblox:infinite-ascent:best", String(bestValue));
        setBest(bestValue);
      }
      seedWorld();
    }

    function kill() {
      if (deadState) return;
      deadState = true;
      setDead(true);
      if (scoreValue > bestValue) {
        bestValue = scoreValue;
        localStorage.setItem("steamblox:infinite-ascent:best", String(bestValue));
        setBest(bestValue);
      }
    }

    function jump() {
      player.jumpBuffer = 0.13;
    }

    function held(...names: string[]) { const mobile = (window as unknown as { infiniteTouch?: Set<string> }).infiniteTouch; return names.some((n) => keys.has(n) || !!mobile?.has(n)); }

    function onKeyDown(e: KeyboardEvent) {
      const k = e.key.toLowerCase();
      if (["arrowleft", "arrowright", "arrowup", " ", "a", "d", "w", "r"].includes(k)) e.preventDefault();
      keys.add(k);
      if ((k === "arrowup" || k === "w" || k === " ") && !e.repeat) jump();
      if (k === "r" && deadState) reset();
      if (!started) seedWorld();
    }
    function onKeyUp(e: KeyboardEvent) { keys.delete(e.key.toLowerCase()); }

    function update(dt: number) {
      if (!started || deadState) return;
      const difficultyValue = Math.min(8, 1 + distance / 1500);
      const speed = 660 + difficultyValue * 34;
      const gravity = 1500 + difficultyValue * 65;
      const jumpPower = 610 + Math.min(55, difficultyValue * 5);
      const left = held("arrowleft", "a");
      const right = held("arrowright", "d");

      player.jumpBuffer = Math.max(0, player.jumpBuffer - dt);
      player.coyote = Math.max(0, player.coyote - dt);
      player.inv = Math.max(0, player.inv - dt);

      const target = (Number(right) - Number(left)) * speed;
      player.vx += (target - player.vx) * Math.min(1, dt * 10);
      if (!left && !right) player.vx *= Math.pow(0.03, dt);

      const wasGround = player.onGround;
      player.vy += gravity * dt;
      const oldBottom = player.y + PLAYER_H;
      player.x += player.vx * dt;
      player.y += player.vy * dt;
      player.onGround = false;

      if (player.x < 5) { player.x = 5; player.vx *= -0.35; }
      if (player.x + PLAYER_W > W - 5) { player.x = W - PLAYER_W - 5; player.vx *= -0.35; }

      for (const p of platforms) {
        if (p.moving) {
          p.x += p.vx * dt;
          if (p.x < 18 || p.x + p.w > W - 18) p.vx *= -1;
        }
        const overlapX = player.x + PLAYER_W - 4 > p.x && player.x + 4 < p.x + p.w;
        const crossing = oldBottom <= p.y + 5 && player.y + PLAYER_H >= p.y && player.vy >= 0;
        if (overlapX && crossing) {
          player.y = p.y - PLAYER_H;
          player.vy = 0;
          player.onGround = true;
          player.coyote = 0.11;
          if (p.spike && player.inv <= 0) {
            kill();
            return;
          }
        }
      }

      if (!wasGround && player.onGround && player.jumpBuffer > 0) player.jumpBuffer = 0;
      if (player.onGround && player.jumpBuffer > 0) {
        player.vy = -jumpPower;
        player.onGround = false;
        player.jumpBuffer = 0;
      }

      for (const e of enemies) {
        e.x += e.vx * dt;
        if (e.x < 18 || e.x > W - 18) e.vx *= -1;
        const dx = Math.abs(player.x + PLAYER_W / 2 - e.x);
        const dy = Math.abs(player.y + PLAYER_H / 2 - e.y);
        if (player.inv <= 0 && dx < e.size + 15 && dy < e.size + 20) {
          if (player.vy > 120 && player.y + PLAYER_H < e.y + 8) {
            e.y = -10000;
            player.vy = -460;
            scoreValue += 180;
          } else {
            kill();
            return;
          }
        }
      }

      if (player.y < cameraY + 220) cameraY = player.y - 220;
      cameraYRef.current = cameraY;
      if (player.y > cameraY + H + 90) { kill(); return; }
      distance = Math.max(distance, (H - 120) - player.y);
      scoreValue = Math.max(scoreValue, Math.floor(distance / 3));
      scoreRef.current = scoreValue;
      sendStateRef.current?.({ x: player.x, y: player.y, score: scoreValue });
      generateAhead();
      for (let i = platforms.length - 1; i >= 0; i--) if (platforms[i].y > cameraY + H + 500) platforms.splice(i, 1);
      for (let i = enemies.length - 1; i >= 0; i--) if (enemies[i].y > cameraY + H + 500 || enemies[i].y < -9000) enemies.splice(i, 1);

      setScore(scoreValue);
      setRun(Math.floor(distance / 10));
      setDifficulty(Math.round(difficultyValue * 10) / 10);
    }

    function draw(now: number) {
      const diff = Math.min(8, 1 + distance / 1500);
      const sky = ctx.createLinearGradient(0, 0, 0, H);
      sky.addColorStop(0, "#070a19");
      sky.addColorStop(0.55, "#111c38");
      sky.addColorStop(1, "#07111b");
      ctx.fillStyle = sky;
      ctx.fillRect(0, 0, W, H);

      ctx.save();
      for (let i = 0; i < 55; i++) {
        const px = (i * 173 + now * (0.008 + (i % 3) * 0.002)) % W;
        const py = ((i * 83 - cameraY * (0.08 + (i % 5) * 0.01)) % H + H) % H;
        ctx.fillStyle = i % 5 === 0 ? "#9be8ff" : "#ffffff";
        ctx.globalAlpha = 0.15 + (i % 4) * 0.06;
        ctx.fillRect(px, py, 2, 2);
      }
      ctx.globalAlpha = 1;
      for (let i = 0; i < 7; i++) {
        const mx = ((i * 190 - cameraY * 0.03) % (W + 240)) - 120;
        const my = 100 + i * 85;
        ctx.fillStyle = "rgba(90,150,255,.07)";
        ctx.beginPath(); ctx.ellipse(mx, my, 120, 32, 0, 0, Math.PI * 2); ctx.fill();
      }
      ctx.restore();

      ctx.save();
      ctx.translate(0, -cameraY);
      for (const p of platforms) {
        const grad = ctx.createLinearGradient(p.x, p.y, p.x, p.y + p.h);
        grad.addColorStop(0, p.spike ? "#ff728e" : p.moving ? "#b993ff" : "#5de6d0");
        grad.addColorStop(1, p.spike ? "#651d3b" : p.moving ? "#35235f" : "#124b4a");
        ctx.fillStyle = grad;
        ctx.shadowBlur = 18;
        ctx.shadowColor = p.spike ? "#ff416c" : p.moving ? "#a875ff" : "#2ef2cf";
        ctx.fillRect(p.x, p.y, p.w, p.h);
        ctx.shadowBlur = 0;
        ctx.fillStyle = "rgba(255,255,255,.55)";
        ctx.fillRect(p.x, p.y, p.w, 3);
        if (p.spike) {
          ctx.fillStyle = "#ffd0da";
          for (let sx = p.x + 5; sx < p.x + p.w - 7; sx += 18) {
            ctx.beginPath(); ctx.moveTo(sx, p.y); ctx.lineTo(sx + 7, p.y - 13); ctx.lineTo(sx + 14, p.y); ctx.closePath(); ctx.fill();
          }
        }
      }

      for (const e of enemies) {
        if (e.y < -9000) continue;
        ctx.save(); ctx.translate(e.x, e.y);
        ctx.fillStyle = "#ff4d78"; ctx.shadowBlur = 18; ctx.shadowColor = "#ff315f";
        ctx.beginPath(); ctx.arc(0, 0, e.size, 0, Math.PI * 2); ctx.fill(); ctx.shadowBlur = 0;
        ctx.fillStyle = "#151322"; ctx.fillRect(-9, -3, 6, 5); ctx.fillRect(3, -3, 6, 5);
        ctx.restore();
      }

      ctx.save();
      ctx.translate(player.x + PLAYER_W / 2, player.y + PLAYER_H / 2);
      if (player.inv > 0) ctx.globalAlpha = 0.55 + Math.sin(now * 0.02) * 0.35;
      ctx.rotate(clamp(player.vx / 900, -0.2, 0.2));
      ctx.fillStyle = "#5de6ff"; ctx.shadowBlur = 24; ctx.shadowColor = "#32dfff";
      ctx.fillRect(-PLAYER_W / 2, -PLAYER_H / 2, PLAYER_W, PLAYER_H);
      ctx.shadowBlur = 0; ctx.fillStyle = "#eaffff"; ctx.fillRect(-8, -10, 16, 7);
      ctx.fillStyle = "#152a44"; ctx.fillRect(-7, 7, 14, 6);
      ctx.restore();
      ctx.restore();

      ctx.fillStyle = "rgba(4,7,15,.78)";
      ctx.fillRect(16, 16, 350, 82);
      ctx.fillStyle = "#eef7ff"; ctx.font = "900 22px system-ui";
      ctx.fillText("INFINITE ASCENT", 30, 45);
      ctx.font = "600 13px system-ui"; ctx.fillStyle = "#9db3cf";
      ctx.fillText(`Score ${scoreValue.toLocaleString()}   ·   ${Math.floor(distance / 10)} m`, 30, 68);
      ctx.fillText(`Difficulté ${diff.toFixed(1)}x   ·   Record ${bestValue.toLocaleString()}`, 30, 87);

      if (!started) {
        ctx.fillStyle = "rgba(4,7,15,.78)"; ctx.fillRect(0, 0, W, H);
        ctx.fillStyle = "#fff"; ctx.font = "900 46px system-ui"; ctx.textAlign = "center";
        ctx.fillText("INFINITE ASCENT", W / 2, 230);
        ctx.font = "600 18px system-ui"; ctx.fillStyle = "#9fc2dc";
        ctx.fillText("Atteins le sommet. Il n’existe pas.", W / 2, 270);
        ctx.font = "500 15px system-ui"; ctx.fillText("← → / A D pour bouger · Espace / ↑ pour sauter", W / 2, 315);
        ctx.fillText("Sur téléphone : utilise les boutons tactiles", W / 2, 342);
        ctx.textAlign = "left";
      }

      if (deadState) {
        ctx.fillStyle = "rgba(4,7,15,.78)"; ctx.fillRect(0, 0, W, H);
        ctx.fillStyle = "#fff"; ctx.font = "900 44px system-ui"; ctx.textAlign = "center";
        ctx.fillText("RUN TERMINÉ", W / 2, 240);
        ctx.font = "700 21px system-ui"; ctx.fillStyle = "#ff9ab1";
        ctx.fillText(`Score : ${scoreValue.toLocaleString()} · ${Math.floor(distance / 10)} m`, W / 2, 282);
        ctx.font = "600 16px system-ui"; ctx.fillStyle = "#c5d4e8";
        ctx.fillText("R ou REJOUER pour tenter de battre le record", W / 2, 325);
        ctx.textAlign = "left";
      }
    }

    function frame(now: number) {
      const dt = Math.min(0.032, (now - last) / 1000);
      last = now;
      time += dt;
      update(dt);
      draw(time * 1000);
      raf = requestAnimationFrame(frame);
    }

    resize();
    window.addEventListener("resize", resize);
    window.addEventListener("keydown", onKeyDown, { passive: false });
    window.addEventListener("keyup", onKeyUp);
    seedWorld();
    started = false;
    player.vy = 0;
    player.y = H - 130;
    cancelAnimationFrame(raf);
    raf = requestAnimationFrame(frame);

    return () => {
      cancelAnimationFrame(raf);
      window.removeEventListener("resize", resize);
      window.removeEventListener("keydown", onKeyDown);
      window.removeEventListener("keyup", onKeyUp);
      // MultiplayerPanel manages its own connection lifecycle
    };
  }, [username]);

  const press = (key: string, eventKey: string) => (e: PointerEvent) => {
    e.preventDefault();
    const w = window as unknown as { infiniteTouch?: Set<string> };
    w.infiniteTouch ??= new Set();
    w.infiniteTouch.add(key);
    window.dispatchEvent(new KeyboardEvent("keydown", { key: eventKey }));
  };
  const release = (key: string, eventKey: string) => (e: PointerEvent) => {
    e.preventDefault();
    (window as unknown as { infiniteTouch?: Set<string> }).infiniteTouch?.delete(key);
    window.dispatchEvent(new KeyboardEvent("keyup", { key: eventKey }));
  };

  const replay = () => window.dispatchEvent(new KeyboardEvent("keydown", { key: "r" }));

  return (
    <div className="infinite-game-shell">
      <GameTools />
      <div className="infinite-game-toolbar">
        <span>Joueur : {username}</span>
        <span>Score {score.toLocaleString()} · Record {best.toLocaleString()} · {difficulty.toFixed(1)}x</span>
        <span>{dead ? "RUN TERMINÉ" : `${run} m`}</span>
      </div>
      <div className="infinite-game-canvas-wrap">
        <canvas ref={canvasRef} aria-label="Jeu Infinite Ascent" />
        {dead && <button className="button infinite-replay" onClick={replay}>↻ REJOUER</button>}
      </div>
      <div className="infinite-touch-controls" aria-label="Contrôles tactiles">
        <button onPointerDown={press("left", "ArrowLeft")} onPointerUp={release("left", "ArrowLeft")} onPointerCancel={release("left", "ArrowLeft")} onPointerLeave={release("left", "ArrowLeft")}>←</button>
        <button onPointerDown={press("jump", "ArrowUp")} onPointerUp={release("jump", "ArrowUp")} onPointerCancel={release("jump", "ArrowUp")}>JUMP</button>
        <button onPointerDown={press("right", "ArrowRight")} onPointerUp={release("right", "ArrowRight")} onPointerCancel={release("right", "ArrowRight")} onPointerLeave={release("right", "ArrowRight")}>→</button>
      </div>
      <p className="muted infinite-game-tip">Les plateformes sont générées au fur et à mesure. Plus tu montes, plus elles rétrécissent, bougent et cachent des pièges.</p>
      <MultiplayerPanel
        username={username}
        gameId="infinite-ascent"
        compact
        onHostSpawn={(m) => { const e = enemiesRef.current; const nid = nextIdRef; for (let i = 0; i < (m.type === "swarm" ? 5 : 1); i++) e.push({ x: Math.random() * W, y: cameraYRef.current + Math.random() * 300, vx: (Math.random() - 0.5) * 80, size: m.type === "boss" ? 40 : m.type === "tank" ? 30 : 18, id: nid.current++ }); }}
        onHostAction={(action) => { const p = playerRef.current; const e = enemiesRef.current; const c = ctxRef.current; if (action === "heal") p.inv = 2; else if (action === "chaos") { for (let i = 0; i < 5; i++) e.push({ x: Math.random() * W, y: cameraYRef.current + Math.random() * 300, vx: (Math.random() - 0.5) * 120, size: 22, id: nextIdRef.current++ }); } else if (action === "jumpscare" && c) { c.fillStyle = "#ff2e4d"; c.fillRect(0, 0, W, H); } else if (action === "reset") e.length = 0; }}
        onHostModify={(opts) => setHostOpts(opts)}
        onHostClear={() => { enemiesRef.current.length = 0; }}
        onPlayerState={(p) => { remotesRef.current.set(p.id, { name: p.username, x: p.state.x || 0, y: p.state.y || 0, score: p.state.score || 0 }); setMpOverlay([...remotesRef.current.values()]); }}
        onPlayerLeft={(id) => { remotesRef.current.delete(id); setMpOverlay([...remotesRef.current.values()]); }}
        onRoomState={(meta) => { remotesRef.current.clear(); for (const p of meta.players) remotesRef.current.set(p.id, { name: p.name, x: p.x, y: p.y, score: p.score }); setMpOverlay([...remotesRef.current.values()]); }}
        sendStateRef={sendStateRef}
      />
      {mpOverlay.length > 0 && (
        <div className="mp-score-board" style={{ top: "auto", bottom: 12, left: 12 }}>
          {mpOverlay.map((p, i) => <div key={i} className="mp-score-row"><span>👤 {p.name}</span><b>{p.score}</b></div>)}
        </div>
      )}
    </div>
  );
}
