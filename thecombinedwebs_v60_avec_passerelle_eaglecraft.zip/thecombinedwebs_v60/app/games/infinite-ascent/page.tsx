import { currentUser } from "@/lib/auth";
import { catalog, hasGameAccess } from "@/lib/store";
import { redirect } from "next/navigation";
import QuestGameTracker from "@/app/QuestGameTracker";
import InfiniteAscentClient from "./InfiniteAscentClient";

export default async function InfiniteAscentPage() {
  const user = await currentUser();
  if (!user) { redirect("/login"); return null; }
  const game = catalog.find((g) => g.id === "infinite-ascent");
  if (!game) { redirect("/steamblox#bibliotheque"); return null; }
  if (!hasGameAccess(user, game.id)) redirect(`/steamblox?purchase=${game.id}`);
  return (
    <main className="wrap infinite-game-page">
      <QuestGameTracker gameId={game.id} />
      <div className="infinite-game-heading">
        <div>
          <span className="tag accent">GRATUIT · INFINI</span>
          <h1>Infinite Ascent</h1>
          <p className="muted">Monte le plus haut possible. Les plateformes deviennent plus petites, les pièges plus nombreux et la vitesse augmente.</p>
        </div>
      </div>
      <InfiniteAscentClient username={user.username} />
    </main>
  );
}
