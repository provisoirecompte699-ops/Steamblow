import {currentUser} from "@/lib/auth";
import {catalog,hasGameAccess} from "@/lib/store";
import {redirect} from "next/navigation";
import {dailyChallenge} from "@/lib/leaderboard";
import QuestGameTracker from "@/app/QuestGameTracker";
import ArcadeGame from "@/app/games/_components/ArcadeGame";

export default async function Page({searchParams}:{searchParams?:Promise<Record<string,string|undefined>>}){
  const sp=searchParams?await searchParams:{};
  const u=await currentUser();
  if(!u){redirect("/login?next=/games/party-pals");return null;}
  const g=catalog.find(x=>x.id==="party-pals")!;
  if(!hasGameAccess(u,g.id)&&!(sp.daily==="1"&&dailyChallenge().id===g.id))redirect(`/steamblox?purchase=${g.id}`);
  return <main className="arc-page"><QuestGameTracker gameId={g.id}/><ArcadeGame username={u.username} gameId="party-pals" mode="party"/></main>;
}
