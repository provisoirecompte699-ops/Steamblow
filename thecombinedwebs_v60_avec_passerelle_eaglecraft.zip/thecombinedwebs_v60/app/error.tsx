"use client";
import {useEffect} from "react";

export default function Error({error,reset}:{error:Error & {digest?:string};reset:()=>void}){
  useEffect(()=>{console.error("TheCombinedWebs page error",error)},[error]);
  return <main className="error-page"><div className="card error-card"><div className="eyebrow">THECOMBINEDWEBS · RÉCUPÉRATION</div><h1>Un problème est survenu.</h1><p className="muted">La page a rencontré une erreur inattendue. Ta session et ta progression ne sont pas supprimées.</p><div className="actions"><button className="button" onClick={()=>reset()}>Réessayer</button><a className="button secondary" href="/steamblox">Retour à l’accueil</a></div></div></main>
}
