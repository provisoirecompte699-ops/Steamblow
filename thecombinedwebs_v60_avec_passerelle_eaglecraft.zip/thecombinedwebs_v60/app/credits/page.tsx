import Link from "next/link";
import EcosystemBar from "../EcosystemBar";

export const metadata = { title: "Crédits · Écosystème TheCombinedWebs" };

const SERVICES = [
  { href: "/steamblox", icon: "🎮", name: "TheCombinedWebs", text: "La plateforme de jeux : bibliothèque, quêtes, amis, multijoueur et vocal global." },
  { href: "/cinestream", icon: "🍿", name: "CinéStream VF", text: "Catalogue films et séries, connecté avec ton compte TheCombinedWebs." },
  { href: "/discord", icon: "💬", name: "Discord TheCombinedWebs", text: "Salons texte, messages privés et chat vocal avec tes amis." },
  { href: "/vortex", icon: "🎬", name: "Vortex", text: "Le second espace streaming de l’écosystème." },
  { href: "/games/baldi-basics-3d", icon: "📏", name: "Baldi’s Basics 3D", text: "Le jeu 3D intégré à la bibliothèque TheCombinedWebs." },
];

export default function CreditsPage() {
  return <main className="external-game-page">
    <EcosystemBar current="credits" />
    <div className="external-game-shell">
      <Link href="/steamblox" className="button secondary">← TheCombinedWebs</Link>
      <div className="external-game-hero">
        <div className="external-game-badge">ÉCOSYSTÈME THECOMBINEDWEBS</div>
        <h1>Crédits</h1>
        <p>Un seul compte, une seule session : tu te connectes une fois et tu passes des jeux aux films sans te reconnecter.</p>
      </div>
      <section className="card external-game-card credits-hero">
        <h2>⭐ Walid</h2>
        <p className="muted">Merci à Walid, crédité dans tout l’écosystème TheCombinedWebs : TheCombinedWebs, CinéStream, Vortex et Baldi’s Basics 3D.</p>
      </section>
      <section className="card external-game-card">
        <h2>🌐 Les services de l’écosystème</h2>
        <div className="eco-grid">
          {SERVICES.map(s => <Link key={s.href} href={s.href} className="eco-tile"><span>{s.icon}</span><b>{s.name}</b><small>{s.text}</small></Link>)}
        </div>
      </section>
      <section className="card external-game-card">
        <h2>👥 Équipe TheCombinedWebs</h2>
        <p className="muted">Younes (créateur) · Moustafa (vice-créateur) · Walid (crédits de l’écosystème)</p>
      </section>
    </div>
  </main>;
}
