"use client";
import { useEffect, useState } from "react";

type Rec = { title: string; reason: string; icon: string };

const GENRE_MAP: Record<string, string[]> = {
  "Inception": ["Sci-Fi", "Action"], "Matrix": ["Sci-Fi", "Action"], "Interstellar": ["Sci-Fi", "Drame"],
  "Avengers": ["Action", "Super-héros"], "Titanic": ["Drame", "Romance"], "Gladiator": ["Action", "Historique"],
  "Joker": ["Drame", "Thriller"], "Spider-Man": ["Action", "Super-héros"], "Batman": ["Action", "Super-héros"],
  "Pulp Fiction": ["Drame", "Crime"], "Forrest Gump": ["Drame", "Comédie"], "Star Wars": ["Sci-Fi", "Aventure"],
  "Le Seigneur des Anneaux": ["Fantasy", "Aventure"], "Harry Potter": ["Fantasy", "Aventure"],
  "Jurassic Park": ["Sci-Fi", "Aventure"], "Le Roi Lion": ["Animation", "Famille"], "Toy Story": ["Animation", "Comédie"],
};

const ALL_FILMS = Object.keys(GENRE_MAP);

export default function CineRecommendations() {
  const [recs, setRecs] = useState<Rec[]>([]);

  useEffect(() => {
    const log = JSON.parse(localStorage.getItem("cinestream:watch-log") || "[]");
    const watched: string[] = log.map((e: { title: string }) => e.title);

    // Find favorite genres
    const genreCount: Record<string, number> = {};
    watched.forEach((t: string) => { (GENRE_MAP[t] || []).forEach(g => { genreCount[g] = (genreCount[g] || 0) + 1; }); });
    const favGenres = Object.entries(genreCount).sort((a, b) => b[1] - a[1]).slice(0, 2).map(([g]) => g);

    // Recommend unwatched films matching favorite genres
    const unwatched = ALL_FILMS.filter(f => !watched.includes(f));
    const matched = unwatched.filter(f => (GENRE_MAP[f] || []).some(g => favGenres.includes(g)));
    const pool = matched.length >= 3 ? matched : unwatched;

    const picks: Rec[] = pool.slice(0, 4).map(f => ({
      title: f,
      reason: favGenres.length ? `Tu aimes les films ${favGenres.join(" / ")}` : "Nouveau pour toi",
      icon: GENRE_MAP[f]?.includes("Sci-Fi") ? "🚀" : GENRE_MAP[f]?.includes("Animation") ? "🎨" : GENRE_MAP[f]?.includes("Action") ? "💥" : "🎬",
    }));

    // If no history, recommend popular films
    if (!watched.length) {
      setRecs([
        { title: "Inception", reason: "Populaire · Sci-Fi", icon: "🚀" },
        { title: "Forrest Gump", reason: "Populaire · Drame", icon: "🎬" },
        { title: "Le Roi Lion", reason: "Populaire · Famille", icon: "🎨" },
        { title: "Pulp Fiction", reason: "Populaire · Crime", icon: "🎭" },
      ]);
    } else {
      setRecs(picks);
    }
  }, []);

  return <div className="card">
    <div className="section-head"><div><div className="eyebrow">RECOMMANDATIONS</div><h3>Tu aimerais peut-être</h3></div></div>
    <div className="ui-cine-recs">
      {recs.map((r, i) => <div key={i} className="ui-cine-rec">
        <span className="ui-cine-rec-icon">{r.icon}</span>
        <div className="ui-cine-rec-info"><b>{r.title}</b><small>{r.reason}</small></div>
      </div>)}
    </div>
  </div>;
}
