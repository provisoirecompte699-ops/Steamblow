import Link from "next/link";
import {currentUser} from "@/lib/auth";
import {redirect} from "next/navigation";
export default async function Special(){const u=await currentUser();if(u)redirect("/steamblox");return <main className="wrap"><section className="card" style={{maxWidth:560,margin:"80px auto"}}><div className="eyebrow">ESPACE PRIVÉ</div><h1>Connexion</h1><p className="muted">Accède à ton espace de jeu.</p><div className="actions"><Link className="button" href="/login">Se connecter</Link><Link className="button secondary" href="/register">Créer un compte</Link></div><p className="status" style={{marginTop:18}}>Retour aux maths : <Link href="/">Algèbre Facile</Link></p></section></main>}
