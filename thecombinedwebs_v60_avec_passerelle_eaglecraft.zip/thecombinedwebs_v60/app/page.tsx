import Link from "next/link";
import type { Metadata } from "next";
import AlgebraTutor, { ExerciseTrainer } from "./AlgebraTutor";

export const metadata: Metadata = {
  title: "Algèbre Facile — Cours, solveur pas à pas et exercices d’algèbre",
  description: "Cours d’algèbre du collège au lycée, solveur d’équations détaillé (1er et 2nd degré, systèmes) et exercices corrigés générés automatiquement.",
};

type Chapter = { n: string; level: string; title: string; def: string; method: string[]; example: { q: string; steps: string[] }; trap: string };

const CHAPTERS: Chapter[] = [
  { n: "01", level: "5e – 4e", title: "Expressions littérales et réduction",
    def: "Une expression littérale contient une ou plusieurs lettres qui représentent des nombres. Réduire, c’est regrouper les termes semblables (les termes en x, en x², les nombres).",
    method: ["Repérer les termes de même nature.", "Additionner leurs coefficients.", "Écrire le résultat dans l’ordre des puissances décroissantes."],
    example: { q: "Réduire A = 5x + 3 − 2x + 7", steps: ["A = 5x − 2x + 3 + 7", "A = 3x + 10"] },
    trap: "3x + 2 n’est pas égal à 5x : on ne peut pas additionner un terme en x et un nombre." },
  { n: "02", level: "4e", title: "Développer : la distributivité",
    def: "Développer, c’est transformer un produit en somme. Simple distributivité : k(a + b) = ka + kb. Double distributivité : (a + b)(c + d) = ac + ad + bc + bd.",
    method: ["Multiplier chaque terme de la première parenthèse par chaque terme de la seconde.", "Faire attention aux signes : un « − » devant une parenthèse change tous les signes.", "Réduire."],
    example: { q: "Développer B = (2x − 1)(x + 5)", steps: ["B = 2x × x + 2x × 5 − 1 × x − 1 × 5", "B = 2x² + 10x − x − 5", "B = 2x² + 9x − 5"] },
    trap: "−(x − 3) = −x + 3, et non −x − 3." },
  { n: "03", level: "3e", title: "Identités remarquables",
    def: "Trois égalités à connaître par cœur, valables pour tous nombres a et b.",
    method: ["(a + b)² = a² + 2ab + b²", "(a − b)² = a² − 2ab + b²", "(a + b)(a − b) = a² − b²"],
    example: { q: "Développer C = (x + 3)²", steps: ["C = x² + 2 × x × 3 + 3²", "C = x² + 6x + 9"] },
    trap: "(x + 3)² n’est pas égal à x² + 9 : il manque le double produit 6x." },
  { n: "04", level: "3e", title: "Factoriser",
    def: "Factoriser, c’est transformer une somme en produit. On cherche un facteur commun, ou on reconnaît une identité remarquable.",
    method: ["Chercher un facteur commun à tous les termes.", "L’écrire devant une parenthèse contenant ce qui reste.", "Sinon, reconnaître a² − b², a² + 2ab + b² ou a² − 2ab + b²."],
    example: { q: "Factoriser D = x² − 16", steps: ["D = x² − 4²", "D = (x − 4)(x + 4)"] },
    trap: "Vérifie toujours en redéveloppant : tu dois retrouver l’expression de départ." },
  { n: "05", level: "4e – 3e", title: "Équations du premier degré",
    def: "Résoudre une équation, c’est trouver toutes les valeurs de l’inconnue qui rendent l’égalité vraie. On peut ajouter, soustraire, multiplier ou diviser les deux membres par un même nombre (non nul pour × et ÷).",
    method: ["Développer et réduire chaque membre.", "Regrouper les termes en x d’un côté, les nombres de l’autre.", "Diviser par le coefficient de x.", "Vérifier en remplaçant x dans l’équation de départ."],
    example: { q: "Résoudre 3(x − 2) + 5 = 2x + 7", steps: ["3x − 6 + 5 = 2x + 7", "3x − 1 = 2x + 7", "3x − 2x = 7 + 1", "x = 8"] },
    trap: "Quand on « passe » un terme de l’autre côté, il change de signe : c’est en réalité une soustraction faite des deux côtés." },
  { n: "06", level: "3e", title: "Équation produit nul",
    def: "Un produit de facteurs est nul si et seulement si l’un au moins de ses facteurs est nul : A × B = 0 ⇔ A = 0 ou B = 0.",
    method: ["Mettre l’équation sous la forme « produit = 0 » (factoriser si besoin).", "Résoudre chaque équation A = 0 et B = 0.", "Donner toutes les solutions."],
    example: { q: "Résoudre (x − 2)(3x + 6) = 0", steps: ["x − 2 = 0   ou   3x + 6 = 0", "x = 2   ou   x = −2"] },
    trap: "Ne pas diviser par x : on perdrait la solution x = 0 (par exemple dans 3x² = 12x)." },
  { n: "07", level: "3e – 2nde", title: "Inéquations",
    def: "Une inéquation se résout comme une équation, avec une règle en plus : multiplier ou diviser par un nombre négatif inverse le sens de l’inégalité.",
    method: ["Regrouper les x d’un côté, les nombres de l’autre.", "Diviser par le coefficient de x en changeant le sens si ce coefficient est négatif.", "Écrire l’ensemble des solutions sous forme d’intervalle."],
    example: { q: "Résoudre −2x + 5 > 11", steps: ["−2x > 6", "x < −3  (on divise par −2 : le sens change)", "S = ]−∞ ; −3["] },
    trap: "Oublier d’inverser le sens en divisant par un nombre négatif." },
  { n: "08", level: "2nde", title: "Systèmes de deux équations",
    def: "Un système linéaire de deux équations à deux inconnues x et y admet, selon les cas, une solution unique, aucune solution ou une infinité de solutions.",
    method: ["Substitution : exprimer une inconnue en fonction de l’autre puis remplacer.", "Combinaison : multiplier les équations pour éliminer une inconnue.", "Déterminant : si D = a₁b₂ − a₂b₁ ≠ 0, la solution est unique."],
    example: { q: "Résoudre { 2x + 3y = 12 ; x − y = 1 }", steps: ["x = y + 1", "2(y + 1) + 3y = 12  ⇔  5y = 10  ⇔  y = 2", "x = 3"] },
    trap: "Toujours vérifier le couple trouvé dans les deux équations." },
  { n: "09", level: "1re", title: "Second degré et discriminant",
    def: "Pour ax² + bx + c = 0 (a ≠ 0), on calcule Δ = b² − 4ac. Si Δ > 0 : deux solutions x = (−b ± √Δ) / (2a). Si Δ = 0 : une solution x₀ = −b / (2a). Si Δ < 0 : aucune solution réelle.",
    method: ["Identifier a, b et c (attention aux signes).", "Calculer Δ.", "Conclure selon le signe de Δ.", "Factoriser : a(x − x₁)(x − x₂)."],
    example: { q: "Résoudre x² − 5x + 6 = 0", steps: ["a = 1, b = −5, c = 6", "Δ = 25 − 24 = 1", "x₁ = (5 − 1) / 2 = 2   ;   x₂ = (5 + 1) / 2 = 3"] },
    trap: "Avec b négatif, b² est positif : (−5)² = 25, pas −25." },
  { n: "10", level: "2nde", title: "Étude de fonctions affines",
    def: "Une fonction affine f(x) = ax + b a pour représentation graphique une droite de coefficient directeur a et d'ordonnée à l'origine b. Sa racine (l'antécédent de 0) est x = −b/a.",
    method: ["Identifier le coefficient a et l'ordonnée b.", "La racine est x = −b/a (si a ≠ 0).", "Si a > 0 : la fonction est croissante ; si a < 0 : décroissante.", "Construire le tableau de signes à partir de la racine."],
    example: { q: "Étudier f(x) = 2x − 6", steps: ["a = 2, b = −6", "Racine : x = 6/2 = 3", "a > 0 : f est croissante", "f(x) < 0 sur ]−∞ ; 3[, f(x) > 0 sur ]3 ; +∞["] },
    trap: "Le signe de a détermine le sens de variation, pas le signe de b." },
  { n: "11", level: "1re", title: "Étude de fonctions du second degré",
    def: "Pour f(x) = ax² + bx + c, la forme canonique est f(x) = a(x − α)² + β où α = −b/(2a) et β = f(α). Le point S(α ; β) est le sommet de la parabole.",
    method: ["Calculer α = −b/(2a) et β = c − b²/(4a).", "Le sommet est S(α ; β) et l'axe de symétrie est x = α.", "Si a > 0 : parabole vers le haut (minimum en β). Si a < 0 : vers le bas (maximum en β).", "Étudier le signe avec Δ : si Δ ≤ 0, la fonction garde un signe constant."],
    example: { q: "Étudier f(x) = x² − 4x + 3", steps: ["α = 4/2 = 2 ; β = 3 − 4 = −1", "Sommet S(2 ; −1), axe x = 2", "a > 0 : parabole vers le haut", "Δ = 16 − 12 = 4 ; racines 1 et 3"] },
    trap: "β n'est pas égal à c : c'est f(α), donc il faut soustraire b²/(4a) à c." },
];

const FORMULAS = [
  ["Distributivité", "k(a + b) = ka + kb"],
  ["Double distributivité", "(a + b)(c + d) = ac + ad + bc + bd"],
  ["Carré d’une somme", "(a + b)² = a² + 2ab + b²"],
  ["Carré d’une différence", "(a − b)² = a² − 2ab + b²"],
  ["Différence de deux carrés", "a² − b² = (a − b)(a + b)"],
  ["Discriminant", "Δ = b² − 4ac"],
  ["Racines (Δ > 0)", "x = (−b ± √Δ) / (2a)"],
  ["Somme et produit des racines", "x₁ + x₂ = −b/a   ·   x₁x₂ = c/a"],
  ["Forme canonique", "f(x) = a(x − α)² + β   avec α = −b/(2a)"],
  ["Sommet de la parabole", "S(α ; β)   ·   β = f(α) = c − b²/(4a)"],
  ["Racine d'une fonction affine", "f(x) = ax + b = 0  ⇔  x = −b/a"],
];

export default function Home() {
  return <main className="af">
    <header className="af-nav">
      <Link href="/" className="af-brand"><span className="af-logo">x²</span>Algèbre Facile</Link>
      <nav><a href="#cours">Cours</a><a href="#solveur">Solveur</a><a href="#exercices">Exercices</a><a href="#formulaire">Formulaire</a></nav>
    </header>

    <section className="af-hero">
      <p className="af-kicker">Mathématiques · de la 5e à la 1re</p>
      <h1>Comprendre l’algèbre, étape par étape.</h1>
      <p className="af-lead">Des cours courts, un solveur qui détaille chaque étape comme au tableau, des exercices corrigés générés à l’infini, des inéquations et des études de fonctions. Gratuit, sans inscription.</p>
      <div className="af-hero-actions"><a className="af-btn" href="#solveur">Résoudre une équation</a><a className="af-btn ghost" href="#exercices">S’entraîner</a></div>
      <ul className="af-points"><li><b>11</b> chapitres</li><li><b>6</b> niveaux d’exercices</li><li><b>Étude</b> de fonctions</li><li><b>Inéquations</b> pas à pas</li><li><b>Calcul exact</b> en fractions</li></ul>
    </section>

    <section id="solveur" className="af-section">
      <div className="af-head"><h2>Solveur pas à pas</h2><p>Équations du 1er et du 2nd degré, développement, factorisation, systèmes, inéquations et étude de fonctions. Chaque étape est justifiée et le résultat est vérifié.</p></div>
      <AlgebraTutor />
    </section>

    <section id="cours" className="af-section">
      <div className="af-head"><h2>Cours</h2><p>L’essentiel de chaque notion : définition, méthode, exemple corrigé et erreur fréquente.</p></div>
      <div className="af-chapters">
        {CHAPTERS.map(c => <details key={c.n} className="af-chapter">
          <summary><span className="af-ch-n">{c.n}</span><span className="af-ch-t">{c.title}</span><span className="af-ch-l">{c.level}</span></summary>
          <div className="af-ch-body">
            <p>{c.def}</p>
            <h4>Méthode</h4>
            <ol>{c.method.map(m => <li key={m}>{m}</li>)}</ol>
            <div className="af-example"><p className="af-example-q">Exemple — {c.example.q}</p>{c.example.steps.map(s => <pre key={s} className="af-math">{s}</pre>)}</div>
            <p className="af-trap"><b>Erreur fréquente :</b> {c.trap}</p>
          </div>
        </details>)}
      </div>
    </section>

    <section id="exercices" className="af-section">
      <div className="af-head"><h2>Exercices corrigés</h2><p>Un nouvel exercice à chaque clic. Deux essais, puis la correction détaillée s’affiche. Ta progression reste sur cet appareil.</p></div>
      <ExerciseTrainer />
    </section>

    <section id="formulaire" className="af-section">
      <div className="af-head"><h2>Formulaire</h2><p>Les formules à connaître, sur une seule page.</p></div>
      <div className="af-formulas">{FORMULAS.map(([k, v]) => <div key={k}><span>{k}</span><pre className="af-math">{v}</pre></div>)}</div>
    </section>

    <footer className="af-footer">
      <div><b>Algèbre Facile</b><p>Ressource pédagogique gratuite pour réviser l’algèbre du collège et du lycée. Les contenus suivent les notions des programmes de mathématiques de 5e, 4e, 3e, seconde et première.</p></div>
      <div className="af-footer-links"><a href="#cours">Cours</a><a href="#solveur">Solveur</a><a href="#exercices">Exercices</a><Link href="/special" className="af-quiet">Espace membre</Link></div>
    </footer>
  </main>;
}
