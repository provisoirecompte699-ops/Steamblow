"use client";
import { useEffect, useRef, useState } from "react";
import { useRouter } from "next/navigation";
import { io, type Socket } from "socket.io-client";

const SERVER = process.env.NEXT_PUBLIC_MULTIPLAYER_SERVER_URL || "";
type Msg = (m: { t: string; ok: boolean } | null) => void;
type WState = { title: string; playing: boolean; pos: number; at: number; hostId?: string; serverTime?: number };
type P = { name: string; x: number; y: number; score: number };
const fmt = (s: number) => `${Math.floor(Math.max(0, s) / 60)}:${String(Math.floor(Math.max(0, s) % 60)).padStart(2, "0")}`;

export default function Realtime({ me, games, setMsg }: { me: string; games: { id: string; title: string }[]; setMsg: Msg }) {
  const router = useRouter(); const sock = useRef<Socket | null>(null);
  const [status, setStatus] = useState<"off" | "connecting" | "ready" | "error">(SERVER ? "connecting" : "off"); const [online, setOnline] = useState(0);
  // matchmaking
  const [game, setGame] = useState(games[0]?.id || ""); const [queue, setQueue] = useState<number | null>(null);
  // salon de visionnage
  const [code, setCode] = useState(""); const [room, setRoom] = useState<string | null>(null); const [hostId, setHostId] = useState(""); const [members, setMembers] = useState<{ id: string; name: string; host: boolean }[]>([]);
  const [ws, setWs] = useState<WState>({ title: "", playing: false, pos: 0, at: Date.now() }); const [offset, setOffset] = useState(0); const [tick, setTick] = useState(0);
  const [goAt, setGoAt] = useState(0); const [chat, setChat] = useState<{ from: string; text: string }[]>([]); const [text, setText] = useState(""); const [title, setTitle] = useState("");
  // spectateur
  const [rooms, setRooms] = useState<{ roomId: string; game: string; players: number; started: boolean }[]>([]); const [spec, setSpec] = useState<string | null>(null);
  const [players, setPlayers] = useState<Record<string, P>>({}); const cv = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    if (!SERVER) return; let alive = true; let s: Socket | null = null;
    (async () => {
      try {
        const r = await fetch("/api/global-voice", { cache: "no-store" }); if (!r.ok) throw 0; const { username, token } = await r.json();
        s = io(SERVER, { transports: ["websocket", "polling"], reconnection: true, reconnectionDelay: 800 }); sock.current = s;
        s.on("connect", () => s!.emit("tcb:auth", { username, token }, (a: { ok: boolean; online?: number }) => { if (!alive) return; if (a?.ok) { setStatus("ready"); setOnline(a.online || 0); } else setStatus("error"); }));
        s.on("connect_error", () => alive && setStatus("error")); s.on("disconnect", () => alive && setStatus("connecting"));
        s.on("tcb:online", (d) => setOnline(d.count));
        s.on("mm:waiting", (d) => setQueue(d.size)); s.on("mm:left", () => setQueue(null));
        s.on("mm:found", (d) => { setQueue(null); setMsg({ t: `Adversaire trouvé : ${d.opponent} ! Direction le salon…`, ok: true }); setTimeout(() => router.push(`/multiplayer?room=${encodeURIComponent(d.roomId)}`), 900); });
        s.on("mm:error", (d) => setMsg({ t: d.message, ok: false }));
        s.on("wp:joined", (d) => { setRoom(d.code); setHostId(d.hostId); setWs(d.state); setOffset(d.state.serverTime - Date.now()); setTitle(d.state.title || ""); setChat([]); });
        s.on("wp:members", (m) => setMembers(m));
        s.on("wp:state", (d: WState) => { setWs(d); setHostId(d.hostId || ""); setOffset((d.serverTime || Date.now()) - Date.now()); });
        s.on("wp:countdown", (d) => { setGoAt(d.goAt); setOffset(d.serverTime - Date.now()); });
        s.on("wp:chat", (m) => setChat((c) => [...c.slice(-39), m])); s.on("wp:error", (d) => setMsg({ t: d.message, ok: false }));
        s.on("spec:error", (d) => setMsg({ t: d.message, ok: false }));
        s.on("spec:joined", (d) => { const o: Record<string, P> = {}; (d.players || []).forEach((p: any) => { o[p.id] = { name: p.name, x: p.x, y: p.y, score: p.score }; }); setPlayers(o); });
        s.on("room:state", (d) => setPlayers((prev) => { const o: Record<string, P> = {}; (d.players || []).forEach((p: any) => { o[p.id] = { name: p.name, x: prev[p.id]?.x ?? p.x, y: prev[p.id]?.y ?? p.y, score: p.score }; }); return o; }));
        s.on("player:state", (d) => setPlayers((prev) => ({ ...prev, [d.id]: { name: d.player?.name || d.username || "?", x: d.state.x, y: d.state.y, score: d.state.score ?? 0 } })));
      } catch { if (alive) setStatus("error"); }
    })();
    const t = setInterval(() => setTick((n) => n + 1), 250);
    return () => { alive = false; clearInterval(t); s?.disconnect(); };
  }, [router, setMsg]);

  // radar du spectateur
  useEffect(() => {
    const c = cv.current; if (!c || !spec) return; const g = c.getContext("2d")!; const list = Object.values(players) as P[];
    g.fillStyle = "#0b0d13"; g.fillRect(0, 0, c.width, c.height); if (!list.length) return;
    const xs = list.map((p) => p.x), ys = list.map((p) => p.y); const minX = Math.min(...xs), maxX = Math.max(...xs), minY = Math.min(...ys), maxY = Math.max(...ys);
    const sx = (c.width - 80) / Math.max(1, maxX - minX), sy = (c.height - 80) / Math.max(1, maxY - minY); const k = Math.min(sx, sy, 2);
    list.forEach((p, i) => { const x = 40 + (p.x - minX) * k + ((c.width - 80) - (maxX - minX) * k) / 2, y = 40 + (p.y - minY) * k + ((c.height - 80) - (maxY - minY) * k) / 2;
      g.fillStyle = ["#8b7cff", "#5ee7c4", "#f5c542", "#ff7a90"][i % 4]; g.beginPath(); g.arc(x, y, 9, 0, 7); g.fill(); g.fillStyle = "#fff"; g.font = "700 12px system-ui"; g.textAlign = "center"; g.fillText(p.name, x, y - 14); });
  }, [players, spec]);

  const emit = (e: string, d?: unknown) => sock.current?.emit(e, d);
  const isHost = !!room && sock.current?.id === hostId;
  const now = Date.now() + offset; void tick;
  const pos = ws.playing ? Math.max(0, ws.pos + (now - ws.at) / 1000) : ws.pos;
  const cd = goAt > now ? Math.ceil((goAt - now) / 1000) : 0;
  const sendState = (p: Partial<WState>) => emit("wp:state", { title, playing: ws.playing, pos, ...p });

  if (status === "off") return <div className="hub-card"><h3>⚡ Temps réel</h3><p className="hub-sub">Le serveur temps réel n’est pas configuré. Netlify ne gère pas les WebSockets : héberge <code>multiplayer-server/</code> (voir DEPLOY_MULTIPLAYER.md) puis définis <code>NEXT_PUBLIC_MULTIPLAYER_SERVER_URL</code>.</p></div>;
  const ready = status === "ready";
  return <div className="hub-grid">
    <div className="hub-card" style={{ gridColumn: "1/-1" }}><span className={`hub-pill ${ready ? "ok" : "wait"}`}>{ready ? `🟢 Connecté · ${online} en ligne` : status === "error" ? "🔴 Connexion impossible" : "🟡 Connexion…"}</span>
      <p className="hub-sub" style={{ marginTop: 8 }}>Connecté comme <b>{me}</b>. {status === "error" && "Vérifie la connexion et la configuration du serveur temps réel."}</p></div>

    <div className="hub-card"><h3>⚔️ Matchmaking rapide</h3><p className="hub-sub">Choisis un jeu : dès qu’un autre joueur cherche le même, vous êtes envoyés dans le même salon.</p>
      <div className="hub-row"><select className="hub-select" value={game} onChange={(e) => setGame(e.target.value)} disabled={queue !== null}>{games.map((g) => <option key={g.id} value={g.id}>{g.title}</option>)}</select>
        {queue === null ? <button className="hub-btn acc" disabled={!ready} onClick={() => emit("mm:join", { game })}>Chercher</button> : <button className="hub-btn danger" onClick={() => emit("mm:leave")}>Annuler</button>}</div>
      {queue !== null && <p className="hub-sub" style={{ marginTop: 8 }}>🔎 Recherche d’un adversaire… ({queue} en file)</p>}</div>

    <div className="hub-card"><h3>👀 Spectateur</h3><p className="hub-sub">Regarde en direct les salons multijoueurs en cours (vue radar des positions).</p>
      <div className="hub-row"><button className="hub-btn" disabled={!ready} onClick={() => sock.current?.emit("spec:list", null, (r: typeof rooms) => setRooms(r))}>Actualiser</button>{spec && <button className="hub-btn danger" onClick={() => { emit("spec:leave", { roomId: spec }); setSpec(null); setPlayers({}); }}>Quitter</button>}</div>
      {rooms.length === 0 ? <p className="hub-sub" style={{ marginTop: 8 }}>Aucun salon actif.</p> : rooms.map((r) => <div key={r.roomId} className="hub-row" style={{ marginTop: 8 }}><b>{r.roomId}</b><span className="hub-pill">{r.game}</span><span className="hub-sub" style={{ margin: 0 }}>{r.players} joueur(s){r.started ? " · en cours" : ""}</span><button className="hub-btn sm acc" onClick={() => { if (spec) emit("spec:leave", { roomId: spec }); setPlayers({}); setSpec(r.roomId); emit("spec:join", { roomId: r.roomId }); }}>Regarder</button></div>)}</div>
    {spec && <div className="hub-card" style={{ gridColumn: "1/-1" }}><h3>📡 Salon {spec}</h3><canvas ref={cv} width={640} height={320} style={{ width: "100%", maxWidth: 640, borderRadius: 12, border: "1px solid #2a2f3a" }} />
      <p className="hub-sub">{(Object.values(players) as P[]).map((p) => `${p.name} (${p.score})`).join(" · ") || "En attente des joueurs…"}</p></div>}

    <div className="hub-card" style={{ gridColumn: "1/-1" }}><h3>🍿 Salon de visionnage synchronisé</h3>
      {!room ? <>
        <p className="hub-sub">Crée un salon ou rejoins celui d’un ami avec son code. L’hôte pilote une horloge commune et lance un compte à rebours : tout le monde appuie sur lecture dans CinéStream au « GO ».</p>
        <div className="hub-row"><input className="hub-input" placeholder="Code du salon (vide = nouveau)" value={code} onChange={(e) => setCode(e.target.value.toUpperCase())} style={{ width: 240 }} /><button className="hub-btn acc" disabled={!ready} onClick={() => emit("wp:join", { code })}>{code ? "Rejoindre" : "Créer un salon"}</button></div></> : <>
        <div className="hub-row" style={{ marginBottom: 10 }}><b>Salon {room}</b><button className="hub-btn sm" onClick={() => navigator.clipboard?.writeText(room)}>Copier le code</button><a className="hub-btn sm" href="/cinestream" target="_blank" rel="noreferrer">Ouvrir CinéStream</a><button className="hub-btn sm danger" onClick={() => { emit("wp:leave"); setRoom(null); setMembers([]); setGoAt(0); }}>Quitter</button></div>
        <p className="hub-sub">👥 {members.map((m) => `${m.name}${m.host ? " 👑" : ""}`).join(", ")}</p>
        {cd > 0 ? <div style={{ fontSize: 72, fontWeight: 950, textAlign: "center", margin: "10px 0" }}>{cd}</div> : <div style={{ fontSize: 40, fontWeight: 900, textAlign: "center", margin: "10px 0" }}>{ws.title ? `${ws.title} · ` : ""}{ws.playing ? (pos > 0 ? `▶ ${fmt(pos)}` : "GO !") : `⏸ ${fmt(pos)}`}</div>}
        {isHost ? <div className="hub-row"><input className="hub-input" placeholder="Titre du film" value={title} maxLength={80} onChange={(e) => setTitle(e.target.value)} onBlur={() => sendState({ title })} />
          <button className="hub-btn acc" onClick={() => emit("wp:countdown")}>⏱ Compte à rebours 5 s</button>
          <button className="hub-btn" onClick={() => sendState({ playing: !ws.playing, pos })}>{ws.playing ? "⏸ Pause" : "▶ Reprendre"}</button>
          <button className="hub-btn sm" onClick={() => sendState({ pos: Math.max(0, pos - 10) })}>−10 s</button><button className="hub-btn sm" onClick={() => sendState({ pos: pos + 10 })}>+10 s</button></div>
          : <p className="hub-sub">L’hôte contrôle l’horloge commune.</p>}
        <div style={{ margin: "12px 0", maxHeight: 160, overflow: "auto" }}>{chat.map((m, i) => <p key={i} className="hub-sub" style={{ margin: "2px 0" }}><b>{m.from}</b> : {m.text}</p>)}</div>
        <div className="hub-row"><input className="hub-input" style={{ flex: 1 }} maxLength={160} placeholder="Écrire au salon…" value={text} onChange={(e) => setText(e.target.value)} onKeyDown={(e) => { if (e.key === "Enter" && text.trim()) { emit("wp:chat", { text }); setText(""); } }} /><button className="hub-btn" onClick={() => { if (text.trim()) { emit("wp:chat", { text }); setText(""); } }}>Envoyer</button></div></>}
    </div>
  </div>;
}
