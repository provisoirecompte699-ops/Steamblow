"use client";
import { useCallback, useEffect, useRef, useState } from "react";

type Props = {
  onFinish: (won: boolean, score: number) => void;
  onClose: () => void;
};

type Kind = "flash" | "smoke" | "crs" | "barricade" | "medkit" | "van";
type Entity = {
  x: number; y: number; vx: number; vy: number;
  r: number; kind: Kind; life?: number; frame?: number; hp?: number;
};
type Particle = { x: number; y: number; vx: number; vy: number; life: number; max: number; color: string; size: number; g?: number };
type Floater = { x: number; y: number; text: string; life: number; color: string };

const W = 160;
const H = 224;
const GOAL = 1600;

function makeSprite(rows: string[], palette: Record<string, string>) {
  const h = rows.length;
  const w = Math.max(...rows.map((r) => r.length));
  const c = document.createElement("canvas");
  c.width = w; c.height = h;
  const ctx = c.getContext("2d")!;
  const img = ctx.createImageData(w, h);
  for (let y = 0; y < h; y++) {
    for (let x = 0; x < (rows[y]?.length || 0); x++) {
      const ch = rows[y][x];
      if (ch === "." || ch === " ") continue;
      const hex = palette[ch];
      if (!hex) continue;
      const i = (y * w + x) * 4;
      const n = parseInt(hex.slice(1), 16);
      img.data[i] = (n >> 16) & 255;
      img.data[i + 1] = (n >> 8) & 255;
      img.data[i + 2] = n & 255;
      img.data[i + 3] = 255;
    }
  }
  ctx.putImageData(img, 0, 0);
  return c;
}

const P = {
  skin: "#f0c8a0", skinD: "#d4a574", shirt: "#7c6cf0", shirtD: "#5a4bd4", pant: "#2d3436", shoe: "#1e272e",
  eye: "#1a1a1a", hair: "#3d2914",
  green: "#3d5c3a", greenD: "#2a4028", greenL: "#5a7a55", helmet: "#1a1a1a", visor: "#6a9a55",
  shield: "#d4af37", shieldD: "#8a7018", boot: "#111",
  yel: "#ffd93d", yelH: "#fff3a0", ora: "#ff9f1a", red: "#e74c3c",
  g1: "#b0b6bc", g2: "#7a828c", g3: "#4b5563",
  asphalt: "#242830", asphaltL: "#2e333c", asphaltD: "#1a1d24",
  line: "#d8d0a0", curb: "#4a3a28", curbL: "#6a5640",
  barr: "#6B3A1A", barrL: "#8B5A2B", cone: "#ff6b35", coneW: "#f5f5f5",
  blood: "#c0392b", white: "#f5f5f5", black: "#0d0d0d",
  neon: "#5ee7c4", purple: "#8b7cff", van: "#2c3e50", vanL: "#3d566e",
  med: "#2ecc71", medC: "#fff",
};

let SPR: {
  player: HTMLCanvasElement[];
  playerDash: HTMLCanvasElement;
  crs: HTMLCanvasElement[];
  flash: HTMLCanvasElement[];
  smoke: HTMLCanvasElement[];
  barricade: HTMLCanvasElement;
  cone: HTMLCanvasElement;
  medkit: HTMLCanvasElement;
  van: HTMLCanvasElement;
  lamp: HTMLCanvasElement;
} | null = null;

function ensureSprites() {
  if (SPR) return SPR;
  const pl = { S: P.skin, D: P.skinD, E: P.eye, H: P.shirt, h: P.shirtD, P: P.pant, B: P.shoe, A: P.hair };
  const playerA = makeSprite([
    "...AAAA..",
    "..SSSSSS.",
    ".SDEEEDS.",
    ".SSSSSSS.",
    "..HHHHH..",
    ".HhHHHhH.",
    "H.HHHHH.H",
    "..PPPPP..",
    "..PP.PP..",
    "..B...B..",
  ], pl);
  const playerB = makeSprite([
    "...AAAA..",
    "..SSSSSS.",
    ".SDEEEDS.",
    ".SSSSSSS.",
    "..HHHHH..",
    ".HhHHHhH.",
    "H.HHHHH.H",
    "..PPPPP..",
    ".PP...PP.",
    "B.......B",
  ], pl);
  const playerDash = makeSprite([
    "...AAAA..",
    "..SSSSSS.",
    ".SDEEEDS.",
    ".SSSSSSS.",
    "HHHHHHHHH",
    "HhHHHHHhH",
    "..PPPPP..",
    ".PP...PP.",
    "B.......B",
    ".........",
  ], pl);

  const cr = { M: P.helmet, V: P.visor, G: P.green, D: P.greenD, L: P.greenL, B: P.boot, S: P.shield, s: P.shieldD };
  const crsA = makeSprite([
    "..MMMMM..",
    ".MMMMMMM.",
    ".MVVVVVM.",
    ".MMMMMMM.",
    ".LGGGGGL.",
    "G.GGGGG.G",
    "G.GGGGG.G",
    "..GGGGG..",
    ".DD...DD.",
    ".BB...BB.",
  ], cr);
  const crsB = makeSprite([
    "..MMMMM..",
    ".MMMMMMM.",
    ".MVVVVVM.",
    ".MMMMMMM.",
    ".LGGGGGL.",
    "G.GGGGG.G",
    "G.GGGGG.G",
    "..GGGGG..",
    "DD.....DD",
    "BB.....BB",
  ], cr);

  const flash0 = makeSprite([
    "....YY....",
    "...YHHY...",
    "..YHHHHY..",
    ".YHHYYHHY.",
    "YHHY..YHHY",
    "YHHY..YHHY",
    ".YHHYYHHY.",
    "..YHHHHY..",
    "...YHHY...",
    "....YY....",
  ], { Y: P.yel, H: P.yelH });
  const flash1 = makeSprite([
    "....OO....",
    "...OYYO...",
    "..OYHHYO..",
    ".OYHYYHYO.",
    "OYHY..YHYO",
    "OYHY..YHYO",
    ".OYHYYHYO.",
    "..OYHHYO..",
    "...OYYO...",
    "....OO....",
  ], { Y: P.yel, H: P.yelH, O: P.ora });

  const smoke0 = makeSprite([
    "........",
    "...11...",
    "..1221..",
    ".122221.",
    ".122221.",
    "..1221..",
    "...11...",
    "........",
  ], { "1": P.g1, "2": P.g2 });
  const smoke1 = makeSprite([
    "..1111..",
    ".122221.",
    "12233221",
    "12333321",
    "12333321",
    "12233221",
    ".122221.",
    "..1111..",
  ], { "1": P.g1, "2": P.g2, "3": P.g3 });
  const smoke2 = makeSprite([
    ".111111.",
    "12222221",
    "12333321",
    "12322321",
    "12333321",
    "12222221",
    ".111111.",
    "........",
  ], { "1": P.g1, "2": P.g2, "3": P.g3 });

  const barricade = makeSprite([
    "BBBBBBBBBBBBBB",
    "BLLLLLLLLLLLLB",
    "BBBBBBBBBBBBBB",
    "B..B......B..B",
    "B..B......B..B",
    "BBBBBBBBBBBBBB",
    "BLLLLLLLLLLLLB",
    "BBBBBBBBBBBBBB",
  ], { B: P.barr, L: P.barrL });

  const cone = makeSprite([
    "....OO....",
    "...OOOO...",
    "...OWWO...",
    "..OOOOOO..",
    "..OWWWWO..",
    ".OOOOOOOO.",
    ".OWWWWWWO.",
    "OOOOOOOOOO",
  ], { O: P.cone, W: P.coneW });

  const medkit = makeSprite([
    "..WWWWWW..",
    ".WWMMMMWW.",
    "WWMMCCMMWW",
    "WWMCCCCMMW",
    "WWMMCCMMWW",
    ".WWMMMMWW.",
    "..WWWWWW..",
    "..........",
  ], { W: P.white, M: P.med, C: P.medC });

  const van = makeSprite([
    "....VVVVVV....",
    "...VVVVVVVV...",
    "..VVLLLLLLVV..",
    ".VVLLLLLLLLVV.",
    "VVLLWWWWWWLLVV",
    "VVLLLLLLLLLLVV",
    "VVVVVVVVVVVVVV",
    ".BB........BB.",
  ], { V: P.van, L: P.vanL, W: P.white, B: P.black });

  const lamp = makeSprite([
    "...YY...",
    "..YHHY..",
    "..YYYY..",
    "...GG...",
    "...GG...",
    "...GG...",
    "...GG...",
    "..GGGG..",
  ], { Y: P.yel, H: P.yelH, G: P.g3 });

  SPR = {
    player: [playerA, playerB],
    playerDash,
    crs: [crsA, crsB],
    flash: [flash0, flash1],
    smoke: [smoke0, smoke1, smoke2],
    barricade, cone, medkit, van, lamp,
  };
  return SPR;
}

export default function BlocusSimulator({ onFinish, onClose }: Props) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [running, setRunning] = useState(false);
  const [paused, setPaused] = useState(false);
  const [over, setOver] = useState<"win" | "lose" | null>(null);
  const [score, setScore] = useState(0);
  const [combo, setCombo] = useState(0);

  const state = useRef({
    px: W / 2, py: H - 42,
    keys: {} as Record<string, boolean>,
    ents: [] as Entity[],
    parts: [] as Particle[],
    floats: [] as Floater[],
    t: 0, dist: 0, hp: 3, maxHp: 3,
    smoke: 0, dash: 0, dashCd: 0, stamina: 100,
    finished: false, shake: 0, invuln: 0, anim: 0,
    nearMiss: 0, combo: 0, maxCombo: 0,
    touch: null as null | { x: number; y: number },
    wave: 0, flashBang: 0,
  });

  const end = useCallback((won: boolean, sc: number) => {
    if (state.current.finished) return;
    state.current.finished = true;
    setRunning(false);
    setOver(won ? "win" : "lose");
    setScore(sc);
    onFinish(won, sc);
  }, [onFinish]);

  useEffect(() => {
    const down = (e: KeyboardEvent) => {
      const k = e.key.toLowerCase();
      state.current.keys[k] = true;
      if (["arrowup", "arrowdown", "arrowleft", "arrowright", " "].includes(k)) e.preventDefault();
      if (k === "p" || k === "escape") setPaused((p) => !p);
      if (k === " " || k === "shift") state.current.keys["dash"] = true;
    };
    const up = (e: KeyboardEvent) => {
      const k = e.key.toLowerCase();
      state.current.keys[k] = false;
      if (k === " " || k === "shift") state.current.keys["dash"] = false;
    };
    window.addEventListener("keydown", down);
    window.addEventListener("keyup", up);
    return () => { window.removeEventListener("keydown", down); window.removeEventListener("keyup", up); };
  }, []);

  useEffect(() => {
    if (!running || paused) return;
    const canvas = canvasRef.current; if (!canvas) return;
    const ctx = canvas.getContext("2d"); if (!ctx) return;
    ctx.imageSmoothingEnabled = false;
    const spr = ensureSprites();
    let raf = 0;
    let last = performance.now();

    const burst = (x: number, y: number, color: string, n = 8, speed = 50) => {
      for (let i = 0; i < n; i++) {
        const a = Math.random() * Math.PI * 2;
        const sp = speed * (0.4 + Math.random());
        state.current.parts.push({
          x, y, vx: Math.cos(a) * sp, vy: Math.sin(a) * sp,
          life: 0.25 + Math.random() * 0.45, max: 0.7, color,
          size: 1 + Math.random() * 2, g: 30 + Math.random() * 40,
        });
      }
    };
    const float = (x: number, y: number, text: string, color: string) => {
      state.current.floats.push({ x, y, text, life: 0.9, color });
    };

    const loop = (now: number) => {
      const dt = Math.min(0.05, (now - last) / 1000);
      last = now;
      const s = state.current;
      s.t += dt;
      s.dist += dt * (42 + Math.min(20, s.t * 0.8));
      s.anim += dt;
      if (s.shake > 0) s.shake = Math.max(0, s.shake - dt);
      if (s.invuln > 0) s.invuln -= dt;
      if (s.smoke > 0) s.smoke -= dt;
      if (s.dash > 0) s.dash -= dt;
      if (s.dashCd > 0) s.dashCd -= dt;
      if (s.flashBang > 0) s.flashBang -= dt;
      if (s.combo > 0) {
        s.nearMiss -= dt;
        if (s.nearMiss <= 0) { s.combo = 0; setCombo(0); }
      }
      // stamina regen
      if (s.dash <= 0) s.stamina = Math.min(100, s.stamina + 28 * dt);

      // movement
      let mx = 0, my = 0;
      if (s.keys["arrowleft"] || s.keys["a"] || s.keys["q"]) mx -= 1;
      if (s.keys["arrowright"] || s.keys["d"]) mx += 1;
      if (s.keys["arrowup"] || s.keys["w"] || s.keys["z"]) my -= 1;
      if (s.keys["arrowdown"] || s.keys["s"]) my += 1;
      if (s.touch) {
        const dx = s.touch.x - s.px, dy = s.touch.y - s.py;
        const len = Math.hypot(dx, dy) || 1;
        if (len > 5) { mx += dx / len; my += dy / len; }
      }
      // dash
      if (s.keys["dash"] && s.dashCd <= 0 && s.stamina >= 35) {
        s.dash = 0.18;
        s.dashCd = 0.7;
        s.stamina -= 35;
        s.invuln = Math.max(s.invuln, 0.2);
        burst(s.px, s.py, P.purple, 6, 70);
        float(s.px, s.py - 10, "DASH", P.purple);
      }
      const len = Math.hypot(mx, my) || 1;
      const base = s.dash > 0 ? 160 : 72;
      const speed = base * (s.smoke > 0 ? 0.52 : 1) * (s.flashBang > 0 ? 0.4 : 1);
      s.px += (mx / len) * speed * dt;
      s.py += (my / len) * speed * dt;
      s.px = Math.max(11, Math.min(W - 11, s.px));
      s.py = Math.max(16, Math.min(H - 12, s.py));

      const diff = 1 + Math.min(2.2, s.t * 0.035);
      const wave = Math.floor(s.dist / 350);
      if (wave > s.wave) {
        s.wave = wave;
        float(W / 2, 40, `VAGUE ${wave + 1}`, P.neon);
      }

      // spawns
      const rf = () => Math.random();
      if (rf() < 0.045 * diff * dt * 60) {
        s.ents.push({
          x: 18 + rf() * (W - 36), y: -10,
          vx: (rf() - 0.5) * 35, vy: 50 + rf() * 55 * diff,
          r: 5, kind: "flash", frame: 0,
        });
      }
      if (rf() < 0.02 * diff * dt * 60) {
        s.ents.push({
          x: 18 + rf() * (W - 36), y: -10,
          vx: (rf() - 0.5) * 18, vy: 38 + rf() * 30,
          r: 7, kind: "smoke", life: 3.2, frame: 0,
        });
      }
      if (rf() < 0.012 * diff * dt * 60) {
        s.ents.push({
          x: 20 + rf() * (W - 40), y: H + 14,
          vx: (s.px - W / 2) * 0.1, vy: -32 - rf() * 28 * diff,
          r: 8, kind: "crs", frame: 0, hp: 1,
        });
      }
      if (rf() < 0.007 * dt * 60) {
        s.ents.push({
          x: rf() < 0.5 ? 24 : W - 24, y: -12,
          vx: 0, vy: 48, r: 11, kind: "barricade",
        });
      }
      if (rf() < 0.003 * dt * 60 && s.hp < s.maxHp) {
        s.ents.push({
          x: 30 + rf() * (W - 60), y: -8,
          vx: 0, vy: 35, r: 6, kind: "medkit",
        });
      }
      // police van rare
      if (rf() < 0.0025 * diff * dt * 60) {
        s.ents.push({
          x: W / 2 + (rf() - 0.5) * 40, y: -20,
          vx: (rf() - 0.5) * 10, vy: 55, r: 14, kind: "van",
        });
      }

      // update ents
      for (const e of s.ents) {
        e.x += e.vx * dt;
        e.y += e.vy * dt;
        e.frame = (e.frame || 0) + dt * 10;
        if (e.kind === "flash") {
          e.vx += (s.px - e.x) * 0.65 * dt;
          e.vy += 12 * dt;
        }
        if (e.kind === "crs") e.vx += (s.px - e.x) * 0.4 * dt;
        if (e.kind === "smoke" && e.life !== undefined) {
          e.life -= dt;
          e.r = 7 + (3.2 - Math.max(0, e.life)) * 5;
        }
        if (e.kind === "van") {
          // van drops flashballs
          if (rf() < 0.08 * dt * 60) {
            s.ents.push({
              x: e.x + (rf() - 0.5) * 16, y: e.y + 8,
              vx: (rf() - 0.5) * 40, vy: 30 + rf() * 40,
              r: 5, kind: "flash", frame: 0,
            });
          }
        }
      }
      s.ents = s.ents.filter((e) =>
        e.y < H + 36 && e.y > -36 && e.x > -40 && e.x < W + 40 &&
        (e.life === undefined || e.life > 0)
      );

      // particles + floaters
      for (const p of s.parts) {
        p.x += p.vx * dt; p.y += p.vy * dt;
        p.vy += (p.g || 40) * dt; p.life -= dt;
      }
      s.parts = s.parts.filter((p) => p.life > 0);
      for (const f of s.floats) { f.y -= 18 * dt; f.life -= dt; }
      s.floats = s.floats.filter((f) => f.life > 0);

      // near-miss detection (combo)
      for (const e of s.ents) {
        if (e.kind !== "flash" && e.kind !== "crs") continue;
        const d = Math.hypot(e.x - s.px, e.y - s.py);
        if (d > e.r + 6 && d < e.r + 16 && s.invuln <= 0) {
          s.combo += 1;
          s.maxCombo = Math.max(s.maxCombo, s.combo);
          s.nearMiss = 1.2;
          setCombo(s.combo);
          if (s.combo >= 3) float(s.px, s.py - 14, `COMBO x${s.combo}`, P.yel);
        }
      }

      // collisions
      if (s.invuln <= 0 && s.dash <= 0) {
        for (const e of s.ents) {
          const dx = e.x - s.px, dy = e.y - s.py;
          const hitR = e.kind === "smoke" ? e.r * 0.65 : e.r + 5;
          if (dx * dx + dy * dy >= hitR * hitR) continue;

          if (e.kind === "medkit") {
            s.hp = Math.min(s.maxHp, s.hp + 1);
            e.y = -999;
            burst(e.x, e.y, P.med, 10, 40);
            float(e.x, e.y, "+❤", P.med);
            continue;
          }
          if (e.kind === "smoke") {
            s.smoke = Math.max(s.smoke, 2.6);
            e.life = 0;
            burst(e.x, e.y, P.g2, 8, 30);
            continue;
          }
          // damage
          s.hp -= 1;
          s.invuln = 1.15;
          s.shake = 0.4;
          s.combo = 0; setCombo(0);
          if (e.kind === "flash") {
            s.flashBang = 0.55;
            burst(s.px, s.py, P.yel, 16, 80);
          } else {
            burst(s.px, s.py, P.blood, 12, 55);
          }
          e.y = -999;
          if (s.hp <= 0) {
            draw(ctx, s, spr);
            const sc = Math.min(100, Math.floor(s.dist / 16) + s.maxCombo * 2);
            end(false, sc);
            return;
          }
        }
      }

      // win
      if (s.dist >= GOAL) {
        draw(ctx, s, spr);
        const sc = Math.min(100, 50 + s.hp * 12 + s.maxCombo * 3 + Math.floor(Math.min(s.t, 30)));
        end(true, sc);
        return;
      }

      draw(ctx, s, spr);
      raf = requestAnimationFrame(loop);
    };

    function draw(ctx: CanvasRenderingContext2D, s: typeof state.current, spr: NonNullable<typeof SPR>) {
      const shx = s.shake > 0 ? (Math.random() - 0.5) * 8 * s.shake : 0;
      const shy = s.shake > 0 ? (Math.random() - 0.5) * 8 * s.shake : 0;

      // night asphalt
      ctx.fillStyle = P.asphaltD;
      ctx.fillRect(0, 0, W, H);

      const scroll = (s.dist * 1.6) % 14;
      ctx.fillStyle = P.asphalt;
      for (let y = -14 + scroll; y < H; y += 14) ctx.fillRect(0, Math.floor(y), W, 7);
      // center line
      ctx.fillStyle = P.line;
      for (let y = -18 + (s.dist * 2.2) % 22; y < H; y += 22) {
        ctx.fillRect(W / 2 - 1, Math.floor(y), 2, 9);
      }
      // sidewalks
      ctx.fillStyle = P.curb;
      ctx.fillRect(0, 0, 11, H);
      ctx.fillRect(W - 11, 0, 11, H);
      ctx.fillStyle = P.curbL;
      ctx.fillRect(10, 0, 1, H);
      ctx.fillRect(W - 11, 0, 1, H);

      // street lamps
      for (let y = (s.dist * 0.9 % 64) - 20; y < H; y += 64) {
        ctx.drawImage(spr.lamp, 1, Math.floor(y));
        ctx.drawImage(spr.lamp, W - 9, Math.floor(y));
        // glow
        ctx.fillStyle = "rgba(255,220,100,0.06)";
        ctx.beginPath(); ctx.arc(5, y + 4, 18, 0, Math.PI * 2); ctx.fill();
        ctx.beginPath(); ctx.arc(W - 5, y + 4, 18, 0, Math.PI * 2); ctx.fill();
      }
      // cones
      for (let y = (s.dist * 0.85 % 40); y < H; y += 40) {
        ctx.drawImage(spr.cone, 2, Math.floor(y));
        ctx.drawImage(spr.cone, W - 12, Math.floor(y));
      }

      // entities
      for (const e of s.ents) {
        const x = Math.round(e.x + shx);
        const y = Math.round(e.y + shy);
        if (e.kind === "flash") {
          const fi = Math.floor((e.frame || 0) / 2) % 2;
          const sc = 1 + Math.sin(s.t * 22) * 0.12;
          ctx.save();
          ctx.translate(x, y);
          ctx.scale(sc, sc);
          ctx.drawImage(spr.flash[fi], -5, -5);
          ctx.restore();
          ctx.fillStyle = "rgba(255,200,40,0.18)";
          ctx.beginPath(); ctx.arc(x, y, 11, 0, Math.PI * 2); ctx.fill();
        } else if (e.kind === "smoke") {
          const fi = Math.min(2, Math.floor((3.2 - (e.life || 0)) * 1.1));
          const sz = 8 + (3.2 - Math.max(0, e.life || 0)) * 6;
          ctx.globalAlpha = 0.65;
          ctx.drawImage(spr.smoke[fi], x - sz / 2, y - sz / 2, sz, sz);
          ctx.globalAlpha = 1;
        } else if (e.kind === "crs") {
          const fi = Math.floor(e.frame || 0) % 2;
          ctx.drawImage(spr.crs[fi], x - 5, y - 6);
          ctx.fillStyle = P.shield;
          ctx.fillRect(x - 8, y - 3, 3, 8);
          ctx.fillStyle = P.shieldD;
          ctx.fillRect(x - 8, y, 3, 2);
        } else if (e.kind === "barricade") {
          ctx.drawImage(spr.barricade, x - 7, y - 4);
        } else if (e.kind === "medkit") {
          ctx.drawImage(spr.medkit, x - 5, y - 4);
        } else if (e.kind === "van") {
          ctx.drawImage(spr.van, x - 8, y - 5);
        }
      }

      // particles
      for (const p of s.parts) {
        ctx.globalAlpha = Math.max(0, p.life / p.max);
        ctx.fillStyle = p.color;
        ctx.fillRect(Math.round(p.x + shx), Math.round(p.y + shy), p.size, p.size);
      }
      ctx.globalAlpha = 1;

      // float texts
      ctx.font = "bold 6px monospace";
      ctx.textAlign = "center";
      for (const f of s.floats) {
        ctx.globalAlpha = Math.max(0, f.life);
        ctx.fillStyle = f.color;
        ctx.fillText(f.text, Math.round(f.x), Math.round(f.y));
      }
      ctx.globalAlpha = 1;

      // player
      if (s.invuln <= 0 || Math.floor(s.invuln * 12) % 2 === 0) {
        const px = Math.round(s.px + shx) - 5;
        const py = Math.round(s.py + shy) - 6;
        if (s.dash > 0) {
          ctx.globalAlpha = 0.5;
          ctx.drawImage(spr.playerDash, px - 2, py);
          ctx.globalAlpha = 1;
          ctx.drawImage(spr.playerDash, px, py);
        } else {
          const fi = Math.floor(s.anim * 7) % 2;
          ctx.drawImage(spr.player[fi], px, py);
        }
      }

      // smoke overlay
      if (s.smoke > 0) {
        ctx.fillStyle = `rgba(100,105,110,${0.22 + s.smoke * 0.1})`;
        ctx.fillRect(0, 0, W, H);
      }
      // flashbang whiteout
      if (s.flashBang > 0) {
        ctx.fillStyle = `rgba(255,255,240,${s.flashBang * 0.85})`;
        ctx.fillRect(0, 0, W, H);
      }
      // vignette
      const g = ctx.createRadialGradient(W / 2, H / 2, 30, W / 2, H / 2, 120);
      g.addColorStop(0, "rgba(0,0,0,0)");
      g.addColorStop(1, "rgba(0,0,0,0.45)");
      ctx.fillStyle = g;
      ctx.fillRect(0, 0, W, H);

      // ===== HUD =====
      ctx.fillStyle = "rgba(0,0,0,0.6)";
      ctx.fillRect(0, 0, W, 20);
      // hearts
      for (let i = 0; i < s.maxHp; i++) {
        ctx.fillStyle = i < s.hp ? P.red : "#333";
        const hx = 3 + i * 11, hy = 5;
        ctx.fillRect(hx + 1, hy, 3, 1);
        ctx.fillRect(hx + 5, hy, 3, 1);
        ctx.fillRect(hx, hy + 1, 9, 3);
        ctx.fillRect(hx + 1, hy + 4, 7, 1);
        ctx.fillRect(hx + 2, hy + 5, 5, 1);
        ctx.fillRect(hx + 3, hy + 6, 3, 1);
      }
      // progress
      const prog = Math.min(1, s.dist / GOAL);
      ctx.fillStyle = "#1a1a22";
      ctx.fillRect(40, 6, W - 56, 7);
      const grad = ctx.createLinearGradient(40, 0, W - 16, 0);
      grad.addColorStop(0, P.purple);
      grad.addColorStop(1, P.neon);
      ctx.fillStyle = grad;
      ctx.fillRect(40, 6, (W - 56) * prog, 7);
      ctx.fillStyle = "#fff";
      ctx.font = "5px monospace";
      ctx.textAlign = "left";
      ctx.fillText(`${Math.floor(prog * 100)}%`, W - 14, 12);

      // stamina bar
      ctx.fillStyle = "#1a1a22";
      ctx.fillRect(3, H - 8, 40, 4);
      ctx.fillStyle = s.stamina > 35 ? P.purple : P.ora;
      ctx.fillRect(3, H - 8, 40 * (s.stamina / 100), 4);

      // combo
      if (s.combo >= 2) {
        ctx.fillStyle = P.yel;
        ctx.font = "bold 7px monospace";
        ctx.textAlign = "right";
        ctx.fillText(`x${s.combo}`, W - 4, H - 6);
      }
      // status icons
      ctx.textAlign = "left";
      ctx.font = "5px monospace";
      if (s.smoke > 0) { ctx.fillStyle = P.g1; ctx.fillText("FUMEE", 48, H - 5); }
      if (s.dashCd > 0) { ctx.fillStyle = P.purple; ctx.fillText("DASH", 78, H - 5); }
    }

    raf = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(raf);
  }, [running, paused, end]);

  const start = () => {
    state.current = {
      px: W / 2, py: H - 42, keys: {}, ents: [], parts: [], floats: [],
      t: 0, dist: 0, hp: 3, maxHp: 3, smoke: 0, dash: 0, dashCd: 0, stamina: 100,
      finished: false, shake: 0, invuln: 0, anim: 0, nearMiss: 0, combo: 0, maxCombo: 0,
      touch: null, wave: 0, flashBang: 0,
    };
    setOver(null); setScore(0); setCombo(0); setPaused(false); setRunning(true);
  };

  const touchPos = (e: React.TouchEvent) => {
    const t = e.touches[0];
    const rect = (e.target as HTMLCanvasElement).getBoundingClientRect();
    return {
      x: ((t.clientX - rect.left) / rect.width) * W,
      y: ((t.clientY - rect.top) / rect.height) * H,
    };
  };

  return (
    <div style={{
      background: "linear-gradient(180deg,#0a0c12,#12100a)",
      borderRadius: 16, padding: 14, border: "2px solid #3d5c3a", maxWidth: 520,
    }}>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 6 }}>
        <b style={{ fontSize: 16, letterSpacing: 0.5 }}>🚨 BLOCUS SIMULATOR</b>
        <div className="hub-row" style={{ gap: 6 }}>
          {running && !over && (
            <button className="hub-btn sm" onClick={() => setPaused((p) => !p)}>{paused ? "▶" : "⏸"}</button>
          )}
          <button className="hub-btn sm" onClick={onClose}>Fermer</button>
        </div>
      </div>
      <p className="hub-sub" style={{ margin: "0 0 8px", fontSize: 12.5 }}>
        Esquive <b style={{ color: "#ffd93d" }}>flashballs</b>, <b style={{ color: "#9aa0a6" }}>fumigènes</b>, CRS et fourgons.
        <b> Espace / Shift</b> = dash · <b>P</b> = pause · Combo en frôlant les projectiles.
        {combo >= 2 && <span style={{ color: "#ffd93d", fontWeight: 800 }}> · COMBO x{combo}</span>}
      </p>

      <div style={{ position: "relative" }}>
        <canvas
          ref={canvasRef}
          width={W}
          height={H}
          style={{
            width: "100%", maxWidth: 480, aspectRatio: `${W}/${H}`,
            borderRadius: 8, background: P.asphaltD, display: "block", margin: "0 auto",
            imageRendering: "pixelated",
            border: "3px solid #111",
            boxShadow: "0 0 0 1px #3d5c3a, 0 10px 28px rgba(0,0,0,.55)",
            touchAction: "none",
          }}
          onTouchStart={(e) => { e.preventDefault(); state.current.touch = touchPos(e); }}
          onTouchMove={(e) => { e.preventDefault(); state.current.touch = touchPos(e); }}
          onTouchEnd={() => { state.current.touch = null; }}
        />
        {!running && !over && (
          <div style={{
            position: "absolute", inset: 0, display: "grid", placeItems: "center",
            background: "rgba(0,0,0,.6)", borderRadius: 8,
          }}>
            <div style={{ textAlign: "center" }}>
              <button className="hub-btn acc" style={{ fontSize: 15, padding: "12px 28px" }} onClick={start}>
                ▶ LANCER LA FUITE
              </button>
              <p className="hub-sub" style={{ marginTop: 10, fontSize: 11 }}>
                Dash · Combos · Kits de soin · Fourgons de police
              </p>
            </div>
          </div>
        )}
        {paused && running && (
          <div style={{
            position: "absolute", inset: 0, display: "grid", placeItems: "center",
            background: "rgba(0,0,0,.55)", borderRadius: 8,
          }}>
            <b style={{ fontSize: 22 }}>⏸ PAUSE</b>
          </div>
        )}
      </div>

      {over && (
        <div style={{
          marginTop: 12, padding: 14, borderRadius: 12, textAlign: "center",
          background: over === "win" ? "linear-gradient(135deg,#0d2818,#0a1a10)" : "linear-gradient(135deg,#2a1010,#1a0808)",
          border: `2px solid ${over === "win" ? "#27ae60" : "#c0392b"}`,
        }}>
          <div style={{ fontSize: 22, fontWeight: 900 }}>{over === "win" ? "🎉 TU AS FILÉ !" : "💥 ATTRAPÉ !"}</div>
          <p className="hub-sub" style={{ margin: "6px 0 10px" }}>
            Score {score}/100 — {over === "win" ? "dette réduite" : "dette +10 %"}
          </p>
          <div className="hub-row" style={{ justifyContent: "center", gap: 8 }}>
            <button className="hub-btn acc sm" onClick={start}>Rejouer</button>
            <button className="hub-btn sm" onClick={onClose}>Retour banque</button>
          </div>
        </div>
      )}
    </div>
  );
}
