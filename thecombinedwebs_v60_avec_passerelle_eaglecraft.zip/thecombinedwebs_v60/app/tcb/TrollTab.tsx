"use client";
import { useEffect, useState } from "react";
import {TROLL_PRICES} from "@/lib/troll-prices";

const FX: [string, string][] = [["flip", "🙃 Retourner l’écran"], ["mirror", "🪞 Miroir"], ["shake", "🫨 Secouer"], ["spin", "🌀 Tourner"], ["rainbow", "🌈 Arc-en-ciel"], ["zoom", "🔍 Zoom"], ["confetti", "🎉 Confettis"], ["fakecrash", "💥 Faux plantage"]];
const post = async (b: Record<string, unknown>) => (await fetch("/api/tcb/fun", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify(b) })).json();

export default function TrollTab({ friends, staff, setMsg }: { friends: string[]; staff: boolean; setMsg: (m: { t: string; ok: boolean } | null) => void }) {
  const [target, setTarget] = useState(friends[0] || ""); const [optout, setOptout] = useState(false);
  useEffect(() => { (async () => { try { const r = await fetch("/api/tcb/fun"); if (r.ok) setOptout((await r.json()).optout); } catch { /* ignore */ } })(); }, []);
  const send = async (effect: string) => { const r = await post({ action: "troll", target, effect }); setMsg({ t: r.error || `Troll envoyé à ${target} !`, ok: !r.error }); };
  const toggle = async () => { const v = !optout; await post({ action: "optout", value: v }); setOptout(v); setMsg({ t: v ? "Tu ne recevras plus de trolls." : "Les trolls sont réactivés.", ok: true }); };
  return <div className="hub-grid">
    <div className="hub-card" style={{ gridColumn: "1/-1" }}><h3>🤡 Troller un ami</h3>
      <p className="hub-sub">Effets visuels inoffensifs qui disparaissent seuls au bout de quelques secondes. {staff ? "En tant que modérateur, tu peux troller n’importe quel joueur (5 s entre deux trolls)." : "Tu peux troller tes amis (1 troll par minute)."} Les trolls n’apparaissent pas pendant une partie.</p>
      <div className="hub-row" style={{ marginBottom: 12 }}>
        {staff || friends.length === 0 ? <input className="hub-input" placeholder="Pseudo" value={target} onChange={(e) => setTarget(e.target.value)} /> : <select className="hub-select" value={target} onChange={(e) => setTarget(e.target.value)}>{friends.map((f) => <option key={f}>{f}</option>)}</select>}</div>
      <div className="hub-row">{FX.map(([k, l]) => <button key={k} className="hub-btn" disabled={!target.trim()} onClick={() => send(k)}>{l} · {TROLL_PRICES[k]} Bobux</button>)}</div></div>
    <div className="hub-card"><h3>🛡️ Me protéger</h3><p className="hub-sub">Désactive les trolls reçus : plus aucun effet ne s’affichera chez toi.</p>
      <button className={`hub-btn ${optout ? "ok" : ""}`} onClick={toggle}>{optout ? "Trolls désactivés" : "Trolls activés"}</button></div>
  </div>;
}
