import { redirect } from "next/navigation";
import { currentUser } from "@/lib/auth";
import HubNav from "@/app/HubNav";
import Client from "./Client";
import "@/app/hub.css";

export const metadata = { title: "TCB Plus · TheCombinedWebs" };
export const dynamic = "force-dynamic";

export default async function Page() {
  const u = await currentUser();
  if (!u) { redirect("/login?next=/tcb"); return null; }
  return <div className="hub"><HubNav username={u.username} /><main className="hub-main"><Client /></main></div>;
}
