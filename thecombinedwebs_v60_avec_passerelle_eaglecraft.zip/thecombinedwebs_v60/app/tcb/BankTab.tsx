"use client";
import { useCallback, useEffect, useState } from "react";
import BlocusSimulator from "./BlocusSimulator";

type LivretInfo = { name: string; balance: number; rate: number; cap: number };
type Ov = {
  account: {
    number: string; iban: string;
    card: { number: string; exp: string; cvv: string; holder: string };
    checking: number; savings: number;
    livrets: Record<string, LivretInfo>;
    goal: { name: string; target: number } | null;
    rate: number; cap: number; transferLimit: number; transferUsed: number;
    overdraftLimit: number; overdraftUsed: number;
    interestHistory: { date: string; amount: number; livret: string }[];
  };
  subscription: { active: boolean; endsAt: number; autoRenew: boolean; price: number; days: number; name: string; creatorUnlimited?: boolean };
  tax: { rate: number; threshold: number; cap: number; estimate: number; exempt: boolean; adminAbuse?: boolean };
  treasury: { total: number; today: number; days: { date: string; total: number; payers: number }[] } | null;
  statement: { at: number; label: string; amount: number; category?: string }[];
  savingsTx: { id: string; type: string; amount: number; note: string; at: number; category?: string }[];
  scheduled: { id: string; to: string; amount: number; note: string; nextAt: number; intervalDays: number; remaining: number }[];
  pots: { id: string; name: string; owner: string; members: string[]; balance: number; goal?: number }[];
  loans: { id: string; from: string; to: string; amount: number; remaining: number; interest: number; dueAt: number; status: string }[];
  insurance: { plan: string; endsAt: number; price: number } | null;
  alerts: { id: string; type: string; message: string; at: number; read: boolean }[];
  categories: { name: string; total: number }[];
  health: { score: number; tips: string[] };
  mystery?: { cost: number; remaining: number; title: string | null };
  haunted?: { haunted: boolean; daysLeft: number; debtDays: number };
  blocus?: { available: boolean; cooldownUntil: number; debt: number };
};
type Msg = (m: { t: string; ok: boolean } | null) => void;
const n = (v: number) => v.toLocaleString("fr-FR");
const date = (t: number) => new Date(t).toLocaleString("fr-FR", { day: "2-digit", month: "2-digit", hour: "2-digit", minute: "2-digit" });
const PERKS = [
  "Intérêts d’épargne doublés : 1 % par jour",
  "Plafond d’épargne augmenté à 50 000 Bobux",
  "Virements quotidiens jusqu’à 5 000 Bobux",
  "Taxe journalière réduite de moitié",
  "Découvert jusqu’à 500 Bobux",
  "Simulateur d’épargne + export CSV",
  "Tableau de bord de dépenses & catégories",
  "Titre exclusif 💎 Premium",
];

function ScoreRing({ score }: { score: number }) {
  const color = score >= 80 ? "#5ee7c4" : score >= 50 ? "#8b7cff" : "#ff8a80";
  return (
    <div style={{ width: 90, height: 90, borderRadius: "50%", background: `conic-gradient(${color} ${score * 3.6}deg, #1a1d26 0)`, display: "grid", placeItems: "center" }}>
      <div style={{ width: 68, height: 68, borderRadius: "50%", background: "#12141c", display: "grid", placeItems: "center", fontWeight: 950, fontSize: 22 }}>{score}</div>
    </div>
  );
}

function MiniBars({ data }: { data: { name: string; total: number }[] }) {
  if (!data.length) return <p className="hub-sub">Pas encore assez de données.</p>;
  const max = Math.max(...data.map((d) => d.total), 1);
  const colors = ["#8b7cff", "#5ee7c4", "#ffb86c", "#ff8a80", "#7ec8ff", "#f0e68c", "#c3a6ff"];
  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 6 }}>
      {data.slice(0, 7).map((d, i) => (
        <div key={d.name} style={{ display: "flex", alignItems: "center", gap: 8 }}>
          <span style={{ width: 90, fontSize: 12, opacity: 0.85, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{d.name}</span>
          <div style={{ flex: 1, height: 10, borderRadius: 6, background: "#1a1d26", overflow: "hidden" }}>
            <div style={{ width: `${(d.total / max) * 100}%`, height: "100%", background: colors[i % colors.length] }} />
          </div>
          <span style={{ width: 70, textAlign: "right", fontSize: 12, fontWeight: 700 }}>{n(d.total)}</span>
        </div>
      ))}
    </div>
  );
}

function CardVisual({ card }: { card: Ov["account"]["card"] }) {
  return (
    <div style={{
      background: "linear-gradient(135deg,#2a1f6e 0%,#1a3a5c 50%,#0d2b3e 100%)",
      borderRadius: 16, padding: "18px 20px", color: "#fff", maxWidth: 340,
      boxShadow: "0 8px 24px rgba(0,0,0,.35)", fontFamily: "monospace", position: "relative", overflow: "hidden",
    }}>
      <div style={{ position: "absolute", top: -20, right: -20, width: 100, height: 100, borderRadius: "50%", background: "rgba(139,124,255,.25)" }} />
      <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 18 }}>
        <span style={{ fontWeight: 800, letterSpacing: 1 }}>TCB BANQUE</span>
        <span style={{ opacity: 0.7, fontSize: 12 }}>VISA</span>
      </div>
      <div style={{ fontSize: 18, letterSpacing: 3, marginBottom: 16 }}>{card.number}</div>
      <div style={{ display: "flex", justifyContent: "space-between", fontSize: 12 }}>
        <div><div style={{ opacity: 0.6, fontSize: 10 }}>TITULAIRE</div>{card.holder}</div>
        <div><div style={{ opacity: 0.6, fontSize: 10 }}>EXP</div>{card.exp}</div>
        <div><div style={{ opacity: 0.6, fontSize: 10 }}>CVV</div>{card.cvv}</div>
      </div>
    </div>
  );
}

export default function BankTab({ friends, setMsg }: { friends: string[]; setMsg: Msg }) {
  const [o, setO] = useState<Ov | null>(null);
  const [dep, setDep] = useState(""); const [wd, setWd] = useState("");
  const [livret, setLivret] = useState("classic");
  const [to, setTo] = useState(friends[0] || ""); const [amt, setAmt] = useState(""); const [note, setNote] = useState("");
  const [gName, setGName] = useState(""); const [gTarget, setGTarget] = useState("");
  const [monthlySave, setMonthlySave] = useState("250");
  const [showBlocus, setShowBlocus] = useState(false);
  const [mysteryResult, setMysteryResult] = useState<{ title: string; text: string } | null>(null);
  // scheduled
  const [sTo, setSTo] = useState(friends[0] || ""); const [sAmt, setSAmt] = useState(""); const [sDays, setSDays] = useState("7"); const [sCount, setSCount] = useState("4");
  // pot
  const [potName, setPotName] = useState(""); const [potGoal, setPotGoal] = useState(""); const [joinId, setJoinId] = useState("");
  const [potAmt, setPotAmt] = useState<Record<string, string>>({});
  // loan
  const [lTo, setLTo] = useState(friends[0] || ""); const [lAmt, setLAmt] = useState(""); const [lDays, setLDays] = useState("7");
  const [repayAmt, setRepayAmt] = useState<Record<string, string>>({});

  const load = useCallback(async () => {
    const r = await fetch("/api/tcb/bank", { cache: "no-store" });
    if (r.ok) {
      const j: Ov = await r.json();
      setO(j);
      setGName((x) => x || j.account.goal?.name || "");
      setGTarget((x) => x || String(j.account.goal?.target || ""));
    }
  }, []);
  useEffect(() => { load(); }, [load]);

  const act = async (body: Record<string, unknown>, ok: string) => {
    const r = await (await fetch("/api/tcb/bank", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify(body) })).json();
    setMsg({ t: r.error || ok, ok: !r.error });
    if (!r.error) await load();
    return r;
  };

  if (!o) return <p className="hub-sub">Chargement…</p>;
  const { account: a, subscription: s } = o;
  const pct = a.goal ? Math.min(100, Math.round((a.savings / a.goal.target) * 100)) : 0;
  const unread = o.alerts.filter((x) => !x.read).length;

  return (
    <div className="hub-grid tcb-bank-dashboard">
      {/* ===== En-tête + soldes ===== */}
      <div className="hub-card" style={{ gridColumn: "1/-1" }}>
        <div className="hub-row" style={{ justifyContent: "space-between", flexWrap: "wrap", gap: 8 }}>
          <b>TCB Banque</b>
          <div className="hub-row" style={{ gap: 6 }}>
            {s.active && <span className="hub-pill acc">💎 Premium</span>}
            {o.insurance && <span className="hub-pill">🛡️ Assuré</span>}
            {a.overdraftUsed > 0 && <span className="hub-pill" style={{ background: "#5c1a1a" }}>Découvert {n(a.overdraftUsed)}</span>}
          </div>
        </div>
        <div className="hub-grid" style={{ marginTop: 10 }}>
          <div><p className="hub-sub" style={{ margin: 0 }}>Compte courant</p><div style={{ fontSize: 34, fontWeight: 950 }}>🪙 {n(a.checking)}</div></div>
          <div><p className="hub-sub" style={{ margin: 0 }}>Épargne totale</p><div style={{ fontSize: 34, fontWeight: 950 }}>🏦 {n(a.savings)}</div></div>
          <div><p className="hub-sub" style={{ margin: 0 }}>Patrimoine</p><div style={{ fontSize: 34, fontWeight: 950 }}>💎 {n(a.checking + a.savings)}</div></div>
        </div>
        <p className="hub-sub" style={{ marginTop: 10 }}>N° de compte <b>{a.number}</b></p>
        <p className="hub-sub" style={{ marginTop: 2 }}>IBAN <b style={{ fontFamily: "monospace", letterSpacing: 1 }}>{a.iban}</b>
          <button className="hub-btn sm" style={{ marginLeft: 8 }} onClick={() => { navigator.clipboard?.writeText(a.iban.replace(/\s/g, "")); setMsg({ t: "IBAN copié.", ok: true }); }}>Copier</button>
        </p>
      </div>

      {/* ===== Alertes ===== */}
      {o.alerts.length > 0 && (
        <div className="hub-card" style={{ gridColumn: "1/-1" }}>
          <div className="hub-row" style={{ justifyContent: "space-between" }}>
            <h3 style={{ margin: 0 }}>🔔 Alertes {unread > 0 && <span className="hub-pill acc">{unread}</span>}</h3>
            {unread > 0 && <button className="hub-btn sm" onClick={() => act({ action: "mark_alerts" }, "Alertes marquées comme lues.")}>Tout marquer lu</button>}
          </div>
          <div style={{ maxHeight: 160, overflowY: "auto", marginTop: 8 }}>
            {o.alerts.slice(0, 8).map((al) => (
              <div key={al.id} style={{ padding: "6px 0", borderBottom: "1px solid #1a1d26", opacity: al.read ? 0.6 : 1 }}>
                <span className="hub-sub" style={{ marginRight: 8 }}>{date(al.at)}</span>
                {al.message}
              </div>
            ))}
          </div>
        </div>
      )}

      {/* ===== Score santé + Carte ===== */}
      <div className="hub-card">
        <h3>❤️ Santé financière</h3>
        <div className="hub-row" style={{ gap: 16, alignItems: "center" }}>
          <ScoreRing score={o.health.score} />
          <div>{o.health.tips.map((t, i) => <p key={i} className="hub-sub" style={{ margin: "2px 0" }}>{t}</p>)}</div>
        </div>
      </div>

      <div className="hub-card">
        <h3>💳 Carte virtuelle TCB</h3>
        <CardVisual card={a.card} />
        <p className="hub-sub" style={{ marginTop: 8 }}>Carte purement cosmétique — aucun paiement réel.</p>
      </div>

      {/* ===== Trésor créateur ===== */}
      {o.treasury && (
        <div className="hub-card" style={{ gridColumn: "1/-1" }}>
          <h3>👑 Trésor du créateur</h3>
          <p className="hub-sub">Toutes les taxes quotidiennes des joueurs te reviennent.</p>
          <div style={{ fontSize: 34, fontWeight: 950 }}>💰 {n(o.treasury.total)}</div>
          <p className="hub-sub">Aujourd’hui : +{n(o.treasury.today)} Bobux</p>
          {o.treasury.days.length > 0 && (
            <table className="hub-table"><tbody>
              {o.treasury.days.map((d) => (
                <tr key={d.date}><td>{d.date}</td><td>{d.payers} contribuable(s)</td><td style={{ textAlign: "right", fontWeight: 800 }}>+{n(d.total)}</td></tr>
              ))}
            </tbody></table>
          )}
        </div>
      )}

      {/* ===== Taxe ===== */}
      <div className="hub-card">
        <h3>🏛️ Taxe journalière</h3>
        {o.tax.exempt ? <p className="hub-sub">Le créateur est exempté de la taxe.</p> : (
          <>
            <p className="hub-sub">Chaque jour, <b>{(o.tax.rate * 100).toString().replace(".", ",")} %</b> de tes Bobux (compte + épargne) au-delà de {n(o.tax.threshold)} est prélevé, max {n(o.tax.cap)}/j.</p>
            <p className="hub-msg ok" style={{ marginTop: 0 }}>
              {o.tax.adminAbuse ? "Taxes suspendues pendant l’Admin Abuse." : `Prochain prélèvement estimé : ${n(o.tax.estimate)} Bobux`}
            </p>
          </>
        )}
      </div>

      {/* ===== Catégories dépenses ===== */}
      <div className="hub-card">
        <h3>📊 Dépenses par catégorie (30 j)</h3>
        <MiniBars data={o.categories} />
      </div>

      {/* ===== Livrets ===== */}
      <div className="hub-card" style={{ gridColumn: "1/-1" }}>
        <h3>🏦 Livrets d’épargne</h3>
        <div className="hub-grid">
          {Object.entries(a.livrets).map(([id, L]) => (
            <div key={id} style={{ padding: 12, borderRadius: 12, background: "#14161e", border: livret === id ? "1px solid #8b7cff" : "1px solid transparent", cursor: "pointer" }} onClick={() => setLivret(id)}>
              <b>{L.name}</b>
              <div style={{ fontSize: 26, fontWeight: 900, margin: "6px 0" }}>{n(L.balance)} 🪙</div>
              <p className="hub-sub" style={{ margin: 0 }}>{(L.rate * 100).toString().replace(".", ",")}% /j · plafond {n(L.cap)}</p>
            </div>
          ))}
        </div>
        <p className="hub-sub" style={{ marginTop: 10 }}>Livret sélectionné : <b>{a.livrets[livret]?.name}</b></p>
        <div className="hub-row" style={{ marginBottom: 8 }}>
          <input className="hub-input" inputMode="numeric" placeholder="Montant" value={dep} onChange={(e) => setDep(e.target.value.replace(/\D/g, ""))} style={{ width: 130 }} />
          <button className="hub-btn acc" disabled={!dep} onClick={async () => { const r = await act({ action: "deposit", amount: Number(dep), livret }, "Dépôt effectué."); if (!r.error) setDep(""); }}>Déposer</button>
        </div>
        <div className="hub-row">
          <input className="hub-input" inputMode="numeric" placeholder="Montant" value={wd} onChange={(e) => setWd(e.target.value.replace(/\D/g, ""))} style={{ width: 130 }} />
          <button className="hub-btn" disabled={!wd} onClick={async () => { const r = await act({ action: "withdraw", amount: Number(wd), livret }, "Retrait effectué."); if (!r.error) setWd(""); }}>Retirer</button>
        </div>
        {a.interestHistory.length > 0 && (
          <div style={{ marginTop: 12 }}>
            <b>Historique des intérêts</b>
            <table className="hub-table"><tbody>
              {a.interestHistory.map((h, i) => (
                <tr key={i}><td>{h.date}</td><td>{h.livret}</td><td style={{ textAlign: "right", color: "#8ef0c0", fontWeight: 800 }}>+{n(h.amount)}</td></tr>
              ))}
            </tbody></table>
          </div>
        )}
      </div>

      {/* ===== Objectif ===== */}
      <div className="hub-card">
        <h3>🎯 Objectif d’épargne</h3>
        <div className="hub-row" style={{ marginBottom: 8 }}>
          <input className="hub-input" maxLength={40} placeholder="Nom (ex. Skin rare)" value={gName} onChange={(e) => setGName(e.target.value)} />
          <input className="hub-input" inputMode="numeric" placeholder="Objectif" value={gTarget} onChange={(e) => setGTarget(e.target.value.replace(/\D/g, ""))} style={{ width: 110 }} />
          <button className="hub-btn" onClick={() => act({ action: "goal", name: gName, target: Number(gTarget) }, gName && gTarget ? "Objectif enregistré." : "Objectif supprimé.")}>OK</button>
        </div>
        {a.goal && (
          <>
            <div style={{ height: 12, borderRadius: 8, background: "#1a1d26", overflow: "hidden" }}>
              <div style={{ width: `${pct}%`, height: "100%", background: "linear-gradient(90deg,#8b7cff,#5ee7c4)" }} />
            </div>
            <p className="hub-sub" style={{ marginTop: 6 }}>{a.goal.name} : {n(a.savings)} / {n(a.goal.target)} ({pct} %)</p>
          </>
        )}
      </div>

      {/* ===== Découvert ===== */}
      <div className="hub-card">
        <h3>📉 Découvert autorisé</h3>
        <p className="hub-sub">Tu peux descendre jusqu’à <b>−{n(a.overdraftLimit)}</b> Bobux. Utilisé : <b>{n(a.overdraftUsed)}</b>.</p>
        <div style={{ height: 10, borderRadius: 6, background: "#1a1d26", overflow: "hidden" }}>
          <div style={{ width: `${a.overdraftLimit ? (a.overdraftUsed / a.overdraftLimit) * 100 : 0}%`, height: "100%", background: a.overdraftUsed > 0 ? "#ff8a80" : "#5ee7c4" }} />
        </div>
      </div>

      {/* ===== Virement instantané ===== */}
      <div className="hub-card" style={{ gridColumn: "1/-1" }}>
        <h3>💸 Virement instantané</h3>
        <p className="hub-sub">Aujourd’hui : {n(a.transferUsed)} / {n(a.transferLimit)} Bobux.</p>
        <div className="hub-row">
          <input className="hub-input" list="tcb-friends" placeholder="Pseudo du destinataire" value={to} onChange={(e) => setTo(e.target.value)} />
          <datalist id="tcb-friends">{friends.map((f) => <option key={f} value={f} />)}</datalist>
          <input className="hub-input" inputMode="numeric" placeholder="Montant" value={amt} onChange={(e) => setAmt(e.target.value.replace(/\D/g, ""))} style={{ width: 110 }} />
          <input className="hub-input" maxLength={30} placeholder="Message (optionnel)" value={note} onChange={(e) => setNote(e.target.value)} />
          <button className="hub-btn acc" disabled={!to.trim() || !amt} onClick={async () => {
            const r = await act({ action: "transfer", to, amount: Number(amt), note }, `Virement envoyé à ${to}.`);
            if (!r.error) { setAmt(""); setNote(""); }
          }}>Envoyer</button>
        </div>
      </div>

      {/* ===== Virements planifiés ===== */}
      <div className="hub-card" style={{ gridColumn: "1/-1" }}>
        <h3>📅 Virements planifiés</h3>
        <div className="hub-row" style={{ marginBottom: 10, flexWrap: "wrap" }}>
          <input className="hub-input" list="tcb-friends2" placeholder="Destinataire" value={sTo} onChange={(e) => setSTo(e.target.value)} />
          <datalist id="tcb-friends2">{friends.map((f) => <option key={f} value={f} />)}</datalist>
          <input className="hub-input" inputMode="numeric" placeholder="Montant" value={sAmt} onChange={(e) => setSAmt(e.target.value.replace(/\D/g, ""))} style={{ width: 100 }} />
          <input className="hub-input" inputMode="numeric" placeholder="Tous les X jours" value={sDays} onChange={(e) => setSDays(e.target.value.replace(/\D/g, ""))} style={{ width: 120 }} />
          <input className="hub-input" inputMode="numeric" placeholder="Nb fois" value={sCount} onChange={(e) => setSCount(e.target.value.replace(/\D/g, ""))} style={{ width: 80 }} />
          <button className="hub-btn acc" disabled={!sTo.trim() || !sAmt} onClick={async () => {
            const r = await act({ action: "schedule", to: sTo, amount: Number(sAmt), intervalDays: Number(sDays) || 7, count: Number(sCount) || 1 }, "Virement planifié créé.");
            if (!r.error) { setSAmt(""); }
          }}>Planifier</button>
        </div>
        {o.scheduled.length === 0 ? <p className="hub-sub">Aucun virement planifié.</p> : (
          <table className="hub-table"><thead><tr><th>Destinataire</th><th>Montant</th><th>Prochain</th><th>Reste</th><th></th></tr></thead><tbody>
            {o.scheduled.map((sc) => (
              <tr key={sc.id}>
                <td>{sc.to}</td>
                <td>{n(sc.amount)}</td>
                <td>{date(sc.nextAt)} (tous les {sc.intervalDays} j)</td>
                <td>{sc.remaining}×</td>
                <td><button className="hub-btn sm danger" onClick={() => act({ action: "cancel_schedule", id: sc.id }, "Virement planifié annulé.")}>Annuler</button></td>
              </tr>
            ))}
          </tbody></table>
        )}
      </div>

      {/* ===== Cagnottes ===== */}
      <div className="hub-card" style={{ gridColumn: "1/-1" }}>
        <h3>🥳 Cagnottes entre amis</h3>
        <div className="hub-row" style={{ marginBottom: 10, flexWrap: "wrap" }}>
          <input className="hub-input" placeholder="Nom de la cagnotte" value={potName} onChange={(e) => setPotName(e.target.value)} maxLength={40} />
          <input className="hub-input" inputMode="numeric" placeholder="Objectif (opt.)" value={potGoal} onChange={(e) => setPotGoal(e.target.value.replace(/\D/g, ""))} style={{ width: 120 }} />
          <button className="hub-btn acc" disabled={!potName.trim()} onClick={async () => {
            const r = await act({ action: "create_pot", name: potName, goal: Number(potGoal) || 0 }, "Cagnotte créée !");
            if (!r.error) { setPotName(""); setPotGoal(""); }
          }}>Créer</button>
          <input className="hub-input" placeholder="ID cagnotte à rejoindre" value={joinId} onChange={(e) => setJoinId(e.target.value)} style={{ width: 180 }} />
          <button className="hub-btn" disabled={!joinId.trim()} onClick={() => act({ action: "join_pot", potId: joinId }, "Cagnotte rejointe.")}>Rejoindre</button>
        </div>
        {o.pots.length === 0 ? <p className="hub-sub">Aucune cagnotte.</p> : o.pots.map((p) => (
          <div key={p.id} style={{ padding: 12, borderRadius: 10, background: "#14161e", marginBottom: 8 }}>
            <div className="hub-row" style={{ justifyContent: "space-between" }}>
              <b>{p.name}</b>
              <span className="hub-sub">ID : {p.id.slice(0, 12)}… · {p.members.length} membre(s)</span>
            </div>
            <div style={{ fontSize: 22, fontWeight: 900, margin: "4px 0" }}>{n(p.balance)} 🪙 {p.goal ? `/ ${n(p.goal)}` : ""}</div>
            {p.goal && (
              <div style={{ height: 8, borderRadius: 6, background: "#1a1d26", overflow: "hidden", marginBottom: 8 }}>
                <div style={{ width: `${Math.min(100, (p.balance / p.goal) * 100)}%`, height: "100%", background: "linear-gradient(90deg,#8b7cff,#5ee7c4)" }} />
              </div>
            )}
            <div className="hub-row">
              <input className="hub-input" inputMode="numeric" placeholder="Montant" value={potAmt[p.id] || ""} onChange={(e) => setPotAmt({ ...potAmt, [p.id]: e.target.value.replace(/\D/g, "") })} style={{ width: 100 }} />
              <button className="hub-btn acc sm" disabled={!potAmt[p.id]} onClick={async () => {
                const r = await act({ action: "contribute_pot", potId: p.id, amount: Number(potAmt[p.id]) }, "Contribution envoyée.");
                if (!r.error) setPotAmt({ ...potAmt, [p.id]: "" });
              }}>Cotiser</button>
              {p.owner === (friends[0] || "").toLowerCase() || true ? (
                <button className="hub-btn sm" disabled={!potAmt[p.id]} onClick={async () => {
                  const r = await act({ action: "withdraw_pot", potId: p.id, amount: Number(potAmt[p.id]) }, "Retrait cagnotte effectué.");
                  if (!r.error) setPotAmt({ ...potAmt, [p.id]: "" });
                }}>Retirer (créateur)</button>
              ) : null}
            </div>
          </div>
        ))}
      </div>

      {/* ===== Prêts P2P ===== */}
      <div className="hub-card" style={{ gridColumn: "1/-1" }}>
        <h3>🤝 Prêts entre joueurs</h3>
        <p className="hub-sub">Demande un prêt à un ami (+5 % d’intérêts). Il doit accepter.</p>
        <div className="hub-row" style={{ marginBottom: 10, flexWrap: "wrap" }}>
          <input className="hub-input" list="tcb-friends3" placeholder="Prêteur" value={lTo} onChange={(e) => setLTo(e.target.value)} />
          <datalist id="tcb-friends3">{friends.map((f) => <option key={f} value={f} />)}</datalist>
          <input className="hub-input" inputMode="numeric" placeholder="Montant" value={lAmt} onChange={(e) => setLAmt(e.target.value.replace(/\D/g, ""))} style={{ width: 100 }} />
          <input className="hub-input" inputMode="numeric" placeholder="Jours" value={lDays} onChange={(e) => setLDays(e.target.value.replace(/\D/g, ""))} style={{ width: 70 }} />
          <button className="hub-btn acc" disabled={!lTo.trim() || !lAmt} onClick={async () => {
            const r = await act({ action: "request_loan", to: lTo, amount: Number(lAmt), days: Number(lDays) || 7 }, "Demande de prêt envoyée.");
            if (!r.error) setLAmt("");
          }}>Demander</button>
        </div>
        {o.loans.length === 0 ? <p className="hub-sub">Aucun prêt en cours.</p> : (
          <table className="hub-table"><thead><tr><th>De → À</th><th>Montant</th><th>Reste</th><th>Échéance</th><th>Statut</th><th></th></tr></thead><tbody>
            {o.loans.map((lo) => (
              <tr key={lo.id}>
                <td>{lo.from} → {lo.to}</td>
                <td>{n(lo.amount)} (+{n(lo.interest)})</td>
                <td>{n(lo.remaining)}</td>
                <td>{date(lo.dueAt)}</td>
                <td>{lo.status}</td>
                <td>
                  {lo.status === "pending" && (
                    <button className="hub-btn sm ok" onClick={() => act({ action: "accept_loan", loanId: lo.id }, "Prêt accepté.")}>Accepter</button>
                  )}
                  {lo.status === "active" && (
                    <span className="hub-row">
                      <input className="hub-input" inputMode="numeric" placeholder="Remb." value={repayAmt[lo.id] || ""} onChange={(e) => setRepayAmt({ ...repayAmt, [lo.id]: e.target.value.replace(/\D/g, "") })} style={{ width: 80 }} />
                      <button className="hub-btn sm" disabled={!repayAmt[lo.id]} onClick={async () => {
                        const r = await act({ action: "repay_loan", loanId: lo.id, amount: Number(repayAmt[lo.id]) }, "Remboursement effectué.");
                        if (!r.error) setRepayAmt({ ...repayAmt, [lo.id]: "" });
                      }}>Rembourser</button>
                    </span>
                  )}
                </td>
              </tr>
            ))}
          </tbody></table>
        )}
      </div>

      {/* ===== Assurance ===== */}
      <div className="hub-card">
        <h3>🛡️ Assurance TCB Protection</h3>
        {o.insurance ? (
          <p className="hub-msg ok">Active jusqu’au {new Date(o.insurance.endsAt).toLocaleDateString("fr-FR")} — protection cosmétique du compte.</p>
        ) : (
          <>
            <p className="hub-sub">150 Bobux pour 30 jours. Badge « Assuré » + petit bonus de prestige.</p>
            <button className="hub-btn acc" disabled={a.checking < 150} onClick={() => act({ action: "buy_insurance" }, "Assurance activée !")}>
              {a.checking < 150 ? `Il te manque ${n(150 - a.checking)} Bobux` : "Souscrire (150 Bobux)"}
            </button>
          </>
        )}
      </div>

      {/* ===== Premium ===== */}
      <div className="hub-card">
        <h3>💎 {s.name}</h3>
        <p className="hub-sub">
          {s.creatorUnlimited
            ? <><b>Premium illimité et gratuit</b> pour le créateur Younes.</>
            : <><b>{n(s.price)} Bobux</b> par mois ({s.days} jours), payés avec ton solde.</>}
        </p>
        <ul className="hub-sub" style={{ paddingLeft: 18, margin: "0 0 12px" }}>{PERKS.map((p) => <li key={p}>{p}</li>)}</ul>
        {s.active ? (
          <>
            <p className="hub-msg ok">
              {s.creatorUnlimited
                ? "Premium créateur actif sans limite de durée."
                : `Abonné jusqu’au ${new Date(s.endsAt).toLocaleDateString("fr-FR")} · ${s.autoRenew ? "renouvellement automatique" : "sans renouvellement"}`}
            </p>
            {!s.creatorUnlimited && (
              <div className="hub-row">
                {s.autoRenew
                  ? <button className="hub-btn danger" onClick={() => act({ action: "cancel" }, "Renouvellement annulé.")}>Annuler le renouvellement</button>
                  : <button className="hub-btn acc" onClick={() => act({ action: "resume" }, "Renouvellement réactivé.")}>Réactiver le renouvellement</button>}
              </div>
            )}
          </>
        ) : (
          <button className="hub-btn acc" disabled={a.checking < s.price} onClick={() => act({ action: "subscribe" }, "Bienvenue dans TCB Premium !")}>
            {a.checking < s.price ? `Il te manque ${n(s.price - a.checking)} Bobux` : `Souscrire pour ${n(s.price)} Bobux`}
          </button>
        )}
      </div>

      {/* ===== Centre Premium ===== */}
      {s.active && (
        <div className="hub-card" style={{ gridColumn: "1/-1", border: "1px solid #8b7cff" }}>
          <h3>✨ Centre Premium avancé</h3>
          <div className="hub-grid">
            <div>
              <b>📈 Simulateur d’épargne</b>
              <p className="hub-sub">Projection sur 30 jours avec intérêts composés.</p>
              <input className="hub-input" inputMode="numeric" value={monthlySave} onChange={(e) => setMonthlySave(e.target.value.replace(/\D/g, "").slice(0, 7))} placeholder="Bobux ajoutés par jour" style={{ width: "100%", marginBottom: 8 }} />
              <div style={{ fontSize: 24, fontWeight: 900 }}>
                🪙 {n(Math.min(1_000_000_000, Math.round((a.savings + Math.max(0, Number(monthlySave) || 0) * 30) * Math.pow(1 + a.rate, 30))))}
              </div>
            </div>
            <div>
              <b>🧠 Analyse des dépenses</b>
              <p>Entrées : <b>{n(o.statement.filter((x) => x.amount > 0).reduce((sum, x) => sum + x.amount, 0))} Bobux</b></p>
              <p>Sorties : <b>{n(Math.abs(o.statement.filter((x) => x.amount < 0).reduce((sum, x) => sum + x.amount, 0)))} Bobux</b></p>
              <p>Solde net : <b>{n(o.statement.reduce((sum, x) => sum + x.amount, 0))} Bobux</b></p>
              <button className="hub-btn acc" onClick={() => {
                const rows = [
                  ["Date", "Opération", "Catégorie", "Montant Bobux"],
                  ...o.statement.map((x) => [new Date(x.at).toISOString(), x.label, x.category || "", String(x.amount)]),
                  ...o.savingsTx.map((x) => [new Date(x.at).toISOString(), x.note, x.category || x.type, String(x.amount)]),
                ];
                const csv = rows.map((r) => r.map((v) => `"${String(v).replace(/"/g, '""')}"`).join(";")).join("\r\n");
                const blob = new Blob(["\uFEFF" + csv], { type: "text/csv;charset=utf-8" });
                const url = URL.createObjectURL(blob);
                const aEl = document.createElement("a"); aEl.href = url; aEl.download = "tcb-plus-releve.csv"; aEl.click();
                URL.revokeObjectURL(url);
                setMsg({ t: "Export CSV préparé.", ok: true });
              }}>Exporter le relevé en CSV</button>
            </div>
          </div>
        </div>
      )}

      <div className="hub-card" style={{ gridColumn: "1/-1" }}>
        <h3>🎰 Guichet Mystère</h3>
        <p className="hub-sub">25 Bobux · 5 tirages/jour. Un malus peut t&apos;endetter.</p>
        <button className="hub-btn acc" disabled={!o.mystery || (o.mystery.remaining ?? 0) <= 0 || a.checking < (o.mystery?.cost ?? 25)}
          onClick={async () => { const r = await act({ action: "mystery" }, "Tirage…"); if (!r.error && r.title) setMysteryResult({ title: r.title, text: r.text }); }}>
          {!o.mystery ? "Tirer" : o.mystery.remaining <= 0 ? "Fermé aujourd’hui" : `Tirer (${o.mystery.cost} Bobux)`}
        </button>
        {mysteryResult && <div style={{ marginTop: 10 }}><b>{mysteryResult.title}</b><p className="hub-sub">{mysteryResult.text}</p></div>}
      </div>
      <div className="hub-card" style={{ gridColumn: "1/-1", border: "1px solid #3d5c3a" }}>
        <h3>🚨 Blocus Simulator</h3>
        <p className="hub-sub">Catalogue : <a href="/games/blocus-simulator" style={{ color: "#8b7cff" }}>/games/blocus-simulator</a>
          {a.overdraftUsed > 0 ? " — victoire = dette réduite." : "."}</p>
        <div className="hub-row">
          <a className="hub-btn acc" href="/games/blocus-simulator">Ouvrir le jeu</a>
          {a.overdraftUsed > 0 && o.blocus?.available && (
            <button className="hub-btn" onClick={() => setShowBlocus(true)}>Jouer ici</button>
          )}
        </div>
        {showBlocus && (
          <div style={{ marginTop: 12 }}>
            <BlocusSimulator onClose={() => setShowBlocus(false)} onFinish={async (won, score) => {
              await act({ action: "blocus", won, score }, won ? "Fuite réussie" : "Attrapé");
            }} />
          </div>
        )}
      </div>

      {/* ===== Relevé ===== */}
      <div className="hub-card" style={{ gridColumn: "1/-1" }}>
        <h3>🧾 Relevé</h3>
        <div className="hub-grid">
          <div>
            <b>Compte courant</b>
            {o.statement.length === 0 ? <p className="hub-sub">Aucune opération.</p> : (
              <table className="hub-table"><tbody>
                {o.statement.map((e, i) => (
                  <tr key={i}>
                    <td>{date(e.at)}</td>
                    <td>{e.label}</td>
                    <td><span className="hub-pill" style={{ fontSize: 11 }}>{e.category || "—"}</span></td>
                    <td style={{ textAlign: "right", color: e.amount < 0 ? "#ffb3ba" : "#8ef0c0", fontWeight: 800 }}>
                      {e.amount > 0 ? "+" : ""}{n(e.amount)}
                    </td>
                  </tr>
                ))}
              </tbody></table>
            )}
          </div>
          <div>
            <b>Épargne & banque</b>
            {o.savingsTx.length === 0 ? <p className="hub-sub">Aucune opération.</p> : (
              <table className="hub-table"><tbody>
                {o.savingsTx.map((e) => (
                  <tr key={e.id}>
                    <td>{date(e.at)}</td>
                    <td>{e.note}</td>
                    <td><span className="hub-pill" style={{ fontSize: 11 }}>{e.category || e.type}</span></td>
                    <td style={{ textAlign: "right", fontWeight: 800 }}>{e.amount > 0 ? "+" : ""}{n(e.amount)}</td>
                  </tr>
                ))}
              </tbody></table>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
