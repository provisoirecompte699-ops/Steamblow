"use client";
import Link from "next/link";
import { useCallback, useEffect, useState } from "react";
import { hashPin, loadParental, saveParental, type Parental } from "../tcbShared";
import TrollTab from "./TrollTab";
import Realtime from "./Realtime";
import BankTab from "./BankTab";

type G = { id: string; title: string };
type Data = {
  me: { username: string; staff: boolean; admin: boolean; bobux: number }; friends: string[];
  daily: { gameId: string; title: string; date: string; played: boolean };
  stories: { id: string; author: string; text: string; emoji: string; gameId?: string; at: number }[];
  playing: { user: string; gameId: string }[];
  referral: { code: string; count: number; usedCode: string | null };
  groups: { slug: string; name: string; icon: string; count: number; joined: boolean }[];
  titles: { id: string; label: string; icon: string; need: string; ok: boolean }[];
  title: string | null; reasons: string[]; games: G[];
};
type Report = { id: string; reporter: string; target: string; reason: string; details: string; status: string; note?: string; decidedBy?: string; at: number };

const post = async (body: Record<string, unknown>) => (await fetch("/api/tcb", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify(body) })).json();
const ago = (t: number) => { const m = Math.floor((Date.now() - t) / 60000); return m < 1 ? "à l’instant" : m < 60 ? `il y a ${m} min` : `il y a ${Math.floor(m / 60)} h`; };
const EMOJIS = ["🎮", "🔥", "🏆", "😂", "😎", "🤯", "🎉", "💀"];

export default function Client() {
  const [d, setD] = useState<Data | null>(null);
  const [tab, setTab] = useState("today");
  const [msg, setMsg] = useState<{ t: string; ok: boolean } | null>(null);
  const load = useCallback(async () => { const r = await fetch("/api/tcb"); if (r.ok) setD(await r.json()); }, []);
  useEffect(() => { load(); const t = setInterval(load, 30000); return () => clearInterval(t); }, [load]);
  const act = async (body: Record<string, unknown>, ok = "C’est fait.") => { const r = await post(body); setMsg({ t: r.error || ok, ok: !r.error }); if (!r.error) load(); return r; };
  const gt = (id: string) => d?.games.find((g) => g.id === id)?.title || id;
  if (!d) return <p className="hub-sub">Chargement…</p>;
  const tabs = [["today", "Aujourd’hui"], ["bank", "Banque"], ["social", "Social"], ["rt", "Temps réel"], ["troll", "Troll"], ["account", "Compte & sécurité"], ...(d.me.staff ? [["mod", "Modération"]] : [])];
  return <>
    <div className="hub-head"><div><span className="hub-kick">TheCombinedWebs · TCB Plus</span><h1>TCB Plus</h1><p>Jeu du jour, titres, stories, groupes, parrainage, sauvegarde et contrôle parental. Raccourci : <kbd>/</kbd> ou <kbd>Ctrl</kbd>+<kbd>K</kbd> pour chercher n’importe où, <kbd>?</kbd> pour l’aide.</p></div></div>
    <div className="hub-tabs">{tabs.map(([k, l]) => <button key={k} className={tab === k ? "on" : ""} onClick={() => { setTab(k); setMsg(null); }}>{l}</button>)}</div>
    {msg && <p className={`hub-msg ${msg.ok ? "ok" : "err"}`}>{msg.t}</p>}

    {tab === "today" && <div className="hub-grid">
      <div className="hub-card"><h3>💸 Admin Abuse quotidien</h3><p className="hub-sub">Un mini-jeu de chasse aux Bobux tous les jours. Quand le créateur ou le vice-créateur lance l’événement, les taxes sont suspendues.</p><Link className="hub-btn acc" href="/admin-abuse">Ouvrir Admin Abuse</Link></div>
      <div className="hub-card"><h3>🎯 Jeu du jour</h3><p className="hub-sub">{d.daily.title}</p>
        <p className="hub-sub">Joue une partie arcade aujourd’hui, puis récupère ton bonus de <b>25 Bobux</b> (50 avec Premium).</p>
        <div className="hub-row"><Link className="hub-btn acc" href={`/games/${d.daily.gameId}`}>▶ Jouer</Link>
          <button className="hub-btn ok" disabled={!d.daily.played} onClick={() => act({ action: "daily" }, "Bonus récupéré !")}>Récupérer +25 Bobux</button></div>
        {!d.daily.played && <p className="hub-sub" style={{ marginTop: 8 }}>Aucune partie arcade jouée aujourd’hui.</p>}</div>
      <div className="hub-card" style={{ gridColumn: "1/-1" }}><h3>🏅 Badges & titres</h3>
        <p className="hub-sub">Débloque des titres en jouant, puis équipe celui que tu préfères.</p>
        <div className="hub-grid">{d.titles.map((t) => <div key={t.id} className="hub-card" style={{ opacity: t.ok ? 1 : .5, padding: 14 }}>
          <b>{t.icon} {t.label}</b><p className="hub-sub" style={{ margin: "4px 0 8px" }}>{t.ok ? "Débloqué" : `À débloquer : ${t.need}`}</p>
          <button className={`hub-btn sm ${d.title === t.id ? "ok" : ""}`} disabled={!t.ok || d.title === t.id} onClick={() => act({ action: "title", id: t.id }, "Titre équipé.")}>{d.title === t.id ? "Équipé" : "Équiper"}</button></div>)}</div></div>
    </div>}

    {tab === "social" && <SocialTab d={d} act={act} gt={gt} />}
    {tab === "bank" && <BankTab friends={d.friends} setMsg={setMsg} />}
    {tab === "rt" && <Realtime me={d.me.username} games={d.games} setMsg={setMsg} />}
    {tab === "troll" && <TrollTab friends={d.friends} staff={d.me.staff} setMsg={setMsg} />}
    {tab === "account" && <AccountTab d={d} act={act} gt={gt} setMsg={setMsg} />}
    {tab === "mod" && <ModTab />}
  </>;
}

function SocialTab({ d, act, gt }: { d: Data; act: (b: Record<string, unknown>, ok?: string) => Promise<any>; gt: (id: string) => string }) {
  const [text, setText] = useState(""); const [emoji, setEmoji] = useState("🎮"); const [game, setGame] = useState(""); const [code, setCode] = useState("");
  const link = typeof location !== "undefined" ? `${location.origin}/register?ref=${encodeURIComponent(d.referral.code)}` : "";
  return <div className="hub-grid">
    <div className="hub-card"><h3>🟢 Amis en jeu</h3>
      {d.playing.length === 0 ? <p className="hub-sub">Personne ne joue en ce moment.</p> : d.playing.map((p) => <div key={p.user} className="hub-row" style={{ marginBottom: 8 }}><b>{p.user}</b><span className="hub-pill acc">{gt(p.gameId)}</span><Link className="hub-btn sm" href={`/games/${p.gameId}`}>Rejoindre</Link></div>)}</div>
    <div className="hub-card"><h3>📣 Parrainage</h3>
      <p className="hub-sub">Ton code : <b>{d.referral.code}</b> · {d.referral.count} filleul(s). Vous gagnez <b>100 Bobux</b> chacun.</p>
      <div className="hub-row"><button className="hub-btn sm" onClick={() => { navigator.clipboard?.writeText(link); }}>Copier mon lien</button></div>
      {d.referral.usedCode ? <p className="hub-sub" style={{ marginTop: 10 }}>Tu as été parrainé par {d.referral.usedCode}.</p>
        : <div className="hub-row" style={{ marginTop: 10 }}><input className="hub-input" placeholder="Code d’un ami" value={code} onChange={(e) => setCode(e.target.value)} /><button className="hub-btn acc" onClick={() => act({ action: "redeem", code }, "+100 Bobux !")}>Valider</button></div>}</div>
    <div className="hub-card" style={{ gridColumn: "1/-1" }}><h3>📸 Stories (24 h)</h3>
      <div className="hub-row" style={{ marginBottom: 12 }}>
        <select className="hub-select" value={emoji} onChange={(e) => setEmoji(e.target.value)}>{EMOJIS.map((e) => <option key={e}>{e}</option>)}</select>
        <input className="hub-input" style={{ flex: 1, minWidth: 180 }} maxLength={140} placeholder="Un score, un exploit, une humeur…" value={text} onChange={(e) => setText(e.target.value)} />
        <select className="hub-select" value={game} onChange={(e) => setGame(e.target.value)}><option value="">Sans jeu</option>{d.games.map((g) => <option key={g.id} value={g.id}>{g.title}</option>)}</select>
        <button className="hub-btn acc" disabled={!text.trim()} onClick={async () => { const r = await act({ action: "story", text, emoji, gameId: game || undefined }, "Story publiée."); if (!r.error) setText(""); }}>Publier</button></div>
      {d.stories.length === 0 ? <p className="hub-sub">Aucune story pour l’instant. Visible par toi et tes amis pendant 24 h.</p>
        : <div className="hub-grid">{d.stories.map((s) => <div key={s.id} className="hub-card" style={{ padding: 14 }}><b>{s.emoji} {s.author}</b><p style={{ margin: "6px 0" }}>{s.text}</p><small className="hub-sub">{s.gameId ? `${gt(s.gameId)} · ` : ""}{ago(s.at)}</small></div>)}</div>}</div>
    <div className="hub-card" style={{ gridColumn: "1/-1" }}><h3>👥 Groupes thématiques</h3>
      <div className="hub-grid">{d.groups.map((g) => <div key={g.slug} className="hub-card" style={{ padding: 14 }}><b>{g.icon} {g.name}</b><p className="hub-sub" style={{ margin: "4px 0 8px" }}>{g.count} membre(s)</p>
        <div className="hub-row"><button className={`hub-btn sm ${g.joined ? "" : "acc"}`} onClick={() => act({ action: "group", slug: g.slug, join: !g.joined }, g.joined ? "Groupe quitté." : "Groupe rejoint.")}>{g.joined ? "Quitter" : "Rejoindre"}</button>
          {g.joined && <Link className="hub-btn sm" href="/discord">💬 Discord</Link>}</div></div>)}</div></div>
  </div>;
}

function AccountTab({ d, act, gt, setMsg }: { d: Data; act: (b: Record<string, unknown>, ok?: string) => Promise<any>; gt: (id: string) => string; setMsg: (m: { t: string; ok: boolean } | null) => void }) {
  const [saver, setSaver] = useState(false);
  const [par, setPar] = useState<Parental | null>(null);
  const [pin, setPin] = useState(""); const [limit, setLimit] = useState(120); const [hidden, setHidden] = useState<string[]>([]);
  const [rt, setRt] = useState("Autre"); const [rtarget, setRtarget] = useState(""); const [rd, setRd] = useState("");
  useEffect(() => { setSaver(localStorage.getItem("tcb:datasaver") === "1"); const p = loadParental(); setPar(p); if (p) { setLimit(p.limitMin); setHidden(p.hidden); } }, []);
  const toggleSaver = () => { const v = !saver; setSaver(v); localStorage.setItem("tcb:datasaver", v ? "1" : "0"); window.dispatchEvent(new Event("tcb-settings")); };
  const exportData = () => {
    const out: Record<string, string> = {}; for (let i = 0; i < localStorage.length; i++) { const k = localStorage.key(i)!; if (k.startsWith("steamblox:") || k.startsWith("tcb:")) out[k] = localStorage.getItem(k)!; }
    const blob = new Blob([JSON.stringify({ app: "TheCombinedWebs", version: 58, user: d.me.username, exportedAt: new Date().toISOString(), data: out }, null, 2)], { type: "application/json" });
    const a = document.createElement("a"); a.href = URL.createObjectURL(blob); a.download = `tcb-sauvegarde-${d.me.username}.json`; a.click(); URL.revokeObjectURL(a.href);
  };
  const importData = async (f: File | undefined) => {
    if (!f) return; try { const j = JSON.parse(await f.text()); if (j.app !== "TheCombinedWebs" || typeof j.data !== "object") throw 0; let n = 0;
      for (const [k, v] of Object.entries(j.data)) if ((k.startsWith("steamblox:") || k.startsWith("tcb:")) && typeof v === "string") { localStorage.setItem(k, v); n++; }
      setMsg({ t: `${n} réglages restaurés. Recharge la page.`, ok: true }); } catch { setMsg({ t: "Fichier de sauvegarde invalide.", ok: false }); }
  };
  const saveParent = async () => {
    if (!/^\d{4}$/.test(pin) && !par) { setMsg({ t: "Choisis un code PIN à 4 chiffres.", ok: false }); return; }
    const pinHash = /^\d{4}$/.test(pin) ? await hashPin(pin) : par!.pinHash;
    const p = { pinHash, limitMin: Math.max(10, Math.min(600, limit)), hidden }; saveParental(p); setPar(p); setPin(""); setMsg({ t: "Contrôle parental enregistré.", ok: true });
  };
  return <div className="hub-grid">
    <div className="hub-card"><h3>💾 Sauvegarde</h3><p className="hub-sub">Exporte tes réglages locaux (thème, avis, replays, etc.) pour les retrouver sur un autre appareil. Ton compte, tes Bobux et ta progression restent liés à ton identifiant.</p>
      <div className="hub-row"><button className="hub-btn acc" onClick={exportData}>Exporter</button><label className="hub-btn">Importer<input type="file" accept="application/json" hidden onChange={(e) => importData(e.target.files?.[0])} /></label></div></div>
    <div className="hub-card"><h3>📉 Économie de données</h3><p className="hub-sub">Coupe les animations et les effets de flou pour alléger l’affichage et la batterie.</p>
      <button className={`hub-btn ${saver ? "ok" : ""}`} onClick={toggleSaver}>{saver ? "Activé" : "Désactivé"}</button></div>
    <div className="hub-card"><h3>📴 Hors-ligne</h3><p className="hub-sub">Les pages déjà visitées et les jeux chargés sont mis en cache : ils restent ouverts sans connexion. Installe l’application depuis le menu du navigateur pour un accès direct.</p></div>
    <div className="hub-card"><h3>⌨️ Raccourcis</h3><p className="hub-sub"><kbd>/</kbd> ou <kbd>Ctrl</kbd>+<kbd>K</kbd> recherche · <kbd>?</kbd> aide · <kbd>g</kbd> puis <kbd>j</kbd> jeux, <kbd>d</kbd> Discord, <kbd>c</kbd> CinéStream, <kbd>t</kbd> tournois, <kbd>p</kbd> passe, <kbd>a</kbd> compte. Désactivés dans les jeux.</p></div>
    <div className="hub-card" style={{ gridColumn: "1/-1" }}><h3>🛡️ Contrôle parental</h3>
      <p className="hub-sub">Limite de temps quotidienne et jeux masqués, protégés par un code PIN (stocké sur cet appareil).</p>
      <div className="hub-row" style={{ marginBottom: 10 }}>
        <input className="hub-input" inputMode="numeric" maxLength={4} placeholder={par ? "Nouveau PIN (optionnel)" : "PIN 4 chiffres"} value={pin} onChange={(e) => setPin(e.target.value.replace(/\D/g, ""))} style={{ width: 160 }} />
        <label className="hub-sub">Limite : <input className="hub-input" type="number" min={10} max={600} step={10} value={limit} onChange={(e) => setLimit(Number(e.target.value))} style={{ width: 90 }} /> min/jour</label></div>
      <details><summary className="hub-sub" style={{ cursor: "pointer" }}>Jeux masqués ({hidden.length})</summary>
        <div className="hub-row" style={{ marginTop: 8 }}>{d.games.map((g) => <label key={g.id} className="hub-pill"><input type="checkbox" checked={hidden.includes(g.id)} onChange={(e) => setHidden(e.target.checked ? [...hidden, g.id] : hidden.filter((x) => x !== g.id))} /> {g.title}</label>)}</div></details>
      <div className="hub-row" style={{ marginTop: 12 }}><button className="hub-btn acc" onClick={saveParent}>Enregistrer</button>
        {par && <button className="hub-btn danger" onClick={() => { localStorage.removeItem("tcb:parental"); setPar(null); setHidden([]); setMsg({ t: "Contrôle parental désactivé.", ok: true }); }}>Désactiver</button>}</div></div>
    <div className="hub-card" style={{ gridColumn: "1/-1" }}><h3>🚩 Signaler un joueur</h3>
      <div className="hub-row"><input className="hub-input" placeholder="Pseudo" value={rtarget} onChange={(e) => setRtarget(e.target.value)} />
        <select className="hub-select" value={rt} onChange={(e) => setRt(e.target.value)}>{d.reasons.map((r) => <option key={r}>{r}</option>)}</select>
        <input className="hub-input" style={{ flex: 1, minWidth: 180 }} maxLength={500} placeholder="Détails (optionnel)" value={rd} onChange={(e) => setRd(e.target.value)} />
        <button className="hub-btn danger" disabled={!rtarget.trim()} onClick={async () => { const r = await act({ action: "report", target: rtarget, reason: rt, details: rd }, "Signalement envoyé à la modération."); if (!r.error) { setRtarget(""); setRd(""); } }}>Envoyer</button></div></div>
  </div>;
}

function ModTab() {
  const [reports, setReports] = useState<Report[]>([]);
  const [note, setNote] = useState<Record<string, string>>({});
  const [msg, setMsg] = useState("");
  const load = useCallback(async () => {
    const r = await fetch("/api/tcb?section=reports");
    if (r.ok) { const j = await r.json(); setReports(j.reports || []); }
  }, []);
  useEffect(() => { load(); }, [load]);
  const decide = async (id: string, status: string) => {
    await post({ action: "decide", id, status, note: note[id] || "" });
    await load();
  };
  return <div className="hub-grid">
    <div className="hub-card" style={{ gridColumn: "1/-1" }}><h3>🚩 File de signalements</h3>
      {reports.length === 0 ? <p className="hub-sub">Aucun signalement.</p> : <table className="hub-table"><thead><tr><th>Cible</th><th>Motif</th><th>Par</th><th>Statut</th><th>Décision</th></tr></thead><tbody>{reports.map((r) => <tr key={r.id}>
        <td><b>{r.target}</b><br /><small className="hub-sub">{r.details || "—"}</small></td><td>{r.reason}</td><td>{r.reporter}<br /><small className="hub-sub">{ago(r.at)}</small></td>
        <td><span className={`hub-pill ${r.status === "open" ? "wait" : "acc"}`}>{r.status === "open" ? "Ouvert" : r.status === "actioned" ? "Traité" : "Classé"}</span>{r.decidedBy && <small className="hub-sub"><br />par {r.decidedBy}{r.note ? ` : ${r.note}` : ""}</small>}</td>
        <td><div className="hub-row"><input className="hub-input" placeholder="Note" value={note[r.id] ?? ""} onChange={(e) => setNote({ ...note, [r.id]: e.target.value })} style={{ width: 120 }} /><button className="hub-btn sm ok" onClick={() => decide(r.id, "actioned")}>Traité</button><button className="hub-btn sm" onClick={() => decide(r.id, "dismissed")}>Classer</button></div></td></tr>)}</tbody></table>}
      {msg && <p className="hub-sub">{msg}</p>}
    </div>
  </div>;
}
