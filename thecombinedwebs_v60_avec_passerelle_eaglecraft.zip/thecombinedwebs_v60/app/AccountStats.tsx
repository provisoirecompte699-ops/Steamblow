"use client";
import { useEffect, useState } from "react";

type Stat = { label: string; value: string; icon: string };

export default function AccountStats({ username, playTimeMinutes, achievements, owned, friends }: { username: string; playTimeMinutes: number; achievements: number; owned: string[]; friends: string[] }) {
  const [stats, setStats] = useState<Stat[]>([]);

  useEffect(() => {
    const games = owned.filter(id => !id.startsWith("film:")).length;
    const films = owned.filter(id => id.startsWith("film:")).length;
    const friendCount = friends.length;
    const arcadeBest = Object.keys(localStorage).filter(k => k.startsWith("steamblox:arcade:") && k.endsWith(":best")).reduce((s, k) => s + Number(localStorage.getItem(k) || 0), 0);
    const achCount = JSON.parse(localStorage.getItem("steamblox:arcade:achievements") || "{}");
    const achUnlocked = Object.keys(achCount).length;
    const algebreStats = JSON.parse(localStorage.getItem("algebre-facile:stats") || "{}");
    const algebreDone = algebreStats.done || 0;
    const algebreCorrect = algebreStats.correct || 0;
    const storyLevel = Number(localStorage.getItem("algebre-facile:story-level") || "1");
    const fmtTime = (m: number) => m >= 60 ? `${Math.floor(m / 60)} h ${String(m % 60).padStart(2, "0")}` : `${m} min`;

    setStats([
      { label: "Temps de jeu", value: fmtTime(playTimeMinutes), icon: "⏱️" },
      { label: "Jeux possédés", value: String(games), icon: "🎮" },
      { label: "Films débloqués", value: String(films), icon: "🍿" },
      { label: "Amis", value: String(friendCount), icon: "👥" },
      { label: "Succès débloqués", value: String(achUnlocked), icon: "🏆" },
      { label: "Score arcade cumulé", value: arcadeBest.toLocaleString(), icon: "💯" },
      { label: "Exercices algèbre", value: `${algebreDone} (${algebreCorrect} réussis)`, icon: "📐" },
      { label: "Mode histoire", value: `Chapitre ${storyLevel}/6`, icon: "📖" },
      { label: "Succès officiels", value: String(achievements), icon: "⭐" },
    ]);
  }, [username, playTimeMinutes, achievements, owned, friends]);

  return <div className="card">
    <div className="section-head"><div><div className="eyebrow">PROFIL</div><h3>Statistiques de compte</h3></div></div>
    <div className="ui-account-stats">
      {stats.map((s, i) => <div key={i} className="ui-account-stat">
        <span className="ui-stat-icon">{s.icon}</span>
        <div><b>{s.value}</b><small>{s.label}</small></div>
      </div>)}
    </div>
  </div>;
}
