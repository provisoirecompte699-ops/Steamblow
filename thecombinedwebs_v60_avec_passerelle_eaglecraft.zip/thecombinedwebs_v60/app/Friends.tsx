"use client";
import {useEffect,useState} from "react";
type Req={id:string;from:string;to:string;status:string};
export default function Friends({initialFriends}:{initialFriends:string[]}){
 const [friends,setFriends]=useState(initialFriends),[incoming,setIncoming]=useState<Req[]>([]),[q,setQ]=useState(""),[results,setResults]=useState<{username:string;role:string}[]>([]),[status,setStatus]=useState("");
 const refresh=async()=>{const r=await fetch("/api/friends");if(r.ok){const d=await r.json();setFriends(d.friends);setIncoming(d.incoming)}};
 useEffect(()=>{refresh()},[]);
 useEffect(()=>{const t=setTimeout(async()=>{if(q.trim().length<1){setResults([]);return}const r=await fetch(`/api/friends?q=${encodeURIComponent(q)}`);if(r.ok)setResults((await r.json()).users)},250);return()=>clearTimeout(t)},[q]);
 const add=async(username:string)=>{setStatus("Envoi...");const r=await fetch("/api/friends",{method:"POST",headers:{"content-type":"application/json"},body:JSON.stringify({action:"add",username})});const d=await r.json();setStatus(d.error||"Demande envoyée");setQ("");setResults([])};
 const respond=async(from:string,accept:boolean)=>{const r=await fetch("/api/friends",{method:"POST",headers:{"content-type":"application/json"},body:JSON.stringify({action:"respond",from,accept})});const d=await r.json();setStatus(d.error|| (accept?"Ami ajouté":"Demande refusée"));await refresh()};
 const remove=async(username:string)=>{await fetch("/api/friends",{method:"POST",headers:{"content-type":"application/json"},body:JSON.stringify({action:"remove",username})});await refresh()};
 return <section className="friends card"><div><div className="eyebrow">SOCIAL</div><h2>Amis</h2><p className="muted">Ajoute des joueurs pour voir qui est dispo et préparer des parties ensemble</p></div>
  <div className="friend-search"><input className="input" value={q} onChange={e=>setQ(e.target.value)} placeholder="Rechercher un pseudo..." aria-label="Rechercher un ami"/>{results.length>0&&<div className="search-results">{results.map(x=><div className="search-result" key={x.username}><span><b>{x.username}</b><small>{x.role}</small></span><button className="button" onClick={()=>add(x.username)}>Ajouter</button></div>)}</div>}</div>
  {status&&<div className="notice">{status}</div>}
  {incoming.length>0&&<div><h3>Demandes reçues</h3>{incoming.map(r=><div className="friend-row" key={r.id}><b>{r.from}</b><div><button className="button" onClick={()=>respond(r.from,true)}>Accepter</button><button className="button secondary" onClick={()=>respond(r.from,false)}>Refuser</button></div></div>)}</div>}
  <h3>Ma liste · {friends.length}</h3>{friends.length===0?<p className="muted">Aucun ami pour l’instant</p>:friends.map(f=><div className="friend-row" key={f}><span className="online-dot"/> <b>{f}</b><button className="button secondary" onClick={()=>remove(f)}>Retirer</button></div>)}
 </section>
}
