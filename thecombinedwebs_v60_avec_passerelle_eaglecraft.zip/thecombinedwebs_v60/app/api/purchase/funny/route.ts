import {NextResponse} from "next/server";
import {currentUser} from "@/lib/auth";
import {catalog} from "@/lib/store";
import {createFunnyRequest} from "@/lib/funny-payment";
export async function POST(req:Request){const u=await currentUser();if(!u)return NextResponse.json({error:"Connexion requise"},{status:401});const {gameId,joke}=await req.json().catch(()=>({}));const game=catalog.find(g=>g.id===gameId);if(!game||game.price<=0)return NextResponse.json({error:"Ce jeu n'est pas payant"},{status:400});if(u.owned.includes(game.id))return NextResponse.json({error:"Jeu déjà possédé"},{status:400});try{const r=await createFunnyRequest(u.username,game.id,String(joke??""));return NextResponse.json({ok:true,id:r.id})}catch(e){return NextResponse.json({error:e instanceof Error?e.message:"Erreur"},{status:400})}}
