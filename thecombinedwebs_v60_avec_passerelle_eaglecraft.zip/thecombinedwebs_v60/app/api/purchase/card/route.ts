import { currentUser } from "@/lib/auth";
import { catalog, getUser, saveUser } from "@/lib/store";
export async function POST(req:Request){
  const u=await currentUser(); if(!u)return Response.json({error:"unauthorized"},{status:401});
  const {gameId}=await req.json(); const game=catalog.find(g=>g.id===gameId);
  if(!game||game.price<=0)return Response.json({error:"invalid game"},{status:400});
  if(u.owned.includes(game.id))return Response.json({ok:true,owned:true});
  const key=process.env.STRIPE_SECRET_KEY;
  if(!key)return Response.json({error:"Paiement par carte non configuré sur ce déploiement."},{status:503});
  const Stripe=(await import("stripe")).default; const stripe=new Stripe(key);
  const session=await stripe.checkout.sessions.create({mode:"payment",line_items:[{price_data:{currency:"eur",product_data:{name:game.title},unit_amount:Math.round(game.price*100)},quantity:1}],success_url:`${new URL(req.url).origin}/purchase/success?session_id={CHECKOUT_SESSION_ID}&game_id=${encodeURIComponent(game.id)}`,cancel_url:`${new URL(req.url).origin}/?purchase=${encodeURIComponent(game.id)}`,metadata:{username:u.username,gameId:game.id}});
  return Response.json({url:session.url});
}
