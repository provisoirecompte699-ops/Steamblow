import { currentUser } from "@/lib/auth";
import { catalog } from "@/lib/store";
import { createCashRequest } from "@/lib/payments";
export async function POST(req:Request){
  const u=await currentUser(); if(!u)return Response.json({error:"unauthorized"},{status:401});
  const {gameId}=await req.json(); const game=catalog.find(g=>g.id===gameId);
  if(!game||game.price<=0)return Response.json({error:"invalid game"},{status:400});
  if(u.owned.includes(game.id))return Response.json({error:"already owned"},{status:409});
  const r=await createCashRequest(u.username,game); return Response.json({ok:true,request:r});
}
