import {NextResponse} from "next/server";
import {currentUser} from "@/lib/auth";
import {catalog,getUser,saveUser} from "@/lib/store";
import {spend,credit} from "@/lib/bobux";

export async function POST(req:Request){
  const u=await currentUser();
  if(!u)return NextResponse.json({error:"Non connecté"},{status:401});
  const b=await req.json().catch(()=>({}));
  const game=catalog.find(g=>g.id===String(b.gameId));
  if(!game||game.price<=0)return NextResponse.json({error:"Jeu invalide"},{status:400});
  if(u.owned.includes(game.id))return NextResponse.json({ok:true,owned:true});
  const price=Math.ceil(game.price*100);
  if(!Number.isSafeInteger(price)||price<=0)return NextResponse.json({error:"Prix invalide"},{status:400});
  try{
    await spend(u.username,price,`Achat de ${game.title}`);
    try{
      const fresh=await getUser(u.username);
      if(!fresh)throw new Error("Utilisateur introuvable");
      fresh.owned=[...new Set([...fresh.owned,game.id])];
      await saveUser(fresh);
      return NextResponse.json({ok:true,owned:true,bobux:fresh.bobux||0});
    }catch(err){
      try{await credit(u.username,price,"TheCombinedWebs","Remboursement automatique après échec de l’achat","gift")}catch{}
      throw err;
    }
  }catch(e){return NextResponse.json({error:e instanceof Error?e.message:"Erreur"},{status:400});}
}
