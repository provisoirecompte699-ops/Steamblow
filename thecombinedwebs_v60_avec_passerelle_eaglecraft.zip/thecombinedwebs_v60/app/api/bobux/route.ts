import {NextResponse} from "next/server";
import {currentUser} from "@/lib/auth";
import {balance,ledgerFor,credit,spend} from "@/lib/bobux";
import {getUser} from "@/lib/store";

export async function GET(){
  const u=await currentUser();
  if(!u)return NextResponse.json({error:"Non connecté"},{status:401});
  return NextResponse.json({balance:await balance(u.username),ledger:await ledgerFor(u.username)},{headers:{"cache-control":"no-store"}});
}

export async function POST(req:Request){
  const me=await currentUser();
  if(!me)return NextResponse.json({error:"Non connecté"},{status:401});
  const b=await req.json().catch(()=>({}));
  if(b.action!=="gift")return NextResponse.json({error:"Action invalide"},{status:400});
  const amount=Number(b.amount);
  if(!Number.isSafeInteger(amount)||amount<=0||amount>1000000)return NextResponse.json({error:"Montant invalide"},{status:400});
  const target=await getUser(String(b.username||""));
  if(!target)return NextResponse.json({error:"Ami introuvable"},{status:404});
  if(!(me.friends||[]).some(x=>x.toLowerCase()===target.username.toLowerCase()))return NextResponse.json({error:"Tu dois être ami avec cette personne."},{status:403});
  try{
    await spend(me.username,amount,`Cadeau à ${target.username}`);
    try{
      await credit(target.username,amount,me.username,`Cadeau de ${me.username}`,"gift");
    }catch(err){
      try{await credit(me.username,amount,"TheCombinedWebs","Remboursement automatique après échec du cadeau","gift")}catch{}
      throw err;
    }
    return NextResponse.json({ok:true,balance:await balance(me.username)});
  }catch(e){return NextResponse.json({error:e instanceof Error?e.message:"Erreur"},{status:400});}
}
