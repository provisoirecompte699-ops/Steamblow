import { NextResponse } from "next/server";
import { currentUser } from "@/lib/auth";
import { CLAN_COLORS, CLAN_EMOJIS, CLAN_MAX, clanRanking, createClan, getClan, joinClan, kickFromClan, leaveClan, updateClan } from "@/lib/clans";

export const dynamic = "force-dynamic";
export async function GET() {
  const me = await currentUser();
  if (!me) return NextResponse.json({ error: "Connexion requise" }, { status: 401 });
  const ranking = await clanRanking();
  const mine = me.clan ? await getClan(me.clan) : null;
  return NextResponse.json({ me: me.username, mine, ranking: ranking.map((c) => ({ ...c, id: c.open || c.id === mine?.id ? c.id : null })), emojis: CLAN_EMOJIS, colors: CLAN_COLORS, max: CLAN_MAX }, { headers: { "cache-control": "no-store" } });
}
export async function POST(req: Request) {
  const me = await currentUser();
  if (!me) return NextResponse.json({ error: "Connexion requise" }, { status: 401 });
  const b = await req.json().catch(() => ({})) as Record<string, string | boolean | undefined>;
  try {
    if (b.action === "create") return NextResponse.json({ clan: await createClan(me.username, { name: String(b.name || ""), tag: String(b.tag || ""), emoji: String(b.emoji || ""), color: String(b.color || ""), motto: String(b.motto || ""), open: b.open !== false }) });
    if (b.action === "join") return NextResponse.json({ clan: await joinClan(me.username, String(b.id || "")) });
    if (b.action === "leave") return NextResponse.json({ clan: await leaveClan(me.username) });
    if (b.action === "kick") return NextResponse.json({ clan: await kickFromClan(me.username, String(b.target || "")) });
    if (b.action === "update") return NextResponse.json({ clan: await updateClan(me.username, { motto: b.motto as string | undefined, emoji: b.emoji as string | undefined, color: b.color as string | undefined, open: b.open as boolean | undefined }) });
    return NextResponse.json({ error: "Action inconnue" }, { status: 400 });
  } catch (e) { return NextResponse.json({ error: e instanceof Error ? e.message : "Erreur" }, { status: 400 }); }
}
