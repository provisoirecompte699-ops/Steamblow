import {currentUser} from "@/lib/auth";
export async function GET(){const u=await currentUser();if(!u)return Response.json({error:"unauthorized"},{status:401});const clientUrl=process.env.NEXT_PUBLIC_MULTIPLAYER_SERVER_URL||process.env.MULTIPLAYER_SERVER_URL||null;return Response.json({server:clientUrl,protocol:"socket.io",message:"Connect the client to the dedicated multiplayer server."})}
