import {currentUser} from "@/lib/auth";
import {getRequests,getOutgoing,searchUsers,sendFriendRequest,respondToRequest,removeFriend} from "@/lib/friends";
import {getUser} from "@/lib/store";
export async function GET(req:Request){const me=await currentUser();if(!me)return Response.json({error:"unauthorized"},{status:401});const q=new URL(req.url).searchParams.get("q");if(q)return Response.json({users:await searchUsers(q,me.username)});const u=await getUser(me.username);return Response.json({friends:u?.friends||[],incoming:await getRequests(me.username),outgoing:await getOutgoing(me.username)});}
export async function POST(req:Request){const me=await currentUser();if(!me)return Response.json({error:"unauthorized"},{status:401});const body=await req.json();let r:any;
 if(body.action==="add")r=await sendFriendRequest(me.username,String(body.username));
 else if(body.action==="respond")r=await respondToRequest(me.username,String(body.from),body.accept===true);
 else if(body.action==="remove")r={ok:await removeFriend(me.username,String(body.username))};
 else return Response.json({error:"action invalide"},{status:400});
 return Response.json(r,r?.error?{status:400}:{});
}
