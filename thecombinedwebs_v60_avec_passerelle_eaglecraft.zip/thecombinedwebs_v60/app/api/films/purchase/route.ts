import { NextResponse } from "next/server";
import { currentUser } from "@/lib/auth";
import { buyFilm, filmStatus, isFilmKey } from "@/lib/films";

export async function POST(req: Request) {
  const u = await currentUser();
  if (!u) return NextResponse.json({ error: "Connexion requise" }, { status: 401 });
  const body = await req.json().catch(() => ({}));
  const { key, title, method, joke } = body as { key?: unknown; title?: unknown; method?: unknown; joke?: unknown };
  if (!isFilmKey(key)) return NextResponse.json({ error: "Film inconnu" }, { status: 400 });
  if (method !== "cash" && method !== "joke") return NextResponse.json({ error: "Moyen de paiement invalide" }, { status: 400 });
  try {
    await buyFilm(u, key, String(title || ""), method, String(joke || ""));
    return NextResponse.json({ ok: true, ...(await filmStatus(u)) });
  } catch (e) {
    return NextResponse.json({ error: e instanceof Error ? e.message : "Erreur" }, { status: 400 });
  }
}
