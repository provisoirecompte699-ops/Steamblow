import { NextResponse } from "next/server";
import { currentUser } from "@/lib/auth";

export const dynamic = "force-dynamic";
export async function GET() {
  const me = await currentUser();
  if (!me) return NextResponse.json({ error: "Connexion requise" }, { status: 401 });
  return NextResponse.json({ list: me.filmList || [], history: me.filmHistory || [] }, { headers: { "cache-control": "no-store" } });
}
