import { NextResponse } from "next/server";
import { currentUser } from "@/lib/auth";
import { filmStatus } from "@/lib/films";

export const dynamic = "force-dynamic";
export async function GET() {
  const u = await currentUser();
  if (!u) return NextResponse.json({ loggedIn: false }, { status: 401 });
  return NextResponse.json({ loggedIn: true, username: u.username, ...(await filmStatus(u)) }, { headers: { "cache-control": "no-store" } });
}
