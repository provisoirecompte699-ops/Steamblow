import { NextResponse } from "next/server";
import { currentUser } from "@/lib/auth";
import { isFilmKey, toggleList } from "@/lib/films";

export async function POST(req: Request) {
  const me = await currentUser();
  if (!me) return NextResponse.json({ error: "Connexion requise" }, { status: 401 });
  const b = await req.json().catch(() => ({})) as { key?: string; title?: string; poster?: string; type?: string };
  if (!isFilmKey(b.key)) return NextResponse.json({ error: "Film inconnu" }, { status: 400 });
  return NextResponse.json(await toggleList(me.username, { key: b.key, title: String(b.title || ""), poster: b.poster ? String(b.poster).slice(0, 300) : undefined, type: b.type }));
}
