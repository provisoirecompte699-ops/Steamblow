import { NextResponse } from "next/server";
import { currentUser } from "@/lib/auth";
import { isFilmKey, recordWatch } from "@/lib/films";
import { awardXp } from "@/lib/progression";

export async function POST(req: Request) {
  const me = await currentUser();
  if (!me) return NextResponse.json({ error: "Connexion requise" }, { status: 401 });
  const b = await req.json().catch(() => ({})) as { key?: string; title?: string; poster?: string; type?: string; cat?: string; season?: number; episode?: number };
  if (!isFilmKey(b.key)) return NextResponse.json({ error: "Film inconnu" }, { status: 400 });
  const history = await recordWatch(me.username, { key: b.key, title: String(b.title || ""), poster: b.poster ? String(b.poster).slice(0, 300) : undefined, type: b.type, cat: b.cat ? String(b.cat).slice(0, 20) : undefined, season: Number(b.season) || undefined, episode: Number(b.episode) || undefined });
  await awardXp(me.username, 15, "film", 75);
  return NextResponse.json({ ok: true, history });
}
