import { NextResponse } from "next/server";
import { currentUser } from "@/lib/auth";
import { isFilmKey, postReview, reviewsFor, reviewsBy } from "@/lib/films";
import { awardXp, grantBadge } from "@/lib/progression";

export const dynamic = "force-dynamic";
export async function GET(req: Request) {
  const me = await currentUser();
  if (!me) return NextResponse.json({ error: "Connexion requise" }, { status: 401 });
  const key = new URL(req.url).searchParams.get("key");
  if (!isFilmKey(key)) return NextResponse.json({ error: "Film inconnu" }, { status: 400 });
  const friends = new Set((me.friends || []).map((f) => f.toLowerCase()));
  const all = await reviewsFor(key);
  const avg = all.length ? all.reduce((s, r) => s + r.rating, 0) / all.length : 0;
  return NextResponse.json({ avg, count: all.length, mine: all.find((r) => r.u.toLowerCase() === me.username.toLowerCase()) || null,
    reviews: all.map((r) => ({ ...r, friend: friends.has(r.u.toLowerCase()) })).sort((a, b) => Number(b.friend) - Number(a.friend) || b.at - a.at).slice(0, 30) });
}
export async function POST(req: Request) {
  const me = await currentUser();
  if (!me) return NextResponse.json({ error: "Connexion requise" }, { status: 401 });
  const b = await req.json().catch(() => ({})) as { key?: string; title?: string; rating?: number; text?: string };
  try {
    const r = await postReview(me.username, String(b.key), String(b.title || ""), Number(b.rating), String(b.text || ""));
    await awardXp(me.username, 10, "review", 50);
    if ((await reviewsBy(me.username)).length >= 5) await grantBadge(me.username, "critic");
    return NextResponse.json({ ok: true, review: r });
  } catch (e) { return NextResponse.json({ error: e instanceof Error ? e.message : "Erreur" }, { status: 400 }); }
}
