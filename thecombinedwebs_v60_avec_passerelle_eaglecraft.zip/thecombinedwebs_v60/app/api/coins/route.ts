import {currentUser} from "@/lib/auth";
import {getUser} from "@/lib/store";
import {balance,credit,ledgerFor} from "@/lib/coins";
const privileged=(r:string)=>r==="creator"||r==="vice_creator";
export async function GET(){const me=await currentUser();if(!me)return Response.json({error:"unauthorized"},{status:401});return Response.json({balance:await balance(me.username),ledger:await ledgerFor(me.username)});}
export async function POST(req:Request){const me=await currentUser();if(!me||!privileged(me.role))return Response.json({error:"Seuls Younes et Moustafa peuvent distribuer des Coins."},{status:403});const body=await req.json();try{const target=String(body.username||"");const amount=Number(body.amount);const reason=String(body.reason||"Distribution administrateur");const u=await getUser(target);if(!u)return Response.json({error:"Utilisateur introuvable"},{status:404});const e=await credit(u.username,amount,me.username,reason,"gift");return Response.json({ok:true,entry:e,balance:await balance(u.username)});}catch(e){return Response.json({error:e instanceof Error?e.message:"Erreur"},{status:400})}}
