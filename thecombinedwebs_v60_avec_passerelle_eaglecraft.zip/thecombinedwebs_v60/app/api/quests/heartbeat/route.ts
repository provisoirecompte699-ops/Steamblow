import {NextResponse} from "next/server";
import {currentUser} from "@/lib/auth";
import {getUser,saveUser} from "@/lib/store";
import {state,progress} from "@/lib/quests";

export async function POST(){
 const u=await currentUser();
 if(!u)return NextResponse.json({error:"Non connecté"},{status:401});
 const user=await getUser(u.username);
 if(!user?.activeGame)return NextResponse.json({ok:true,seconds:0,progress:0});
 const now=Date.now();
 const started=Date.parse(user.activeGame.startedAt);
 const elapsed=Math.max(0,Math.min(30,Math.floor((now-started)/1000)));
 if(elapsed<1)return NextResponse.json({ok:true,seconds:0});
 user.activeGame.startedAt=new Date(now).toISOString();
 user.activeGame.elapsedSeconds=(user.activeGame.elapsedSeconds||0)+elapsed;
 const totalPlayed=user.activeGame.elapsedSeconds;
 user.playTimeMinutes=Math.floor(totalPlayed/60)+(user.playTimeMinutes||0);
 user.activeGame.elapsedSeconds=totalPlayed%60;
 await saveUser(user);
 const st=await state(user.username);
 const total=Math.min(300,(st.progress.play||0)+elapsed);
 const next=await progress(user.username,"play",total);
 return NextResponse.json({ok:true,seconds:elapsed,progress:next.progress.play||0,playTimeMinutes:user.playTimeMinutes||0});
}
export const dynamic="force-dynamic";
