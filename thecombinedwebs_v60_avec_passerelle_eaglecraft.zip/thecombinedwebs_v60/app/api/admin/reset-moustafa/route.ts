import { currentUser } from "@/lib/auth";
import { resetMoustafaPassword, PasswordResetError } from "@/lib/password-reset";
import {sameRequestOrigin} from "@/lib/request-origin";
export const dynamic = "force-dynamic";
const headers = { "cache-control": "no-store" };
export async function POST(req: Request) {
  const me = await currentUser();
  if (!me) return Response.json({ error: "Connexion requise." }, { status: 401, headers });
  if (me.role !== "creator") return Response.json({ error: "Réservé au créateur." }, { status: 403, headers });
  if (!sameRequestOrigin(req)) return Response.json({ error: "Origine non autorisée." }, { status: 403, headers });
  if (!req.headers.get("content-type")?.startsWith("application/json")) return Response.json({ error: "Format JSON requis." }, { status: 415, headers });
  try {
    const body = await req.json();
    if (!body || typeof body.currentPassword !== "string" || typeof body.newPassword !== "string" || typeof body.confirmation !== "string")
      throw new PasswordResetError("Formulaire incomplet.", 400);
    const result = await resetMoustafaPassword(me.username, body.currentPassword, body.newPassword, body.confirmation);
    return Response.json({ ok: true, ...result }, { headers });
  } catch (error) {
    if (error instanceof PasswordResetError) return Response.json({ error: error.message }, { status: error.status, headers });
    return Response.json({ error: "Réinitialisation indisponible. Vérifie le stockage du serveur et réessaie." }, { status: 503, headers });
  }
}
