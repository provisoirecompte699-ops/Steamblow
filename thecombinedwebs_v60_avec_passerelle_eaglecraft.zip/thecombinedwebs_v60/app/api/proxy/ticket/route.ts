import { NextResponse } from "next/server";
import { currentUser } from "@/lib/auth";
import { catalog, hasGameAccess } from "@/lib/store";
import { PROXY_SITES, issueProxyTicket, type ProxySite } from "@/lib/proxy-ticket";
import { listPortals, portalUrl } from "@/lib/portals";

export const dynamic = "force-dynamic";
const NS = { headers: { "cache-control": "no-store" } };

export async function GET(req: Request) {
  const me = await currentUser(); if (!me) return NextResponse.json({ error: "Connexion requise" }, { status: 401 });
  const params = new URL(req.url).searchParams;
  const portalId = params.get("portal");
  if (portalId) {
    const p = (await listPortals()).find(p => p.id === portalId && p.enabled);
    if (!p) return NextResponse.json({ error: "Portail indisponible." }, { status: 404 });
    const game = p.games.find(g => g.id === params.get("game"));
    const u = portalUrl(game?.url || p.url, p.hosts);
    const base = (process.env.NEXT_PUBLIC_PROXY_URL || "").trim().replace(/\/+$/, "");
    return NextResponse.json({ configured: !!base, isolated: p.isolated, url: base ? `${base}/s/${issueProxyTicket(me.username, p.hosts)}/${u.host}${u.pathname}${u.search}` : undefined }, NS);
  }
  const key = params.get("site") as ProxySite; const site = PROXY_SITES[key];
  if (!site) return NextResponse.json({ error: "Site inconnu" }, { status: 400 });
  const game = catalog.find((g) => g.id === site.game); if (!game || !hasGameAccess(me, game.id)) return NextResponse.json({ error: "Accès refusé" }, { status: 403 });
  const base = (process.env.NEXT_PUBLIC_PROXY_URL || "").trim().replace(/\/+$/, "");
  if (!base) return NextResponse.json({ configured: false, isolated: site.isolated }, NS);
  return NextResponse.json({ configured: true, isolated: site.isolated, url: `${base}/s/${issueProxyTicket(me.username)}/${site.host}${site.path}` }, NS);
}
