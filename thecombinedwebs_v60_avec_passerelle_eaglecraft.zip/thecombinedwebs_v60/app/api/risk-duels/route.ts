import {currentUser} from "@/lib/auth";
import {riskAction,riskDuelsFor} from "@/lib/risk-duels";
export const dynamic="force-dynamic";
export async function GET(){const me=await currentUser();if(!me)return Response.json({error:"Connexion requise."},{status:401});return Response.json({username:me.username,friends:me.friends||[],duels:await riskDuelsFor(me.username)},{headers:{"cache-control":"no-store"}});}
export async function POST(req:Request){const me=await currentUser();if(!me)return Response.json({error:"Connexion requise."},{status:401});try{return Response.json(await riskAction(me.username,await req.json()));}catch(e){return Response.json({error:e instanceof Error?e.message:"Erreur."},{status:400});}}
