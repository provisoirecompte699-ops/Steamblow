import {NextResponse} from "next/server";
export async function GET(){return NextResponse.json({ok:true,service:"steamblox",version:"6.1.0",time:new Date().toISOString()},{headers:{"cache-control":"no-store"}})}
