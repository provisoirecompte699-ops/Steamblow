import { NextResponse } from "next/server";
import { currentUser } from "@/lib/auth";
import { createTournament, currentMatch, getTournament, joinTournament, leaveTournament, listTournaments, startTournament } from "@/lib/tournaments";
import { ARCADE_GAMES } from "@/lib/leaderboard";

export const dynamic = "force-dynamic";
export async function GET(req: Request) {
  const me = await currentUser();
  if (!me) return NextResponse.json({ error: "Connexion requise" }, { status: 401 });
  const id = new URL(req.url).searchParams.get("id");
  if (id) { const t = await getTournament(id); if (!t) return NextResponse.json({ error: "Introuvable" }, { status: 404 }); return NextResponse.json({ tournament: t, myMatch: currentMatch(t, me.username) }); }
  return NextResponse.json({ games: ARCADE_GAMES, tournaments: await listTournaments() }, { headers: { "cache-control": "no-store" } });
}
export async function POST(req: Request) {
  const me = await currentUser();
  if (!me) return NextResponse.json({ error: "Connexion requise" }, { status: 401 });
  const b = await req.json().catch(() => ({})) as { action?: string; id?: string; name?: string; gameId?: string; size?: number };
  try {
    if (b.action === "create") return NextResponse.json({ tournament: await createTournament(me.username, String(b.name || ""), String(b.gameId || ""), Number(b.size)) });
    if (b.action === "join") return NextResponse.json({ tournament: await joinTournament(me.username, String(b.id)) });
    if (b.action === "leave") return NextResponse.json({ tournament: await leaveTournament(me.username, String(b.id)) });
    if (b.action === "start") return NextResponse.json({ tournament: await startTournament(me.username, String(b.id)) });
    return NextResponse.json({ error: "Action inconnue" }, { status: 400 });
  } catch (e) { return NextResponse.json({ error: e instanceof Error ? e.message : "Erreur" }, { status: 400 }); }
}
