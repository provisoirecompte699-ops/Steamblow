import { NextResponse } from "next/server";
import { currentUser } from "@/lib/auth";
import { COSMETICS, SEASON_TIERS, XP_PER_TIER, buyCosmetic, claimTier, equipCosmetic, levelInfo, seasonOf, tierReward, badgesOf } from "@/lib/progression";
import { getUser } from "@/lib/store";

export const dynamic = "force-dynamic";
async function state(username: string) {
  const u = (await getUser(username))!;
  return { level: levelInfo(u.xp || 0), season: seasonOf(u), tiers: Array.from({ length: SEASON_TIERS }, (_, i) => ({ t: i + 1, reward: tierReward(i + 1) })), xpPerTier: XP_PER_TIER,
    cosmetics: COSMETICS, owned: u.cosmetics?.owned || [], equipped: { border: u.cosmetics?.border, name: u.cosmetics?.name, sound: u.cosmetics?.sound }, bobux: u.bobux || 0, badges: badgesOf(u) };
}
export async function GET() {
  const me = await currentUser();
  if (!me) return NextResponse.json({ error: "Connexion requise" }, { status: 401 });
  return NextResponse.json(await state(me.username), { headers: { "cache-control": "no-store" } });
}
export async function POST(req: Request) {
  const me = await currentUser();
  if (!me) return NextResponse.json({ error: "Connexion requise" }, { status: 401 });
  const b = await req.json().catch(() => ({})) as { action?: string; tier?: number; id?: string | null; type?: "border" | "name" | "sound" };
  try {
    if (b.action === "claim") await claimTier(me.username, Number(b.tier));
    else if (b.action === "buy") await buyCosmetic(me.username, String(b.id));
    else if (b.action === "equip" && b.type) await equipCosmetic(me.username, b.type, b.id || null);
    else return NextResponse.json({ error: "Action inconnue" }, { status: 400 });
    return NextResponse.json(await state(me.username));
  } catch (e) { return NextResponse.json({ error: e instanceof Error ? e.message : "Erreur" }, { status: 400 }); }
}
