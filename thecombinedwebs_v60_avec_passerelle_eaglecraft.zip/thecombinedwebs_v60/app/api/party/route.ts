import { NextResponse } from "next/server";
import { currentUser } from "@/lib/auth";
import { createParty, getParty, partyAction, type PartyFilm } from "@/lib/parties";

export const dynamic = "force-dynamic";
export async function POST(req: Request) {
  const me = await currentUser();
  if (!me) return NextResponse.json({ error: "Connexion requise" }, { status: 401 });
  const b = await req.json().catch(() => ({})) as { action?: string; id?: string; film?: PartyFilm; text?: string; play?: { playing: boolean; t: number }; ready?: boolean };
  try {
    if (b.action === "create") return NextResponse.json({ party: await createParty(me.username), now: Date.now() });
    if (b.action === "peek") return NextResponse.json({ party: await getParty(String(b.id || "").toUpperCase()), now: Date.now() });
    const p = await partyAction(me.username, String(b.id || ""), { action: String(b.action || "beat"), film: b.film, text: b.text, play: b.play, ready: b.ready });
    return NextResponse.json({ party: p, now: Date.now() }, { headers: { "cache-control": "no-store" } });
  } catch (e) { return NextResponse.json({ error: e instanceof Error ? e.message : "Erreur" }, { status: 400 }); }
}
