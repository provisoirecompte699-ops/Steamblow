import { currentUser } from "@/lib/auth";
import { eventAction, liveEvents, startEvent, publicEvent, treasureToken } from "@/lib/live-events";
export const dynamic = "force-dynamic";
export async function GET(req: Request) {
  const me = await currentUser();
  const events = await liveEvents();
  const page = new URL(req.url).searchParams.get("page");
  const treasure = me ? events.find(e => e.type === "treasure" && e.secret && !e.winner && e.page === page) : undefined;
  return Response.json({ events: events.map(publicEvent), treasure: treasure ? { id: treasure.id, token: treasureToken(treasure, me!.username), spot: treasure.spot } : null, username: me?.username, canControl: !!me && ["creator", "vice_creator"].includes(me.role) }, { headers: { "cache-control": "no-store" } });
}
export async function POST(req: Request) {
  const me = await currentUser(); if (!me) return Response.json({ error: "Connexion requise." }, { status: 401 });
  try {
    const b = await req.json();
    if (b.action === "start") {
      if (!["creator", "vice_creator"].includes(me.role)) return Response.json({ error: "Réservé au créateur." }, { status: 403 });
      const event = await startEvent(me.username, b);
      const { notifyEvent } = await import("@/lib/push");
      await notifyEvent(event).catch(() => {});
      return Response.json({ event: publicEvent(event) });
    }
    return Response.json({ event: publicEvent(await eventAction(me.username, String(b.id), String(b.action), b.token)) });
  } catch (e) { return Response.json({ error: e instanceof Error ? e.message : "Requête invalide." }, { status: 400 }); }
}
