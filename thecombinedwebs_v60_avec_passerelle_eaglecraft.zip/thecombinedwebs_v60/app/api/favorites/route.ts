import {NextResponse} from "next/server";
import {currentUser} from "@/lib/auth";
import {catalog} from "@/lib/store";
import {library,libraryAction} from "@/lib/portals";
import {progress} from "@/lib/quests";
export async function GET(){const u=await currentUser();if(!u)return NextResponse.json({error:"Non connecté"},{status:401});return NextResponse.json({favorites:(await library(u.username)).favorites.filter(x=>!x.startsWith("portal:"))});}
export async function POST(req:Request){
  const u=await currentUser();if(!u)return NextResponse.json({error:"Non connecté"},{status:401});
  const b=await req.json().catch(()=>({})),game=catalog.find(g=>g.id===String(b.gameId));
  if(!game)return NextResponse.json({error:"Jeu inconnu"},{status:404});
  const d=await libraryAction(u.username,game.id,"favorite");
  if(d?.favorites.includes(game.id))await progress(u.username,"favorite",1);
  return NextResponse.json({ok:true,favorites:d?.favorites.filter(x=>!x.startsWith("portal:"))||[]});
}
