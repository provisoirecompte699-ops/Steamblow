import { currentUser } from "@/lib/auth";
import { allGames, indexPortal, library, libraryAction, listPortals, savePortal } from "@/lib/portals";
export const dynamic = "force-dynamic";
export async function GET(req: Request) {
  const me = await currentUser();
  const q = (new URL(req.url).searchParams.get("q") || "").toLocaleLowerCase("fr").slice(0,100);
  const games = (await allGames()).filter(g => `${g.title} ${g.category || ""}`.toLocaleLowerCase("fr").includes(q));
  return Response.json({ portals: await listPortals(), games, library: me ? await library(me.username) : { favorites: [], recent: [] }, username: me?.username, canControl: me?.role === "creator" || me?.role === "vice_creator" }, { headers: { "cache-control": "no-store" } });
}
export async function POST(req: Request) {
  const me = await currentUser(); if (!me) return Response.json({ error: "Connexion requise." }, { status: 401 });
  try {
    const text = await req.text(); if (text.length > 1_000_000) throw new Error("Import trop volumineux.");
    const b = JSON.parse(text);
    if (b.action === "favorite" || b.action === "recent") return Response.json({ library: await libraryAction(me.username, String(b.id), b.action) });
    if (!["creator", "vice_creator"].includes(me.role)) return Response.json({ error: "Réservé au créateur." }, { status: 403 });
    if (b.action === "save") return Response.json({ portal: await savePortal(b) });
    if (b.action === "index") return Response.json({ portal: await indexPortal(String(b.id), b.games) });
    throw new Error("Action inconnue.");
  } catch (e) { return Response.json({ error: e instanceof Error ? e.message : "Requête invalide." }, { status: 400 }); }
}
