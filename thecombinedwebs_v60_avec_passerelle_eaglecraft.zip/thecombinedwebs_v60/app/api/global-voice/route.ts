import { currentUser } from "@/lib/auth";
import { issueGlobalVoiceToken } from "@/lib/global-voice";

export async function GET() {
  const u = await currentUser();
  if (!u) return Response.json({ error: "unauthorized" }, { status: 401, headers: { "Cache-Control": "no-store" } });
  const canSpeak = u.role === "creator";
  try { return Response.json(
    { username: u.username, token: issueGlobalVoiceToken(u.username, canSpeak), canSpeak },
    { headers: { "Cache-Control": "no-store" } }
  ); } catch {
    return Response.json({error:"Le serveur temps réel n’est pas configuré."},{status:503,headers:{"Cache-Control":"no-store"}});
  }
}
