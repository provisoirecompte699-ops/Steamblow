import { NextResponse } from "next/server";
import { currentUser } from "@/lib/auth";
import { EFFECTS, finishBobuxRun, getOptOut, sendTroll, setOptOut, startBobuxRun, takeTrolls } from "@/lib/tcb-fun";

export const dynamic = "force-dynamic";
const NS = { headers: { "cache-control": "no-store" } };
const err = (m: string, s = 400) => NextResponse.json({ error: m }, { status: s });

export async function GET() {
  const me = await currentUser(); if (!me) return err("Connexion requise", 401);
  return NextResponse.json({ trolls: await takeTrolls(me.username), optout: await getOptOut(me.username), effects: EFFECTS }, NS);
}
export async function POST(req: Request) {
  const me = await currentUser(); if (!me) return err("Connexion requise", 401);
  const b = await req.json().catch(() => ({})); let r: any;
  try {
    switch (String(b.action || "")) {
      case "code": r = await startBobuxRun(me.username, b.code); break;
      case "finish": r = await finishBobuxRun(me.username, b.id, b.caught); break;
      case "troll": r = await sendTroll(me, b.target, b.effect); break;
      case "optout": await setOptOut(me.username, !!b.value); r = { ok: true }; break;
      default: return err("Action inconnue");
    }
  } catch (e) { return err(e instanceof Error ? e.message : "Erreur"); }
  return r?.error ? err(r.error) : NextResponse.json(r, NS);
}
