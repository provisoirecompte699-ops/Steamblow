import {NextResponse} from "next/server";
import {currentUser} from "@/lib/auth";
import {catalog,getAllUsers} from "@/lib/store";
import {PAGES,REASONS,activeTitle,claimDaily,createReport,createStory,decideReport,friendsPlaying,gameOfDay,isStaff,listGroups,listReports,listStories,redeemReferral,referralInfo,setPresence,setTitle,titlesFor,toggleGroup,today} from "@/lib/tcb";

export const dynamic="force-dynamic";
const NS={headers:{"cache-control":"no-store"}};
const err=(m:string,s=400)=>NextResponse.json({error:m},{status:s});

export async function GET(req:Request){
  const q=new URL(req.url).searchParams;const section=q.get("section")||"overview";
  const me=await currentUser();if(!me)return err("Connexion requise",401);
  if(section==="search"){
    const s=(q.get("q")||"").trim().toLowerCase().slice(0,40);if(!s)return NextResponse.json({games:[],users:[],pages:[]},NS);
    const games=catalog.filter(g=>g.title.toLowerCase().includes(s)).slice(0,6).map(g=>({id:g.id,title:g.title}));
    const users=(await getAllUsers()).filter(u=>!u.banned&&u.username.toLowerCase().includes(s)).slice(0,5).map(u=>({username:u.username}));
    const pages=PAGES.filter(p=>p.label.toLowerCase().includes(s)).slice(0,5);
    return NextResponse.json({games,users,pages},NS);
  }
  if(section==="reports"){if(!isStaff(me))return err("Réservé à la modération",403);return NextResponse.json({reports:await listReports()},NS)}
  const [stories,playing,referral,groups,titles,title]=await Promise.all([listStories(me.username),friendsPlaying(me.username),referralInfo(me.username),listGroups(me.username),titlesFor(me),activeTitle(me.username)]);
  const gid=gameOfDay();
  return NextResponse.json({me:{username:me.username,staff:isStaff(me),admin:me.role==="creator"||me.role==="vice_creator",bobux:me.bobux||0},friends:me.friends||[],daily:{gameId:gid,title:catalog.find(g=>g.id===gid)?.title||gid,date:today(),played:!!(me.xpDaily?.date===today()&&(me.xpDaily.by.arcade||0)>0)},stories,playing,referral,groups,titles,title,reasons:REASONS,games:catalog.filter(g=>g.playable).map(g=>({id:g.id,title:g.title}))},NS);
}

export async function POST(req:Request){
  const me=await currentUser();if(!me)return err("Connexion requise",401);
  const b=await req.json().catch(()=>({}));const a=String(b.action||"");let r:any;
  try{
    switch(a){
      case"presence":await setPresence(me.username,b.gameId);r={ok:true};break;
      case"story":r=await createStory(me.username,b.text,b.emoji,b.gameId);break;
      case"redeem":r=await redeemReferral(me.username,b.code);break;
      case"group":r=await toggleGroup(me.username,b.slug,!!b.join);break;
      case"report":r=await createReport(me.username,b.target,b.reason,b.details);break;
      case"daily":r=await claimDaily(me.username);break;
      case"title":r=await setTitle(me.username,String(b.id||""));break;
      case"decide":if(!isStaff(me))return err("Réservé à la modération",403);r=await decideReport(me.username,b.id,b.status,b.note);break;
      default:return err("Action inconnue");
    }
  }catch(e){return err(e instanceof Error?e.message:"Erreur")}
  return r?.error?err(r.error):NextResponse.json(r,NS);
}
