import { NextResponse } from "next/server";
import { currentUser } from "@/lib/auth";
import { deposit, overview, setAutoRenew, setGoal, subscribe, transfer, withdraw } from "@/lib/tcb-bank";

export const dynamic = "force-dynamic";
const NS = { headers: { "cache-control": "no-store" } };
const err = (m: string, s = 400) => NextResponse.json({ error: m }, { status: s });

export async function GET() {
  const me = await currentUser(); if (!me) return err("Connexion requise", 401);
  return NextResponse.json(await overview(me), NS);
}
export async function POST(req: Request) {
  const me = await currentUser(); if (!me) return err("Connexion requise", 401);
  const b = await req.json().catch(() => ({})); let r: any;
  try {
    switch (String(b.action || "")) {
      case "deposit": r = await deposit(me.username, b.amount); break;
      case "withdraw": r = await withdraw(me.username, b.amount); break;
      case "transfer": r = await transfer(me.username, b.to, b.amount, b.note); break;
      case "goal": r = await setGoal(me.username, b.name, b.target); break;
      case "subscribe": r = await subscribe(me.username); break;
      case "cancel": r = await setAutoRenew(me.username, false); break;
      case "resume": r = await setAutoRenew(me.username, true); break;
      default: return err("Action inconnue");
    }
  } catch (e) { return err(e instanceof Error ? e.message : "Erreur"); }
  return r?.error ? err(r.error) : NextResponse.json(r, NS);
}
