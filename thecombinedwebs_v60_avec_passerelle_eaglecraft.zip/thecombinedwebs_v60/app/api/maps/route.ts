import { NextResponse } from "next/server";
import { currentUser } from "@/lib/auth";
import { MAP_MODES, deleteMap, getMap, likeMap, listMaps, saveMap } from "@/lib/maps";

export const dynamic = "force-dynamic";
export async function GET(req: Request) {
  const me = await currentUser();
  if (!me) return NextResponse.json({ error: "Connexion requise" }, { status: 401 });
  const id = new URL(req.url).searchParams.get("id");
  if (id) { const m = await getMap(id); return m ? NextResponse.json({ map: m }) : NextResponse.json({ error: "Carte introuvable" }, { status: 404 }); }
  return NextResponse.json({ modes: MAP_MODES, maps: await listMaps() }, { headers: { "cache-control": "no-store" } });
}
export async function POST(req: Request) {
  const me = await currentUser();
  if (!me) return NextResponse.json({ error: "Connexion requise" }, { status: 401 });
  const b = await req.json().catch(() => ({})) as { action?: string; id?: string; map?: Parameters<typeof saveMap>[1] };
  try {
    if (b.action === "save" && b.map) return NextResponse.json({ map: await saveMap(me.username, b.map) });
    if (b.action === "like") return NextResponse.json({ map: await likeMap(me.username, String(b.id)) });
    if (b.action === "delete") return NextResponse.json({ ok: await deleteMap(me.username, String(b.id), ["creator", "vice_creator", "moderator"].includes(me.role)) });
    return NextResponse.json({ error: "Action inconnue" }, { status: 400 });
  } catch (e) { return NextResponse.json({ error: e instanceof Error ? e.message : "Erreur" }, { status: 400 }); }
}
