import { NextResponse } from "next/server";
import { currentUser } from "@/lib/auth";
import { ARCADE_GAMES, DAILY_PRIZE, WEEKLY_PRIZE, board, dailyChallenge, settleWeek, weekId } from "@/lib/leaderboard";

export const dynamic = "force-dynamic";
export async function GET(req: Request) {
  const me = await currentUser();
  if (!me) return NextResponse.json({ error: "Connexion requise" }, { status: 401 });
  await settleWeek();
  const q = new URL(req.url).searchParams;
  const game = q.get("game") || ARCADE_GAMES[0].id;
  const scope = q.get("scope") === "all" ? "all" : q.get("scope") === "daily" ? "daily" : q.get("scope") === "map" ? "map" : "week";
  const entries = scope === "daily" ? await board("daily", "defi") : scope === "map" ? await board("map", "custom", String(q.get("map") || "")) : await board(scope, game);
  const friends = new Set([(me.username).toLowerCase(), ...(me.friends || []).map((f) => f.toLowerCase())]);
  return NextResponse.json({ games: ARCADE_GAMES, game, scope, week: weekId(), daily: dailyChallenge(), prizes: { weekly: WEEKLY_PRIZE, daily: DAILY_PRIZE },
    entries: entries.slice(0, 100).map((e, i) => ({ ...e, rank: i + 1, friend: friends.has(e.u.toLowerCase()) })) }, { headers: { "cache-control": "no-store" } });
}
