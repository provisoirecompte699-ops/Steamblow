import {NextResponse} from "next/server";
import {sessionUser} from "@/lib/auth";
export const dynamic="force-dynamic";export const revalidate=0;
export async function GET(){const u=await sessionUser();if(!u)return NextResponse.json({authenticated:false,banned:false},{headers:{"cache-control":"no-store"}});if(u.banned)return NextResponse.json({authenticated:true,banned:true,reason:u.banReason||"Bannissement par la modération."},{status:403,headers:{"cache-control":"no-store"}});return NextResponse.json({authenticated:true,banned:false,username:u.username,role:u.role},{headers:{"cache-control":"no-store"}})}
