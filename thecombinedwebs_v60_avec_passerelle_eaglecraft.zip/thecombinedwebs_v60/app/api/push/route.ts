import { currentUser } from "@/lib/auth";
import { pushConfigured, subscribePush, unsubscribePush } from "@/lib/push";
export const dynamic="force-dynamic";
export async function GET(){return Response.json({configured:pushConfigured(),publicKey:process.env.NEXT_PUBLIC_VAPID_PUBLIC_KEY||""});}
export async function POST(req:Request){
  const me=await currentUser();if(!me)return Response.json({error:"Connexion requise."},{status:401});
  try{const b=await req.json();if(b.action==="remove")await unsubscribePush(me.username,String(b.endpoint));else await subscribePush(me.username,b.subscription,b.events!==false,b.friends!==false);return Response.json({ok:true});}
  catch(e){return Response.json({error:e instanceof Error?e.message:"Erreur."},{status:400});}
}
