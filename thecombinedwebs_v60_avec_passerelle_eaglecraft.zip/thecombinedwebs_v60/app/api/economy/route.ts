import { currentUser } from "@/lib/auth";
import { economyAction, economyState } from "@/lib/economy";
export const dynamic = "force-dynamic";
export async function GET() {
  const me=await currentUser();
  const state=await economyState(me?.username);
  return Response.json({...state,treasury:me&&["creator","vice_creator"].includes(me.role)?state.treasury:undefined,username:me?.username},{headers:{"cache-control":"no-store"}});
}
export async function POST(req:Request) {
  const me=await currentUser();if(!me)return Response.json({error:"Connexion requise."},{status:401});
  try{return Response.json(await economyAction(me.username,await req.json()));}
  catch(e){return Response.json({error:e instanceof Error?e.message:"Requête invalide."},{status:400});}
}
