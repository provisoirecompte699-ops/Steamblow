import { settleLottery } from "@/lib/economy";
import { timingSafeEqual } from "node:crypto";
export const dynamic="force-dynamic";
export async function POST(req:Request) {
  const secret=process.env.TCB_CRON_SECRET||"",provided=(req.headers.get("authorization")||"").replace(/^Bearer /,"");
  if(!secret||provided.length!==secret.length||!timingSafeEqual(Buffer.from(secret),Buffer.from(provided)))return Response.json({error:"Accès refusé."},{status:403});
  await settleLottery();return Response.json({ok:true});
}
