import { NextResponse } from "next/server";
import { currentUser } from "@/lib/auth";
import { hasGameAccess } from "@/lib/store";
import { dailyChallenge, gameById, submitScore } from "@/lib/leaderboard";
import { awardXp } from "@/lib/progression";
import { reportMatch } from "@/lib/tournaments";
import { countPlay } from "@/lib/maps";
import { scoreDuel } from "@/lib/duels";

/** Fin de partie arcade : classements, défi du jour, tournoi, XP. */
export async function POST(req: Request) {
  const me = await currentUser();
  if (!me) return NextResponse.json({ error: "Connexion requise" }, { status: 401 });
  const b = await req.json().catch(() => ({})) as { gameId?: string; score?: number; duration?: number; daily?: boolean; mapId?: string; tournament?: string; match?: string; replay?: string; duel?:string; duelToken?:string };
  const g = gameById(String(b.gameId || ""));
  const score = Math.floor(Number(b.score) || 0);
  const duration = Number(b.duration) || 0;
  if (!g) return NextResponse.json({ error: "Jeu inconnu" }, { status: 400 });
  const daily = !!b.daily && dailyChallenge().id === g.id;
  if (!daily && !hasGameAccess(me, g.id)) return NextResponse.json({ error: "Jeu non possédé" }, { status: 403 });
  // garde-fous simples contre les scores impossibles
  if (score < 0 || score > 2_000_000 || duration < 3 || score > duration * 4000) return NextResponse.json({ error: "Score refusé" }, { status: 400 });
  const res: Record<string, unknown> = {};
  if (b.duel) {
    try { res.duel = await scoreDuel(me.username,String(b.duel),String(b.duelToken),g.id,score,duration); }
    catch(e) { return NextResponse.json({error:e instanceof Error?e.message:"Duel invalide."},{status:400}); }
  }
  if (b.tournament && b.match) { const t = await reportMatch(me.username, String(b.tournament), String(b.match), score); res.tournament = t ? { id: t.id, status: t.status, champion: t.champion } : null; }
  if (b.mapId) await countPlay(String(b.mapId));
  res.boards = await submitScore(me.username, g.id, score, { daily, mapId: b.mapId ? String(b.mapId) : undefined, replay: b.replay ? String(b.replay).slice(0, 24) : undefined });
  let xp = 15 + Math.min(120, Math.floor(score / 60)) + Math.min(40, Math.floor(duration / 6));
  const daily1 = daily ? await awardXp(me.username, 100, "daily", 100) : null;
  const gain = await awardXp(me.username, xp, "arcade", 1500);
  xp = (gain?.gained || 0) + (daily1?.gained || 0);
  res.xp = { gained: xp, level: gain?.level, into: gain?.into, need: gain?.need, levelUp: !!(gain?.levelUp || daily1?.levelUp) };
  return NextResponse.json(res);
}
