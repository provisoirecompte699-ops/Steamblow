import { NextResponse } from "next/server";

export const dynamic = "force-dynamic";
export const maxDuration = 30;

/**
 * Flux TikTok en direct — proxy serveur vers une source publique de vidéos TikTok.
 * Aucun compte TikTok ni clé API officielle requis.
 *
 * Améliorations :
 * - Supporte `exclude` pour dédupliquer les vidéos déjà chargées
 * - Appelle tikwm jusqu'à 3 fois pour obtenir suffisamment de vidéos nouvelles
 * - Retourne l'URL MP4 directe (`play`) pour un lecteur natif fluide
 * - Cache court (15s) pour le chargement initial uniquement
 */

type TikTokVideo = {
  id: string;
  author: string;
  nickname?: string;
  desc: string;
  cover?: string;
  play?: string;
  duration?: number;
  playCount?: number;
  diggCount?: number;
  commentCount?: number;
  shareCount?: number;
  createTime?: number;
  musicTitle?: string;
};

// Cache simple en mémoire (15s) pour le chargement initial uniquement
let cache: { at: number; videos: TikTokVideo[] } | null = null;
const TTL = 15_000;

const REGIONS = ["FR", "US", "GB", "JP", "BR", "DE", "ES", "IT", "KR", "MX"];

export async function GET(req: Request) {
  const url = new URL(req.url);
  const region = url.searchParams.get("region") || "FR";
  const count = Math.min(parseInt(url.searchParams.get("count") || "20"), 30);
  const excludeParam = url.searchParams.get("exclude") || "";
  const excludeIds = new Set(excludeParam.split(",").filter(Boolean));
  const isRefresh = url.searchParams.get("refresh") === "1";

  // Cache pour le chargement initial (sans exclude)
  if (!isRefresh && excludeIds.size === 0 && cache && Date.now() - cache.at < TTL) {
    return NextResponse.json({ videos: cache.videos, cached: true, source: "tiktok-live" });
  }

  let allVideos: TikTokVideo[] = [];
  let attempts = 0;
  const maxAttempts = excludeIds.size > 0 ? 3 : 1;

  while (allVideos.length < count && attempts < maxAttempts) {
    attempts++;
    try {
      const apiUrl = `https://www.tikwm.com/api/feed/list?region=${encodeURIComponent(region)}&count=${count}`;
      const r = await fetch(apiUrl, {
        headers: { "User-Agent": "Mozilla/5.0", Accept: "application/json" },
        signal: AbortSignal.timeout(12_000),
      });
      if (!r.ok) break;
      const d = await r.json();
      const raw = Array.isArray(d?.data) ? d.data : [];

      for (const v of raw) {
        const id = String(v?.video_id || "");
        if (!id || excludeIds.has(id) || allVideos.some((x) => x.id === id)) continue;
        allVideos.push({
          id,
          author: v?.author?.unique_id || "tiktok",
          nickname: v?.author?.nickname || undefined,
          desc: v?.title || v?.content_desc?.join(" ") || "",
          cover: v?.cover || v?.origin_cover || undefined,
          play: v?.play || v?.wmplay || undefined,
          duration: v?.duration || undefined,
          playCount: v?.play_count || undefined,
          diggCount: v?.digg_count || undefined,
          commentCount: v?.comment_count || undefined,
          shareCount: v?.share_count || undefined,
          createTime: v?.create_time || undefined,
          musicTitle: v?.music_info?.title || undefined,
        });
        if (allVideos.length >= count) break;
      }
    } catch {
      break;
    }
  }

  if (allVideos.length === 0) {
    return NextResponse.json(
      { error: "Aucune vidéo reçue de TikTok", videos: [] },
      { status: 502 }
    );
  }

  // Cache seulement pour le chargement initial
  if (!isRefresh && excludeIds.size === 0) {
    cache = { at: Date.now(), videos: allVideos };
  }

  return NextResponse.json({ videos: allVideos, source: "tiktok-live" });
}


