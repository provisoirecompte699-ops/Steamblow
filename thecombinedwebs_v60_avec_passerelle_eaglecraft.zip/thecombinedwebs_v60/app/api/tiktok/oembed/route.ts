import { NextResponse } from "next/server";

export const dynamic = "force-dynamic";

/** Proxy oEmbed TikTok : récupère le titre et l'auteur d'une vidéo sans clé API. */
export async function GET(req: Request) {
  const url = new URL(req.url).searchParams.get("url");
  if (!url) return NextResponse.json({ error: "URL manquante" }, { status: 400 });

  try {
    const oembedUrl = `https://www.tiktok.com/oembed?url=${encodeURIComponent(url)}`;
    const r = await fetch(oembedUrl, { headers: { "user-agent": "Mozilla/5.0" } });
    if (!r.ok) return NextResponse.json({ error: "Vidéo introuvable ou privée" }, { status: 404 });
    const d = await r.json();
    return NextResponse.json({
      author_name: d.author_name || undefined,
      title: d.title || undefined,
      thumbnail_url: d.thumbnail_url || undefined,
    }, { headers: { "cache-control": "max-age=3600" } });
  } catch {
    return NextResponse.json({ error: "Erreur réseau" }, { status: 500 });
  }
}
