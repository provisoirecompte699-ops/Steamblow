import { currentUser } from "@/lib/auth";
import { duelAction, duelsFor } from "@/lib/duels";
import { ARCADE_GAMES } from "@/lib/leaderboard";
export const dynamic="force-dynamic";
export async function GET(){
  const me=await currentUser();if(!me)return Response.json({error:"Connexion requise."},{status:401});
  return Response.json({duels:await duelsFor(me.username),games:ARCADE_GAMES.filter(g=>g.id!=="blocus-simulator"),friends:me.friends||[],username:me.username},{headers:{"cache-control":"no-store"}});
}
export async function POST(req:Request){
  const me=await currentUser();if(!me)return Response.json({error:"Connexion requise."},{status:401});
  try{return Response.json(await duelAction(me.username,await req.json()));}catch(e){return Response.json({error:e instanceof Error?e.message:"Erreur."},{status:400});}
}
