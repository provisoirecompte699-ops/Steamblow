import { currentUser } from "@/lib/auth";
import { cloudSave, SaveConflict, writeCloudSave } from "@/lib/cloud-saves";
export const dynamic="force-dynamic";
export async function GET(req:Request){
  const me=await currentUser();if(!me)return Response.json({error:"Connexion requise."},{status:401});
  try{return Response.json({save:await cloudSave(me.username,new URL(req.url).searchParams.get("game")||"")},{headers:{"cache-control":"no-store"}});}catch(e){return Response.json({error:e instanceof Error?e.message:"Erreur."},{status:400});}
}
export async function PUT(req:Request){
  const me=await currentUser();if(!me)return Response.json({error:"Connexion requise."},{status:401});
  try{const b=await req.json();return Response.json({save:await writeCloudSave(me.username,String(b.gameId),b.data,Number(b.baseVersion))});}catch(e){return Response.json({error:e instanceof Error?e.message:"Erreur."},{status:e instanceof SaveConflict?409:400});}
}
