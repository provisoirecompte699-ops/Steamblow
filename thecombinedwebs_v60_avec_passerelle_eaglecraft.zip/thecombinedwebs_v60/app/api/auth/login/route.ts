import { NextResponse } from "next/server";
import { loginWithPassword } from "@/lib/login";
export const dynamic = "force-dynamic";

// Connexion JSON utilisée par CinéStream (et tout client de l'écosystème TheCombinedWebs).
export async function POST(req: Request) {
  let body: { username?: unknown; password?: unknown } = {};
  try { body = await req.json(); } catch {}
  const username = typeof body.username === "string" ? body.username.slice(0, 40) : "";
  const password = typeof body.password === "string" ? body.password.slice(0, 200) : "";
  if (!username || !password) return NextResponse.json({ ok: false, error: "invalid" }, { status: 400, headers: { "cache-control": "no-store" } });
  try {
    const r = await loginWithPassword(username, password);
    if (!r.ok) return NextResponse.json({ ok: false, error: r.error }, { status: r.error === "rate_limited" ? 429 : 401, headers: { "cache-control": "no-store" } });
    const token=req.headers.get("x-tcb-client")==="bearer"?r.token:undefined;
    return NextResponse.json({ ok: true, username: r.user.username, role: r.user.role, reward: r.reward, streak: r.streak,token }, { headers: { "cache-control": "no-store" } });
  } catch (error) {
    // Log server-side only. Never expose cookies, account data or stack traces.
    console.error("TheCombinedWebs login failed", error instanceof Error ? error.message : "Unknown error");
    return NextResponse.json({ ok: false, error: "unavailable" }, { status: 503, headers: { "cache-control": "no-store" } });
  }
}
