import {clearSession} from "@/lib/auth";
export async function POST(){
  try {
    await clearSession();
    return Response.json({ok:true},{headers:{"cache-control":"no-store"}});
  } catch {
    return Response.json({error:"Déconnexion indisponible. Réessaie."},{status:503,headers:{"cache-control":"no-store"}});
  }
}
