import { NextResponse } from "next/server";
import { registerAccount } from "@/lib/login";
export const dynamic = "force-dynamic";

export async function POST(req: Request) {
  let body: { username?: unknown; password?: unknown } = {};
  try { body = await req.json(); } catch {}
  const username = typeof body.username === "string" ? body.username.slice(0, 40) : "";
  const password = typeof body.password === "string" ? body.password.slice(0, 200) : "";
  const r = await registerAccount(username, password);
  if (!r.ok) return NextResponse.json({ ok: false, error: r.error }, { status: r.error === "exists" ? 409 : 400, headers: { "cache-control": "no-store" } });
  return NextResponse.json({ ok: true, username: r.user.username, role: r.user.role }, { headers: { "cache-control": "no-store" } });
}
