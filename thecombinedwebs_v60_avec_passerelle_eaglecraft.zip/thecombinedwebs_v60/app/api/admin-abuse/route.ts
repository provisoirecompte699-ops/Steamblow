import { NextResponse } from "next/server";
import { currentUser } from "@/lib/auth";
import { adminAbuseStatus, finishAdminAbuseRun, startAdminAbuse, startAdminAbuseRun, stopAdminAbuse } from "@/lib/admin-abuse";
export const dynamic = "force-dynamic";
const noStore = { headers: { "cache-control": "no-store" } };
const err = (message: string, status = 400) => NextResponse.json({ error: message }, { status, ...noStore });
export async function GET() {
  const me = await currentUser(); if (!me) return err("Connexion requise.", 401);
  return NextResponse.json(await adminAbuseStatus(me.username), noStore);
}
export async function POST(req: Request) {
  const me = await currentUser(); if (!me) return err("Connexion requise.", 401);
  const b = await req.json().catch(() => ({})); let result: any;
  try {
    switch (String(b.action || "")) {
      case "start-event": result = await startAdminAbuse(me.username); break;
      case "stop-event": result = await stopAdminAbuse(me.username); break;
      case "start-game": result = await startAdminAbuseRun(me.username); break;
      case "finish-game": result = await finishAdminAbuseRun(me.username, b.runId, b.score); break;
      default: return err("Action inconnue.");
    }
  } catch (e) { return err(e instanceof Error ? e.message : "Erreur serveur."); }
  return result?.error ? err(result.error) : NextResponse.json(result, noStore);
}
