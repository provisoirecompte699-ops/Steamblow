import { NextResponse } from "next/server";
import { currentUser } from "@/lib/auth";
import { getCall, touchPresence, unreadDMs } from "@/lib/discord";

export const dynamic = "force-dynamic";
/** Battement léger envoyé depuis toutes les pages : statut d'activité + appels entrants + MP non lus. */
export async function GET(req: Request) {
  const me = await currentUser();
  if (!me) return NextResponse.json({ loggedIn: false }, { status: 401 });
  const where = (new URL(req.url).searchParams.get("where") || "").slice(0, 60);
  await touchPresence(me.username, where || undefined);
  return NextResponse.json({ loggedIn: true, username: me.username, call: await getCall(me.username), unread: await unreadDMs(me) }, { headers: { "cache-control": "no-store" } });
}
