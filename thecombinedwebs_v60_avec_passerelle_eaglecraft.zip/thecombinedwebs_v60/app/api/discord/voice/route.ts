import { NextResponse } from "next/server";
import { currentUser } from "@/lib/auth";
import { isPartyMember } from "@/lib/parties";
import { groupAccess } from "@/lib/tcb";
import { canAccess, pushSignal, takeSignals, touchPresence, voiceBeat, voiceLeave, type Signal } from "@/lib/discord";

export const dynamic = "force-dynamic";
type Body = { action?: string; room?: string; muted?: boolean; deaf?: boolean; speaking?: boolean; signals?: { to: string; kind: Signal["kind"]; sdp?: unknown }[] };

export async function POST(req: Request) {
  const me = await currentUser();
  if (!me) return NextResponse.json({ error: "Connexion requise" }, { status: 401 });
  const b = await req.json().catch(() => ({})) as Body;
  const room = String(b.room || "");
  if (!canAccess(me, room)) return NextResponse.json({ error: "Salon vocal inaccessible" }, { status: 403 });
  if (b.action !== "leave" && !(await groupAccess(me.username,room))) return NextResponse.json({error:"Rejoins d'abord ce groupe."},{status:403});
  if (room.startsWith("party~") && b.action !== "leave" && !(await isPartyMember(me.username, room.slice(6)))) return NextResponse.json({ error: "Rejoins d'abord la soirée ciné" }, { status: 403 });
  try {
    if (b.action === "leave") {
      await voiceLeave(me, room);
      await touchPresence(me.username, undefined, null);
      return NextResponse.json({ ok: true });
    }
    const members = await voiceBeat(me, room, { muted: b.muted, deaf: b.deaf, speaking: b.speaking }, b.action === "join");
    const names = new Set(members.map((m) => m.u.toLowerCase()));
    for (const s of (b.signals || []).slice(0, 16)) {
      if (!s || typeof s.to !== "string" || !["offer", "answer", "bye"].includes(s.kind)) continue;
      if (!names.has(s.to.toLowerCase()) && s.kind !== "bye") continue;
      if (JSON.stringify(s.sdp || "").length > 60000) continue;
      await pushSignal(me.username, room, s);
    }
    if (b.action === "join") await touchPresence(me.username, undefined, room);
    const inbox = (await takeSignals(me.username)).filter((s) => s.room === room);
    return NextResponse.json({ ok: true, members, inbox }, { headers: { "cache-control": "no-store" } });
  } catch (e) {
    return NextResponse.json({ error: e instanceof Error ? e.message : "Erreur" }, { status: 400 });
  }
}
