import { NextResponse } from "next/server";
import { currentUser } from "@/lib/auth";
import { canAccess, editMessage, reportMessage, sendMessage } from "@/lib/discord";
import { awardXp } from "@/lib/progression";
import { groupAccess } from "@/lib/tcb";

export async function POST(req: Request) {
  const me = await currentUser();
  if (!me) return NextResponse.json({ error: "Connexion requise" }, { status: 401 });
  const b = await req.json().catch(() => ({})) as { action?: string; channel?: string; text?: string; id?: string; emoji?: string; replyTo?: string };
  const channel = String(b.channel || "");
  if (!canAccess(me, channel)) return NextResponse.json({ error: "Salon inaccessible" }, { status: 403 });
  if (!(await groupAccess(me.username,channel))) return NextResponse.json({error:"Groupe inaccessible."},{status:403});
  try {
    if (b.action === "send") {
      const message = await sendMessage(me, channel, String(b.text || ""), b.replyTo ? String(b.replyTo) : undefined);
      await awardXp(me.username, 2, "chat", 40);
      return NextResponse.json({ ok: true, message });
    }
    if (b.action === "report") return NextResponse.json({ ok: true, report: await reportMessage(me, channel, String(b.id || ""), String(b.text || "")) });
    if (b.action === "delete" || b.action === "edit" || b.action === "react") {
      const ok = await editMessage(me, channel, String(b.id || ""), b.action, b.action === "react" ? String(b.emoji || "") : String(b.text || ""));
      return NextResponse.json({ ok }, { status: ok ? 200 : 400 });
    }
    return NextResponse.json({ error: "Action inconnue" }, { status: 400 });
  } catch (e) {
    return NextResponse.json({ error: e instanceof Error ? e.message : "Erreur" }, { status: 400 });
  }
}
