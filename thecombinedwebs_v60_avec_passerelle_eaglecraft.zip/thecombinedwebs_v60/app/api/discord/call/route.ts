import { NextResponse } from "next/server";
import { currentUser } from "@/lib/auth";
import { clearCall, getCall, ring } from "@/lib/discord";

export async function POST(req: Request) {
  const me = await currentUser();
  if (!me) return NextResponse.json({ error: "Connexion requise" }, { status: 401 });
  const b = await req.json().catch(() => ({})) as { action?: string; to?: string };
  try {
    if (b.action === "ring") return NextResponse.json({ ok: true, room: await ring(me, String(b.to || "")) });
    if (b.action === "dismiss") { await clearCall(me.username); return NextResponse.json({ ok: true }); }
    if (b.action === "cancel") {
      const c = await getCall(String(b.to || ""));
      if (c && c.from.toLowerCase() === me.username.toLowerCase()) await clearCall(String(b.to));
      return NextResponse.json({ ok: true });
    }
    return NextResponse.json({ error: "Action inconnue" }, { status: 400 });
  } catch (e) {
    return NextResponse.json({ error: e instanceof Error ? e.message : "Erreur" }, { status: 400 });
  }
}
