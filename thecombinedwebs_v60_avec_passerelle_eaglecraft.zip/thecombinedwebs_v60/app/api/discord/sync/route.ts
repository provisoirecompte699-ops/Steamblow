import { NextResponse } from "next/server";
import { currentUser } from "@/lib/auth";
import { getClan } from "@/lib/clans";
import { groupAccess, listGroups } from "@/lib/tcb";
import { equipMap } from "@/lib/progression";
import { REACTIONS, TEXT_CHANNELS, VOICE_MAX, VOICE_ROOMS, canAccess, dmId, friendsPresence, getCall, getChannel, getRead, markRead, touchPresence, voiceMembers } from "@/lib/discord";

export const dynamic = "force-dynamic";
const H = { "cache-control": "no-store" };

export async function GET(req: Request) {
  const me = await currentUser();
  if (!me) return NextResponse.json({ error: "Connexion requise" }, { status: 401 });
  const q = new URL(req.url).searchParams;
  const c = q.get("c") || "general";
  const rev = Number(q.get("rev") || -1);
  const inVoice = q.get("voice") || null;
  if (!canAccess(me, c)) return NextResponse.json({ error: "Salon inaccessible" }, { status: 403 });
  if (!(await groupAccess(me.username,c))) return NextResponse.json({error:"Groupe inaccessible."},{status:403});

  await touchPresence(me.username, "Sur Discord", inVoice);
  const friends = await friendsPresence(me);
  const chan = await getChannel(c);
  const last = chan.messages[chan.messages.length - 1];
  if (last) await markRead(me.username, c, last.at);
  const read = await getRead(me.username);

  const dms = await Promise.all(friends.map(async (f) => {
    const id = dmId(me.username, f.username);
    const d = id === c ? chan : await getChannel(id);
    const l = d.messages[d.messages.length - 1];
    return { id, with: f.username, last: l?.at || 0, preview: l ? `${l.author === me.username ? "Toi : " : ""}${l.text.slice(0, 60)}` : "", unread: !!l && l.author !== me.username && l.at > (read[id] || 0) };
  }));
  const clan = me.clan ? await getClan(me.clan) : null;
  const groups=(await listGroups(me.username)).filter(g=>g.joined);
  const voiceRooms = [...VOICE_ROOMS,...(clan ? [{ id: `clanvc~${clan.id}`, name: `${clan.emoji} Vocal ${clan.tag}` }] : []),...groups.map(g=>({id:`groupvc~${g.slug}`,name:`Vocal ${g.name}`}))];
  const voice: Record<string, { u: string; muted?: boolean; deaf?: boolean; speaking?: boolean }[]> = {};
  for (const r of voiceRooms) voice[r.id] = (await voiceMembers(r.id)).map(({ u, muted, deaf, speaking }) => ({ u, muted, deaf, speaking }));

  return NextResponse.json({
    me: { username: me.username, role: me.role },
    channels: [...TEXT_CHANNELS,...groups.map(g=>({id:`group~${g.slug}`,name:g.name,topic:`Chat du groupe ${g.name}`,icon:"#"}))],
    clan: clan ? { id: clan.id, name: clan.name, tag: clan.tag, emoji: clan.emoji, color: clan.color, channel: { id: `clan~${clan.id}`, name: `clan-${clan.tag.toLowerCase()}`, topic: clan.motto || `Salon privé du clan ${clan.name}`, icon: clan.emoji } } : null,
    voiceRooms,
    cos: await equipMap([me.username, ...chan.messages.slice(-120).map((m) => m.author), ...Object.values(voice).flat().map((m) => m.u), ...friends.map((f) => f.username)]),
    voiceMax: VOICE_MAX,
    reactions: REACTIONS,
    friends: friends.sort((a, b) => Number(b.online) - Number(a.online) || a.username.localeCompare(b.username)),
    dms: dms.sort((a, b) => b.last - a.last),
    voice,
    call: await getCall(me.username),
    channel: c,
    rev: chan.rev,
    messages: chan.rev === rev ? null : chan.messages.slice(-120),
  }, { headers: H });
}
