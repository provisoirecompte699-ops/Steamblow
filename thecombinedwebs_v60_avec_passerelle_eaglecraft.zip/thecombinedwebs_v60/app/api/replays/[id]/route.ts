import { getReplay } from "@/lib/leaderboard";

export async function GET(_req: Request, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const r = await getReplay(id);
  if (!r) return new Response("Introuvable", { status: 404 });
  const buf = Buffer.from(r.data, "base64");
  return new Response(buf, { headers: { "content-type": r.mime, "content-length": String(buf.length), "cache-control": "public, max-age=86400", "accept-ranges": "none" } });
}
