import { NextResponse } from "next/server";
import { currentUser } from "@/lib/auth";
import { gameById, saveReplay } from "@/lib/leaderboard";
import { sendMessage } from "@/lib/discord";

export const maxDuration = 30;
/** Envoi d'une rediffusion (WebM encodé en base64, 4 Mo max). */
export async function POST(req: Request) {
  const me = await currentUser();
  if (!me) return NextResponse.json({ error: "Connexion requise" }, { status: 401 });
  const b = await req.json().catch(() => ({})) as { gameId?: string; score?: number; data?: string; mime?: string; share?: boolean };
  const g = gameById(String(b.gameId || ""));
  const data = String(b.data || "");
  if (!g || !data) return NextResponse.json({ error: "Rediffusion invalide" }, { status: 400 });
  if (data.length > 5_600_000) return NextResponse.json({ error: "Rediffusion trop lourde (4 Mo max)" }, { status: 413 });
  if (!/^[A-Za-z0-9+/=]+$/.test(data.slice(0, 2000))) return NextResponse.json({ error: "Format invalide" }, { status: 400 });
  const mime = /^video\/(webm|mp4)/.test(String(b.mime)) ? String(b.mime).split(";")[0] : "video/webm";
  const r = await saveReplay({ u: me.username, gameId: g.id, title: g.title, score: Math.floor(Number(b.score) || 0), mime, data });
  if (b.share) { try { await sendMessage(me, "jeux", `🎬 Rediffusion ${g.title} · ${r.score} pts /replay/${r.id}`); } catch { /* anti-spam */ } }
  return NextResponse.json({ ok: true, id: r.id, url: `/replay/${r.id}` });
}
