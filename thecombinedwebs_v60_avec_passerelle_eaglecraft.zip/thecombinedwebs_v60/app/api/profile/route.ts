import { NextResponse } from "next/server";
import { currentUser } from "@/lib/auth";
import { getUser, saveUser } from "@/lib/store";
import { cleanText } from "@/lib/discord";
import { allGames } from "@/lib/portals";

const THEMES = ["default", "neon", "light", "retro"];
export async function POST(req: Request) {
  const me = await currentUser();
  if (!me) return NextResponse.json({ error: "Connexion requise" }, { status: 401 });
  const b = await req.json().catch(() => ({})) as { status?: string; bio?: string; theme?: string; favoriteGame?:string; showcasedAchievements?:string[] };
  const u = await getUser(me.username);
  if (!u) return NextResponse.json({ error: "Compte introuvable" }, { status: 404 });
  if (b.status !== undefined) u.status = cleanText(String(b.status)).slice(0, 60);
  if (b.bio !== undefined) u.bio = cleanText(String(b.bio)).slice(0, 240);
  if (b.theme !== undefined && THEMES.includes(String(b.theme))) u.theme = String(b.theme);
  if(b.favoriteGame!==undefined){
    if(b.favoriteGame && !(await allGames()).some(g=>g.id===b.favoriteGame))return NextResponse.json({error:"Jeu favori inconnu."},{status:400});
    u.favoriteGame=String(b.favoriteGame);
  }
  if(b.showcasedAchievements!==undefined){
    if(!Array.isArray(b.showcasedAchievements)||b.showcasedAchievements.length>6||b.showcasedAchievements.some(id=>!(u.achievements||[]).includes(id)))return NextResponse.json({error:"Choisis au plus six succès déjà débloqués."},{status:400});
    u.showcasedAchievements=[...new Set(b.showcasedAchievements)];
  }
  await saveUser(u);
  return NextResponse.json({ ok: true, status: u.status || "", bio: u.bio || "", theme: u.theme || "default" });
}
