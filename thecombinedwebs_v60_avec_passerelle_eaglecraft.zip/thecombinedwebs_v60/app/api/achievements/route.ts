import {NextResponse} from "next/server";import {currentUser} from "@/lib/auth";import {saveUser} from "@/lib/store";
const allowed=new Set(["meet-younes","meet-moustafa"]);
export async function POST(req:Request){const u=await currentUser();if(!u)return NextResponse.json({error:"Non connecté"},{status:401});const b=await req.json().catch(()=>({}));const ids=Array.isArray(b.ids)?b.ids.filter((x:any)=>allowed.has(String(x))):[];u.achievements=[...(u.achievements||[])];for(const id of ids)if(!u.achievements.includes(id))u.achievements.push(id);await saveUser(u);return NextResponse.json({ok:true,achievements:u.achievements});}
export const dynamic="force-dynamic";
