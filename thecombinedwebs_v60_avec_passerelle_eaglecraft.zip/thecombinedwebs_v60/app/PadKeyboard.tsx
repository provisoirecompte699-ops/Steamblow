"use client";
import { useEffect, useState } from "react";
export default function PadKeyboard() {
  const [target, setTarget] = useState<
      HTMLInputElement | HTMLTextAreaElement | null
    >(null),
    [text, setText] = useState(""),
    [caps, setCaps] = useState(false);
  useEffect(() => {
    const h = (e: Event) => {
      const el = (e as CustomEvent).detail.element;
      setTarget(el);
      setText(el.value || "");
    };
    window.addEventListener("tcb-pad-keyboard", h);
    return () => window.removeEventListener("tcb-pad-keyboard", h);
  }, []);
  useEffect(() => {
    if (target)
      setTimeout(
        () =>
          document.querySelector<HTMLButtonElement>("[data-pad-key]")?.focus(),
        50,
      );
  }, [target]);
  if (!target) return null;
  const numeric = target.type === "number";
  const keys = numeric
    ? "0123456789"
    : `${caps ? "ABCDEFGHIJKLMNOPQRSTUVWXYZ" : "abcdefghijklmnopqrstuvwxyz"}0123456789@.!?-_`;
  const close = () => {
    setTarget(null);
    setTimeout(() => target.focus(), 50);
  };
  const apply = () => {
    const proto =
      target instanceof HTMLTextAreaElement
        ? HTMLTextAreaElement.prototype
        : HTMLInputElement.prototype;
    Object.getOwnPropertyDescriptor(proto, "value")?.set?.call(target, text);
    target.dispatchEvent(new Event("input", { bubbles: true }));
    target.dispatchEvent(new Event("change", { bubbles: true }));
    close();
  };
  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-label="Clavier à la manette"
      style={{
        position: "fixed",
        inset: 0,
        zIndex: 100000,
        background: "#000b",
        display: "grid",
        placeItems: "center",
        padding: 16,
      }}
    >
      <section className="feature-panel" style={{ width: "min(680px,100%)" }}>
        <h2>Clavier à la manette</h2>
        <p style={{ overflowWrap: "anywhere", minHeight: 48 }}>
          {target.type === "password"
            ? "•".repeat(text.length)
            : text || "Choisis des caractères avec la manette"}
        </p>
        <div
          style={{
            display: "grid",
            gridTemplateColumns: "repeat(8,1fr)",
            gap: 8,
          }}
        >
          {[...keys].map((k) => (
            <button
              key={k}
              data-pad-key
              className="f-btn"
              onClick={() => setText((v) => v + k)}
            >
              {k}
            </button>
          ))}
        </div>
        <div className="f-row" style={{ marginTop: 16 }}>
          {!numeric && (
            <>
              <button className="f-btn" onClick={() => setText((v) => v + " ")}>
                Espace
              </button>
              <button
                className="f-btn"
                aria-pressed={caps}
                onClick={() => setCaps(!caps)}
              >
                Majuscules
              </button>
            </>
          )}
          <button
            className="f-btn"
            onClick={() => setText((v) => v.slice(0, -1))}
          >
            Effacer
          </button>
          <button className="f-btn primary" onClick={apply}>
            Valider
          </button>
          <button
            className="f-btn"
            data-close
            aria-label="Fermer"
            onClick={close}
          >
            Annuler
          </button>
        </div>
      </section>
    </div>
  );
}
