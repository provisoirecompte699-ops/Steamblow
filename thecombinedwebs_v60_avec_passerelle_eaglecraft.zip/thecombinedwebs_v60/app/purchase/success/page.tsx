import { currentUser } from "@/lib/auth";
import { catalog, getUser, saveUser } from "@/lib/store";
import Link from "next/link";
export default async function PurchaseSuccess({searchParams}:{searchParams:Promise<{session_id?:string;game_id?:string}>}){
  const u=await currentUser(); const q=await searchParams;
  if(!u||!q.session_id||!q.game_id)return <main className="wrap"><div className="card"><h1>Paiement</h1><p>Session invalide.</p><Link className="button" href="/">Retour</Link></div></main>;
  const key=process.env.STRIPE_SECRET_KEY;
  if(!key)return <main className="wrap"><div className="card"><h1>Paiement</h1><p>Le paiement est en attente de configuration du serveur.</p></div></main>;
  const Stripe=(await import("stripe")).default; const stripe=new Stripe(key); const s=await stripe.checkout.sessions.retrieve(q.session_id);
  const game=catalog.find(g=>g.id===q.game_id);
  const valid=s.payment_status==="paid" && s.metadata?.username===u.username && s.metadata?.gameId===q.game_id && game;
  if(valid){const fresh=await getUser(u.username);if(fresh&&!fresh.owned.includes(game.id)){fresh.owned.push(game.id);await saveUser(fresh)}}
  return <main className="wrap"><div className="card"><h1>{valid?"Achat confirmé":"Paiement non confirmé"}</h1><p>{valid?`${game.title} est maintenant dans ton compte.`:"La transaction n'a pas pu être validée."}</p><Link className="button" href={valid?`/games/${game.id}`:"/"}>{valid?"Jouer":"Retour"}</Link></div></main>;
}
