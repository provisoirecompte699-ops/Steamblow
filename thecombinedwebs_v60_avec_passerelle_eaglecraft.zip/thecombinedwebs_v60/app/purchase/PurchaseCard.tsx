"use client";
import {useState} from "react";
export default function PurchaseCard({gameId,price}:{gameId:string;price:number}){
 const [busy,setBusy]=useState(false); const [msg,setMsg]=useState(""); const [joke,setJoke]=useState(""); const [funnyOpen,setFunnyOpen]=useState(false);
 async function submitFunny(){
  if(busy || !joke.trim()) return;
  setBusy(true); setMsg("");
  try{
   const r=await fetch("/api/purchase/funny",{method:"POST",headers:{"content-type":"application/json"},body:JSON.stringify({gameId,joke:joke.trim()})});
   const d=await r.json().catch(()=>({}));
   if(!r.ok) throw new Error(d.error||"Erreur serveur");
   setFunnyOpen(false); setJoke(""); setMsg("Blague envoyée. Younes ou Moustafa doit maintenant décider.");
  }catch(e){setMsg(e instanceof Error?e.message:"Une erreur est survenue")}
  finally{setBusy(false)}
 }
 async function request(path:string){
  if(busy)return; setBusy(true); setMsg("");
  try{
   const r=await fetch(path,{method:"POST",headers:{"content-type":"application/json"},body:JSON.stringify({gameId})});
   const d=await r.json().catch(()=>({}));
   if(!r.ok)throw new Error(d.error||"Erreur serveur");
   if(d.url){window.location.assign(d.url);return}
   setMsg(path.includes("cash")?"Demande envoyée aux créateurs. Le jeu sera débloqué après remise des espèces et validation.":"Paiement lancé");
  }catch(e){setMsg(e instanceof Error?e.message:"Une erreur est survenue")}
  finally{setBusy(false)}
 }
 async function buyBobux(){if(busy)return;setBusy(true);setMsg("");try{const r=await fetch("/api/purchase/bobux",{method:"POST",headers:{"content-type":"application/json"},body:JSON.stringify({gameId})});const d=await r.json();if(!r.ok)throw new Error(d.error||"Achat impossible");setMsg("Jeu acheté avec des Bobux. Il est maintenant dans ta bibliothèque.");}catch(e){setMsg(e instanceof Error?e.message:"Erreur")}finally{setBusy(false)}}
 return <div><h3>Accès anticipé · {price.toFixed(2)} €</h3><div className="actions"><button className="button secondary" disabled={busy} onClick={buyBobux}>🪙 Acheter avec des Bobux</button><button className="button" disabled={busy} onClick={()=>request("/api/purchase/card")}>{busy?"Chargement…":"Payer par carte"}</button><button className="button secondary" disabled={busy} onClick={()=>request("/api/purchase/cash")}>Payer en espèces</button></div><button className="button secondary" disabled={busy} onClick={()=>setFunnyOpen(!funnyOpen)}>😂 Faire rire un créateur</button>{funnyOpen&&<div className="funny-box"><p className="muted">Raconte une blague. Ce n’est pas une détection automatique de rire : Younes ou Moustafa décide manuellement.</p><textarea className="input" maxLength={500} value={joke} onChange={e=>setJoke(e.target.value)} placeholder="Ta meilleure blague…"/><button className="button" disabled={busy||!joke.trim()} onClick={submitFunny}>Envoyer la blague</button></div>}{msg&&<p className="muted" aria-live="polite">{msg}</p>}</div>
}
