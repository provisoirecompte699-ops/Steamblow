"use client";
import Link from "next/link";
import { useState } from "react";
export default function ProfileActions({ username, isMe, isFriend, bio }: { username: string; isMe: boolean; isFriend: boolean; bio: string }) {
  const [msg, setMsg] = useState("");
  const [edit, setEdit] = useState(false);
  const [text, setText] = useState(bio);
  if (isMe) return <div style={{ display: "grid", gap: 8, minWidth: 220 }}>
    {edit ? <><textarea className="hub-input" rows={3} maxLength={240} value={text} onChange={(e) => setText(e.target.value)} placeholder="Ta bio" />
      <button className="hub-btn pri" onClick={async () => { await fetch("/api/profile", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ bio: text }) }); location.reload(); }}>Enregistrer</button></>
      : <button className="hub-btn" onClick={() => setEdit(true)}>Modifier ma bio</button>}
    <Link className="hub-btn" href="/passe">Statut, cosmétiques et thème</Link>
  </div>;
  return <div style={{ display: "grid", gap: 8 }}>
    {isFriend ? <Link className="hub-btn acc" href={`/discord?dm=${encodeURIComponent(username)}`}>Envoyer un message</Link>
      : <button className="hub-btn pri" onClick={async () => { const r = await (await fetch("/api/friends", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ action: "add", username }) })).json(); setMsg(r.error || "Demande d’ami envoyée"); }}>Ajouter en ami</button>}
    {msg && <small className="hub-msg">{msg}</small>}
  </div>;
}
