import Link from "next/link";
import { notFound, redirect } from "next/navigation";
import { currentUser } from "@/lib/auth";
import { catalog, getUser } from "@/lib/store";
import { badgesOf, levelInfo, seasonOf, COSMETICS } from "@/lib/progression";
import { bestsOf, replaysOf } from "@/lib/leaderboard";
import { getClan } from "@/lib/clans";
import { reviewsBy } from "@/lib/films";
import HubNav from "@/app/HubNav";
import ProfileActions from "./ProfileActions";
import ProfileShowcase from "./ProfileShowcase";
import { allGames, library } from "@/lib/portals";
import { activeTitle, titlesFor } from "@/lib/tcb";
import "@/app/hub.css";

export const dynamic = "force-dynamic";
export async function generateMetadata({ params }: { params: Promise<{ username: string }> }) { const { username } = await params; return { title: `${decodeURIComponent(username)} · Profil TheCombinedWebs` }; }
const ROLE: Record<string, string> = { creator: "Créateur", vice_creator: "Co-créateur", moderator: "Modérateur", user: "Joueur" };
const COLORS = ["#8b7cff", "#5ee7c4", "#ff6b6b", "#4dabf7", "#f783ac", "#ffd43b", "#69db7c"];

export default async function Profile({ params }: { params: Promise<{ username: string }> }) {
  const me = await currentUser();
  const { username } = await params;
  const u = await getUser(decodeURIComponent(username));
  if (!u || u.banned) notFound();
  const isMe = u.username.toLowerCase() === me?.username.toLowerCase();
  const lv = levelInfo(u.xp || 0), season = seasonOf(u), badges = badgesOf(u);
  const [bests, replays, clan, reviews] = await Promise.all([bestsOf(u.username), replaysOf(u.username), u.clan ? getClan(u.clan) : null, reviewsBy(u.username)]);
  const games=await allGames(),lib=await library(u.username);
  const favs = lib.favorites.map((id) => games.find((g) => g.id === id)).filter(Boolean).slice(0, 6);
  const selectedTitle=await activeTitle(u.username);
  const titleLabel=(await titlesFor(u)).find(t=>t.id===selectedTitle)?.label;
  const favorite=games.find(g=>g.id===u.favoriteGame);
  const color = COLORS[[...u.username].reduce((s, c) => s + c.charCodeAt(0), 0) % COLORS.length];
  const isFriend = (me?.friends || []).some((f) => f.toLowerCase() === u.username.toLowerCase());
  const hours = Math.round((u.playTimeMinutes || 0) / 6) / 10;
  return <div className="hub"><HubNav username={me?.username} /><main className="hub-main">
    <div className="hub-card" style={{ marginBottom: 16 }}>
      <div className="prof">
        <div className={`prof-av ${u.cosmetics?.border ? `cos-${u.cosmetics.border}` : ""}`} style={{ background: `linear-gradient(140deg, ${color}, #1b1f30)` }}>{u.username.slice(0, 1).toUpperCase()}</div>
        <div style={{ flex: 1, minWidth: 220 }}>
          <div className="hub-row"><h1 className={u.cosmetics?.name ? `cos-${u.cosmetics.name}` : ""}>{u.username}</h1>{clan && <span className="clan-tag" style={{ color: clan.color }}>{clan.emoji} [{clan.tag}]</span>}<span className="hub-pill">{ROLE[u.role] || "Joueur"}</span></div>
          <p className="prof-status">{u.status || (isMe ? "Ajoute un statut depuis Passe & boutique" : "Pas de statut")}</p>
          {u.bio && <p className="hub-muted" style={{ marginTop: 0 }}>{u.bio}</p>}
          {titleLabel&&<p className="hub-pill">Titre : {titleLabel}</p>}
          {favorite&&<p>Jeu favori : <Link href={favorite.portalId==="local"?favorite.url:`/portails/jouer?portal=${favorite.portalId}&game=${encodeURIComponent(favorite.id)}`}>{favorite.title}</Link></p>}
          <div className="badges">{badges.map((b) => <span key={b.id} className="hub-pill" title={b.label}>{b.icon} {b.label}</span>)}</div>
        </div>
        <ProfileActions username={u.username} isMe={isMe} isFriend={isFriend} bio={u.bio || ""} />
      </div>
    </div>
    <div className="hub-card" style={{marginBottom:16}}><h2 style={{fontSize:20}}>Vitrine de succès</h2><div className="hub-row">{(u.showcasedAchievements||u.achievements||[]).slice(0,6).map(id=><span className="hub-pill" key={id}>{id.replace(/[-_]/g," ")}</span>)}</div>{isMe&&<ProfileShowcase games={games.map(g=>({id:g.id,title:g.title}))} favorite={u.favoriteGame||""} achievements={u.achievements||[]} selected={u.showcasedAchievements||[]} />}</div>
    <div className="stat-grid" style={{ marginBottom: 16 }}>
      <div><span>Niveau</span><b>{lv.level}</b><div className="bar" style={{ marginTop: 6 }}><i style={{ width: `${(lv.into / lv.need) * 100}%` }} /></div></div>
      <div><span>Passe {season.name}</span><b>Palier {season.tier}</b></div>
      <div><span>Temps de jeu</span><b>{hours} h</b></div>
      <div><span>Succès</span><b>{(u.achievements || []).length}</b></div>
      <div><span>Amis</span><b>{(u.friends || []).length}</b></div>
      <div><span>Films notés</span><b>{reviews.length}</b></div>
    </div>
    <div className="hub-grid">
      <div className="hub-card"><h3>Meilleurs classements</h3>{!bests.length ? <p className="hub-muted">Aucun score enregistré.</p> : <table className="hub-table"><tbody>{bests.slice(0, 8).map((b) => <tr key={b.game}><td className={`hub-rank r${b.rank}`}>{b.rank}</td><td><Link href={`/classements?game=${b.game}&scope=all`}>{b.title}</Link></td><td><b>{b.score.toLocaleString("fr-FR")}</b></td></tr>)}</tbody></table>}</div>
      <div className="hub-card"><h3>Jeux favoris</h3>{!favs.length ? <p className="hub-muted">Aucun favori.</p> : <div className="hub-row">{favs.map((g) => <Link key={g!.id} className="hub-pill" href={g!.portalId==="local"?g!.url:`/portails/jouer?portal=${g!.portalId}&game=${encodeURIComponent(g!.id)}`}>{g!.title}</Link>)}</div>}
        {clan && <><h3 style={{ marginTop: 18 }}>Clan</h3><Link href="/clans" className="hub-row"><span className="clan-logo" style={{ width: 40, height: 40, fontSize: 20, background: clan.color + "33" }}>{clan.emoji}</span><b>{clan.name}</b></Link></>}</div>
      <div className="hub-card"><h3>Rediffusions</h3>{!replays.length ? <p className="hub-muted">Aucune rediffusion partagée.</p> : <div style={{ display: "grid", gap: 6 }}>{replays.map((r) => <Link key={r.id} href={`/replay/${r.id}`} className="hub-row" style={{ justifyContent: "space-between" }}><span>▶ {r.title}</span><b>{r.score.toLocaleString("fr-FR")} pts</b></Link>)}</div>}</div>
      <div className="hub-card"><h3>Avis ciné</h3>{!reviews.length ? <p className="hub-muted">Aucun avis.</p> : <div style={{ display: "grid", gap: 10 }}>{reviews.slice(0, 6).map((r) => <div key={r.key}><b>{r.title}</b> <span className="stars">{"★".repeat(r.rating)}{"☆".repeat(5 - r.rating)}</span>{r.text && <div className="hub-muted" style={{ fontSize: 13.5 }}>{r.text}</div>}</div>)}</div>}</div>
    </div>
    {isMe && u.cosmetics?.owned?.length ? <p className="hub-muted" style={{ marginTop: 16, fontSize: 13 }}>Cosmétiques possédés : {u.cosmetics.owned.map((id) => COSMETICS.find((c) => c.id === id)?.name || id).join(", ")}</p> : null}
  </main></div>;
}
