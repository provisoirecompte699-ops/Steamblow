import Link from "next/link";
import { notFound, redirect } from "next/navigation";
import { currentUser } from "@/lib/auth";
import { getJSON } from "@/lib/data-store";
import HubNav from "@/app/HubNav";
import "@/app/hub.css";

export const dynamic = "force-dynamic";
type Meta = { id: string; u: string; gameId: string; title: string; score: number; at: number };
export default async function ReplayPage({ params }: { params: Promise<{ id: string }> }) {
  const me = await currentUser();
  if (!me) redirect("/login");
  const { id } = await params;
  if (!/^[a-z0-9]{6,20}$/.test(id)) notFound();
  const m = await getJSON<Meta>("steamblox-replays", `meta:${id}`);
  if (!m) notFound();
  return <div className="hub"><HubNav username={me.username} /><main className="hub-main">
    <div className="hub-head"><div><span className="hub-kick">Rediffusion</span><h1>{m.title}</h1><p><Link href={`/u/${encodeURIComponent(m.u)}`}>{m.u}</Link> · {m.score.toLocaleString("fr-FR")} points · {new Date(m.at).toLocaleString("fr-FR")}</p></div>
      <div className="hub-row"><Link className="hub-btn" href={`/classements?game=${m.gameId}`}>Classement</Link><Link className="hub-btn pri" href={`/games/${m.gameId}`}>Battre ce score</Link></div></div>
    <div className="hub-card" style={{ padding: 10 }}><video src={`/api/replays/${m.id}`} controls autoPlay playsInline style={{ width: "100%", borderRadius: 12, background: "#000", maxHeight: "75vh" }} /></div>
  </main></div>;
}
