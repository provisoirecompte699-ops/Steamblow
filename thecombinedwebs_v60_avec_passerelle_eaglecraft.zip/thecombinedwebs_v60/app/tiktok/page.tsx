import { redirect } from "next/navigation";
import { currentUser } from "@/lib/auth";
import TikTokFeed from "./TikTokFeed";

export const metadata = { title: "TikTok · TheCombinedWebs", description: "Scrolle des vidéos TikTok sans compte." };
export const dynamic = "force-dynamic";

export default async function TikTokPage() {
  const u = await currentUser();
  if (!u) { redirect("/login?next=/tiktok"); return null; }
  return <TikTokFeed username={u.username} />;
}
