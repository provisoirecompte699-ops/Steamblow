"use client";
/**
 * TikTokFeed — flux vertical style TikTok, vidéos en direct de TikTok.
 *
 * Fonctionnalités :
 * - Lecteur vidéo natif <video> (MP4 direct de TikTok) avec fallback iframe
 * - Double-tap pour aimer avec animation cœur + vibration
 * - Tap zones : gauche = précédent, droite = suivant, centre = pause/play
 * - Barre de progression avec timeupdate
 * - Contrôle du son (mute par défaut, sauvegardé en localStorage)
 * - Défilement infini fluide avec déduplication
 * - Poster (cover) affiché immédiatement pendant le chargement
 * - Préchargement de la vidéo suivante
 * - "Pas intéressé" : masque la vidéo localement
 * - Favoris : liste des vidéos likées accessible dans un tiroir
 * - Sélecteur de région
 * - Transitions fluides entre les vidéos
 */
import { useState, useEffect, useRef, useCallback } from "react";
import Link from "next/link";

type Video = {
  id: string;
  author?: string;
  nickname?: string;
  desc?: string;
  cover?: string;
  play?: string;
  duration?: number;
  playCount?: number;
  diggCount?: number;
  commentCount?: number;
  shareCount?: number;
  createTime?: number;
  musicTitle?: string;
  isCustom?: boolean;
  addedBy?: string;
};

const REGIONS = [
  { code: "FR", label: "🇫🇷 France", flag: "🇫🇷" },
  { code: "US", label: "🇺🇸 USA", flag: "🇺🇸" },
  { code: "GB", label: "🇬🇧 UK", flag: "🇬🇧" },
  { code: "JP", label: "🇯🇵 Japon", flag: "🇯🇵" },
  { code: "BR", label: "🇧🇷 Brésil", flag: "🇧🇷" },
  { code: "DE", label: "🇩🇪 Allemagne", flag: "🇩🇪" },
  { code: "ES", label: "🇪🇸 Espagne", flag: "🇪🇸" },
  { code: "IT", label: "🇮🇹 Italie", flag: "🇮🇹" },
  { code: "KR", label: "🇰🇷 Corée", flag: "🇰🇷" },
  { code: "MX", label: "🇲🇽 Mexique", flag: "🇲🇽" },
];

function extractVideoId(input: string): string | null {
  const t = input.trim();
  const m1 = t.match(/tiktok\.com\/(?:@[\w.-]+\/)?video\/(\d+)/i);
  if (m1) return m1[1];
  const m2 = t.match(/tiktok\.com\/t\/(\w+)/i);
  if (m2) return m2[1];
  if (/^\d{15,25}$/.test(t)) return t;
  const m3 = t.match(/embed\/v2\/(\d+)/i);
  if (m3) return m3[1];
  return null;
}

function fmtCount(n?: number): string {
  if (!n) return "";
  if (n >= 1_000_000) return (n / 1_000_000).toFixed(1).replace(/\.0$/, "") + "M";
  if (n >= 1_000) return (n / 1_000).toFixed(1).replace(/\.0$/, "") + "K";
  return String(n);
}

function timeAgo(ts?: number): string {
  if (!ts) return "";
  const diff = Date.now() / 1000 - ts;
  if (diff < 3600) return `${Math.floor(diff / 60)} min`;
  if (diff < 86400) return `${Math.floor(diff / 3600)} h`;
  if (diff < 604800) return `${Math.floor(diff / 86400)} j`;
  return `${Math.floor(diff / 604800)} sem`;
}

export default function TikTokFeed({ username }: { username: string }) {
  const [videos, setVideos] = useState<Video[]>([]);
  const [customVideos, setCustomVideos] = useState<Video[]>([]);
  const [hiddenVideos, setHiddenVideos] = useState<Set<string>>(new Set());
  const [current, setCurrent] = useState(0);
  const [liked, setLiked] = useState<Set<string>>(new Set());
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [loadingMore, setLoadingMore] = useState(false);
  const [showAdd, setShowAdd] = useState(false);
  const [urlInput, setUrlInput] = useState("");
  const [addError, setAddError] = useState("");
  const [addLoading, setAddLoading] = useState(false);
  const [muted, setMuted] = useState(true);
  const [paused, setPaused] = useState(false);
  const [progress, setProgress] = useState(0);
  const [showHeart, setShowHeart] = useState<{ id: string; x: number; y: number } | null>(null);
  const [region, setRegion] = useState("FR");
  const [showRegions, setShowRegions] = useState(false);
  const [showFavorites, setShowFavorites] = useState(false);
  const [favoriteVideos, setFavoriteVideos] = useState<Video[]>([]);

  const containerRef = useRef<HTMLDivElement>(null);
  const videoRefs = useRef<Map<string, HTMLVideoElement>>(new Map());
  const seenIds = useRef<Set<string>>(new Set());
  const hasMore = useRef(true);
  const lastTap = useRef<{ id: string; time: number } | null>(null);
  const scrollTimeout = useRef<ReturnType<typeof setTimeout> | null>(null);
  const isScrolling = useRef(false);

  // Charger préférences depuis localStorage
  useEffect(() => {
    try {
      const savedLikes = localStorage.getItem("steamblox:tiktok:likes");
      if (savedLikes) setLiked(new Set(JSON.parse(savedLikes)));
      const savedCustom = localStorage.getItem("steamblox:tiktok:custom");
      if (savedCustom) {
        const parsed = JSON.parse(savedCustom) as Video[];
        if (Array.isArray(parsed)) {
          setCustomVideos(parsed);
          parsed.forEach((v) => seenIds.current.add(v.id));
        }
      }
      const savedMuted = localStorage.getItem("steamblox:tiktok:muted");
      if (savedMuted !== null) setMuted(savedMuted === "true");
      const savedRegion = localStorage.getItem("steamblox:tiktok:region");
      if (savedRegion) setRegion(savedRegion);
      const savedHidden = localStorage.getItem("steamblox:tiktok:hidden");
      if (savedHidden) setHiddenVideos(new Set(JSON.parse(savedHidden)));
      const savedFavs = localStorage.getItem("steamblox:tiktok:favorites");
      if (savedFavs) setFavoriteVideos(JSON.parse(savedFavs));
    } catch {}
  }, []);

  // Sauvegarder les likes + mettre à jour les favoris
  useEffect(() => {
    try { localStorage.setItem("steamblox:tiktok:likes", JSON.stringify([...liked])); } catch {}
    // Mettre à jour la liste des favoris
    const favs = allVideos.filter((v) => liked.has(v.id));
    setFavoriteVideos(favs);
    try { localStorage.setItem("steamblox:tiktok:favorites", JSON.stringify(favs)); } catch {}
  }, [liked, videos, customVideos]);

  useEffect(() => {
    try { localStorage.setItem("steamblox:tiktok:muted", String(muted)); } catch {}
  }, [muted]);

  useEffect(() => {
    try { localStorage.setItem("steamblox:tiktok:region", region); } catch {}
  }, [region]);

  useEffect(() => {
    try { localStorage.setItem("steamblox:tiktok:hidden", JSON.stringify([...hiddenVideos])); } catch {}
  }, [hiddenVideos]);

  const saveCustom = useCallback((v: Video[]) => {
    try { localStorage.setItem("steamblox:tiktok:custom", JSON.stringify(v.slice(0, 50))); } catch {}
  }, []);

  // Filtrer les vidéos masquées
  const allVideos = [...customVideos, ...videos].filter((v) => !hiddenVideos.has(v.id));

  // Charger le flux
  const loadFeed = useCallback(async (append: boolean) => {
    if (append) {
      setLoadingMore(true);
      // Passer les IDs déjà vus pour dédupliquer côté serveur
      const excludeIds = [...seenIds.current].slice(-100).join(",");
      try {
        const r = await fetch(`/api/tiktok/feed?region=${region}&count=20&exclude=${excludeIds}&refresh=1`);
        if (!r.ok) { hasMore.current = false; return; }
        const d = await r.json();
        const fresh: Video[] = (d.videos || []).filter((v: Video) => !seenIds.current.has(v.id));
        fresh.forEach((v) => seenIds.current.add(v.id));
        if (fresh.length === 0) { hasMore.current = false; return; }
        setVideos((prev) => [...prev, ...fresh]);
      } catch {
        hasMore.current = false;
      } finally {
        setLoadingMore(false);
      }
    } else {
      setLoading(true);
      setError(null);
      seenIds.current = new Set([...customVideos.map((v) => v.id)]);
      try {
        const r = await fetch(`/api/tiktok/feed?region=${region}&count=20`);
        if (!r.ok) {
          const d = await r.json().catch(() => ({}));
          throw new Error(d.error || "Source indisponible");
        }
        const d = await r.json();
        const fresh: Video[] = (d.videos || []).filter((v: Video) => !seenIds.current.has(v.id));
        fresh.forEach((v) => seenIds.current.add(v.id));
        if (fresh.length === 0) {
          setError("Aucune vidéo disponible. Réessaie ou change de région.");
          hasMore.current = false;
        }
        setVideos(fresh);
        setCurrent(0);
        hasMore.current = true;
      } catch (e: any) {
        setError(e.message || "Impossible de charger le flux TikTok");
        hasMore.current = false;
      } finally {
        setLoading(false);
      }
    }
  }, [region, customVideos]);

  // Charger au montage et au changement de région
  useEffect(() => {
    loadFeed(false);
  }, [loadFeed]);

  // Gestion du scroll snap
  const onScroll = useCallback((e: React.UIEvent<HTMLDivElement>) => {
    const el = e.currentTarget;
    const idx = Math.round(el.scrollTop / el.clientHeight);
    if (idx !== current) {
      setCurrent(idx);
      setPaused(false);
      setProgress(0);
    }

    // Marquer comme "scrolling" pour éviter les taps
    isScrolling.current = true;
    if (scrollTimeout.current) clearTimeout(scrollTimeout.current);
    scrollTimeout.current = setTimeout(() => { isScrolling.current = false; }, 150);

    // Charger plus si on est à 5 vidéos de la fin
    if (idx >= allVideos.length - 5 && hasMore.current && !loadingMore) {
      loadFeed(true);
    }
  }, [current, allVideos.length, loadingMore, loadFeed]);

  // Gérer la lecture/pause des vidéos
  useEffect(() => {
    allVideos.forEach((v, i) => {
      const el = videoRefs.current.get(v.id);
      if (!el) return;
      if (i === current && !paused) {
        el.play().catch(() => {});
      } else {
        el.pause();
      }
    });
  }, [current, paused, allVideos]);

  // Navigation clavier
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.target instanceof HTMLInputElement) return;
      if (e.code === "ArrowDown" || e.code === "ArrowRight") {
        e.preventDefault();
        setCurrent((c) => Math.min(c + 1, allVideos.length - 1));
      } else if (e.code === "ArrowUp" || e.code === "ArrowLeft") {
        e.preventDefault();
        setCurrent((c) => Math.max(c - 1, 0));
      } else if (e.code === "Space") {
        e.preventDefault();
        setPaused((p) => !p);
      } else if (e.key === "m" || e.key === "M") {
        setMuted((m) => !m);
      }
    };
    addEventListener("keydown", onKey);
    return () => removeEventListener("keydown", onKey);
  }, [allVideos.length]);

  // Snap scroll au changement d'index
  useEffect(() => {
    const el = containerRef.current;
    if (!el) return;
    const child = el.children[current] as HTMLElement;
    if (child) child.scrollIntoView({ behavior: "smooth", block: "start" });
  }, [current]);

  const toggleLike = useCallback((id: string) => {
    setLiked((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  }, []);

  // Double-tap pour aimer
  const onVideoTap = useCallback((e: React.MouseEvent | React.TouchEvent, video: Video) => {
    if (isScrolling.current) return;
    const now = Date.now();
    const last = lastTap.current;

    // Coordonnées du tap pour l'animation cœur
    let x = 0, y = 0;
    if ("touches" in e) {
      const t = e.touches[0] || (e as any).changedTouches?.[0];
      if (t) { x = t.clientX; y = t.clientY; }
    } else {
      x = (e as React.MouseEvent).clientX;
      y = (e as React.MouseEvent).clientY;
    }

    if (last && last.id === video.id && now - last.time < 350) {
      // Double-tap : liker
      if (!liked.has(video.id)) {
        setLiked((prev) => new Set(prev).add(video.id));
      }
      // Animation cœur
      setShowHeart({ id: video.id + now, x, y });
      setTimeout(() => setShowHeart(null), 800);
      // Vibration
      if (navigator.vibrate) navigator.vibrate(30);
      lastTap.current = null;
    } else {
      // Simple tap : vérifier la zone (gauche = précédent, droite = suivant, centre = pause)
      const el = containerRef.current;
      if (el) {
        const rect = el.getBoundingClientRect();
        const relX = x - rect.left;
        const third = rect.width / 3;
        if (relX < third) {
          // Gauche : précédent
          setCurrent((c) => Math.max(0, c - 1));
        } else if (relX > third * 2) {
          // Droite : suivant
          setCurrent((c) => Math.min(allVideos.length - 1, c + 1));
        } else {
          // Centre : pause/play
          setPaused((p) => !p);
        }
      }
      lastTap.current = { id: video.id, time: now };
    }
  }, [liked, allVideos.length]);

  const hideVideo = useCallback((video: Video) => {
    setHiddenVideos((prev) => new Set(prev).add(video.id));
    // Passer à la suivante
    setCurrent((c) => Math.min(c + 1, allVideos.length - 2));
  }, [allVideos.length]);

  const addVideo = useCallback(async () => {
    setAddError("");
    const input = urlInput.trim();
    if (!input) return;
    const id = extractVideoId(input);
    if (!id) {
      setAddError("URL TikTok invalide. Colle un lien comme : https://www.tiktok.com/@user/video/...");
      return;
    }
    if (seenIds.current.has(id)) {
      setAddError("Cette vidéo est déjà dans ton flux.");
      return;
    }
    setAddLoading(true);

    let author: string | undefined;
    let desc: string | undefined;
    let cover: string | undefined;
    try {
      const tiktokUrl = input.includes("tiktok.com") ? input : `https://www.tiktok.com/video/${id}`;
      const r = await fetch(`/api/tiktok/oembed?url=${encodeURIComponent(tiktokUrl)}`);
      if (r.ok) {
        const d = await r.json();
        author = d.author_name;
        desc = d.title;
        cover = d.thumbnail_url;
      }
    } catch {}

    const video: Video = {
      id,
      author,
      desc,
      cover,
      isCustom: true,
      addedBy: username,
    };
    seenIds.current.add(id);
    const next = [video, ...customVideos];
    setCustomVideos(next);
    saveCustom(next);
    setUrlInput("");
    setShowAdd(false);
    setCurrent(0);
    setAddLoading(false);
  }, [urlInput, customVideos, username, saveCustom]);

  const removeVideo = useCallback((idx: number) => {
    setCustomVideos((prev) => {
      const next = prev.filter((_, i) => i !== idx);
      saveCustom(next);
      return next;
    });
    setCurrent((c) => Math.max(0, c - 1));
  }, [saveCustom]);

  const shareVideo = useCallback(async (v: Video) => {
    const shareUrl = `https://www.tiktok.com/video/${v.id}`;
    try {
      if (navigator.share) {
        await navigator.share({ title: v.desc || "Vidéo TikTok", url: shareUrl });
      } else {
        await navigator.clipboard.writeText(shareUrl);
      }
    } catch {}
  }, []);

  // États de chargement et d'erreur
  if (loading && allVideos.length === 0) {
    return (
      <div className="tt-app">
        <div className="tt-loading-screen">
          <div className="tt-spinner" />
          <p>Chargement du flux TikTok...</p>
        </div>
      </div>
    );
  }

  if (error && allVideos.length === 0) {
    return (
      <div className="tt-app">
        <header className="tt-header">
          <Link href="/steamblox" className="tt-back">← TheCombinedWebs</Link>
          <div className="tt-title"><span className="tt-logo">🎵</span><b>TikTok</b></div>
          <button className="tt-add-btn" onClick={() => setShowAdd(!showAdd)}>＋ Ajouter</button>
        </header>
        {showAdd && (
          <div className="tt-add-panel">
            <h3>Ajouter une vidéo TikTok</h3>
            <p>Colle le lien d'une vidéo TikTok publique.</p>
            <div className="tt-add-row">
              <input className="tt-input" value={urlInput} onChange={(e) => setUrlInput(e.target.value)} onKeyDown={(e) => e.key === "Enter" && addVideo()} placeholder="https://www.tiktok.com/@user/video/..." autoFocus />
              <button className="tt-add-confirm" onClick={addVideo} disabled={addLoading}>{addLoading ? "..." : "Ajouter"}</button>
            </div>
            {addError && <small className="tt-error">{addError}</small>}
          </div>
        )}
        <div className="tt-error-screen">
          <span className="tt-error-icon">📡</span>
          <h3>Flux TikTok indisponible</h3>
          <p>{error}</p>
          <div className="tt-error-actions">
            <button className="tt-retry-btn" onClick={() => loadFeed(false)}>Réessayer</button>
            <button className="tt-retry-btn secondary" onClick={() => setShowAdd(true)}>Ajouter un lien</button>
          </div>
          <small className="tt-error-note">TikTok ne propose pas de flux public officiel sans compte. La source peut être temporairement indisponible.</small>
        </div>
      </div>
    );
  }

  const currentVideo = allVideos[current];

  return (
    <div className="tt-app">
      {/* En-tête */}
      <header className="tt-header">
        <Link href="/steamblox" className="tt-back">← TheCombinedWebs</Link>
        <div className="tt-title">
          <span className="tt-logo">🎵</span>
          <b>TikTok</b>
          <small className="tt-badge-live">● En direct</small>
        </div>
        <div className="tt-header-right">
          <button className="tt-icon-btn" onClick={() => setShowFavorites(!showFavorites)} title="Favoris">
            {showFavorites ? "📂" : "❤️"}
          </button>
          <button className="tt-region-btn" onClick={() => setShowRegions(!showRegions)} title="Région">
            {REGIONS.find((r) => r.code === region)?.flag || "🌍"} ▾
          </button>
          <button className="tt-add-btn" onClick={() => setShowAdd(!showAdd)}>＋</button>
        </div>
      </header>

      {/* Sélecteur de région */}
      {showRegions && (
        <div className="tt-region-panel">
          <h3>Choisir une région</h3>
          <div className="tt-region-grid">
            {REGIONS.map((r) => (
              <button
                key={r.code}
                className={`tt-region-item ${r.code === region ? "on" : ""}`}
                onClick={() => { setRegion(r.code); setShowRegions(false); }}
              >
                <span className="tt-region-flag">{r.flag}</span>
                <small>{r.label}</small>
              </button>
            ))}
          </div>
        </div>
      )}

      {/* Panneau d'ajout */}
      {showAdd && (
        <div className="tt-add-panel">
          <h3>Ajouter une vidéo TikTok</h3>
          <p>Colle le lien d'une vidéo TikTok publique. Aucun compte requis.</p>
          <div className="tt-add-row">
            <input className="tt-input" value={urlInput} onChange={(e) => setUrlInput(e.target.value)} onKeyDown={(e) => e.key === "Enter" && addVideo()} placeholder="https://www.tiktok.com/@user/video/..." autoFocus />
            <button className="tt-add-confirm" onClick={addVideo} disabled={addLoading}>{addLoading ? "..." : "Ajouter"}</button>
          </div>
          {addError && <small className="tt-error">{addError}</small>}
        </div>
      )}

      {/* Tiroir des favoris */}
      {showFavorites && (
        <div className="tt-fav-panel">
          <div className="tt-fav-head">
            <h3>❤️ Mes favoris ({favoriteVideos.length})</h3>
            <button className="tt-fav-close" onClick={() => setShowFavorites(false)}>✕</button>
          </div>
          {favoriteVideos.length === 0 ? (
            <p className="tt-fav-empty">Double-tap sur une vidéo pour l'ajouter à tes favoris.</p>
          ) : (
            <div className="tt-fav-grid">
              {favoriteVideos.map((v) => (
                <div key={v.id} className="tt-fav-item" onClick={() => { setShowFavorites(false); const idx = allVideos.findIndex((x) => x.id === v.id); if (idx >= 0) setCurrent(idx); }}>
                  {v.cover && <img src={v.cover} alt="" loading="lazy" />}
                  <div className="tt-fav-info">
                    <small>@{v.author}</small>
                    <span>{v.desc?.slice(0, 40)}</span>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* Flux vertical */}
      <div className="tt-feed" ref={containerRef} onScroll={onScroll}>
        {allVideos.map((v, i) => {
          const isActive = i === current;
          const isNear = Math.abs(i - current) <= 1;
          const isLiked = liked.has(v.id);
          return (
            <div key={v.id} className={`tt-item ${isActive ? "active" : ""} ${isNear ? "near" : ""}`}>
              {/* Lecteur vidéo natif ou fallback iframe */}
              <div className="tt-video-wrap" onClick={(e) => onVideoTap(e, v)}>
                {/* Poster (cover) affiché immédiatement */}
                {v.cover && (
                  <img
                    className={`tt-poster ${isActive && !paused ? "hidden" : ""}`}
                    src={v.cover}
                    alt=""
                    aria-hidden
                  />
                )}

                {/* Vidéo native si URL play disponible */}
                {v.play ? (
                  <video
                    ref={(el) => { if (el) videoRefs.current.set(v.id, el); else videoRefs.current.delete(v.id); }}
                    className="tt-video"
                    src={isActive || isNear ? v.play : undefined}
                    poster={v.cover}
                    playsInline
                    loop
                    muted={muted}
                    autoPlay={isActive}
                    preload={isNear ? "auto" : "none"}
                    onTimeUpdate={(e) => {
                      const el = e.currentTarget;
                      if (el.duration) setProgress((el.currentTime / el.duration) * 100);
                    }}
                    onPlay={() => setPaused(false)}
                    onPause={() => {}}
                  />
                ) : (
                  <iframe
                    src={isActive || isNear ? `https://www.tiktok.com/embed/v2/${v.id}` : undefined}
                    className="tt-iframe"
                    allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture; fullscreen"
                    allowFullScreen
                    title={v.desc || `TikTok ${v.id}`}
                    loading={isActive ? "eager" : "lazy"}
                    scrolling="no"
                  />
                )}

                {/* Animation cœur au double-tap */}
                {showHeart && showHeart.id === v.id + Date.now().toString().slice(-5) && (
                  <div className="tt-heart-burst" style={{ left: showHeart.x, top: showHeart.y }}>
                    ❤️
                  </div>
                )}

                {/* Indicateur de pause */}
                {isActive && paused && (
                  <div className="tt-pause-icon">⏸</div>
                )}

                {/* Squelette de chargement */}
                {isActive && !v.play && !v.cover && (
                  <div className="tt-skeleton" />
                )}
              </div>

              {/* Overlay gradient */}
              <div className="tt-overlay" />

              {/* Barre de progression */}
              {isActive && v.play && (
                <div className="tt-progress-bar">
                  <div className="tt-progress-fill" style={{ width: `${progress}%` }} />
                </div>
              )}

              {/* Boutons latéraux */}
              <div className="tt-actions">
                <button className={`tt-act-btn ${isLiked ? "liked" : ""}`} onClick={(e) => { e.stopPropagation(); toggleLike(v.id); }} title="J'aime">
                  <span className="tt-act-icon">{isLiked ? "❤️" : "🤍"}</span>
                  {v.diggCount && <small>{fmtCount(v.diggCount)}</small>}
                </button>
                <button className="tt-act-btn" onClick={(e) => { e.stopPropagation(); shareVideo(v); }} title="Partager">
                  <span className="tt-act-icon">📤</span>
                  {v.shareCount && <small>{fmtCount(v.shareCount)}</small>}
                </button>
                <button className="tt-act-btn" onClick={(e) => { e.stopPropagation(); hideVideo(v); }} title="Pas intéressé">
                  <span className="tt-act-icon">🙈</span>
                  <small>Passer</small>
                </button>
                <a className="tt-act-btn" href={`https://www.tiktok.com/video/${v.id}`} target="_blank" rel="noopener noreferrer" onClick={(e) => e.stopPropagation()} title="Ouvrir sur TikTok">
                  <span className="tt-act-icon">🔗</span>
                  <small>Ouvrir</small>
                </a>
                {v.isCustom && (
                  <button className="tt-act-btn danger" onClick={(e) => { e.stopPropagation(); removeVideo(i); }} title="Supprimer">
                    <span className="tt-act-icon">🗑️</span>
                    <small>Retirer</small>
                  </button>
                )}
              </div>

              {/* Contrôles en bas */}
              <div className="tt-bottom-controls">
                <button className="tt-ctrl-btn" onClick={(e) => { e.stopPropagation(); setMuted((m) => !m); }} title={muted ? "Activer le son" : "Couper le son"}>
                  {muted ? "🔇" : "🔊"}
                </button>
                <button className="tt-ctrl-btn" onClick={(e) => { e.stopPropagation(); setPaused((p) => !p); }} title={paused ? "Lecture" : "Pause"}>
                  {paused ? "▶" : "⏸"}
                </button>
              </div>

              {/* Info en bas */}
              <div className="tt-info">
                {v.author && (
                  <div className="tt-author-row">
                    <b className="tt-author">@{v.author}</b>
                    {v.nickname && v.nickname !== v.author && <small className="tt-nickname">{v.nickname}</small>}
                  </div>
                )}
                <p className="tt-desc">{v.desc || "Vidéo TikTok"}</p>
                <div className="tt-meta">
                  {v.playCount && <span>▶ {fmtCount(v.playCount)}</span>}
                  {v.createTime && <span>· {timeAgo(v.createTime)}</span>}
                  {v.musicTitle && <span className="tt-music">🎵 {v.musicTitle}</span>}
                </div>
                {v.isCustom && v.addedBy === username && <small className="tt-added-by">Ajouté par toi</small>}
              </div>

              {/* Indicateur de navigation */}
              {i < allVideos.length - 1 ? (
                <div className="tt-nav-hint"><span>↓ Suivant</span></div>
              ) : loadingMore ? (
                <div className="tt-nav-hint"><div className="tt-spinner small" /><span>Chargement...</span></div>
              ) : hasMore.current ? (
                <div className="tt-nav-hint"><span>↓ Charger plus</span></div>
              ) : null}
            </div>
          );
        })}
      </div>
    </div>
  );
}
