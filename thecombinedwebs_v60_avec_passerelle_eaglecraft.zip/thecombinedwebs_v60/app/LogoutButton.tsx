"use client";
import { useState } from "react";

export default function LogoutButton({ className = "button secondary" }: { className?: string }) {
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  async function logout() {
    if (busy) return;
    setBusy(true); setError("");
    try {
      const response = await fetch("/api/auth/logout", { method: "POST", credentials: "same-origin", cache: "no-store" });
      if (!response.ok) throw new Error("logout");
      // Full navigation drops in-memory authentication without deleting saved games.
      window.location.replace("/login");
    } catch {
      setError("Déconnexion impossible pour le moment. Réessaie.");
      setBusy(false);
    }
  }
  return <span><button type="button" className={className} disabled={busy} onClick={logout}>{busy ? "Déconnexion…" : "Se déconnecter"}</button>{error && <span role="alert" className="status error">{error}</span>}</span>;
}
