'use client';
import {useEffect,useState} from 'react';
export default function GameTools(){
 const [fps,setFps]=useState(0),[cinema,setCinema]=useState(false),[full,setFull]=useState(false);
 useEffect(()=>{let frames=0,last=performance.now(),id=0;const loop=(now:number)=>{frames++;if(now-last>=500){setFps(Math.round(frames*1000/(now-last)));frames=0;last=now}id=requestAnimationFrame(loop)};id=requestAnimationFrame(loop);return()=>cancelAnimationFrame(id)},[]);
 function toggleCinema(){const n=!cinema;setCinema(n);document.body.classList.toggle('game-cinema',n)}
 async function fullscreen(){const el=document.querySelector('.game-shell') as HTMLElement|null;if(!el)return;if(!document.fullscreenElement)await el.requestFullscreen?.();else await document.exitFullscreen?.();setFull(!!document.fullscreenElement)}
 return <div className="game-tools"><span className="fps-pill">FPS {fps}</span><button onClick={toggleCinema}>{cinema?'UI':'🎬'}</button><button onClick={fullscreen}>{full?'⤢':'⛶'}</button></div>
}
