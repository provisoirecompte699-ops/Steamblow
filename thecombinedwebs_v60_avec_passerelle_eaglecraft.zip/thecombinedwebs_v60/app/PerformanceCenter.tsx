"use client";
import {useEffect,useState} from "react";

export default function PerformanceCenter(){
 const [mode,setMode]=useState<"boost"|"balanced">("boost");
 const [fps,setFps]=useState(0);
 useEffect(()=>{
  setMode((localStorage.getItem("steamblox:performance") as any)||"boost");
  let frames=0,last=performance.now(),raf=0;
  const tick=(now:number)=>{frames++;if(now-last>=1000){setFps(Math.round(frames*1000/(now-last)));frames=0;last=now}raf=requestAnimationFrame(tick)};
  raf=requestAnimationFrame(tick);return()=>cancelAnimationFrame(raf)
 },[]);
 const apply=(v:"boost"|"balanced")=>{setMode(v);localStorage.setItem("steamblox:performance",v);window.dispatchEvent(new CustomEvent("steamblox:performance",{detail:v}))};
 return <section className="card performance-center"><div><div className="tag accent">PERFORMANCE</div><h2>Mode 100 FPS</h2><p className="muted">TheCombinedWebs vise 100 FPS quand l’écran et le matériel le permettent. Un écran 60 Hz ne va pas soudainement devenir 100 Hz parce qu’on lui parle gentiment.</p></div><div className="perf-grid"><div className="perf-stat"><span>FPS interface</span><strong>{fps||"—"}</strong></div><div className="perf-stat"><span>Mode</span><strong>{mode==="boost"?"Boost":"Équilibré"}</strong></div><div className="perf-actions"><button className={mode==="boost"?"button":"button secondary"} onClick={()=>apply("boost")}>⚡ Boost</button><button className={mode==="balanced"?"button":"button secondary"} onClick={()=>apply("balanced")}>⚖ Équilibré</button></div></div></section>
}
