import { currentUser } from "@/lib/auth";
import { listPortals } from "@/lib/portals";
import { redirect, notFound } from "next/navigation";
import Link from "next/link";
import ProxyFrame from "@/app/proxy/ProxyFrame";
export const dynamic = "force-dynamic";
export default async function Play({ searchParams }: { searchParams: Promise<{ portal?: string; game?: string }> }) {
  const q = await searchParams;
  if (!(await currentUser())) redirect("/login?next=/portails");
  const p = (await listPortals()).find(p => p.id === q.portal && p.enabled);
  if (!p) notFound();
  const g = p.games.find(g => g.id === q.game);
  return <main><div style={{ padding: 16, display: "flex", justifyContent: "space-between" }}><h1 style={{ fontSize: 24 }}>{g?.title || p.name}</h1><Link href="/portails">Retour aux portails</Link></div><ProxyFrame site={p.id} portal game={g?.id} label={g?.title || p.name} fallbackUrl={g?.url || p.url} /></main>;
}
