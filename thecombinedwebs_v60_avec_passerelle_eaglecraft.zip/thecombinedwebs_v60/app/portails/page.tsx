import FeaturePage from "../FeaturePages";
export const metadata={title:"Portails · TheCombinedWebs"};
export default function Page(){return <FeaturePage mode="portails"/>;}
