"use client";
import { useEffect, useState } from "react";
import Link from "next/link";

type Rank = { rank: number; name: string; score: number; game: string };

const GAMES = [
  { id: "meteor-mayhem", name: "Meteor Mayhem" },
  { id: "crystal-rush", name: "Crystal Rush" },
  { id: "cyber-siege", name: "Cyber Siege" },
  { id: "block-brawl", name: "Block Brawl" },
  { id: "neon-arena", name: "Neon Arena" },
];

export default function HallOfFame() {
  const [ranks, setRanks] = useState<Rank[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Try fetching from leaderboard API, fall back to localStorage
    Promise.all(
      GAMES.map(g =>
        fetch(`/api/leaderboard?game=${g.id}&scope=all`).then(r => r.ok ? r.json() : null).then(d => {
          if (d?.board?.[0]) return { rank: 1, name: d.board[0].name || d.board[0].u || "?", score: d.board[0].score || 0, game: g.name };
          return null;
        }).catch(() => null)
      )
    ).then(results => {
      const valid = results.filter(Boolean) as Rank[];
      if (valid.length) setRanks(valid);
      else {
        // Fallback: localStorage records
        const local = GAMES.map(g => {
          const s = Number(localStorage.getItem(`steamblox:arcade:${g.id.includes("-") ? g.id.split("-")[0] : g.id}:best`) || 0);
          return s > 0 ? { rank: 1, name: "Toi", score: s, game: g.name } : null;
        }).filter(Boolean) as Rank[];
        setRanks(local);
      }
      setLoading(false);
    }).catch(() => setLoading(false));
  }, []);

  return <div className="card">
    <div className="section-head"><div><div className="eyebrow">RECORDS</div><h3>Hall of Fame</h3></div><small>Top 1 par jeu</small></div>
    {loading ? <p className="muted">Chargement des records…</p> : <div className="ui-hof-grid">
      {ranks.map((r, i) => <div key={i} className={`ui-hof-card ${i === 0 ? "gold" : ""}`}>
        <div className="ui-hof-rank">#{r.rank}</div>
        <h4>{r.name}</h4>
        <small>{r.game}</small>
        <b style={{ color: "#ffd43b" }}>{r.score.toLocaleString()} pts</b>
      </div>)}
      {!ranks.length && <p className="muted">Joue aux jeux arcade pour voir les records ici.</p>}
    </div>}
    <Link href="/classements" className="button secondary" style={{ marginTop: 10 }}>Voir tous les classements →</Link>
  </div>;
}
