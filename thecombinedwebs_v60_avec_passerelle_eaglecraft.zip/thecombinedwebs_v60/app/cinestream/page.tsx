import type { Metadata } from "next";
import CineShell from "./CineShell";

export const metadata: Metadata = { title: "CinéStream VF · Écosystème TheCombinedWebs" };

// CinéStream fait partie de l'écosystème TheCombinedWebs : même domaine, même cookie de session.
// La page affiche son propre écran de connexion qui accepte les comptes TheCombinedWebs.
export default function CineStreamPage() {
  return <CineShell />;
}
