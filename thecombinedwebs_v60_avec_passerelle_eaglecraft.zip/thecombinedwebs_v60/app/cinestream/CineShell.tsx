"use client";
import { useCallback, useEffect, useRef, useState } from "react";
import { VoiceEngine, type VoiceSnapshot } from "@/app/discord/voice";
import "./party.css";

type Film = { key: string; title: string; tmdbId?: number; type?: string; season?: number; episode?: number; poster?: string };
type Party = { id: string; host: string; members: Record<string, { u: string; at: number; ready?: boolean }>; film: Film | null; filmAt: number; countdown: number | null; chat: { id: string; u: string; text: string; at: number }[] };
const low = (s: string) => s.toLowerCase();
const QUICK_REACTIONS = ["❤️", "😂", "😱", "🔥", "👏", "😭", "🤯", "😍"];
const QUICK_MSGS = ["C'est génial !", "Pause pipi ?", "Quel film !", "On reprend ?", "Trop bien !", "Attendez-moi"];
const QUIZ_BANK = [
  { q: "Quel film parle d'un voyage dans l'espace pour sauver l'humanité ?", a: ["Interstellar","Titanic","Shrek","Cars"], correct: 0 },
  { q: "Quel personnage a un scarabée doré comme symbole ?", a: ["Spider-Man","Batman","Superman","Iron Man"], correct: 1 },
  { q: "Dans quel film trouve-t-on le personnage de Forrest Gump ?", a: ["Forrest Gump","Pulp Fiction","Fight Club","Inception"], correct: 0 },
  { q: "Qui a réalisé 'Inception' ?", a: ["Spielberg","Nolan","Scorsese","Tarantino"], correct: 1 },
  { q: "Quel film d'animation parle d'un poisson-clown perdu ?", a: ["Shrek","Toy Story","Nemo","Ratatouille"], correct: 2 },
  { q: "Dans 'Matrix', quelle pilule prend Neo ?", a: ["La bleue","La rouge","La verte","La jaune"], correct: 1 },
  { q: "Qui joue Jack dans 'Titanic' ?", a: ["Brad Pitt","Leonardo DiCaprio","Tom Cruise","Matt Damon"], correct: 1 },
  { q: "Quel film Marvel a un héros avec un marteau ?", a: ["Iron Man","Thor","Hulk","Captain America"], correct: 1 },
  { q: "Dans quel film trouve-t-on le personnage de Joker ?", a: ["Batman","Superman","Flash","Aquaman"], correct: 0 },
  { q: "Quel film parle d'un palefrenier qui devient roi ?", a: ["Gladiator","Roi Lion","Shrek","Le Hobbit"], correct: 1 },
];
let reactId = 0;

/** Soirée ciné : regarder le même film en même temps que ses amis, avec chat et vocal. */
export default function CineShell() {
  const frame = useRef<HTMLIFrameElement>(null);
  const [open, setOpen] = useState(false);
  const [me, setMe] = useState<string | null>(null);
  const [party, setParty] = useState<Party | null>(null);
  const [code, setCode] = useState("");
  const [err, setErr] = useState("");
  const [draft, setDraft] = useState("");
  const [count, setCount] = useState<number | null>(null);
  const [voice, setVoice] = useState<VoiceSnapshot | null>(null);
  const [floatingReactions, setFloatingReactions] = useState<{ id: number; emoji: string; x: number }[]>([]);
  const [showQuickMsgs, setShowQuickMsgs] = useState(false);
  const [ready, setReady] = useState(false);
  const [quiz, setQuiz] = useState<{ q: string; a: string[]; correct: number; } | null>(null);
  const [quizResult, setQuizResult] = useState<string>("");
  useEffect(() => { if (party && me) { setReady(!!party.members[low(me)]?.ready); } }, [party, me]);
  const offset = useRef(0);
  const played = useRef<number | null>(null);
  const partyRef = useRef<Party | null>(null);
  const engine = useRef<VoiceEngine | null>(null);
  const chatEnd = useRef<HTMLDivElement>(null);
  partyRef.current = party;

  const call = useCallback(async (body: Record<string, unknown>) => {
    try {
      const r = await fetch("/api/party", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify(body) });
      const d = await r.json();
      if (d.now) offset.current = d.now - Date.now();
      if (d.error) { setErr(d.error); return null; }
      setErr(""); setParty(d.party); return d.party as Party | null;
    } catch { setErr("Connexion perdue"); return null; }
  }, []);

  useEffect(() => {
    fetch("/api/session", { cache: "no-store" }).then((r) => r.json()).then((d) => { if (d.authenticated) { setMe(d.username); engine.current = new VoiceEngine(d.username); engine.current.subscribe(setVoice); } }).catch(() => {});
    const q = new URLSearchParams(location.search).get("party");
    if (q) { setOpen(true); setCode(q.toUpperCase()); }
    return () => { engine.current?.leave(); };
  }, []);
  useEffect(() => { if (me && code && code.length === 6 && !party && new URLSearchParams(location.search).get("party") === code) call({ action: "beat", id: code }); }, [me, code, party, call]);

  // Battement de cœur de la soirée
  useEffect(() => {
    if (!party?.id) return;
    const id = party.id;
    const t = setInterval(() => call({ action: "beat", id }), 2000);
    const bye = () => { navigator.sendBeacon?.("/api/party", new Blob([JSON.stringify({ action: "leave", id })], { type: "application/json" })); };
    addEventListener("pagehide", bye);
    return () => { clearInterval(t); removeEventListener("pagehide", bye); };
  }, [party?.id, call]);

  // Compte à rebours partagé, puis ouverture du film chez tout le monde
  useEffect(() => {
    if (!party?.countdown || !party.film) { setCount(null); return; }
    const target = party.countdown, film = party.film;
    const tick = () => {
      const left = Math.ceil((target - (Date.now() + offset.current)) / 1000);
      if (left <= 0) { setCount(null); if (played.current !== target) { played.current = target; frame.current?.contentWindow?.postMessage({ type: "cs-play", film }, location.origin); } return true; }
      setCount(left); return false;
    };
    if (tick()) return;
    const t = setInterval(() => { if (tick()) clearInterval(t); }, 200);
    return () => clearInterval(t);
  }, [party?.countdown, party?.film]);

  // Messages venant de CinéStream (titre ouvert, bouton « Regarder avec des amis »)
  useEffect(() => {
    const h = (e: MessageEvent) => {
      if (e.origin !== location.origin || !e.data) return;
      const p = partyRef.current;
      if (e.data.type === "cs-party-open") { setOpen(true); if (p && me && low(p.host) === low(me)) call({ action: "film", id: p.id, film: e.data.film }); }
      if (e.data.type === "cs-open" && p && me && low(p.host) === low(me) && (!p.film || p.film.key !== e.data.film.key || p.film.episode !== e.data.film.episode || p.film.season !== e.data.film.season) && played.current !== p.countdown) call({ action: "film", id: p.id, film: e.data.film });
    };
    addEventListener("message", h);
    return () => removeEventListener("message", h);
  }, [me, call]);
  useEffect(() => { chatEnd.current?.scrollIntoView({ block: "end" }); }, [party?.chat.length]);

  const isHost = !!party && !!me && low(party.host) === low(me);
  const room = party ? `party~${party.id}` : "";
  const inVoice = voice?.room === room && !!room;
  const leave = async () => { if (inVoice) await engine.current?.leave(); if (party) await call({ action: "leave", id: party.id }); setParty(null); history.replaceState(null, "", "/cinestream"); };
  const members = party ? Object.values(party.members) : [];
  const readyCount = members.filter(m => m.ready || low(m.u) === low(party?.host || "")).length;
  const allReady = party && members.length >= 2 && readyCount === members.length;

  const sendReaction = (emoji: string) => {
    const id = ++reactId;
    setFloatingReactions(r => [...r, { id, emoji, x: 20 + Math.random() * 60 }]);
    setTimeout(() => setFloatingReactions(r => r.filter(f => f.id !== id)), 3000);
    if (party) call({ action: "chat", id: party.id, text: emoji });
  };
  const sendQuickMsg = (msg: string) => { if (party) { call({ action: "chat", id: party.id, text: msg }); setShowQuickMsgs(false); } };
  const toggleReady = () => { const next = !ready; setReady(next); if (party) call({ action: "beat", id: party.id, ready: next } as any); };
  // v55 : quiz cinéma
  const startQuiz = () => { const i = Math.floor(Math.random() * QUIZ_BANK.length); setQuiz(QUIZ_BANK[i]); setQuizResult(""); };
  const answerQuiz = (idx: number) => { if (!quiz || quizResult) return; const correct = idx === quiz.correct; setQuizResult(correct ? "Bravo ! +10 Bobux virtuels 🎉" : `Raté ! La bonne réponse était : ${quiz.a[quiz.correct]}`); if (correct && party) call({ action: "chat", id: party.id, text: "Quiz : bonne réponse ! 🎉" }); setTimeout(() => setQuiz(null), 3000); };

  return <main className="vortex-shell" style={{ minHeight: "100dvh", background: "#06060a", color: "#fff", position: "relative" }}>
    <iframe ref={frame} title="CinéStream VF" src="/cinestream/index.html" style={{ width: "100%", height: "100dvh", minHeight: "100dvh", border: 0, display: "block" }}
      allow="autoplay; encrypted-media; picture-in-picture; fullscreen" referrerPolicy="strict-origin-when-cross-origin" loading="eager" allowFullScreen />
    {count != null && <div className="cp-count" aria-live="assertive"><span>{count}</span><small>{party?.film?.title}</small></div>}
    {floatingReactions.length > 0 && <div className="cp-reactions" aria-hidden="true">{floatingReactions.map(r => <span key={r.id} className="cp-float-emoji" style={{ left: `${r.x}%` }}>{r.emoji}</span>)}</div>}
    {party && <div className="cp-reaction-bar" aria-label="Réactions">{QUICK_REACTIONS.map(e => <button key={e} className="cp-react-btn" onClick={() => sendReaction(e)} aria-label={`Réagir ${e}`}>{e}</button>)}<button className="cp-react-btn cp-quick-toggle" onClick={() => setShowQuickMsgs(!showQuickMsgs)}>💬</button></div>}
    {showQuickMsgs && party && <div className="cp-quick-msgs">{QUICK_MSGS.map(m => <button key={m} className="cp-quick-msg" onClick={() => sendQuickMsg(m)}>{m}</button>)}</div>}
    {quiz && <div className="cp-quiz-overlay" onClick={(e) => { if (e.target === e.currentTarget) setQuiz(null); }}><div className="cp-quiz-card"><h3>🎯 Quiz Ciné</h3><p>{quiz.q}</p><div className="cp-quiz-answers">{quiz.a.map((a, i) => <button key={i} className="cp-b" onClick={() => answerQuiz(i)} disabled={!!quizResult}>{a}</button>)}</div>{quizResult && <p className="cp-quiz-result">{quizResult}</p>}</div></div>}
    {me && <button className={`cp-fab${party ? " live" : ""}`} onClick={() => setOpen(!open)} aria-expanded={open}>🍿 {party ? `Soirée ${party.id} · ${members.length}` : "Soirée ciné"}</button>}
    {open && me && <aside className="cp-panel" aria-label="Soirée ciné">
      <header><b>Soirée ciné</b><button onClick={() => setOpen(false)} aria-label="Fermer">✕</button></header>
      {err && <p className="cp-err">{err}</p>}
      {!party ? <div className="cp-body">
        <p className="cp-muted">Regarde le même film en même temps que tes amis, avec un chat et un salon vocal. Chacun doit avoir débloqué le film.</p>
        <button className="cp-b pri" onClick={async () => { const p = await call({ action: "create" }); if (p) history.replaceState(null, "", `/cinestream?party=${p.id}`); }}>Créer une soirée</button>
        <div className="cp-or">ou</div>
        <div className="cp-line"><input value={code} maxLength={6} onChange={(e) => setCode(e.target.value.toUpperCase())} placeholder="CODE" aria-label="Code de la soirée" /><button className="cp-b" onClick={async () => { const p = await call({ action: "beat", id: code }); if (p) history.replaceState(null, "", `/cinestream?party=${p.id}`); }}>Rejoindre</button></div>
      </div> : <div className="cp-body">
        <div className="cp-code"><span>Code</span><b>{party.id}</b><button className="cp-b sm" onClick={() => { navigator.clipboard?.writeText(`${location.origin}/cinestream?party=${party.id}`); setErr(""); }}>Copier le lien</button></div>
        <div className="cp-members">{members.map((m) => <span key={m.u} className={voice?.speaking[low(m.u)] ? "talk" : ""}>{m.u}{low(m.u) === low(party.host) ? " 👑" : ""}{m.ready ? " ✓" : ""}</span>)}</div>
        {party.film && <div className="cp-ready-bar"><span className="cp-ready-count">{readyCount}/{members.length} prêts</span>{!isHost && <button className={`cp-b sm${ready ? " ok" : ""}`} onClick={toggleReady}>{ready ? "Prêt ✓" : "Je suis prêt"}</button>}<button className="cp-b sm" onClick={startQuiz}>🎯 Quiz</button></div>}
        <div className="cp-film">{party.film ? <><b>{party.film.title}{party.film.type === "tv" ? ` · S${party.film.season}E${party.film.episode}` : ""}</b><span className="cp-muted">{isHost ? "Tout le monde est prêt ? Lance le compte à rebours." : "L’hôte lancera la lecture pour tout le monde."}</span></>
          : <span className="cp-muted">{isHost ? "Ouvre un film dans CinéStream : il sera proposé à tout le monde." : "En attente du choix de l’hôte…"}</span>}</div>
        {isHost && party.film && <button className="cp-b pri" onClick={() => call({ action: "countdown", id: party.id })}>{allReady ? "▶ Lancer pour tous (5 s)" : "▶ Lancer maintenant"}</button>}
        {!isHost && party.film && <button className="cp-b" onClick={() => frame.current?.contentWindow?.postMessage({ type: "cs-play", film: party.film }, location.origin)}>Ouvrir le film maintenant</button>}
        <p className="cp-note">Les lecteurs externes ne peuvent pas être pilotés : le départ est synchronisé par le compte à rebours. Mettez pause à l’oral si besoin.</p>
        <div className="cp-line">{inVoice ? <><button className={`cp-b sm${voice?.muted ? " off" : ""}`} onClick={() => engine.current?.setMuted(!voice?.muted)}>{voice?.muted ? "Micro coupé" : "🎙️ Micro"}</button><button className="cp-b sm danger" onClick={() => engine.current?.leave()}>Quitter le vocal</button></>
          : <button className="cp-b sm ok" onClick={() => engine.current?.join(room)} disabled={!!voice?.joining}>🎧 Rejoindre le vocal</button>}</div>
        {voice?.error && <p className="cp-err">{voice.error}</p>}
        <div className="cp-chat">{party.chat.map((m) => <div key={m.id}><b>{m.u}</b> {m.text}</div>)}<div ref={chatEnd} /></div>
        <form className="cp-line" onSubmit={(e) => { e.preventDefault(); if (!draft.trim()) return; call({ action: "chat", id: party.id, text: draft }); setDraft(""); }}><input value={draft} maxLength={300} onChange={(e) => setDraft(e.target.value)} placeholder="Message à la soirée" aria-label="Message" /><button className="cp-b">Envoyer</button></form>
        <button className="cp-b ghost" onClick={leave}>Quitter la soirée</button>
      </div>}
    </aside>}
  </main>;
}
