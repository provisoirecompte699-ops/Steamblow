"use client";
import { useCallback, useEffect, useState } from "react";
import { playJoinSound } from "@/app/cosmetics";

type Cos = { id: string; type: "border" | "name" | "sound"; name: string; price: number; pass?: boolean; desc: string };
type Rw = { kind: "bobux"; amount: number } | { kind: "cosmetic"; id: string } | { kind: "xpboost"; amount: number };
type D = { level: { level: number; into: number; need: number; total: number }; season: { id: string; name: string; xp: number; tier: number; into: number; claimed: number[]; endsAt: number }; tiers: { t: number; reward: Rw }[]; xpPerTier: number;
  cosmetics: Cos[]; owned: string[]; equipped: { border?: string; name?: string; sound?: string }; bobux: number; badges: { id: string; label: string; icon: string }[] };
const THEMES = [
  { id: "default", name: "Sombre (par défaut)", bg: "linear-gradient(120deg,#0b0d14,#24265a)" },
  { id: "neon", name: "Néon", bg: "linear-gradient(120deg,#12002b,#00f0ff)" },
  { id: "light", name: "Minimal clair", bg: "linear-gradient(120deg,#f5f6fa,#c9cede)" },
  { id: "retro", name: "Rétro pixel", bg: "repeating-linear-gradient(90deg,#2b2d42 0 8px,#8d99ae 8px 16px)" },
];

export default function Client({ me }: { me: string }) {
  const [d, setD] = useState<D | null>(null);
  const [msg, setMsg] = useState<{ t: string; err?: boolean } | null>(null);
  const [theme, setTheme] = useState("default");
  const [status, setStatus] = useState("");
  const load = useCallback(async () => setD(await (await fetch("/api/progression")).json()), []);
  useEffect(() => { load(); setTheme(localStorage.getItem("steamblox:theme") || "default"); }, [load]);
  const act = async (body: Record<string, unknown>, ok: string) => {
    setMsg(null); const r = await (await fetch("/api/progression", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify(body) })).json();
    if (r.error) setMsg({ t: r.error, err: true }); else { setD(r); setMsg({ t: ok }); }
  };
  const pickTheme = (t: string) => { setTheme(t); localStorage.setItem("steamblox:theme", t); document.documentElement.dataset.sbtheme = t; window.dispatchEvent(new Event("sb-theme")); fetch("/api/profile", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ theme: t }) }); };
  const saveStatus = async () => { const r = await (await fetch("/api/profile", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ status }) })).json(); setMsg(r.error ? { t: r.error, err: true } : { t: "Statut enregistré" }); };
  if (!d) return <div className="hub-empty">Chargement…</div>;
  const cosName = (id: string) => d.cosmetics.find((c) => c.id === id)?.name || id;
  const rwLabel = (r: Rw) => r.kind === "bobux" ? `${r.amount} Bobux` : r.kind === "xpboost" ? `+${r.amount} XP` : cosName(r.id);
  const rwIcon = (r: Rw) => r.kind === "bobux" ? "🪙" : r.kind === "xpboost" ? "✨" : r.id.startsWith("border") ? "🖼️" : r.id.startsWith("name") ? "🔤" : "🔊";
  const days = Math.max(0, Math.ceil((d.season.endsAt - Date.now()) / 86400000));
  const Preview = ({ c }: { c: Cos }) => c.type === "border" ? <span className={`cos-${c.id}`} style={{ width: 42, height: 42, borderRadius: "50%", background: "#8b7cff", display: "grid", placeItems: "center", fontWeight: 900 }}>{me[0]?.toUpperCase()}</span>
    : c.type === "name" ? <b className={`cos-${c.id}`} style={{ fontSize: 18 }}>{me}</b> : <button className="hub-btn sm" onClick={() => playJoinSound(c.id)}>▶ Écouter</button>;
  return <>
    <div className="hub-head"><div><span className="hub-kick">Progression</span><h1>Passe & boutique</h1><p>Gagne de l’XP en jouant, en discutant, en regardant des films et en notant. Chaque niveau rapporte 20 Bobux. Le passe de saison se renouvelle chaque mois.</p></div><span className="hub-pill acc">🪙 {d.bobux.toLocaleString("fr-FR")} Bobux</span></div>
    {msg && <p className={`hub-msg ${msg.err ? "err" : ""}`}>{msg.t}</p>}
    <div className="hub-grid" style={{ marginBottom: 16 }}>
      <div className="hub-card lvl"><div className="lvl-badge">{d.level.level}</div><div style={{ flex: 1 }}><b>Niveau {d.level.level}</b><div className="hub-muted" style={{ fontSize: 13, margin: "4px 0 8px" }}>{d.level.into} / {d.level.need} XP · total {d.level.total.toLocaleString("fr-FR")} XP</div><div className="bar"><i style={{ width: `${(d.level.into / d.level.need) * 100}%` }} /></div></div></div>
      <div className="hub-card"><b>Mon statut</b><div className="hub-row" style={{ marginTop: 8 }}><input className="hub-input" style={{ flex: 1 }} placeholder="En train de jouer à Neon Tag…" maxLength={60} value={status} onChange={(e) => setStatus(e.target.value)} /><button className="hub-btn" onClick={saveStatus}>OK</button></div>
        <div className="badges" style={{ marginTop: 12 }}>{d.badges.length ? d.badges.map((b) => <span key={b.id} className="hub-pill">{b.icon} {b.label}</span>) : <span className="hub-muted" style={{ fontSize: 13 }}>Pas encore de badge : gagne un tournoi, finis 1er de la semaine ou crée des cartes.</span>}</div></div>
    </div>
    <div className="hub-card" style={{ marginBottom: 16 }}>
      <div className="hub-row" style={{ justifyContent: "space-between" }}><div><h2 style={{ margin: 0 }}>Passe {d.season.name}</h2><span className="hub-muted">Palier {d.season.tier}/30 · {d.season.into}/{d.xpPerTier} XP vers le suivant · fin dans {days} jour{days > 1 ? "s" : ""}</span></div><span className="hub-pill ok">Gratuit pour tous</span></div>
      <div className="bar" style={{ margin: "12px 0 14px" }}><i style={{ width: `${(Math.min(30, d.season.tier) / 30) * 100}%` }} /></div>
      <div className="pass">{d.tiers.map(({ t, reward }) => { const got = d.season.claimed.includes(t), can = t <= d.season.tier && !got;
        return <div key={t} className={`tier ${got ? "got" : ""} ${t > d.season.tier ? "lock" : ""}`}><b>Palier {t}</b><span className="ic">{rwIcon(reward)}</span><small>{rwLabel(reward)}</small>
          {got ? <span className="hub-pill ok">Récupéré</span> : can ? <button className="hub-btn sm ok" onClick={() => act({ action: "claim", tier: t }, `Palier ${t} récupéré`)}>Récupérer</button> : <span className="hub-muted" style={{ fontSize: 12 }}>🔒</span>}</div>; })}</div>
    </div>
    <div className="hub-card" style={{ marginBottom: 16 }}>
      <h2>Boutique de cosmétiques</h2><p className="hub-muted" style={{ marginTop: -4 }}>Les bordures et effets de pseudo s’affichent dans Discord et sur ton profil. Les sons jouent quand tu rejoins un salon vocal.</p>
      {(["border", "name", "sound"] as const).map((type) => <div key={type} style={{ marginBottom: 14 }}><h3 style={{ fontSize: 15, color: "#a9afbd" }}>{type === "border" ? "Bordures d’avatar" : type === "name" ? "Effets de pseudo" : "Sons d’arrivée en vocal"}</h3>
        <div className="shop">{d.cosmetics.filter((c) => c.type === type).map((c) => { const own = d.owned.includes(c.id), eq = d.equipped[type] === c.id;
          return <div key={c.id} className={`item ${eq ? "eq" : ""}`}><div className="prev"><Preview c={c} /></div><b>{c.name}</b><span className="hub-muted" style={{ fontSize: 13 }}>{c.desc}</span>
            {eq ? <button className="hub-btn sm" onClick={() => act({ action: "equip", type, id: null }, "Retiré")}>Retirer</button> : own ? <button className="hub-btn sm acc" onClick={() => act({ action: "equip", type, id: c.id }, "Équipé")}>Équiper</button>
              : c.pass ? <span className="hub-pill">Passe de saison</span> : <button className="hub-btn sm pri" disabled={d.bobux < c.price} onClick={() => act({ action: "buy", id: c.id }, `${c.name} acheté`)}>🪙 {c.price}</button>}</div>; })}</div></div>)}
    </div>
    <div className="hub-card"><h2>Thème de l’interface</h2><div className="theme-pick">{THEMES.map((t) => <button key={t.id} className={theme === t.id ? "on" : ""} onClick={() => pickTheme(t.id)}><i style={{ background: t.bg }} />{t.name}</button>)}</div></div>
  </>;
}
