import { redirect } from "next/navigation";
import { currentUser } from "@/lib/auth";
import HubNav from "@/app/HubNav";
import Client from "./Client";
import "@/app/hub.css";

export const metadata = { title: "Passe de saison · TheCombinedWebs" };
export const dynamic = "force-dynamic";

export default async function Page() {
  const u = await currentUser();
  if (!u) { redirect("/login?next=/passe"); return null; }
  return <div className="hub"><HubNav username={u.username} /><main className="hub-main"><Client me={u.username} /></main></div>;
}
