"use client";

import { useEffect, useState } from "react";

const GAME_ROUTES = new Set([
  "/games/neon-drift-3d",
  "/games/turbo-kart",
]);

const KEY_GROUPS: Record<string, string[]> = {
  left: ["ArrowLeft", "a", "q"],
  right: ["ArrowRight", "d"],
  up: ["ArrowUp", "w", "z", " "],
  down: ["ArrowDown", "s"],
  action: ["e", "f"],
  boost: ["Shift"],
};

function emit(type: "keydown" | "keyup", keys: string[]) {
  for (const key of keys) {
    window.dispatchEvent(new KeyboardEvent(type, { key, bubbles: true }));
  }
}

export default function MobileGameControls() {
  const [visible, setVisible] = useState(false);
  const [isGame, setIsGame] = useState(false);

  useEffect(() => {
    setIsGame(GAME_ROUTES.has(window.location.pathname));
    if (!GAME_ROUTES.has(window.location.pathname)) return;
    const update = () => setVisible(window.matchMedia("(pointer: coarse)").matches || window.innerWidth < 800);
    update();
    window.addEventListener("resize", update);
    return () => window.removeEventListener("resize", update);
  }, [isGame]);

  if (!isGame || !visible) return null;

  const hold = (group: string) => ({
    onPointerDown: (event: React.PointerEvent<HTMLButtonElement>) => {
      event.preventDefault();
      event.currentTarget.setPointerCapture?.(event.pointerId);
      emit("keydown", KEY_GROUPS[group]);
    },
    onPointerUp: (event: React.PointerEvent<HTMLButtonElement>) => {
      event.preventDefault();
      emit("keyup", KEY_GROUPS[group]);
    },
    onPointerCancel: () => emit("keyup", KEY_GROUPS[group]),
    onContextMenu: (event: React.MouseEvent) => event.preventDefault(),
  });

  return (
    <div className="mobile-game-controls" aria-label="Commandes tactiles">
      <div className="mobile-game-dpad">
        <button {...hold("left")} aria-label="Gauche">←</button>
        <button {...hold("up")} aria-label="Saut / haut">↑</button>
        <button {...hold("right")} aria-label="Droite">→</button>
        <button {...hold("down")} aria-label="Bas">↓</button>
      </div>
      <div className="mobile-game-actions">
        <button {...hold("action")} aria-label="Action">E</button>
        <button {...hold("boost")} aria-label="Boost">SHIFT</button>
      </div>
    </div>
  );
}
