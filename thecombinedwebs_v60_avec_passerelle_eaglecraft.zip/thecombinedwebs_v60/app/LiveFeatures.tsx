"use client";
import { useEffect, useState } from "react";
import { usePathname } from "next/navigation";
import "./features.css";
export default function LiveFeatures() {
  const path = usePathname(),
    [treasure, setTreasure] = useState<{
      id: string;
      token: string;
      spot: number;
    } | null>(null),
    [msg, setMsg] = useState("");
  useEffect(() => {
    let off = false;
    const tick = async () => {
      try {
        const r = await fetch(`/api/events?page=${encodeURIComponent(path)}`, {
          cache: "no-store",
        });
        const d = await r.json();
        if (!off) setTreasure(d.treasure || null);
      } catch {}
    };
    tick();
    const t = setInterval(tick, 7000);
    return () => {
      off = true;
      clearInterval(t);
    };
  }, [path]);
  useEffect(() => {
    if (!path.startsWith("/games/")) return;
    fetch("/api/portals", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ action: "recent", id: path.split("/")[2] }),
    }).catch(() => {});
  }, [path]);
  if (!treasure)
    return msg ? (
      <div
        role="status"
        className="f-note"
        style={{
          position: "fixed",
          bottom: 16,
          left: 16,
          zIndex: 6000,
          maxWidth: 320,
        }}
      >
        {msg}
        <button className="f-btn" onClick={() => setMsg("")}>
          Fermer
        </button>
      </div>
    ) : null;
  const spots = [
    { bottom: 24, right: 24 },
    { bottom: 160, left: 16 },
    { top: "48%", right: 12 },
    { bottom: 80, right: "32%" },
  ];
  return (
    <button
      className="f-treasure"
      style={spots[treasure.spot] || spots[0]}
      aria-label="Objet caché : récupérer le trésor"
      onClick={async () => {
        try {
          const r = await fetch("/api/events", {
            method: "POST",
            headers: { "content-type": "application/json" },
            body: JSON.stringify({
              action: "find",
              id: treasure.id,
              token: treasure.token,
            }),
          });
          const d = await r.json();
          setMsg(
            d.error ||
              `Trésor trouvé ! ${d.event.reward} Bobux de récompense, doublés si l'Heure dorée est active.`,
          );
          setTreasure(null);
        } catch {
          setMsg("Connexion indisponible. Réessaie.");
        }
      }}
    >
      ◆
    </button>
  );
}
