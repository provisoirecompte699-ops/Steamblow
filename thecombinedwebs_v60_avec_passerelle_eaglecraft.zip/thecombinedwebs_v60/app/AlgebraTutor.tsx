"use client";
import {useEffect,useState} from "react";
import {AlgebraError,Frac,LEVELS,checkAnswer,generateExercise,simplifyExpression,solveEquation,solveInequality,studyFunction,solveSystem,type Exercise,type Level,type Step} from "@/lib/algebra";

type Tab="equation"|"expression"|"systeme"|"inequation"|"fonction";
const EXAMPLES:Record<Tab,string[]>={
 equation:["3(x − 2) + 5 = 2x + 7","x/2 + 1/3 = 5","x² − 5x + 6 = 0","2x² + 3x − 7 = 0","(x + 1)(x − 3) = x"],
 expression:["(x + 3)²","(2x − 1)(x + 5)","2(3x − 4) − 5x","6x + 9","(x − 4)(x + 4)"],
 systeme:[],
 inequation:["3x − 7 ≤ 5","−2x + 5 > 11","2(x + 1) ≥ x − 4","5x + 3 < 2x − 6"],
 fonction:["2x − 5","3x + 7","x² − 5x + 6","2x² + 3x − 7","−3x + 12","x² + 4x − 5"],
};

function Steps({steps,summary}:{steps:Step[];summary?:string}){
 return <div className="af-steps">
  <ol>{steps.map((s,i)=><li key={i}><div className="af-step-n">{i+1}</div><div><p className="af-step-t">{s.title}</p><pre className="af-math">{s.math}</pre>{s.note&&<p className="af-step-note">{s.note}</p>}</div></li>)}</ol>
  {summary&&<div className="af-result"><span>Résultat</span><b>{summary}</b></div>}
 </div>;
}

function errText(e:unknown){return e instanceof AlgebraError||e instanceof Error?e.message:"Saisie invalide."}

export default function AlgebraTutor(){
 const [tab,setTab]=useState<Tab>("equation");
 const [eqIn,setEqIn]=useState("3(x − 2) + 5 = 2x + 7");
 const [exIn,setExIn]=useState("(2x − 1)(x + 5)");
 const [ineqIn,setIneqIn]=useState("3x − 7 ≤ 5");
 const [funcIn,setFuncIn]=useState("x² − 5x + 6");
 const [sys,setSys]=useState({a1:"2",b1:"3",c1:"12",a2:"1",b2:"-1",c2:"1"});
 const [out,setOut]=useState<{steps:Step[];summary?:string}|null>(null);
 const [err,setErr]=useState("");

 function run(t:Tab=tab,value?:string){
  setErr("");
  try{
   if(t==="equation"){const r=solveEquation(value??eqIn);setOut({steps:r.steps,summary:r.summary})}
   else if(t==="expression"){setOut({steps:simplifyExpression(value??exIn)})}
   else if(t==="inequation"){const r=solveInequality(value??ineqIn);setOut({steps:r.steps,summary:r.summary})}
   else if(t==="fonction"){const r=studyFunction(value??funcIn);setOut({steps:r.steps,summary:r.summary})}
   else{const f=(k:keyof typeof sys)=>Frac.parse(sys[k]);const r=solveSystem(f("a1"),f("b1"),f("c1"),f("a2"),f("b2"),f("c2"));setOut({steps:r.steps,summary:r.summary})}
  }catch(e){setOut(null);setErr(errText(e))}
 }
 useEffect(()=>{run("equation")},[]);// eslint-disable-line react-hooks/exhaustive-deps
 const switchTab=(t:Tab)=>{setTab(t);setOut(null);setErr("");setTimeout(()=>run(t),0)};

 return <div className="af-tool">
  <div className="af-tabs" role="tablist">
   {([["equation","Résoudre une équation"],["expression","Développer · factoriser"],["systeme","Système 2 × 2"],["inequation","Inéquation"],["fonction","Étude de fonction"]] as [Tab,string][]).map(([id,l])=><button key={id} role="tab" aria-selected={tab===id} className={tab===id?"on":""} onClick={()=>switchTab(id)}>{l}</button>)}
  </div>
  <div className="af-tool-body">
   {tab==="equation"&&<form onSubmit={e=>{e.preventDefault();run()}}>
    <label className="af-label" htmlFor="af-eq">Équation en x (1er ou 2nd degré)</label>
    <div className="af-row"><input id="af-eq" className="af-input af-input-math" value={eqIn} onChange={e=>setEqIn(e.target.value)} spellCheck={false} autoComplete="off" placeholder="ex. 4(x + 1) = 2x − 6"/><button className="af-btn">Résoudre</button></div>
    <div className="af-chips">{EXAMPLES.equation.map(x=><button type="button" key={x} onClick={()=>{setEqIn(x);run("equation",x)}}>{x}</button>)}</div>
   </form>}
   {tab==="expression"&&<form onSubmit={e=>{e.preventDefault();run()}}>
    <label className="af-label" htmlFor="af-ex">Expression en x</label>
    <div className="af-row"><input id="af-ex" className="af-input af-input-math" value={exIn} onChange={e=>setExIn(e.target.value)} spellCheck={false} autoComplete="off" placeholder="ex. (x + 2)(x − 5)"/><button className="af-btn">Calculer</button></div>
    <div className="af-chips">{EXAMPLES.expression.map(x=><button type="button" key={x} onClick={()=>{setExIn(x);run("expression",x)}}>{x}</button>)}</div>
   </form>}
   {tab==="systeme"&&<form onSubmit={e=>{e.preventDefault();run()}}>
    <label className="af-label">Système de deux équations à deux inconnues</label>
    {[1,2].map(n=><div key={n} className="af-sys-row">
     <input className="af-input af-num" aria-label={`a${n}`} value={sys[`a${n}` as keyof typeof sys]} onChange={e=>setSys({...sys,[`a${n}`]:e.target.value})}/><span>x +</span>
     <input className="af-input af-num" aria-label={`b${n}`} value={sys[`b${n}` as keyof typeof sys]} onChange={e=>setSys({...sys,[`b${n}`]:e.target.value})}/><span>y =</span>
     <input className="af-input af-num" aria-label={`c${n}`} value={sys[`c${n}` as keyof typeof sys]} onChange={e=>setSys({...sys,[`c${n}`]:e.target.value})}/>
    </div>)}
    <p className="af-help">Coefficients entiers, décimaux (2,5) ou fractions (3/4).</p>
    <button className="af-btn">Résoudre le système</button>
   </form>}
   {tab==="inequation"&&<form onSubmit={e=>{e.preventDefault();run()}}>
    <label className="af-label" htmlFor="af-ineq">Inéquation en x (1er degré)</label>
    <div className="af-row"><input id="af-ineq" className="af-input af-input-math" value={ineqIn} onChange={e=>setIneqIn(e.target.value)} spellCheck={false} autoComplete="off" placeholder="ex. 3x − 7 ≤ 5"/><button className="af-btn">Résoudre</button></div>
    <div className="af-chips">{EXAMPLES.inequation.map(x=><button type="button" key={x} onClick={()=>{setIneqIn(x);run("inequation",x)}}>{x}</button>)}</div>
   </form>}
   {tab==="fonction"&&<form onSubmit={e=>{e.preventDefault();run()}}>
    <label className="af-label" htmlFor="af-func">Fonction f(x) en x (affine ou second degré)</label>
    <div className="af-row"><input id="af-func" className="af-input af-input-math" value={funcIn} onChange={e=>setFuncIn(e.target.value)} spellCheck={false} autoComplete="off" placeholder="ex. 2x − 5 ou x² − 4x + 3"/><button className="af-btn">Étudier</button></div>
    <div className="af-chips">{EXAMPLES.fonction.map(x=><button type="button" key={x} onClick={()=>{setFuncIn(x);run("fonction",x)}}>{x}</button>)}</div>
   </form>}
   {err&&<p className="af-error" role="alert">{err}</p>}
   {out&&<Steps steps={out.steps} summary={out.summary}/>}
   <p className="af-help">Saisie : <code>2x</code>, <code>3(x+1)</code>, <code>x²</code> ou <code>x^2</code>, <code>x/2</code>, fractions <code>1/3</code>, décimaux <code>1,5</code>. Pour les inéquations : <code>≤ ≥ &lt; &gt;</code>. Les calculs sont faits en valeurs exactes.</p>
  </div>
 </div>;
}

type Stats={done:number;correct:number;streak:number;best:number;byLevel?:Record<number,{done:number;correct:number}>;bestTime?:number|null;timeDone?:number|null;timeCorrect?:number|null};
const SKEY="algebre-facile:stats";
const TKEY="algebre-facile:timed";
const QUIZ_BANK = [
  { q: "Quel film parle d'un voyage dans l'espace pour sauver l'humanité ?", a: ["Interstellar","Titanic","Shrek","Cars"], correct: 0 },
  { q: "Quel personnage a un scarabée doré comme symbole ?", a: ["Spider-Man","Batman","Superman","Iron Man"], correct: 1 },
  { q: "Dans quel film trouve-t-on le personnage de Forrest Gump ?", a: ["Forrest Gump","Pulp Fiction","Fight Club","Inception"], correct: 0 },
  { q: "Qui a réalisé 'Inception' ?", a: ["Spielberg","Nolan","Scorsese","Tarantino"], correct: 1 },
  { q: "Quel film d'animation parle d'un poisson-clown perdu ?", a: ["Shrek","Toy Story","Nemo","Ratatouille"], correct: 2 },
  { q: "Dans 'Matrix', quelle pilule prend Neo ?", a: ["La bleue","La rouge","La verte","La jaune"], correct: 1 },
  { q: "Qui joue Jack dans 'Titanic' ?", a: ["Brad Pitt","Leonardo DiCaprio","Tom Cruise","Matt Damon"], correct: 1 },
  { q: "Quel film Marvel a un héros avec un marteau ?", a: ["Iron Man","Thor","Hulk","Captain America"], correct: 1 },
  { q: "Dans quel film trouve-t-on le personnage de Joker ?", a: ["Batman","Superman","Flash","Aquaman"], correct: 0 },
  { q: "Quel film parle d'un palefrenier qui devient roi ?", a: ["Gladiator","Roi Lion","Shrek","Le Hobbit"], correct: 1 },
];

export function ExerciseTrainer(){
 const [level,setLevel]=useState<Level>(1);
 const [ex,setEx]=useState<Exercise|null>(null);
 const [answer,setAnswer]=useState("");
 const [tries,setTries]=useState(0);
 const [state,setState]=useState<"idle"|"ok"|"ko"|"shown">("idle");
 const [msg,setMsg]=useState("");
 const [stats,setStats]=useState<Stats>({done:0,correct:0,streak:0,best:0});
 const [mode,setMode]=useState<"practice"|"timed"|"stats"|"exam"|"story">("practice");
 const [timedState,setTimedState]=useState<{running:boolean;timeLeft:number;question:number;correct:number;total:number;finished:boolean}>({running:false,timeLeft:60,question:0,correct:0,total:10,finished:false});
 const [timedEx,setTimedEx]=useState<Exercise|null>(null);
 const [timedAnswer,setTimedAnswer]=useState("");
 const [showStats,setShowStats]=useState(false);
 const [examState,setExamState]=useState<{running:boolean;q:number;correct:number;total:number;finished:boolean;questions:Exercise[];answers:string[];results:boolean[]}>({running:false,q:0,correct:0,total:15,finished:false,questions:[],answers:[],results:[]});
 const [storyState,setStoryState]=useState<{level:number;hp:number;maxHp:number;score:number;question:number;ex:Exercise|null;answer:string;result:string;finished:boolean;boss:string}>({level:1,hp:3,maxHp:3,score:0,question:0,ex:null,answer:"",result:"",finished:false,boss:""});
 useEffect(()=>{try{const s=localStorage.getItem(SKEY);if(s)setStats(JSON.parse(s))}catch{};setEx(generateExercise(1))},[]);
 const save=(s:Stats)=>{setStats(s);try{localStorage.setItem(SKEY,JSON.stringify(s))}catch{}};
 const next=(l:Level=level)=>{setEx(generateExercise(l));setAnswer("");setTries(0);setState("idle");setMsg("")};
 const pick=(l:Level)=>{setLevel(l);next(l)};
 function check(){
  if(!ex||state==="ok"||state==="shown")return;
  const r=checkAnswer(ex,answer);
  if(r.error){setMsg(r.error);return}
  if(r.ok){setState("ok");setMsg(tries===0?"Exact du premier coup.":"Exact.");const streak=stats.streak+1;const byLevel=stats.byLevel||{};const lv=byLevel[ex.level]||{done:0,correct:0};byLevel[ex.level]={done:lv.done+1,correct:lv.correct+1};save({done:stats.done+1,correct:stats.correct+1,streak,best:Math.max(stats.best,streak),byLevel,bestTime:stats.bestTime,timeDone:stats.timeDone,timeCorrect:stats.timeCorrect});fetch("/api/quests",{method:"POST",headers:{"content-type":"application/json"},body:JSON.stringify({action:"progress",id:"algebre",value:1})}).catch(()=>{});return}
  const t=tries+1;setTries(t);setState("ko");
  if(t>=2){setState("shown");setMsg("Voici la correction détaillée.");const byLevel=stats.byLevel||{};const lv=byLevel[ex.level]||{done:0,correct:0};byLevel[ex.level]={done:lv.done+1,correct:lv.correct};save({...stats,done:stats.done+1,streak:0,byLevel})}
  else setMsg(ex.level===4?"Pas encore. Indice : calcule le discriminant Δ = b² − 4ac.":"Pas encore. Indice : regroupe les termes en x d’un côté, les nombres de l’autre.");
 }
 // ——— Mode chronométré ———
 const startTimed=()=>{setTimedState({running:true,timeLeft:60,question:0,correct:0,total:10,finished:false});setTimedEx(generateExercise(1));setTimedAnswer("")};
 useEffect(()=>{if(!timedState.running)return;const t=setInterval(()=>{setTimedState(s=>{if(s.timeLeft<=1){return{...s,running:false,finished:true}}return{...s,timeLeft:s.timeLeft-1}})},1000);return()=>clearInterval(t)},[timedState.running]);
 const checkTimed=()=>{
  if(!timedEx||!timedState.running)return;
  const r=checkAnswer(timedEx,timedAnswer);
  const correct=r.ok?timedState.correct+1:timedState.correct;
  const q=timedState.question+1;
  if(q>=timedState.total){
   setTimedState({...timedState,question:q,correct,running:false,finished:true});
   const timeUsed=60-timedState.timeLeft;const prev=stats.bestTime||999;
   if(timeUsed<prev||correct>(stats.timeCorrect||0)){save({...stats,bestTime:timeUsed,timeDone:timedState.total,timeCorrect:correct})}
  }else{setTimedState({...timedState,question:q,correct});setTimedEx(generateExercise(Math.min(4,1+Math.floor(q/3))as Level));setTimedAnswer("")}
 };
 // ——— Stats détaillées ———
 const rate=stats.done?Math.round(stats.correct/stats.done*100):0;
 const levelsMastered=Object.entries(stats.byLevel||{}).filter(([,v])=>v.correct>=5&&v.done>=8).length;
 const correction=ex&&state==="shown"?(()=>{try{return solveEquation(ex.text)}catch{return null}})():null;

 // ——— Examen blanc ———
 const startExam=()=>{const questions:Exercise[]=[];for(let i=0;i<15;i++)questions.push(generateExercise((1+rnd3(i))as Level));setExamState({running:true,q:0,correct:0,total:15,finished:false,questions,answers:[],results:[]});};
 const rnd3=(i:number)=>{if(i<5)return 1+Math.floor(Math.random()*2);if(i<10)return 3;return 4;};
 const checkExam=()=>{
  if(!examState.running)return;
  const ex2=examState.questions[examState.q];if(!ex2)return;
  const r=checkAnswer(ex2,examState.answers[examState.q]||"");
  const ok=r.ok;const correct=ok?examState.correct+1:examState.correct;
  const results=[...examState.results,ok];
  const q=examState.q+1;
  if(q>=examState.total){const note=Math.round((correct/examState.total)*20*10)/10;setExamState({...examState,q,correct,finished:true,running:false,results});fetch("/api/quests",{method:"POST",headers:{"content-type":"application/json"},body:JSON.stringify({action:"progress",id:"algebre",value:1})}).catch(()=>{});}
  else{setExamState({...examState,q,correct,results});}
 };
 const setExamAnswer=(v:string)=>{const answers=[...examState.answers];answers[examState.q]=v;setExamState({...examState,answers});};

 // ——— Mode histoire ———
 const STORY_BOSSES=["Gardien des Équations","Maître des Parenthèses","Seigneur du Second Degré","Dragon des Fractions","Sorcier du Produit Nul","Titan des Problèmes"];
 const startStory=()=>{const lvl=Number(localStorage.getItem("algebre-facile:story-level")||"1");setStoryState({level:lvl,hp:3,maxHp:3,score:0,question:0,ex:generateExercise(Math.min(4,lvl)as Level),answer:"",result:"",finished:false,boss:STORY_BOSSES[lvl-1]||STORY_BOSSES[0]});};
 const checkStory=()=>{
  if(!storyState.ex||storyState.finished)return;
  const r=checkAnswer(storyState.ex,storyState.answer);
  if(r.ok){const newScore=storyState.score+100;const newQ=storyState.question+1;
   if(newQ>=5){
    const nextLevel=Math.min(6,storyState.level+1);localStorage.setItem("algebre-facile:story-level",String(nextLevel));
    setStoryState({...storyState,score:newScore,question:newQ,finished:true,result:`Boss vaincu ! Niveau ${storyState.level} terminé. Le prochain boss : ${STORY_BOSSES[nextLevel-1]||""}.`});
    fetch("/api/quests",{method:"POST",headers:{"content-type":"application/json"},body:JSON.stringify({action:"progress",id:"algebre",value:5})}).catch(()=>{});
   }else{setStoryState({...storyState,score:newScore,question:newQ,ex:generateExercise(Math.min(4,storyState.level)as Level),answer:"",result:"Correct ! +100 pts"});}
  }else{const newHp=storyState.hp-1;if(newHp<=0){setStoryState({...storyState,hp:0,finished:true,result:"Game Over... Réessaie !"});}
  else{setStoryState({...storyState,hp:newHp,result:"Raté ! -1 PV"});}}
 };

 return <div className="af-trainer">
  <div className="af-mode-tabs">
   <button className={mode==="practice"?"on":""} onClick={()=>setMode("practice")}>Entraînement</button>
   <button className={mode==="timed"?"on":""} onClick={()=>{setMode("timed");startTimed()}}>⚡ Chrono</button>
   <button className={mode==="exam"?"on":""} onClick={()=>{setMode("exam");startExam()}}>📝 Examen blanc</button>
   <button className={mode==="story"?"on":""} onClick={()=>{setMode("story");startStory()}}>📖 Mode histoire</button>
   <button className={mode==="stats"?"on":""} onClick={()=>setMode("stats")}>📊 Statistiques</button>
  </div>

  {mode==="practice"&&<>
  <div className="af-levels">{LEVELS.map(l=><button key={l.id} className={level===l.id?"on":""} onClick={()=>pick(l.id)}><b>{l.label}</b><small>{l.hint}</small></button>)}</div>
  <div className="af-ex-card">
   <p className="af-label">Résous l’équation{ex?.multi?" (donne les deux solutions, séparées par « ; »)":""}</p>
   <div className="af-ex-eq">{ex?.text??"…"}</div>
   <form className="af-row" onSubmit={e=>{e.preventDefault();check()}}>
    <span className="af-x">x =</span>
    <input className="af-input af-input-math" value={answer} onChange={e=>setAnswer(e.target.value)} placeholder={ex?.multi?"ex. −2 ; 5":"ex. 4 ou 7/3"} autoComplete="off" inputMode="text" disabled={state==="ok"||state==="shown"}/>
    {state==="ok"||state==="shown"?<button type="button" className="af-btn" onClick={()=>next()}>Exercice suivant →</button>:<button className="af-btn">Vérifier</button>}
   </form>
   {msg&&<p className={`af-feedback ${state==="ok"?"good":state==="idle"?"":"bad"}`}>{state==="ok"?"✓ ":state==="ko"?"✗ ":""}{msg}</p>}
   {correction&&<Steps steps={correction.steps} summary={correction.summary}/>}
   {(state==="idle"||state==="ko")&&ex&&<button type="button" className="af-link" onClick={()=>{setState("shown");setMsg("Correction affichée.");const byLevel=stats.byLevel||{};const lv=byLevel[ex.level]||{done:0,correct:0};byLevel[ex.level]={done:lv.done+1,correct:lv.correct};save({...stats,done:stats.done+1,streak:0,byLevel})}}>Voir la correction</button>}
  </div>
  </>}

  {mode==="timed"&&<>
  <div className="af-timed-card">
   {!timedState.running&&!timedState.finished&&<>
    <h3>⚡ Défi chronométré</h3>
    <p className="af-help">Résous 10 équations le plus vite possible. Le chronomètre démarre au premier clic.</p>
    <div className="af-timed-controls"><button className="af-btn" onClick={startTimed}>Démarrer</button></div>
   </>}
   {timedState.running&&<>
    <div className="af-timed-hud"><span className="af-timer">⏱ {timedState.timeLeft}s</span><span className="af-progress">Question {timedState.question+1}/{timedState.total}</span><span className="af-score">✓ {timedState.correct}</span></div>
    {timedEx&&<div className="af-ex-card">
     <div className="af-ex-eq">{timedEx.text}</div>
     <form className="af-row" onSubmit={e=>{e.preventDefault();checkTimed()}}>
      <span className="af-x">x =</span>
      <input className="af-input af-input-math" value={timedAnswer} onChange={e=>setTimedAnswer(e.target.value)} placeholder="Ta réponse" autoComplete="off" inputMode="text" autoFocus/>
      <button className="af-btn">Valider</button>
     </form>
    </div>}
   </>}
   {timedState.finished&&<>
    <div className="af-timed-result">
     <h3>Terminé !</h3>
     <p className="af-timed-score">{timedState.correct}/{timedState.total} correctes</p>
     <p className="af-help">Temps : {60-timedState.timeLeft}s · {stats.bestTime?`Meilleur temps : ${stats.bestTime}s`:"Premier record !"}</p>
     <button className="af-btn" onClick={startTimed}>Recommencer</button>
    </div>
   </>}
  </div>
  </>}

  {mode==="exam"&&<>
  <div className="af-timed-card">
   {!examState.running&&!examState.finished&&<>
    <h3>📝 Examen blanc</h3>
    <p className="af-help">15 questions mixtes (niveaux 1 à 4). Note sur 20. Corrigé détaillé à la fin.</p>
    <div className="af-timed-controls"><button className="af-btn" onClick={startExam}>Commencer l'examen</button></div>
   </>}
   {examState.running&&<>
    <div className="af-timed-hud"><span className="af-progress">Question {examState.q+1}/{examState.total}</span><span className="af-score">✓ {examState.correct}</span></div>
    {examState.questions[examState.q]&&<div className="af-ex-card">
     <div className="af-ex-eq">{examState.questions[examState.q].text}</div>
     <form className="af-row" onSubmit={e=>{e.preventDefault();checkExam()}}>
      <span className="af-x">x =</span>
      <input className="af-input af-input-math" value={examState.answers[examState.q]||""} onChange={e=>setExamAnswer(e.target.value)} placeholder="Ta réponse" autoComplete="off" inputMode="text" autoFocus/>
      <button className="af-btn">Valider</button>
     </form>
    </div>}
   </>}
   {examState.finished&&<>
    <div className="af-timed-result">
     <h3>Examen terminé !</h3>
     <p className="af-timed-score">{examState.correct}/{examState.total}</p>
     <p className="af-help">Note : <b>{Math.round((examState.correct/examState.total)*20*10)/10}/20</b></p>
     <div className="af-exam-review">{examState.results.map((ok,i)=>(<div key={i} className={`af-exam-item ${ok?"good":"bad"}`}><span>{ok?"✓":"✗"}</span><small>{examState.questions[i]?.text||""}</small></div>))}</div>
     <button className="af-btn" onClick={startExam}>Recommencer</button>
    </div>
   </>}
  </div>
  </>}

  {mode==="story"&&<>
  <div className="af-timed-card af-story-card">
   {!storyState.ex&&!storyState.finished&&<>
    <h3>📖 Mode Histoire</h3>
    <p className="af-help">Affronte 6 boss mathématiques ! 5 questions par boss, 3 vies, difficulté croissante.</p>
    <div className="af-story-bosses">{STORY_BOSSES.map((b,i)=><div key={i} className={`af-story-chip ${i<Number(localStorage.getItem("algebre-facile:story-level")||"1")?"unlocked":"locked"}`}><span>{i<Number(localStorage.getItem("algebre-facile:story-level")||"1")?"⚔️":"🔒"}</span>{b}</div>)}</div>
    <div className="af-timed-controls"><button className="af-btn" onClick={startStory}>Commenter l'aventure</button></div>
   </>}
   {storyState.ex&&!storyState.finished&&<>
    <div className="af-story-hud"><span className="af-story-boss">👹 {storyState.boss}</span><span className="af-progress">Question {storyState.question+1}/5</span><span>❤️ {"❤️".repeat(storyState.hp)}</span><span className="af-score">{storyState.score} pts</span></div>
    <div className="af-ex-card">
     <div className="af-ex-eq">{storyState.ex.text}</div>
     <form className="af-row" onSubmit={e=>{e.preventDefault();checkStory()}}>
      <span className="af-x">x =</span>
      <input className="af-input af-input-math" value={storyState.answer} onChange={e=>setStoryState({...storyState,answer:e.target.value})} placeholder="Ta réponse" autoComplete="off" inputMode="text" autoFocus/>
      <button className="af-btn">Valider</button>
     </form>
     {storyState.result&&<p className="af-feedback">{storyState.result}</p>}
    </div>
   </>}
   {storyState.finished&&<>
    <div className="af-timed-result">
     <h3>{storyState.hp>0?"Boss vaincu !":"Game Over"}</h3>
     <p className="af-timed-score">{storyState.score} pts</p>
     <p className="af-help">{storyState.result}</p>
     <button className="af-btn" onClick={startStory}>{storyState.hp>0?"Boss suivant →":"Réessayer"}</button>
    </div>
   </>}
  </div>
  </>}

  {mode==="stats"&&<>
  <div className="af-stats-detail">
   <h3>📊 Mes statistiques</h3>
   <dl className="af-stats">
    <div><dt>Exercices</dt><dd>{stats.done}</dd></div>
    <div><dt>Réussite</dt><dd>{rate} %</dd></div>
    <div><dt>Série actuelle</dt><dd>{stats.streak}</dd></div>
    <div><dt>Record série</dt><dd>{stats.best}</dd></div>
    <div><dt>Meilleur chrono</dt><dd>{stats.bestTime?`${stats.bestTime}s`:"—"}</dd></div>
    <div><dt>Niveaux maîtrisés</dt><dd>{levelsMastered}/7</dd></div>
   </dl>
   <h4>Arbre de compétences</h4>
   <div className="af-skill-tree">{LEVELS.map(l=>{const s=stats.byLevel?.[l.id]||{done:0,correct:0};const rate2=s.done?Math.round(s.correct/s.done*100):0;const mastered=s.correct>=5&&s.done>=8;return <div key={l.id} className={`af-skill ${mastered?"mastered":""}`}><div className="af-skill-icon">{mastered?"⭐":rate2>0?"📖":"🔒"}</div><b>{l.label}</b><small>{s.done} faits · {rate2}% réussite</small></div>})}</div>
   <h4>Progression mode histoire</h4>
   <div className="af-story-progress">{STORY_BOSSES.map((b,i)=>{const unlocked=i<Number(localStorage.getItem("algebre-facile:story-level")||"1");return <div key={i} className={`af-story-chapter ${unlocked?"unlocked":""}`}><span>{unlocked?"⚔️":"🔒"}</span><div><b>{b}</b><small>Chapitre {i+1}</small></div></div>})}</div>
  </div>
  </>}

  {mode==="practice"&&<dl className="af-stats">
   <div><dt>Exercices</dt><dd>{stats.done}</dd></div>
   <div><dt>Réussite</dt><dd>{rate} %</dd></div>
   <div><dt>Série</dt><dd>{stats.streak}</dd></div>
   <div><dt>Record</dt><dd>{stats.best}</dd></div>
  </dl>}
 </div>;
}
