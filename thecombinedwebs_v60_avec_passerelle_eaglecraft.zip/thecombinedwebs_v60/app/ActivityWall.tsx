"use client";
import { useEffect, useState } from "react";

type Activity = { id: number; icon: string; text: string; time: string };

const ACTIVITY_SOURCES = [
  () => ({ icon: "🎮", text: "Partie jouée sur un jeu arcade" }),
  () => ({ icon: "🏆", text: "Succès débloqué dans un jeu" }),
  () => ({ icon: "💯", text: "Nouveau record personnel" }),
  () => ({ icon: "📐", text: "Exercice d'algèbre réussi" }),
  () => ({ icon: "⚡", text: "Défi chronométré terminé" }),
  () => ({ icon: "🍿", text: "Film regardé sur CinéStream" }),
  () => ({ icon: "⭐", text: "Avis publié sur un film" }),
  () => ({ icon: "🛡️", text: "Tournoi disputé" }),
  () => ({ icon: "🪙", text: "Quête quotidienne réclamée" }),
  () => ({ icon: "🔥", text: "Série d'exercices en cours" }),
];

const AKEY = "steamblox:activity-feed";
const MAX = 12;

export function logActivity(icon: string, text: string) {
  try {
    const feed = JSON.parse(localStorage.getItem(AKEY) || "[]");
    feed.unshift({ id: Date.now(), icon, text, time: new Date().toLocaleTimeString("fr-FR", { hour: "2-digit", minute: "2-digit" }) });
    localStorage.setItem(AKEY, JSON.stringify(feed.slice(0, MAX)));
  } catch {}
}

export default function ActivityWall() {
  const [feed, setFeed] = useState<Activity[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    try {
      const local = JSON.parse(localStorage.getItem(AKEY) || "[]");
      setFeed(local);
    } catch {}
    // Try fetching server-side activities
    fetch("/api/leaderboard?scope=all").then(r => r.ok ? r.json() : null).then(() => {
      setLoading(false);
    }).catch(() => setLoading(false));
  }, []);

  if (!feed.length && !loading) {
    return <div className="card ui-activity-wall">
      <div className="section-head"><div><div className="eyebrow">ACTIVITÉ</div><h3>Mur d'activités</h3></div></div>
      <p className="muted">Joue, résous des exercices, regarde des films — tes exploits apparaîtront ici.</p>
    </div>;
  }

  return <div className="card ui-activity-wall">
    <div className="section-head"><div><div className="eyebrow">ACTIVITÉ</div><h3>Mur d'activités</h3></div><small>{feed.length}</small></div>
    {feed.map(a => <div key={a.id} className="ui-activity-item">
      <span className="ui-act-icon">{a.icon}</span>
      <div className="ui-act-text"><b>{a.text}</b><small>{a.time}</small></div>
    </div>)}
    {!feed.length && <p className="muted">Chargement…</p>}
  </div>;
}
