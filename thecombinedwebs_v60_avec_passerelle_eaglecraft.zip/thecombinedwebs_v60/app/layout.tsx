import "./globals.css";
import type { ReactNode } from "react";
import ServiceWorker from "./ServiceWorker";
import BanGuard from "./BanGuard";
import PlatformPicker from "./PlatformPicker";
import SteambloxDownloadScreen from "./SteambloxDownloadScreen";
import EasterEggs from "./EasterEggs";
import AdaptivePerformance from "./AdaptivePerformance";
import MobileGameControls from "./MobileGameControls";
import SocialNotifier from "./SocialNotifier";
import DiscordVoiceProvider from "./DiscordVoiceProvider";
import ThemeManager from "./ThemeManager";
import InstallPrompt from "./InstallPrompt";
import TcbGlobal from "./TcbGlobal";
import LiveFeatures from "./LiveFeatures";
import PadKeyboard from "./PadKeyboard";

export const dynamic = "force-dynamic";
export const runtime = "nodejs";

export const metadata={title:"TheCombinedWebs",description:"Une plateforme de jeux 2D et 3D avec multijoueur en ligne",manifest:"/manifest.webmanifest",appleWebApp:{capable:true,title:"TheCombinedWebs",statusBarStyle:"black-translucent" as const},icons:{icon:"/icons/icon-192.png",apple:"/icons/icon-192.png"}};
export const viewport={themeColor:"#0b0d14",width:"device-width",initialScale:1,viewportFit:"cover" as const};
const THEME_BOOT=`try{var t=localStorage.getItem("steamblox:theme");if(t&&t!=="default")document.documentElement.dataset.sbtheme=t}catch(e){}`;

export default async function RootLayout({children}:{children:ReactNode}){
  return <html lang="fr" suppressHydrationWarning><body suppressHydrationWarning><script dangerouslySetInnerHTML={{__html:THEME_BOOT}} /><script src="/eco/adshield.js" /><ThemeManager /><InstallPrompt /><ServiceWorker /><TcbGlobal /><BanGuard /><PlatformPicker /><SteambloxDownloadScreen /><EasterEggs />
      <AdaptivePerformance /><MobileGameControls /><LiveFeatures /><PadKeyboard /><DiscordVoiceProvider><SocialNotifier />{children}</DiscordVoiceProvider><script src="/eco/tv.js" defer /></body></html>;
}
