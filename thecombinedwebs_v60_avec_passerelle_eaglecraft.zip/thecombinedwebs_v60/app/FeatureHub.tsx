"use client";
import {useEffect,useState} from "react";

type Feed={id:number;icon:string;text:string;time:string};
export default function FeatureHub(){
 const [wishlist,setWishlist]=useState<string[]>([]),[notifications,setNotifications]=useState(true),[fps,setFps]=useState(true),[compact,setCompact]=useState(false),[reduced,setReduced]=useState(false),[daily,setDaily]=useState(false),[sound,setSound]=useState(true),[feed,setFeed]=useState<Feed[]>([]);
 useEffect(()=>{try{
  setWishlist(JSON.parse(localStorage.getItem('steamblox:wishlist')||'[]'));
  setNotifications(localStorage.getItem('steamblox:notifications')!=='0');setFps(localStorage.getItem('steamblox:fps')!=='0');
  setCompact(localStorage.getItem('steamblox:compact')==='1');setReduced(localStorage.getItem('steamblox:reducedMotion')==='1');setSound(localStorage.getItem('steamblox:sfx')!=='0');
  const saved=JSON.parse(localStorage.getItem('steamblox:feed')||'[]');setFeed(Array.isArray(saved)?saved.slice(0,5):[]);
 }catch{}}
 ,[]);
 const toggle=(key:string,value:boolean)=>localStorage.setItem(key,value?'1':'0');
 const claimDaily=()=>{if(daily)return;const entry={id:Date.now(),icon:'🎁',text:'Récompense quotidienne récupérée : +25 XP',time:'à l’instant'};const next=[entry,...feed].slice(0,5);setFeed(next);setDaily(true);localStorage.setItem('steamblox:dailyClaim',new Date().toISOString().slice(0,10));localStorage.setItem('steamblox:feed',JSON.stringify(next));localStorage.setItem('steamblox:xpBonus','25')};
 useEffect(()=>{try{setDaily(localStorage.getItem('steamblox:dailyClaim')===new Date().toISOString().slice(0,10))}catch{}},[]);
 return <section className="card sb-feature-hub"><div className="section-head"><div><div className="eyebrow">NOUVEAUTÉS</div><h3>Centre TheCombinedWebs</h3></div><span className="tag accent">v17</span></div>
  <div className="feature-grid">
   <div><b>🎁 Récompense quotidienne</b><small>Reviens chaque jour pour récupérer 25 XP.</small><button disabled={daily} onClick={claimDaily}>{daily?'Déjà récupérée':'Récupérer +25 XP'}</button></div>
   <div><b>🔔 Notifications</b><small>Alertes de nouveaux contenus et événements.</small><button onClick={()=>{const v=!notifications;setNotifications(v);toggle('steamblox:notifications',v)}}>{notifications?'Activées':'Désactivées'}</button></div>
   <div><b>⚡ Mode performance</b><small>Affiche les infos FPS dans les expériences compatibles.</small><button onClick={()=>{const v=!fps;setFps(v);toggle('steamblox:fps',v)}}>{fps?'Activé':'Désactivé'}</button></div>
   <div><b>❤️ Liste de souhaits</b><small>{wishlist.length} jeu{wishlist.length>1?'x':''} enregistré{wishlist.length>1?'s':''}.</small><button onClick={()=>{const n=wishlist.length?[]:['demo'];setWishlist(n);localStorage.setItem('steamblox:wishlist',JSON.stringify(n))}}>{wishlist.length?'Vider':'Ajouter un exemple'}</button></div>
   <div><b>📐 Interface compacte</b><small>Réduit l’espace occupé par les cartes du dashboard.</small><button onClick={()=>{const v=!compact;setCompact(v);toggle('steamblox:compact',v);document.documentElement.classList.toggle('sb-compact',v)}}>{compact?'Activée':'Désactivée'}</button></div>
   <div><b>♿ Réduire les animations</b><small>Limite les mouvements pour une interface plus calme.</small><button onClick={()=>{const v=!reduced;setReduced(v);toggle('steamblox:reducedMotion',v);document.documentElement.classList.toggle('sb-reduced-motion',v)}}>{reduced?'Activé':'Désactivé'}</button></div>
   <div><b>🔊 Effets sonores</b><small>Active ou coupe les petits sons de l’interface.</small><button onClick={()=>{const v=!sound;setSound(v);toggle('steamblox:sfx',v)}}>{sound?'Activés':'Désactivés'}</button></div>
   <div><b>📡 Mode hors-ligne</b><small>Le service worker garde les éléments déjà visités disponibles hors connexion.</small><span className="feature-badge">PWA actif</span></div>
  </div>
  <div className="sb-activity"><div className="section-head"><div><div className="eyebrow">ACTIVITÉ</div><h4>Journal récent</h4></div><small>{feed.length}/5</small></div>{feed.length?<div className="activity-list">{feed.map(x=><div className="activity" key={x.id}><span>{x.icon}</span><div><b>{x.text}</b><small>{x.time}</small></div></div>)}</div>:<p className="muted">Tes récompenses et événements récents apparaîtront ici.</p>}</div>
 </section>
}
