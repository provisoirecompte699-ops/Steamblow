"use client";
import { useEffect, useState } from "react";
import Link from "next/link";

type Challenge = { id: string; from: string; to: string; game: string; targetScore: number; status: "pending" | "win" | "lose" | "expired"; createdAt: number; result?: number };
const CKEY = "steamblox:challenges";

const GAMES = [
  { id: "meteor-mayhem", name: "Meteor Mayhem" },
  { id: "crystal-rush", name: "Crystal Rush" },
  { id: "cyber-siege", name: "Cyber Siege" },
  { id: "block-brawl", name: "Block Brawl" },
  { id: "neon-arena", name: "Neon Arena" },
  { id: "castle-clash", name: "Castle Clash" },
  { id: "party-pals", name: "Party Pals" },
  { id: "rooftop-rivals", name: "Rooftop Rivals" },
  { id: "pixel-heist", name: "Pixel Heist" },
  { id: "mystic-mines", name: "Mystic Mines" },
  { id: "neon-tag", name: "Neon Tag" },
];

export default function FriendChallenges({ username, friends }: { username: string; friends: string[] }) {
  const [challenges, setChallenges] = useState<Challenge[]>([]);
  const [showCreate, setShowCreate] = useState(false);
  const [form, setForm] = useState({ friend: friends[0] || "", game: GAMES[0].id, target: 500 });

  useEffect(() => {
    try { setChallenges(JSON.parse(localStorage.getItem(CKEY) || "[]")); } catch {}
  }, []);

  const save = (c: Challenge[]) => { setChallenges(c); try { localStorage.setItem(CKEY, JSON.stringify(c)); } catch {} };

  const create = () => {
    const c: Challenge = { id: Date.now().toString(36), from: username, to: form.friend, game: GAMES.find(g => g.id === form.game)?.name || form.game, targetScore: form.target, status: "pending", createdAt: Date.now() };
    save([c, ...challenges].slice(0, 20));
    setShowCreate(false);
  };

  const resolve = (id: string, won: boolean) => {
    const c = challenges.find(x => x.id === id);
    if (!c) return;
    const myScore = Number(localStorage.getItem(`steamblox:arcade:${c.game.toLowerCase().replace(/\s/g, "-")}:best`) || 0);
    const result = myScore;
    const won_ = myScore >= c.targetScore;
    save(challenges.map(x => x.id === id ? { ...x, status: won_ ? "win" : "lose", result } : x));
  };

  return <div className="card">
    <div className="section-head">
      <div><div className="eyebrow">AMIS</div><h3>Défis entre amis</h3></div>
      <button className="button secondary" onClick={() => setShowCreate(!showCreate)}>+ Lancer un défi</button>
    </div>
    {showCreate && friends.length > 0 && <div style={{ marginBottom: 12 }}>
      <div style={{ display: "flex", gap: 8, flexWrap: "wrap", marginBottom: 8 }}>
        <select className="input" value={form.friend} onChange={e => setForm({ ...form, friend: e.target.value })} style={{ flex: 1, minWidth: 120 }}>
          {friends.map(f => <option key={f} value={f}>{f}</option>)}
        </select>
        <select className="input" value={form.game} onChange={e => setForm({ ...form, game: e.target.value })} style={{ flex: 1, minWidth: 120 }}>
          {GAMES.map(g => <option key={g.id} value={g.id}>{g.name}</option>)}
        </select>
        <input className="input" type="number" value={form.target} onChange={e => setForm({ ...form, target: Number(e.target.value) })} style={{ width: 100 }} placeholder="Score à battre" />
      </div>
      <button className="button" onClick={create}>Envoyer le défi</button>
    </div>}
    {showCreate && friends.length === 0 && <p className="muted" style={{ marginBottom: 8 }}>Ajoute des amis d'abord pour les défier.</p>}
    {challenges.map(c => <div key={c.id} className="ui-challenge-card">
      <span className="ui-challenge-icon">{c.status === "win" ? "🏆" : c.status === "lose" ? "😅" : "⚔️"}</span>
      <div className="ui-challenge-info">
        <b>{c.from === username ? "Tu défies " : "Défi de "}{c.from === username ? c.to : c.from}</b>
        <small>{c.game} · objectif : {c.targetScore} pts{c.result ? ` · ton score : ${c.result}` : ""}</small>
      </div>
      {c.status === "pending" && c.from === username ? <span className="ui-challenge-status pending">En attente</span>
      : c.status === "pending" ? <button className="button secondary" style={{ padding: "4px 12px", fontSize: 12 }} onClick={() => resolve(c.id, false)}>Relever</button>
      : <span className={`ui-challenge-status ${c.status}`}>{c.status === "win" ? "Gagné" : "Perdu"}</span>}
    </div>)}
    {!challenges.length && <p className="muted">Lance un défi à un ami : bat son record sur un jeu précis.</p>}
  </div>;
}
