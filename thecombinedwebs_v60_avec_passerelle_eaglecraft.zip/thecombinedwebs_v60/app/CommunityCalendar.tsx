"use client";
import { useEffect, useState } from "react";

type CalEvent = { day: number; title: string; icon: string; time: string; type: "tournoi" | "cine" | "event" | "clan" };

const EVENTS: CalEvent[] = [
  { day: 1, title: "Tournoi Meteor Mayhem", icon: "🏆", time: "18h", type: "tournoi" },
  { day: 1, title: "Défi quotidien doublé", icon: "⚡", time: "Toute la journée", type: "event" },
  { day: 2, title: "Soirée CinéStream", icon: "🍿", time: "21h", type: "cine" },
  { day: 2, title: "Clan Wars", icon: "🛡️", time: "20h", type: "clan" },
  { day: 3, title: "Tournoi Crystal Rush", icon: "🏆", time: "18h", type: "tournoi" },
  { day: 4, title: "Boss hebdomadaire reset", icon: "👹", time: "00h", type: "event" },
  { day: 4, title: "Soirée Vortex", icon: "🎬", time: "20h", type: "cine" },
  { day: 5, title: "Tournoi Neon Tag", icon: "🏆", time: "18h", type: "tournoi" },
  { day: 5, title: "Marathon arcade", icon: "🎮", time: "Toute la journée", type: "event" },
  { day: 6, title: "Clan Wars finales", icon: "🛡️", time: "20h", type: "clan" },
  { day: 7, title: "Tournoi tous jeux", icon: "🏆", time: "17h", type: "tournoi" },
  { day: 7, title: "Soirée CinéStream", icon: "🍿", time: "21h", type: "cine" },
];

const DAYS = ["Lun", "Mar", "Mer", "Jeu", "Ven", "Sam", "Dim"];

export default function CommunityCalendar() {
  const [today, setToday] = useState(1);

  useEffect(() => {
    const d = new Date().getDay(); // 0 = Sunday
    setToday(d === 0 ? 7 : d);
  }, []);

  const typeColor: Record<string, string> = {
    tournoi: "#f59e0b", cine: "#ef4444", event: "#8b7cff", clan: "#10b981",
  };

  return <div className="card">
    <div className="section-head"><div><div className="eyebrow">AGENDA</div><h3>Calendrier communautaire</h3></div></div>
    <div className="ui-cal-grid">
      {DAYS.map((d, i) => {
        const dayNum = i + 1;
        const dayEvents = EVENTS.filter(e => e.day === dayNum);
        const isToday = dayNum === today;
        return <div key={i} className={`ui-cal-day ${isToday ? "today" : ""}`}>
          <div className="ui-cal-header"><b>{d}</b>{isToday && <span className="ui-cal-today">Aujourd'hui</span>}</div>
          <div className="ui-cal-events">
            {dayEvents.map((e, j) => <div key={j} className="ui-cal-event" style={{ borderLeftColor: typeColor[e.type] }}>
              <span>{e.icon}</span>
              <div><b>{e.title}</b><small>{e.time}</small></div>
            </div>)}
          </div>
        </div>;
      })}
    </div>
  </div>;
}
