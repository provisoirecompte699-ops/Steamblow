"use client";
import {useEffect,useMemo,useState} from "react";

type Achievement={id:string;icon:string;title:string;desc:string;xp:number};
const achievements:Achievement[]=[
 {id:"first-launch",icon:"🚀",title:"Premier lancement",desc:"Lance ton premier jeu.",xp:100},
 {id:"social",icon:"👥",title:"Esprit d'équipe",desc:"Rejoins une partie multijoueur.",xp:150},
 {id:"3d",icon:"🕶️",title:"Bienvenue en 3D",desc:"Joue à une expérience 3D Premium.",xp:250},
 {id:"collector",icon:"🎒",title:"Collectionneur",desc:"Ajoute 5 jeux à ta bibliothèque.",xp:300},
 {id:"meet-younes",icon:"👑",title:"Rencontre avec Younes",desc:"Rencontre le créateur Younes dans TheCombinedWebs.",xp:500},
 {id:"meet-moustafa",icon:"🛡️",title:"Rencontre avec Moustafa",desc:"Rencontre le vice créateur Moustafa dans TheCombinedWebs.",xp:500},
];
export default function ProgressCenter({ownedCount=0,has3D=false}:{ownedCount?:number;has3D?:boolean}){
 const [xp,setXp]=useState(0),[unlocked,setUnlocked]=useState<string[]>([]),[compact,setCompact]=useState(false),[reduced,setReduced]=useState(false);
 useEffect(()=>{try{setXp(Number(localStorage.getItem("steamblox:xp")||0));setUnlocked(JSON.parse(localStorage.getItem("steamblox:achievements")||"[]"));fetch("/api/avatar").catch(()=>{});setCompact(localStorage.getItem("steamblox:compact") === "1");setReduced(localStorage.getItem("steamblox:reduced-motion") === "1")}catch{}}
 ,[]);
 const level=Math.floor(xp/1000)+1, into=xp%1000;
 const unlock=(id:string)=>{if(unlocked.includes(id))return;const a=achievements.find(x=>x.id===id);if(!a)return;const next=[...unlocked,id];setUnlocked(next);setXp(v=>{const n=v+a.xp;localStorage.setItem("steamblox:xp",String(n));return n});localStorage.setItem("steamblox:achievements",JSON.stringify(next));};
 const eligible=useMemo(()=>new Set(["first-launch",...(ownedCount>=5?["collector"]:[]),...(has3D?["3d"]:[])]),[ownedCount,has3D]);
 return <section className="progress-center">
  <div className="progress-card card"><div className="section-head"><div><div className="eyebrow">PROGRESSION</div><h3>Niveau {level}</h3></div><span className="xp-pill">{xp} XP</span></div><div className="level-bar"><i style={{width:`${into/10}%`}}/></div><small className="muted">{1000-into} XP avant le niveau {level+1}</small></div>
  <div className="progress-card card"><div className="section-head"><div><div className="eyebrow">SUCCÈS</div><h3>{unlocked.length}/{achievements.length} débloqués</h3></div><span>🏆</span></div><div className="achievement-grid">{achievements.map(a=>{const done=unlocked.includes(a.id);const can=eligible.has(a.id);return <button key={a.id} className={`achievement ${done?"done":""}`} disabled={!can||done} onClick={()=>unlock(a.id)}><span>{done?a.icon:"🔒"}</span><div><b>{a.title}</b><small>{done?a.desc:can?`${a.desc} • +${a.xp} XP`:a.desc}</small></div></button>})}</div></div>
  <div className="progress-card card"><div className="section-head"><div><div className="eyebrow">ACCESSIBILITÉ</div><h3>Confort de jeu</h3></div><span>⚙️</span></div><div className="settings-row"><div><b>Interface compacte</b><small>Réduit les espacements du launcher.</small></div><button onClick={()=>{const n=!compact;setCompact(n);localStorage.setItem("steamblox:compact",n?"1":"0");document.documentElement.classList.toggle("sb-compact",n)}}>{compact?"Activée":"Désactivée"}</button></div><div className="settings-row"><div><b>Réduire les animations</b><small>Limite les mouvements de l'interface.</small></div><button onClick={()=>{const n=!reduced;setReduced(n);localStorage.setItem("steamblox:reduced-motion",n?"1":"0");document.documentElement.classList.toggle("sb-reduced-motion",n)}}>{reduced?"Activé":"Désactivé"}</button></div></div>
 </section>;
}
