"use client";
import { useEffect, useState } from "react";

type Mentor = { name: string; level: number; mentees: string[] };
type Mentee = { name: string; joinedAt: number };

const MKEY = "steamblox:mentorship";

export default function Mentorship({ username, friends }: { username: string; friends: string[] }) {
  const [isMentor, setIsMentor] = useState(false);
  const [mentees, setMentees] = useState<Mentee[]>([]);
  const [myMentor, setMyMentor] = useState<string | null>(null);
  const [availableMentors, setAvailableMentors] = useState<Mentor[]>([]);

  useEffect(() => {
    try {
      const data = JSON.parse(localStorage.getItem(MKEY) || "{}");
      setIsMentor(data.isMentor || false);
      setMentees(data.mentees || []);
      setMyMentor(data.myMentor || null);
    } catch {}
    // Generate fake mentors for demo
    setAvailableMentors([
      { name: "Younes", level: 42, mentees: ["Alex", "Sam"] },
      { name: "MaxPower", level: 31, mentees: ["Léa"] },
      { name: "GamerQueen", level: 28, mentees: ["Tom", "Nina", "Jade"] },
    ]);
  }, []);

  const becomeMentor = () => {
    const data = { isMentor: true, mentees: [], myMentor };
    localStorage.setItem(MKEY, JSON.stringify(data));
    setIsMentor(true);
  };

  const stopMentor = () => {
    const data = { isMentor: false, mentees: [], myMentor };
    localStorage.setItem(MKEY, JSON.stringify(data));
    setIsMentor(false);
  };

  const joinMentor = (name: string) => {
    const data = { isMentor, mentees, myMentor: name };
    localStorage.setItem(MKEY, JSON.stringify(data));
    setMyMentor(name);
  };

  return <div className="card">
    <div className="section-head"><div><div className="eyebrow">COMMUNAUTÉ</div><h3>Système de mentorat</h3></div></div>
    {isMentor ? <div className="ui-mentor-mode">
      <p className="ui-mentor-badge">🎓 Tu es mentor !</p>
      <p className="muted" style={{ fontSize: 13 }}>Tu peux parrainer de nouveaux joueurs et gagner de l'XP bonus.</p>
      <div className="ui-mentees">
        {mentees.length === 0 ? <p className="muted" style={{ fontSize: 13 }}>Aucun filleul pour le moment.</p> :
          mentees.map((m, i) => <div key={i} className="ui-mentee"><span>👤</span><b>{m.name}</b><small>Depuis {new Date(m.joinedAt).toLocaleDateString("fr-FR")}</small></div>)}
      </div>
      <button className="button secondary" style={{ marginTop: 8, fontSize: 12 }} onClick={stopMentor}>Arrêter le mentorat</button>
    </div> : <div>
      {myMentor ? <div className="ui-mentor-current">
        <p>Ton mentor : <b style={{ color: "#8b7cff" }}>{myMentor}</b></p>
        <p className="muted" style={{ fontSize: 13 }}>Profite de l'XP bonus en jouant avec lui !</p>
      </div> : <div className="ui-mentor-list">
        <p className="muted" style={{ fontSize: 13, marginBottom: 10 }}>Rejoins un mentor expérimenté pour progresser plus vite :</p>
        {availableMentors.map((m, i) => <div key={i} className="ui-mentor-item">
          <div className="ui-mentor-info"><span className="ui-mentor-ava">{m.name[0]}</span><div><b>{m.name}</b><small>Niv. {m.level} · {m.mentees.length} filleul(s)</small></div></div>
          <button className="button" style={{ padding: "4px 10px", fontSize: 12 }} onClick={() => joinMentor(m.name)}>Rejoindre</button>
        </div>)}
      </div>}
      <button className="button secondary" style={{ marginTop: 10, fontSize: 12 }} onClick={becomeMentor}>Devenir mentor (Niv. 25+)</button>
    </div>}
  </div>;
}
