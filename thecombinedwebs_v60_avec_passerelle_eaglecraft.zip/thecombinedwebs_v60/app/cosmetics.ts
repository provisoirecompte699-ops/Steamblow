"use client";
// Sons d'arrivée en vocal (synthétisés, aucun fichier audio)
let ctx: AudioContext | null = null;
export function playJoinSound(id?: string | null) {
  if (!id || typeof window === "undefined") return;
  try {
    ctx = ctx || new (window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext)();
    const c = ctx, t0 = c.currentTime;
    const tone = (f: number, at: number, dur: number, type: OscillatorType = "sine", vol = 0.18, slide?: number) => {
      const o = c.createOscillator(), g = c.createGain(); o.type = type; o.frequency.setValueAtTime(f, t0 + at); if (slide) o.frequency.exponentialRampToValueAtTime(slide, t0 + at + dur);
      g.gain.setValueAtTime(0.0001, t0 + at); g.gain.exponentialRampToValueAtTime(vol, t0 + at + 0.01); g.gain.exponentialRampToValueAtTime(0.0001, t0 + at + dur);
      o.connect(g).connect(c.destination); o.start(t0 + at); o.stop(t0 + at + dur + 0.02);
    };
    if (id === "sound-laser") { tone(1400, 0, 0.25, "sawtooth", 0.12, 200); tone(1800, 0.12, 0.2, "square", 0.06, 300); }
    else if (id === "sound-8bit") { [523, 659, 784, 1047].forEach((f, i) => tone(f, i * 0.07, 0.09, "square", 0.1)); }
    else if (id === "sound-drum") { for (let i = 0; i < 8; i++) tone(110 + Math.random() * 30, i * 0.045, 0.06, "triangle", 0.22, 60); tone(80, 0.4, 0.35, "sine", 0.35, 40); tone(1200, 0.4, 0.3, "triangle", 0.08); }
    else if (id === "sound-chime") { [880, 1318, 1760].forEach((f, i) => tone(f, i * 0.1, 0.6, "sine", 0.12)); }
  } catch { /* audio indisponible */ }
}
export const borderClass = (b?: string) => (b ? `cos-${b}` : "");
export const nameClass = (n?: string) => (n ? `cos-${n}` : "");
