"use client";
import { useEffect, useState } from "react";

type Solved = { eq: string; correct: boolean; at: number };

export default function RevisionSheet() {
  const [items, setItems] = useState<Solved[]>([]);
  const [show, setShow] = useState(false);

  useEffect(() => {
    try { setItems(JSON.parse(localStorage.getItem("algebre-facile:solved-log") || "[]")); } catch {}
  }, []);

  const wrong = items.filter(i => !i.correct).slice(-20);
  const right = items.filter(i => i.correct).slice(-10);

  const generatePDF = () => {
    const w = window.open("", "_blank");
    if (!w) return;
    const date = new Date().toLocaleDateString("fr-FR");
    w.document.write(`<!doctype html><html><head><meta charset="utf-8"><title>Fiche de révision — ${date}</title>
    <style>
      body{font-family:Georgia,serif;max-width:800px;margin:40px auto;padding:20px;color:#1a1a1a}
      h1{color:#4338ca;border-bottom:3px solid #4338ca;padding-bottom:10px}
      h2{color:#7c3aed;margin-top:30px}
      .eq{font-size:18px;padding:8px 12px;margin:4px 0;border-radius:6px}
      .wrong{background:#fee2e2;border-left:4px solid #dc2626}
      .right{background:#dcfce7;border-left:4px solid #16a34a}
      .header{text-align:center;margin-bottom:30px}
      .header p{color:#666;font-size:14px}
      .print-btn{position:fixed;top:20px;right:20px;background:#4338ca;color:#fff;border:none;padding:10px 20px;border-radius:8px;cursor:pointer;font-size:14px}
      @media print{.print-btn{display:none}}
    </style></head><body>
    <button class="print-btn" onclick="window.print()">🖨️ Imprimer / PDF</button>
    <div class="header"><h1>📐 Fiche de révision d'algèbre</h1><p>TheCombinedWebs · ${date}</p></div>
    <h2>❌ À retravailler (${wrong.length})</h2>
    ${wrong.length ? wrong.map(i => `<div class="eq wrong">${i.eq}</div>`).join("") : "<p>Aucune erreur récente, bravo !</p>"}
    <h2>✓ Réussis récemment (${right.length})</h2>
    ${right.length ? right.map(i => `<div class="eq right">${i.eq}</div>`).join("") : "<p>Pas encore d'exercice réussi.</p>"}
    <h2>💡 Conseils</h2>
    <ul>
    ${wrong.length > 5 ? "<li>Beaucoup d'erreurs récentes : revois les bases du chapitre correspondant.</li>" : ""}
    ${wrong.some(i => i.eq.includes("²")) ? "<li>Les équations du second degré te posent problème : revois le discriminant et les racines.</li>" : ""}
    ${wrong.some(i => i.eq.includes("/")) ? "<li>Les fractions sont difficiles : entraîne-toi au niveau 5.</li>" : ""}
    ${wrong.some(i => i.eq.includes("(")) ? "<li>Les parenthèses : pense à distribuer le signe devant !</li>" : ""}
    <li>Le mode histoire t'aide à progresser étape par étape.</li>
    <li>Fais un examen blanc régulièrement pour suivre tes progrès.</li>
    </ul>
    </body></html>`);
    w.document.close();
  };

  const logExercise = (eq: string, correct: boolean) => {
    const log = JSON.parse(localStorage.getItem("algebre-facile:solved-log") || "[]");
    log.push({ eq, correct, at: Date.now() });
    localStorage.setItem("algebre-facile:solved-log", JSON.stringify(log.slice(-100)));
    setItems(log.slice(-100));
  };

  useEffect(() => {
    (window as unknown as { __logExercise?: (eq: string, correct: boolean) => void }).__logExercise = logExercise;
  }, []);

  return <div className="card">
    <div className="section-head"><div><div className="eyebrow">RÉVISION</div><h3>Fiche de révision PDF</h3></div>
      <button className="button secondary" style={{ padding: "6px 12px", fontSize: 12 }} onClick={generatePDF}>📄 Générer</button>
    </div>
    <div className="muted" style={{ fontSize: 13 }}>
      {wrong.length} erreur(s) récente(s) à retravailler.
      {!wrong.length && right.length > 0 && " Aucune erreur, continue !"}
      {!wrong.length && !right.length && " Fais des exercices pour remplir ta fiche."}
    </div>
  </div>;
}
