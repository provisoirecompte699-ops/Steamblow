"use client";
import { useEffect } from "react";
/** Applique le thème choisi (néon, minimal clair, rétro pixel) sur toutes les pages. */
export default function ThemeManager() {
  useEffect(() => {
    const apply = () => { let t="default";try{t=localStorage.getItem("steamblox:theme")||"default";}catch{} if (t === "default") delete document.documentElement.dataset.sbtheme; else document.documentElement.dataset.sbtheme = t; };
    apply(); window.addEventListener("sb-theme", apply); window.addEventListener("storage", apply);
    return () => { window.removeEventListener("sb-theme", apply); window.removeEventListener("storage", apply); };
  }, []);
  return null;
}
