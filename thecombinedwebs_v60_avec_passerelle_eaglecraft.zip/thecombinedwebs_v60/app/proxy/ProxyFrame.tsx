"use client";
import { useEffect, useState } from "react";

type Info = { configured: boolean; url?: string; isolated?: boolean; error?: string };
const btn = { padding: "8px 12px", borderRadius: 9, border: "1px solid #2a2e38", background: "#181b22", color: "#fff", fontSize: 12, fontWeight: 700, cursor: "pointer", textDecoration: "none" } as const;

/** Affiche un site via le proxy TCB (iframe). Pour GTA : la page hôte doit être isolée (COOP/COEP) pour que SharedArrayBuffer fonctionne. */
export default function ProxyFrame({ site, fallbackUrl, label, portal = false, game }: { site: string; fallbackUrl: string; label: string; portal?: boolean; game?: string }) {
  const [info, setInfo] = useState<Info | null>(null); const [iso, setIso] = useState<boolean | null>(null); const [loading, setLoading] = useState(true);
  useEffect(() => {
    setIso(typeof window !== "undefined" ? window.crossOriginIsolated : null);
    fetch(`/api/proxy/ticket?${portal ? "portal" : "site"}=${encodeURIComponent(site)}${game ? `&game=${encodeURIComponent(game)}` : ""}`, { cache: "no-store" }).then(async (r) => setInfo(r.ok ? await r.json() : { configured: false, error: (await r.json().catch(() => ({}))).error })).catch(() => setInfo({ configured: false, error: "Réseau indisponible" }));
  }, [site, portal, game]);
  if (!info) return <div style={{ height: "calc(100dvh - 100px)", display: "grid", placeItems: "center", color: "#aaa" }}>Préparation du proxy…</div>;
  if (!info.configured) return <div style={{ height: "calc(100dvh - 100px)", display: "grid", placeItems: "center", padding: 24, textAlign: "center" }}><div style={{ maxWidth: 460 }}>
    <h2 style={{ margin: "0 0 10px" }}>Proxy non configuré</h2>
    <p style={{ color: "#8b909c", lineHeight: 1.5 }}>{info.error || `Pour afficher ${label} dans le site, déploie le dossier proxy-server/ (voir PROXY_SERVER.md) puis définis NEXT_PUBLIC_PROXY_URL et redéploie.`}</p>
    <a style={{ ...btn, background: "#8b7cff", display: "inline-block" }} href={fallbackUrl} target="_blank" rel="noopener noreferrer">Ouvrir {label} ↗</a></div></div>;
  const needIso = !!info.isolated && iso === false;
  return <div style={{ position: "relative", width: "100%", height: "calc(100dvh - 100px)", background: "#000" }}>
    <iframe title={label} src={info.url} onLoad={() => setLoading(false)} allow="autoplay; fullscreen; gamepad; keyboard-map; cross-origin-isolated; clipboard-write; microphone" allowFullScreen style={{ width: "100%", height: "100%", border: 0, display: "block", background: "#000" }} />
    {loading && <div style={{ position: "absolute", inset: 0, display: "grid", placeItems: "center", background: "rgba(0,0,0,.7)", color: "#ccc", fontFamily: "monospace", fontSize: 13, pointerEvents: "none" }}>Chargement de {label} via le proxy… (peut prendre 1–2 min)</div>}
    <div style={{ position: "absolute", bottom: 12, right: 12, display: "flex", gap: 8, flexWrap: "wrap", justifyContent: "flex-end", zIndex: 5 }}>
      {info.isolated && <span style={{ ...btn, background: "rgba(0,0,0,.75)", color: needIso ? "#ffb3ba" : "#8ef0c0" }}>{iso === null ? "…" : needIso ? "Isolation cross-origin inactive" : "Isolation cross-origin active ✓"}</span>}
      <a style={{ ...btn, background: "#8b7cff" }} href={info.url} target="_blank" rel="noopener noreferrer">Plein écran (proxy) ↗</a>
      <a style={btn} href={fallbackUrl} target="_blank" rel="noopener noreferrer">Source d’origine ↗</a>
    </div>
    {needIso && <p style={{ position: "absolute", top: 10, left: 10, right: 10, margin: 0, padding: "8px 12px", borderRadius: 9, background: "rgba(40,10,14,.9)", color: "#ffd0d6", fontSize: 12 }}>La page hôte n’est pas isolée : redéploie le site avec NEXT_PUBLIC_PROXY_URL défini (les en-têtes COOP/COEP sont ajoutés au build).</p>}
  </div>;
}
