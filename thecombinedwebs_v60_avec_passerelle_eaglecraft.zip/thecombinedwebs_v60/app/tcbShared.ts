export type Parental = { pinHash: string; limitMin: number; hidden: string[] };
export async function hashPin(pin: string) {
  const b = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(`tcb:${pin}`));
  return Array.from(new Uint8Array(b)).map((x) => x.toString(16).padStart(2, "0")).join("");
}
export function loadParental(): Parental | null { try { const p = JSON.parse(localStorage.getItem("tcb:parental") || "null"); return p && p.pinHash ? p : null; } catch { return null; } }
export function saveParental(p: Parental) { localStorage.setItem("tcb:parental", JSON.stringify(p)); window.dispatchEvent(new Event("tcb-settings")); }
