import { redirect } from "next/navigation";
import Link from "next/link";
import { registerAccount, safeNext } from "@/lib/login";

export default async function Register({ searchParams }: { searchParams?: Promise<{ error?: string; next?: string }> }) {
  const q = searchParams ? await searchParams : {};
  const error = q.error || "";
  const next = safeNext(q.next, "");

  async function register(fd: FormData) {
    "use server";
    const target = safeNext(String(fd.get("next") || ""), "/steamblox");
    const r = await registerAccount(String(fd.get("username") || ""), String(fd.get("password") || ""));
    if (!r.ok) {
      const p = new URLSearchParams({ error: r.error });
      if (target !== "/steamblox") p.set("next", target);
      redirect(`/register?${p.toString()}`);
      return;
    }
    redirect(target);
  }

  return <main className="wrap">
    <section className="card" style={{ maxWidth: 460, margin: "70px auto" }}>
      <div className="eyebrow">ÉCOSYSTÈME THECOMBINEDWEBS</div>
      <h1>Créer un compte</h1>
      <p className="status">Ce compte fonctionne aussi sur CinéStream, Vortex et Baldi&apos;s Basics 3D.</p>
      {error === "username" && <p className="status error" role="alert">Le pseudo doit contenir 3 à 20 caractères : lettres, chiffres ou _.</p>}
      {error === "password" && <p className="status error" role="alert">Le mot de passe doit contenir au moins 6 caractères.</p>}
      {error === "exists" && <p className="status error" role="alert">Ce pseudo existe déjà.</p>}
      <form action={register} className="form-stack">
        <input type="hidden" name="next" value={next} />
        <label>Pseudo<input className="input" name="username" minLength={3} maxLength={20} required autoComplete="username" /></label>
        <label>Mot de passe<input className="input" name="password" type="password" minLength={6} required autoComplete="new-password" /></label>
        <button className="button">Créer mon compte</button>
      </form>
      <p className="status" style={{ marginTop: 16 }}>Déjà inscrit ? <Link href={next ? `/login?next=${encodeURIComponent(next)}` : "/login"}>Connexion</Link></p>
      <p className="status" style={{ marginTop: 8, opacity: .7 }}>Crédits : Walid</p>
    </section>
  </main>;
}
