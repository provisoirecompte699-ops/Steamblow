"use client";
import { useEffect, useState } from "react";

type Notif = { id: string; icon: string; text: string; at: number; read: boolean };

const NKEY = "steamblox:notifications";

export function pushNotif(icon: string, text: string) {
  try {
    const all = JSON.parse(localStorage.getItem(NKEY) || "[]");
    all.unshift({ id: Date.now().toString(36) + Math.random().toString(36).slice(2), icon, text, at: Date.now(), read: false });
    localStorage.setItem(NKEY, JSON.stringify(all.slice(0, 50)));
    window.dispatchEvent(new Event("steamblox-notif"));
  } catch {}
}

export default function InAppNotifications() {
  const [notifs, setNotifs] = useState<Notif[]>([]);
  const [open, setOpen] = useState(false);

  useEffect(() => {
    const load = () => { try { setNotifs(JSON.parse(localStorage.getItem(NKEY) || "[]")); } catch {} };
    load();
    window.addEventListener("steamblox-notif", load);
    const t = setInterval(load, 5000);
    return () => { window.removeEventListener("steamblox-notif", load); clearInterval(t); };
  }, []);

  const unread = notifs.filter(n => !n.read).length;

  const markRead = () => {
    const updated = notifs.map(n => ({ ...n, read: true }));
    setNotifs(updated);
    localStorage.setItem(NKEY, JSON.stringify(updated));
  };

  const clear = () => { setNotifs([]); localStorage.setItem(NKEY, "[]"); };

  return <>
    <button className="ui-notif-btn" onClick={() => { setOpen(!open); if (!open) markRead(); }}>
      🔔{unread > 0 && <span className="ui-notif-badge">{unread}</span>}
    </button>
    {open && <div className="ui-notif-panel">
      <div className="ui-notif-header"><b>Notifications</b>{notifs.length > 0 && <button className="ui-notif-clear" onClick={clear}>Tout effacer</button>}</div>
      {notifs.length === 0 ? <p className="ui-notif-empty">Aucune notification</p> : <div className="ui-notif-list">
        {notifs.map(n => <div key={n.id} className={`ui-notif-item ${n.read ? "" : "unread"}`}>
          <span className="ui-notif-icon">{n.icon}</span>
          <div><p>{n.text}</p><small>{new Date(n.at).toLocaleTimeString("fr-FR", { hour: "2-digit", minute: "2-digit" })}</small></div>
        </div>)}
      </div>}
    </div>}
  </>;
}
