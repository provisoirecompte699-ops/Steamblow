"use client";
import Link from "next/link";
import { useCallback, useEffect, useState } from "react";

type C = { id: string | null; name: string; tag: string; emoji: string; color: string; motto: string; owner: string; members: string[]; open: boolean; xp: number; avgLevel: number };
type D = { me: string; mine: (C & { id: string }) | null; ranking: C[]; emojis: string[]; colors: string[]; max: number };
const low = (s: string) => s.toLowerCase();

export default function Client({ me }: { me: string }) {
  const [d, setD] = useState<D | null>(null);
  const [f, setF] = useState({ name: "", tag: "", emoji: "🐺", color: "#8b7cff", motto: "", open: true });
  const [code, setCode] = useState("");
  const [msg, setMsg] = useState<{ t: string; err?: boolean } | null>(null);
  const load = useCallback(async () => setD(await (await fetch("/api/clans")).json()), []);
  useEffect(() => { load(); }, [load]);
  const act = async (action: string, extra: Record<string, unknown> = {}) => {
    setMsg(null); const r = await (await fetch("/api/clans", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ action, ...extra }) })).json();
    if (r.error) setMsg({ t: r.error, err: true }); else { setMsg({ t: "C’est fait." }); load(); }
  };
  if (!d) return <div className="hub-empty">Chargement…</div>;
  const mine = d.mine;
  const rank = mine ? d.ranking.findIndex((c) => c.tag === mine.tag) + 1 : 0;
  return <>
    <div className="hub-head"><div><span className="hub-kick">Communauté</span><h1>Clans</h1><p>Forme une équipe de {d.max} joueurs maximum avec ton logo, ton salon privé texte et vocal sur Discord, et grimpe au classement des clans (somme de l’XP des membres).</p></div></div>
    {msg && <p className={`hub-msg ${msg.err ? "err" : ""}`}>{msg.t}</p>}
    {mine ? <div className="hub-card" style={{ marginBottom: 16 }}>
      <div className="hub-row" style={{ gap: 16 }}>
        <div className="clan-logo" style={{ background: mine.color + "33", border: `2px solid ${mine.color}` }}>{mine.emoji}</div>
        <div style={{ flex: 1 }}><div className="hub-row"><h2 style={{ margin: 0 }}>{mine.name}</h2><span className="clan-tag" style={{ color: mine.color }}>[{mine.tag}]</span>{rank > 0 && <span className="hub-pill acc">{rank}{rank === 1 ? "er" : "e"} au classement</span>}</div>
          <p className="hub-muted" style={{ margin: "4px 0 0" }}>{mine.motto || "Pas encore de devise"} · chef : {mine.owner} · code d’invitation : <b style={{ color: "#fff" }}>{mine.id}</b></p></div>
        <div className="hub-row"><Link className="hub-btn acc" href="/discord">Salon du clan</Link><button className="hub-btn danger" onClick={() => confirm("Quitter le clan ?") && act("leave")}>Quitter</button></div>
      </div>
      <h3 style={{ marginTop: 18 }}>Membres ({mine.members.length}/{d.max})</h3>
      <div className="hub-row">{mine.members.map((m) => <span key={m} className="hub-pill"><Link href={`/u/${encodeURIComponent(m)}`}>{m}</Link>{low(m) === low(mine.owner) ? " 👑" : ""}{low(mine.owner) === low(me) && low(m) !== low(me) && <button className="hub-btn sm" style={{ padding: "1px 7px" }} onClick={() => act("kick", { target: m })} aria-label={`Exclure ${m}`}>×</button>}</span>)}</div>
      {low(mine.owner) === low(me) && <div className="hub-row" style={{ marginTop: 14 }}>
        <input className="hub-input" style={{ flex: 1, minWidth: 200 }} defaultValue={mine.motto} placeholder="Devise du clan" maxLength={80} onBlur={(e) => e.target.value !== mine.motto && act("update", { motto: e.target.value })} />
        <label className="hub-row hub-muted" style={{ gap: 6 }}><input type="checkbox" defaultChecked={mine.open} onChange={(e) => act("update", { open: e.target.checked })} /> Clan public</label>
      </div>}
    </div> : <div className="hub-grid" style={{ marginBottom: 16 }}>
      <div className="hub-card">
        <h3>Créer mon clan</h3>
        <div style={{ display: "grid", gap: 10 }}>
          <div className="hub-row"><input className="hub-input" style={{ flex: 2 }} placeholder="Nom du clan" maxLength={28} value={f.name} onChange={(e) => setF({ ...f, name: e.target.value })} /><input className="hub-input" style={{ flex: 1, minWidth: 90 }} placeholder="TAG" maxLength={5} value={f.tag} onChange={(e) => setF({ ...f, tag: e.target.value.toUpperCase() })} /></div>
          <input className="hub-input" placeholder="Devise (facultatif)" maxLength={80} value={f.motto} onChange={(e) => setF({ ...f, motto: e.target.value })} />
          <div className="emoji-pick">{d.emojis.map((e) => <button key={e} className={f.emoji === e ? "on" : ""} onClick={() => setF({ ...f, emoji: e })}>{e}</button>)}</div>
          <div className="hub-row color-pick">{d.colors.map((c) => <button key={c} className={f.color === c ? "on" : ""} style={{ background: c }} onClick={() => setF({ ...f, color: c })} aria-label={c} />)}</div>
          <label className="hub-row hub-muted" style={{ gap: 6 }}><input type="checkbox" checked={f.open} onChange={(e) => setF({ ...f, open: e.target.checked })} /> Public (tout le monde peut rejoindre)</label>
          <button className="hub-btn pri" onClick={() => act("create", f)}>Créer le clan</button>
        </div>
      </div>
      <div className="hub-card"><h3>Rejoindre avec un code</h3><p className="hub-muted">Les clans privés se rejoignent avec le code donné par un membre.</p>
        <div className="hub-row"><input className="hub-input" placeholder="CODE" value={code} maxLength={6} onChange={(e) => setCode(e.target.value.toUpperCase())} /><button className="hub-btn pri" onClick={() => act("join", { id: code })}>Rejoindre</button></div></div>
    </div>}
    <div className="hub-card"><h3>Classement des clans</h3>
      {!d.ranking.length ? <div className="hub-empty">Aucun clan pour l’instant.</div> :
        <table className="hub-table"><thead><tr><th>#</th><th>Clan</th><th>Membres</th><th>XP totale</th><th></th></tr></thead><tbody>
          {d.ranking.map((c, i) => <tr key={c.tag} className={mine?.tag === c.tag ? "me" : ""}><td className={`hub-rank r${i + 1}`}>{i + 1}</td>
            <td><span style={{ fontSize: 20, marginRight: 8 }}>{c.emoji}</span><b>{c.name}</b> <span className="clan-tag" style={{ color: c.color }}>[{c.tag}]</span><div className="hub-muted" style={{ fontSize: 12.5 }}>{c.motto}</div></td>
            <td>{c.members.length}/{d.max}</td><td><b>{c.xp.toLocaleString("fr-FR")}</b> <span className="hub-muted">· niv. moy. {c.avgLevel}</span></td>
            <td>{!mine && c.id && c.open && c.members.length < d.max && <button className="hub-btn sm" onClick={() => act("join", { id: c.id })}>Rejoindre</button>}{!c.open && <span className="hub-pill">Privé</span>}</td></tr>)}
        </tbody></table>}
    </div>
  </>;
}
