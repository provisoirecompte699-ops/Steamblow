"use client";
import { useEffect, useState } from "react";
type BIP = Event & { prompt: () => Promise<void>; userChoice: Promise<{ outcome: string }> };
/** Bouton « Installer l'application » (PWA). Masqué dans l'APK Android. */
export default function InstallPrompt() {
  const [ev, setEv] = useState<BIP | null>(null);
  const [hide, setHide] = useState(true);
  useEffect(() => {
    if (navigator.userAgent.includes("SteambloxApp") || matchMedia("(display-mode: standalone)").matches) return;
    try{if (localStorage.getItem("steamblox:install-dismissed") === "1") return;}catch{}
    const h = (e: Event) => { e.preventDefault(); setEv(e as BIP); setHide(false); };
    window.addEventListener("beforeinstallprompt", h);
    return () => window.removeEventListener("beforeinstallprompt", h);
  }, []);
  if (hide || !ev) return null;
  return <div style={{ position: "fixed", left: 16, bottom: 16, zIndex: 9000, display: "flex", gap: 8, alignItems: "center", background: "#151821", border: "1px solid #2a2f3a", borderRadius: 14, padding: "8px 8px 8px 14px", color: "#fff", boxShadow: "0 12px 40px #0008", fontSize: 14, fontWeight: 650 }}>
    Installer TheCombinedWebs comme une app
    <button onClick={async () => { await ev.prompt(); await ev.userChoice; setHide(true); }} style={{ border: 0, borderRadius: 10, padding: "8px 12px", background: "#fff", color: "#0b0c10", fontWeight: 800, cursor: "pointer" }}>Installer</button>
    <button aria-label="Plus tard" onClick={() => { try{localStorage.setItem("steamblox:install-dismissed", "1");}catch{} setHide(true); }} style={{ border: 0, background: "transparent", color: "#8b91a0", fontSize: 18, cursor: "pointer" }}>×</button>
  </div>;
}
