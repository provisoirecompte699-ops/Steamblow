"use client";
import { useEffect, useState } from "react";
import "./features.css";
export default function RiskDuels() {
  const [d, setD] = useState<any>(null),
    [to, setTo] = useState(""),
    [stake, setStake] = useState(10),
    [busy, setBusy] = useState(false),
    [msg, setMsg] = useState(""),
    [error, setError] = useState("");
  const load = async () => {
    try {
      const r = await fetch("/api/risk-duels", { cache: "no-store" });
      if (r.ok) setD(await r.json());
    } catch {}
  };
  useEffect(() => {
    load();
    const t = setInterval(load, 1500);
    return () => clearInterval(t);
  }, []);
  useEffect(()=>{
    const fn=()=>JSON.stringify({kind:"risk-duels",username:d?.username,duels:d?.duels||[],coordinates:"Interface HTML, cases ordonnées de 1 à 6"});
    (window as any).render_game_to_text=fn;
    return()=>{if((window as any).render_game_to_text===fn)delete (window as any).render_game_to_text;};
  },[d]);
  const act = async (b: any) => {
    setBusy(true);
    setError("");
    try {
      const r = await fetch("/api/risk-duels", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify(b),
      });
      const v = await r.json();
      if (!r.ok) throw new Error(v.error);
      setMsg(v.message);
      await load();
    } catch (e) {
      setError((e as Error).message);
    } finally {
      setBusy(false);
    }
  };
  return (
    <section className="f-card f-stack">
      <div>
        <span className="f-kicker">Duel entre amis</span>
        <h2>Roulette russe</h2>
        <p className="f-muted">
          Six cases, une seule case fatale, chacun joue à son tour.
          L'élimination concerne uniquement le personnage du mini-jeu. Le
          gagnant reçoit les deux mises depuis les comptes bancaires.
        </p>
      </div>
      {d ? (
        <>
          <div className="f-fields">
            <label className="f-field">
              Ami à inviter
              <select
                value={to || d.friends[0] || ""}
                onChange={(e) => setTo(e.target.value)}
              >
                {!d.friends.length && <option value="">Aucun ami</option>}
                {d.friends.map((f: string) => (
                  <option key={f}>{f}</option>
                ))}
              </select>
            </label>
            <label className="f-field">
              Mise de chaque joueur
              <input
                type="number"
                min={1}
                max={10000}
                value={stake}
                onChange={(e) => setStake(Number(e.target.value))}
              />
            </label>
          </div>
          <button
            data-testid="button-create-risk-duel"
            className="f-btn primary"
            disabled={busy || !d.friends.length}
            onClick={() =>
              act({ action: "create", to: to || d.friends[0], stake })
            }
          >
            Inviter et réserver {stake} Bobux
          </button>
          {d.duels.map((duel: any) => (
            <article key={duel.id} className="f-card">
              <h3>
                {duel.from} contre {duel.to}
              </h3>
              <p>
                {duel.stake} Bobux chacun · cagnotte {duel.stake * 2} Bobux
              </p>
              <div className="f-row" aria-label="Les six cases du duel">
                {Array.from({ length: 6 }, (_, i) => (
                  <span
                    key={i}
                    style={{
                      width: 44,
                      height: 44,
                      display: "grid",
                      placeItems: "center",
                      border: "1px solid var(--f-edge)",
                      borderRadius: 6,
                      background: duel.moves[i]
                        ? duel.moves[i].safe
                          ? "#3a543b"
                          : "#a33237"
                        : "var(--f-bg)",
                      color: duel.moves[i] ? "white" : "var(--f-text)",
                    }}
                  >
                    {duel.moves[i] ? (duel.moves[i].safe ? "✓" : "×") : i + 1}
                  </span>
                ))}
              </div>
              {duel.status === "pending" ? (
                <div className="f-row" style={{ marginTop: 16 }}>
                  {duel.to === d.username && (
                    <button
                      className="f-btn primary"
                      disabled={busy}
                      onClick={() => act({ action: "accept", id: duel.id })}
                    >
                      Accepter et miser {duel.stake}
                    </button>
                  )}
                  <button
                    className="f-btn"
                    disabled={busy}
                    onClick={() => act({ action: "cancel", id: duel.id })}
                  >
                    Refuser / annuler
                  </button>
                </div>
              ) : duel.status === "active" ? (
                <>
                  <p>
                    Tour de {duel.turn} · {6 - duel.position} cases restantes.
                  </p>
                  <button
                    className="f-btn primary"
                    disabled={busy || duel.turn !== d.username}
                    onClick={() =>
                      act({
                        action: "play",
                        id: duel.id,
                        position: duel.position,
                      })
                    }
                  >
                    {duel.turn === d.username
                      ? "Jouer mon tour"
                      : "Attendre mon ami"}
                  </button>
                </>
              ) : duel.status === "finished" ? (
                <p className="f-note">
                  {duel.eliminated} est éliminé virtuellement. {duel.winner}{" "}
                  remporte {duel.stake * 2} Bobux.
                </p>
              ) : (
                <p className="f-muted">Duel annulé, mises rendues.</p>
              )}
            </article>
          ))}
        </>
      ) : (
        <p className="f-muted">
          Connecte-toi et ajoute un ami pour lancer un duel.
        </p>
      )}
      {error && (
        <p className="f-note f-error" role="alert">
          {error}
        </p>
      )}
      {msg && (
        <p className="f-note" role="status">
          {msg}
        </p>
      )}
    </section>
  );
}
