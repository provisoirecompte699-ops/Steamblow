"use client";
import Link from "next/link";
import { useCallback, useEffect, useState } from "react";

type M = { id: string; a: string | null; b: string | null; sa?: number; sb?: number; winner?: string | null };
type T = { id: string; name: string; gameId: string; size: number; createdBy: string; players: string[]; status: string; rounds: M[][]; champion?: string };
type G = { id: string; title: string };
const low = (s?: string | null) => (s || "").toLowerCase();
const roundName = (i: number, n: number) => (i === n - 1 ? "Finale" : i === n - 2 ? "Demi-finales" : "Quarts de finale");

export default function Client({ me }: { me: string }) {
  const [games, setGames] = useState<G[]>([]);
  const [list, setList] = useState<T[]>([]);
  const [open, setOpen] = useState<T | null>(null);
  const [myMatch, setMyMatch] = useState<M | null>(null);
  const [form, setForm] = useState({ name: "", gameId: "meteor-mayhem", size: 4 });
  const [msg, setMsg] = useState("");
  const load = useCallback(async () => { const d = await (await fetch("/api/tournaments")).json(); if (d.games) { setGames(d.games); setList(d.tournaments); } }, []);
  const openT = useCallback(async (id: string) => { const d = await (await fetch(`/api/tournaments?id=${id}`)).json(); if (d.tournament) { setOpen(d.tournament); setMyMatch(d.myMatch); history.replaceState(null, "", `?id=${id}`); } }, []);
  useEffect(() => { load(); const id = new URLSearchParams(location.search).get("id"); if (id) openT(id); }, [load, openT]);
  useEffect(() => { if (!open) return; const t = setInterval(() => openT(open.id), 6000); return () => clearInterval(t); }, [open, openT]);
  const act = async (action: string, extra: Record<string, unknown> = {}) => {
    setMsg(""); const d = await (await fetch("/api/tournaments", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ action, ...extra }) })).json();
    if (d.error) { setMsg(d.error); return; } await load(); if (d.tournament) openT(d.tournament.id); else { setOpen(null); history.replaceState(null, "", "/tournois"); }
  };
  const title = (id: string) => games.find((g) => g.id === id)?.title || id;
  const status = (t: T) => t.status === "open" ? <span className="hub-pill wait">Inscriptions {t.players.length}/{t.size}</span> : t.status === "running" ? <span className="hub-pill acc">En cours</span> : <span className="hub-pill ok">🏆 {t.champion}</span>;

  if (open) {
    const joined = open.players.some((p) => low(p) === low(me));
    return <>
      <div className="hub-head"><div><span className="hub-kick">Tournoi · {title(open.gameId)}</span><h1>{open.name}</h1><p>Chaque match : les deux joueurs font une partie sur la même carte. Le meilleur score passe. Le champion gagne 200 Bobux et le badge Champion.</p></div>
        <div className="hub-row"><button className="hub-btn" onClick={() => { setOpen(null); history.replaceState(null, "", "/tournois"); }}>← Tous les tournois</button>{status(open)}</div></div>
      {msg && <p className="hub-msg err">{msg}</p>}
      {open.status === "open" && <div className="hub-card" style={{ marginBottom: 16 }}>
        <h3>Joueurs inscrits</h3><div className="hub-row" style={{ marginBottom: 12 }}>{open.players.map((p) => <span key={p} className="hub-pill">{p}{low(p) === low(open.createdBy) ? " · organisateur" : ""}</span>)}</div>
        <div className="hub-row">
          {!joined && <button className="hub-btn pri" onClick={() => act("join", { id: open.id })}>S’inscrire</button>}
          {joined && low(open.createdBy) !== low(me) && <button className="hub-btn" onClick={() => act("leave", { id: open.id })}>Se désinscrire</button>}
          {low(open.createdBy) === low(me) && <button className="hub-btn acc" disabled={open.players.length < 2} onClick={() => act("start", { id: open.id })}>Lancer maintenant ({open.players.length} joueurs)</button>}
          <button className="hub-btn" onClick={() => { navigator.clipboard?.writeText(`${location.origin}/tournois?id=${open.id}`); setMsg("Lien copié, envoie-le à tes amis sur Discord."); }}>Copier le lien d’invitation</button>
        </div></div>}
      {myMatch && open.status === "running" && <div className="hub-card hub-daily" style={{ marginBottom: 16 }}><div><span className="hub-kick">À toi de jouer</span><br /><b>Match contre {low(myMatch.a) === low(me) ? myMatch.b : myMatch.a}</b><div className="hub-muted">Une seule tentative, fais ton meilleur score.</div></div><Link className="hub-btn pri" href={`/games/${open.gameId}?t=${open.id}`}>Jouer mon match</Link></div>}
      {open.rounds.length > 0 && <div className="hub-card"><div className="bracket">{open.rounds.map((r, i) => <div className="bracket-col" key={i}><h4>{roundName(i, open.rounds.length)}</h4>
        {r.map((m) => <div key={m.id} className={`match ${low(m.a) === low(me) || low(m.b) === low(me) ? "mine" : ""}`}>
          {([["a", "sa"], ["b", "sb"]] as const).map(([k, sk]) => <div key={k} className={m.winner && m.winner === m[k] ? "win" : m[k] ? "" : "tbd"}><span>{m[k] || (m.winner !== undefined ? "—" : "À venir")}</span><span>{m[sk] != null ? m[sk]!.toLocaleString("fr-FR") : m[k] && m.winner === undefined ? "…" : ""}</span></div>)}
        </div>)}</div>)}</div></div>}
    </>;
  }
  return <>
    <div className="hub-head"><div><span className="hub-kick">Compétition</span><h1>Tournois</h1><p>Crée un tableau à 4 ou 8 joueurs, invite tes amis, et suivez le bracket en direct. 200 Bobux pour le champion.</p></div></div>
    <div className="hub-card" style={{ marginBottom: 16 }}>
      <h3>Créer un tournoi</h3>
      <div className="hub-row">
        <input className="hub-input" placeholder="Nom du tournoi" value={form.name} maxLength={40} onChange={(e) => setForm({ ...form, name: e.target.value })} />
        <select className="hub-select" value={form.gameId} onChange={(e) => setForm({ ...form, gameId: e.target.value })}>{games.map((g) => <option key={g.id} value={g.id}>{g.title}</option>)}</select>
        <select className="hub-select" value={form.size} onChange={(e) => setForm({ ...form, size: Number(e.target.value) })}><option value={4}>4 joueurs</option><option value={8}>8 joueurs</option></select>
        <button className="hub-btn pri" onClick={() => act("create", form)}>Créer</button>
      </div>{msg && <p className="hub-msg err">{msg}</p>}
      <p className="hub-muted" style={{ marginBottom: 0, fontSize: 13 }}>Pour jouer un match, il faut posséder le jeu (sauf les jeux gratuits).</p>
    </div>
    {!list.length ? <div className="hub-card hub-empty">Aucun tournoi pour l’instant. Crée le premier.</div> :
      <div className="hub-grid">{list.map((t) => <button key={t.id} className="hub-card" style={{ textAlign: "left", cursor: "pointer", color: "inherit", font: "inherit" }} onClick={() => openT(t.id)}>
        <div className="hub-row" style={{ justifyContent: "space-between" }}><b style={{ fontSize: 17 }}>{t.name}</b>{status(t)}</div>
        <p className="hub-muted" style={{ margin: "8px 0 0" }}>{title(t.gameId)} · {t.size} joueurs · par {t.createdBy}</p>
      </button>)}</div>}
  </>;
}
