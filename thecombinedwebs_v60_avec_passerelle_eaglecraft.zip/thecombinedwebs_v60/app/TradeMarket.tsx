"use client";
import { useEffect, useState } from "react";

type Cosmetic = { id: string; name: string; icon: string; rarity: "common" | "rare" | "epic" | "legendary" };
type Trade = { id: string; from: string; offer: Cosmetic; want: Cosmetic; at: number; status: "open" | "accepted" | "declined" };

const COSMETICS: Cosmetic[] = [
  { id: "c1", name: "Bordure Néon", icon: "🔷", rarity: "common" },
  { id: "c2", name: "Bordure Or", icon: "🟡", rarity: "rare" },
  { id: "c3", name: "Bordure Diamant", icon: "💎", rarity: "epic" },
  { id: "c4", name: "Skin Galaxie", icon: "🌌", rarity: "legendary" },
  { id: "c5", name: "Skin Volcanique", icon: "🌋", rarity: "epic" },
  { id: "c6", name: "Skin Polaire", icon: "🐧", rarity: "rare" },
  { id: "c7", name: "Bordure Arc-en-ciel", icon: "🌈", rarity: "legendary" },
  { id: "c8", name: "Skin Forêt", icon: "🌳", rarity: "common" },
];

const SAMPLE_TRADES: Trade[] = [
  { id: "t1", from: "NeonNinja", offer: COSMETICS[0], want: COSMETICS[1], at: Date.now() - 3600000, status: "open" },
  { id: "t2", from: "SpeedGamer", offer: COSMETICS[5], want: COSMETICS[3], at: Date.now() - 7200000, status: "open" },
  { id: "t3", from: "ProGamer_X", offer: COSMETICS[2], want: COSMETICS[6], at: Date.now() - 86400000, status: "open" },
];

const TKEY = "steamblox:trades";
const OWNED_KEY = "steamblox:owned-cosmetics";

export default function TradeMarket({ username }: { username: string }) {
  const [trades, setTrades] = useState<Trade[]>([]);
  const [owned, setOwned] = useState<Cosmetic[]>([]);
  const [offerId, setOfferId] = useState("");
  const [wantId, setWantId] = useState("");

  useEffect(() => {
    try {
      const stored = JSON.parse(localStorage.getItem(TKEY) || "[]");
      setTrades([...SAMPLE_TRADES, ...stored]);
      const ownedIds = JSON.parse(localStorage.getItem(OWNED_KEY) || "[]");
      setOwned(COSMETICS.filter(c => ownedIds.includes(c.id)));
    } catch {}
    // Grant some cosmetics if none
    if (owned.length === 0) {
      const starter = [COSMETICS[0].id, COSMETICS[7].id];
      localStorage.setItem(OWNED_KEY, JSON.stringify(starter));
      setOwned([COSMETICS[0], COSMETICS[7]]);
    }
  }, []);

  const createTrade = () => {
    if (!offerId || !wantId || offerId === wantId) return;
    const trade: Trade = { id: Date.now().toString(36), from: username, offer: COSMETICS.find(c => c.id === offerId)!, want: COSMETICS.find(c => c.id === wantId)!, at: Date.now(), status: "open" };
    const stored = JSON.parse(localStorage.getItem(TKEY) || "[]");
    stored.unshift(trade);
    localStorage.setItem(TKEY, JSON.stringify(stored.slice(0, 30)));
    setTrades([trade, ...trades.filter(t => t.id !== trade.id)]);
    setOfferId(""); setWantId("");
  };

  const acceptTrade = (id: string) => {
    const trade = trades.find(t => t.id === id);
    if (!trade) return;
    // Add wanted cosmetic to owned
    const ownedIds = JSON.parse(localStorage.getItem(OWNED_KEY) || "[]");
    if (!ownedIds.includes(trade.want.id)) ownedIds.push(trade.want.id);
    localStorage.setItem(OWNED_KEY, JSON.stringify(ownedIds));
    setOwned(COSMETICS.filter(c => ownedIds.includes(c.id)));
    // Remove trade
    const updated = trades.filter(t => t.id !== id);
    setTrades(updated);
    const stored = JSON.parse(localStorage.getItem(TKEY) || "[]").filter((t: Trade) => t.id !== id);
    localStorage.setItem(TKEY, JSON.stringify(stored));
  };

  const rarityColor: Record<string, string> = { common: "#94a3b8", rare: "#3b82f6", epic: "#a855f7", legendary: "#f59e0b" };

  return <div className="card">
    <div className="section-head"><div><div className="eyebrow">MARCHÉ</div><h3>Marché d'échange</h3></div></div>
    <div className="ui-trade-create">
      <h4>Créer une offre</h4>
      <div className="ui-trade-row">
        <div><label>Tu offres</label><select className="input" value={offerId} onChange={e => setOfferId(e.target.value)}>
          <option value="">— Choisir —</option>
          {owned.map(c => <option key={c.id} value={c.id}>{c.icon} {c.name}</option>)}
        </select></div>
        <span className="ui-trade-arrow">⇄</span>
        <div><label>Tu veux</label><select className="input" value={wantId} onChange={e => setWantId(e.target.value)}>
          <option value="">— Choisir —</option>
          {COSMETICS.map(c => <option key={c.id} value={c.id}>{c.icon} {c.name}</option>)}
        </select></div>
      </div>
      <button className="button" onClick={createTrade} disabled={!offerId || !wantId}>Publier l'offre</button>
    </div>
    <div className="ui-trade-list">
      <h4>Offres disponibles ({trades.length})</h4>
      {trades.map(t => <div key={t.id} className="ui-trade-item">
        <div className="ui-trade-cosmetic"><span style={{ fontSize: 24 }}>{t.offer.icon}</span><div><b>{t.offer.name}</b><small style={{ color: rarityColor[t.offer.rarity] }}>{t.offer.rarity}</small></div></div>
        <span className="ui-trade-arrow">→</span>
        <div className="ui-trade-cosmetic"><span style={{ fontSize: 24 }}>{t.want.icon}</span><div><b>{t.want.name}</b><small style={{ color: rarityColor[t.want.rarity] }}>{t.want.rarity}</small></div></div>
        <div className="ui-trade-actions">
          <small>par {t.from}</small>
          {t.from !== username ? <button className="button" style={{ padding: "4px 10px", fontSize: 12 }} onClick={() => acceptTrade(t.id)}>Accepter</button> : <span className="muted" style={{ fontSize: 12 }}>Ton offre</span>}
        </div>
      </div>)}
    </div>
  </div>;
}
