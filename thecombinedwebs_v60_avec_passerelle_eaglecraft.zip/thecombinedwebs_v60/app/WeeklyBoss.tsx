"use client";
import { useEffect, useState } from "react";

type BossState = { name: string; hp: number; maxHp: number; contributors: number; defeated: boolean; reward: number; week?: string };

const BOSS_NAMES = ["Le Golem de Cristal", "Dragon Néon", "Seigneur des Ombres", "Titane Mécanique", "Phénix Cosmique", "Hydre Glycée"];
const WEEK_KEY = () => { const d = new Date(); const y = d.getFullYear(); const w = Math.ceil(((d.getTime() - new Date(y, 0, 1).getTime()) / 86400000 + new Date(y, 0, 1).getDay() + 1) / 7); return `${y}-W${w}`; };
const BKEY = "steamblox:boss-state";

export function getBossState(): BossState {
  try {
    const wk = WEEK_KEY();
    const saved = JSON.parse(localStorage.getItem(BKEY) || "{}");
    if (saved.week === wk) return saved;
    const name = BOSS_NAMES[parseInt(wk.slice(-2)) % BOSS_NAMES.length] || BOSS_NAMES[0];
    const maxHp = 50000;
    return { name, hp: maxHp, maxHp, contributors: 0, defeated: false, reward: 200, week: wk } as BossState;
  } catch { return { name: BOSS_NAMES[0], hp: 50000, maxHp: 50000, contributors: 0, defeated: false, reward: 200 }; }
}

export function damageBoss(amount: number) {
  try {
    const s = getBossState();
    if (s.defeated) return s;
    s.hp = Math.max(0, s.hp - amount);
    s.contributors++;
    if (s.hp === 0) s.defeated = true;
    s.week = WEEK_KEY();
    localStorage.setItem(BKEY, JSON.stringify(s));
    return s;
  } catch { return getBossState(); }
}

export default function WeeklyBoss() {
  const [boss, setBoss] = useState<BossState | null>(null);
  useEffect(() => { setBoss(getBossState()); }, []);
  const hpPct = boss ? Math.round((boss.hp / boss.maxHp) * 100) : 100;

  return <div className="card">
    <div className="section-head"><div><div className="eyebrow">COMMUNAUTÉ</div><h3>Boss de la semaine</h3></div></div>
    {boss && <div className="ui-boss-card">
      <div className="ui-boss-icon">{boss.defeated ? "💀" : "👹"}</div>
      <div className="ui-boss-info">
        <h3>{boss.name}</h3>
        {boss.defeated ? <p style={{ color: "#10b981", fontWeight: 700, margin: "4px 0" }}>Vaincu par la communauté ! 🎉</p> : <>
          <div className="ui-boss-hp-bar"><i style={{ width: `${hpPct}%` }} /></div>
          <div className="ui-boss-meta">
            <span>❤️ {boss.hp.toLocaleString()} / {boss.maxHp.toLocaleString()}</span>
            <span>👥 <b>{boss.contributors}</b> contributeurs</span>
            <span>🪙 Récompense : <b>{boss.reward}</b> Bobux</span>
          </div>
        </>}
        <small style={{ display: "block", marginTop: 8, color: "#a9afbd" }}>Tes scores en arcade contribuent à vaincre le boss. Chaque point inflige 1 dégât.</small>
      </div>
    </div>}
  </div>;
}
