"use client";
import { useEffect, useState } from "react";

type Replay = { game: string; player: string; score: number; duration: string; likes: number; liked: boolean; at: number };

const SAMPLE_REPLAYS: Replay[] = [
  { game: "Meteor Mayhem", player: "NeonNinja", score: 12450, duration: "2:34", likes: 42, liked: false, at: Date.now() - 86400000 },
  { game: "Crystal Rush", player: "SpeedGamer", score: 8900, duration: "3:12", likes: 28, liked: false, at: Date.now() - 172800000 },
  { game: "Cyber Siege", player: "ProGamer_X", score: 15600, duration: "4:45", likes: 67, liked: false, at: Date.now() - 259200000 },
  { game: "Neon Tag", player: "FlashWin", score: 3200, duration: "1:58", likes: 19, liked: false, at: Date.now() - 432000000 },
  { game: "Castle Clash", player: "KnightAce", score: 7800, duration: "3:30", likes: 35, liked: false, at: Date.now() - 518400000 },
  { game: "Block Brawl", player: "ComboKing", score: 11200, duration: "2:15", likes: 51, liked: false, at: Date.now() - 604800000 },
];

const RKEY = "steamblox:replay-likes";

export default function ReplayLibrary() {
  const [replays, setReplays] = useState<Replay[]>([]);
  const [filter, setFilter] = useState<string>("all");

  useEffect(() => {
    try {
      const likes = JSON.parse(localStorage.getItem(RKEY) || "{}");
      setReplays(SAMPLE_REPLAYS.map(r => ({ ...r, liked: !!likes[r.player + r.game] })));
    } catch { setReplays(SAMPLE_REPLAYS); }
  }, []);

  const like = (i: number) => {
    const updated = [...replays];
    const r = updated[i];
    r.liked = !r.liked;
    r.likes += r.liked ? 1 : -1;
    setReplays(updated);
    try {
      const likes = JSON.parse(localStorage.getItem(RKEY) || "{}");
      likes[r.player + r.game] = r.liked;
      localStorage.setItem(RKEY, JSON.stringify(likes));
    } catch {}
  };

  const games = [...new Set(replays.map(r => r.game))];
  const filtered = filter === "all" ? replays : replays.filter(r => r.game === filter);
  const sorted = [...filtered].sort((a, b) => b.likes - a.likes);

  return <div className="card">
    <div className="section-head"><div><div className="eyebrow">COMMUNAUTÉ</div><h3>Bibliothèque de replays</h3></div></div>
    <div className="ui-replay-filters">
      <button className={`ui-replay-filter ${filter === "all" ? "on" : ""}`} onClick={() => setFilter("all")}>Tous</button>
      {games.map(g => <button key={g} className={`ui-replay-filter ${filter === g ? "on" : ""}`} onClick={() => setFilter(g)}>{g}</button>)}
    </div>
    <div className="ui-replays">
      {sorted.map((r, i) => <div key={i} className="ui-replay">
        <div className="ui-replay-thumb"><span>🎮</span><small>{r.duration}</small></div>
        <div className="ui-replay-info"><b>{r.player}</b><small>{r.game}</small><small>Score : {r.score.toLocaleString()}</small></div>
        <button className={`ui-replay-like ${r.liked ? "liked" : ""}`} onClick={() => like(i)}>❤ {r.likes}</button>
      </div>)}
    </div>
  </div>;
}
