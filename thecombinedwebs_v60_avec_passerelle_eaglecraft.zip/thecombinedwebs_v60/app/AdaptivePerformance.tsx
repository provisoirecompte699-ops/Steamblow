"use client";
import {useEffect} from "react";

export default function AdaptivePerformance(){
  useEffect(()=>{
    let raf=0, last=performance.now(), frames=0, lastSample=performance.now();
    let level="high";
    const memory=(navigator as any).deviceMemory || 4;
    const cores=navigator.hardwareConcurrency || 4;
    const apply=(next:string)=>{
      if(next===level && document.documentElement.dataset.tcbQuality) return;
      level=next;
      document.documentElement.dataset.tcbQuality=next;
    };
    const loop=(now:number)=>{
      frames++;
      if(now-lastSample>=2500){
        const fps=frames*1000/(now-lastSample); frames=0; lastSample=now;
        const lowMemory=memory<=2 || cores<=2;
        const next=fps<42||lowMemory?"eco":fps<54?"balanced":"high";
        apply(next);
      }
      last=now; raf=requestAnimationFrame(loop);
    };
    apply(memory<=2||cores<=2?"eco":"high");
    raf=requestAnimationFrame(loop);
    return()=>cancelAnimationFrame(raf);
  },[]);
  return null;
}
