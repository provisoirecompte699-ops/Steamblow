"use client";

import {useEffect, useState} from "react";

function Logo({small=false}:{small?:boolean}){
  return <div className={small?"sb-download-logo small":"sb-download-logo"} aria-label="Logo TheCombinedWebs"><span>TCB</span></div>;
}

export default function SteambloxDownloadScreen(){
  const [visible,setVisible]=useState(true);
  const [progress,setProgress]=useState(4);
  const [status,setStatus]=useState("Initialisation de TheCombinedWebs…");

  useEffect(()=>{
    try{if(sessionStorage.getItem("steamblox:splash-seen")){setVisible(false);return}sessionStorage.setItem("steamblox:splash-seen","1")}catch{}
    const start=performance.now();
    let frame=0;
    const statuses=[
      "Initialisation de TheCombinedWebs…",
      "Chargement de l’interface…",
      "Préparation de la bibliothèque…",
      "Connexion aux services…",
      "Presque prêt…"
    ];
    const tick=()=>{
      const elapsed=performance.now()-start;
      const next=Math.min(100,Math.round(4+(elapsed/360)*96));
      setProgress(next);
      setStatus(statuses[Math.min(statuses.length-1,Math.floor(next/22))]);
      if(next<100) frame=requestAnimationFrame(tick);
      else window.setTimeout(()=>setVisible(false),260);
    };
    frame=requestAnimationFrame(tick);
    return()=>{cancelAnimationFrame(frame)};
  },[]);

  if(!visible)return null;
  return <div className="sb-download-overlay" role="status" aria-live="polite">
    <div className="sb-download-backdrop"/>
    <div className="sb-download-panel">
      <div className="sb-download-orbit orbit-a"/><div className="sb-download-orbit orbit-b"/>
      <div className="sb-download-logo-wrap"><Logo/></div>
      <div className="sb-download-brand">THECOMBINEDWEBS</div>
      <div className="sb-download-status">{status}</div>
      <div className="sb-progress-track" aria-label={`Chargement ${progress}%`}><div className="sb-progress-fill" style={{width:`${progress}%`}}/></div>
      <div className="sb-progress-meta"><span>{progress}%</span><span>READY PLAYER</span></div>
    </div>
  </div>;
}
