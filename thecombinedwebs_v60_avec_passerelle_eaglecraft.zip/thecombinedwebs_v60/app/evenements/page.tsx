import FeaturePage from "../FeaturePages";
export const metadata={title:"Événements · TheCombinedWebs"};
export default function Page(){return <FeaturePage mode="evenements"/>;}
