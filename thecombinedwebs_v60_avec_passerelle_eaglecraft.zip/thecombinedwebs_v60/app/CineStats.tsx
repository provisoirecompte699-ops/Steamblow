"use client";
import { useEffect, useState } from "react";

type WatchEntry = { title: string; at: number; duration?: number };
type CineStat = { label: string; value: string; icon: string };

const FILM_GENRES: Record<string, string[]> = {
  "Inception": ["Sci-Fi", "Action"], "Matrix": ["Sci-Fi", "Action"], "Interstellar": ["Sci-Fi", "Drame"],
  "Avengers": ["Action", "Super-héros"], "Titanic": ["Drame", "Romance"], "Gladiator": ["Action", "Historique"],
  "Joker": ["Drame", "Thriller"], "Spider-Man": ["Action", "Super-héros"], "Batman": ["Action", "Super-héros"],
};

export function logWatch(title: string, duration?: number) {
  try {
    const log = JSON.parse(localStorage.getItem("cinestream:watch-log") || "[]");
    log.push({ title, at: Date.now(), duration });
    localStorage.setItem("cinestream:watch-log", JSON.stringify(log.slice(-200)));
  } catch {}
}

export default function CineStats() {
  const [stats, setStats] = useState<CineStat[]>([]);
  const [topFilms, setTopFilms] = useState<{ title: string; count: number }[]>([]);

  useEffect(() => {
    const log: WatchEntry[] = JSON.parse(localStorage.getItem("cinestream:watch-log") || "[]");
    const totalMin = log.reduce((s, e) => s + (e.duration || 90), 0);
    const fmtTime = (m: number) => m >= 60 ? `${Math.floor(m / 60)} h ${String(m % 60).padStart(2, "0")}` : `${m} min`;

    const counts: Record<string, number> = {};
    log.forEach(e => { counts[e.title] = (counts[e.title] || 0) + 1; });
    const top = Object.entries(counts).sort((a, b) => b[1] - a[1]).slice(0, 5);

    const genres: Record<string, number> = {};
    log.forEach(e => { (FILM_GENRES[e.title] || ["Autre"]).forEach(g => { genres[g] = (genres[g] || 0) + 1; }); });
    const favGenre = Object.entries(genres).sort((a, b) => b[1] - a[1])[0];

    setStats([
      { label: "Films regardés", value: String(log.length), icon: "🎬" },
      { label: "Temps total", value: fmtTime(totalMin), icon: "⏱️" },
      { label: "Genre préféré", value: favGenre ? favGenre[0] : "—", icon: "🎭" },
      { label: "Badge", value: log.length >= 50 ? "🏆 Cinéphile" : log.length >= 20 ? "🍿 Habitué" : log.length >= 5 ? "🎥 Débutant" : "—", icon: "🏅" },
    ]);
    setTopFilms(top.map(([title, count]) => ({ title, count })));
  }, []);

  return <div className="card">
    <div className="section-head"><div><div className="eyebrow">CINÉSTREAM</div><h3>Statistiques de visionnage</h3></div></div>
    <div className="ui-account-stats">
      {stats.map((s, i) => <div key={i} className="ui-account-stat"><span className="ui-stat-icon">{s.icon}</span><div><b>{s.value}</b><small>{s.label}</small></div></div>)}
    </div>
    {topFilms.length > 0 && <div className="ui-cine-top">
      <h4>Top 5 films regardés</h4>
      {topFilms.map((f, i) => <div key={i} className="ui-cine-top-item"><span>{i + 1}.</span><b>{f.title}</b><small>{f.count}x</small></div>)}
    </div>}
  </div>;
}
