"use client";
import { useEffect, useState } from "react";
import Link from "next/link";

type FriendRank = { name: string; score: number; game: string };

const GAMES = ["meteor-mayhem", "crystal-rush", "cyber-siege", "block-brawl", "neon-arena", "castle-clash", "party-pals", "rooftop-rivals", "pixel-heist", "mystic-mines", "neon-tag"];
const GAME_NAMES: Record<string, string> = {
  "meteor-mayhem": "Meteor Mayhem", "crystal-rush": "Crystal Rush", "cyber-siege": "Cyber Siege",
  "block-brawl": "Block Brawl", "neon-arena": "Neon Arena", "castle-clash": "Castle Clash",
  "party-pals": "Party Pals", "rooftop-rivals": "Rooftop Rivals", "pixel-heist": "Pixel Heist",
  "mystic-mines": "Mystic Mines", "neon-tag": "Neon Tag",
};

export default function FriendLeaderboard({ username, friends }: { username: string; friends: string[] }) {
  const [ranks, setRanks] = useState<FriendRank[]>([]);

  useEffect(() => {
    const all = [username, ...friends];
    const result: FriendRank[] = [];
    for (const name of all) {
      for (const g of GAMES) {
        const s = Number(localStorage.getItem(`steamblox:arcade:${g}:best`) || 0);
        if (s > 0) result.push({ name, score: s, game: GAME_NAMES[g] || g });
      }
    }
    result.sort((a, b) => b.score - a.score);
    setRanks(result.slice(0, 20));
  }, [username, friends]);

  if (!ranks.length) return null;

  return <div className="card">
    <div className="section-head"><div><div className="eyebrow">ENTRE AMIS</div><h3>Classement entre amis</h3></div></div>
    <div className="ui-friend-ranks">
      {ranks.map((r, i) => <div key={i} className={`ui-friend-rank ${r.name === username ? "me" : ""}`}>
        <span className="ui-rank-num">{i + 1}</span>
        <div className="ui-rank-info"><b>{r.name}{r.name === username ? " (toi)" : ""}</b><small>{r.game}</small></div>
        <b className="ui-rank-score">{r.score.toLocaleString()} pts</b>
      </div>)}
    </div>
  </div>;
}
