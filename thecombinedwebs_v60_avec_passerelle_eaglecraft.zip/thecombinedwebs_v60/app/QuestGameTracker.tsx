"use client";
import {useEffect} from "react";
export default function QuestGameTracker({gameId}:{gameId:string}){useEffect(()=>{let alive=true;const launch=()=>fetch("/api/quests/launch",{method:"POST",headers:{"content-type":"application/json"},body:JSON.stringify({gameId})}).catch(()=>{});launch();const timer=setInterval(()=>{if(alive)fetch("/api/quests/heartbeat",{method:"POST"}).catch(()=>{})},15000);return()=>{alive=false;clearInterval(timer)}},[gameId]);return null}
