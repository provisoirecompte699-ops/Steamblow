"use client";
import { useEffect, useState } from "react";

type Problem = { text: string; answer: number; unit: string; category: string };

const PROBLEMS: Problem[] = [
  // Budget
  { text: "Ton budget mensuel est de 1500 €. Tu dépenses 650 € pour le loyer, 180 € pour le téléphone, 350 € pour la nourriture et 90 € pour les transports. Combien te reste-t-il ?", answer: 230, unit: "€", category: "Budget" },
  { text: "Tu économises 45 € par mois. Combien auras-tu économisé après 8 mois ?", answer: 360, unit: "€", category: "Budget" },
  { text: "Un article coûte 80 € et est soldé à -25%. Quel est son prix final ?", answer: 60, unit: "€", category: "Budget" },
  { text: "Tu gagnes 12 € de l'heure et travailles 6 h par jour pendant 5 jours. Quel est ton salaire total ?", answer: 360, unit: "€", category: "Budget" },
  // Cuisine
  { text: "Une recette pour 4 personnes utilise 200g de farine. Combien pour 6 personnes ?", answer: 300, unit: "g", category: "Cuisine" },
  { text: "Tu dois mélanger 2/3 de litre d'eau avec 1/4 de litre de sirop. Quel volume total en mL ?", answer: 917, unit: "mL", category: "Cuisine" },
  { text: "Un gâteau cuit 35 minutes. Tu le sors à 19h45. À quelle heure l'as-tu mis au four ?", answer: 1910, unit: "h", category: "Cuisine" },
  // Conversions
  { text: "Convertis 3,5 km en mètres.", answer: 3500, unit: "m", category: "Conversions" },
  { text: "Une voiture roule à 90 km/h. Quelle distance parcourt-elle en 2h30 ?", answer: 225, unit: "km", category: "Conversions" },
  { text: "Convertis 2,5 heures en minutes.", answer: 150, unit: "min", category: "Conversions" },
  // Physique
  { text: "Un objet tombe avec une accélération de 9,8 m/s². Quelle vitesse atteint-il après 3 secondes ?", answer: 29, unit: "m/s", category: "Physique" },
  { text: "Une force de 50 N s'exerce sur un objet de 10 kg. Quelle est son accélération ?", answer: 5, unit: "m/s²", category: "Physique" },
];

export default function RealLifeProblems() {
  const [idx, setIdx] = useState(0);
  const [answer, setAnswer] = useState("");
  const [result, setResult] = useState("");
  const [score, setScore] = useState(0);
  const [done, setDone] = useState<number[]>([]);

  const next = () => {
    const remaining = PROBLEMS.map((_, i) => i).filter(i => !done.includes(i));
    if (remaining.length === 0) { setIdx(-1); return; }
    const pick = remaining[Math.floor(Math.random() * remaining.length)];
    setIdx(pick);
    setAnswer("");
    setResult("");
  };

  useEffect(() => { next(); }, []);

  const check = () => {
    if (idx < 0) return;
    const p = PROBLEMS[idx];
    const user = Number(answer.trim().replace(",", "."));
    const ok = Math.abs(user - p.answer) < 0.5;
    if (ok) { setResult("✓ Correct ! +20 pts"); setScore(s => s + 20); setDone(d => [...d, idx]); }
    else setResult(`✗ La réponse était ${p.answer} ${p.unit}.`);
    setTimeout(next, 2500);
  };

  const current = idx >= 0 ? PROBLEMS[idx] : null;

  return <div className="card">
    <div className="section-head"><div><div className="eyebrow">VIE RÉELLE</div><h3>Problèmes de la vie réelle</h3></div></div>
    {current ? <div className="ui-real-life">
      <span className="ui-rl-cat">{current.category}</span>
      <p className="ui-rl-text">{current.text}</p>
      <form className="af-row" style={{ justifyContent: "center" }} onSubmit={e => { e.preventDefault(); check(); }}>
        <input className="af-input af-input-math" value={answer} onChange={e => setAnswer(e.target.value)} placeholder={`Réponse en ${current.unit}`} inputMode="numeric" autoFocus />
        <button className="af-btn">Vérifier</button>
      </form>
      {result && <p style={{ textAlign: "center", fontWeight: 700, marginTop: 8 }}>{result}</p>}
    </div> : <div className="ui-real-life-done">
      <h3>🎉 Tous les problèmes résolus !</h3>
      <p>Score : <b style={{ color: "#ffd43b", fontSize: 20 }}>{score} pts</b></p>
      <button className="button" onClick={() => { setDone([]); setScore(0); next(); }}>Recommencer</button>
    </div>}
    {score > 0 && idx >= 0 && <p className="muted" style={{ fontSize: 12, marginTop: 8 }}>Score : {score} pts · {done.length}/{PROBLEMS.length} résolus</p>}
  </div>;
}
