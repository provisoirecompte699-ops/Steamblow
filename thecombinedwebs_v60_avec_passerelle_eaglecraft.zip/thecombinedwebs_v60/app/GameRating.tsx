"use client";
import { useEffect, useState } from "react";

type Rating = { gameId: string; rating: number; text?: string; at: number };
const RKEY = "steamblox:game-ratings";

export function rateGame(gameId: string, rating: number, text: string) {
  try {
    const all = JSON.parse(localStorage.getItem(RKEY) || "[]");
    const idx = all.findIndex((r: Rating) => r.gameId === gameId);
    const entry = { gameId, rating, text: text.slice(0, 300), at: Date.now() };
    if (idx >= 0) all[idx] = entry; else all.unshift(entry);
    localStorage.setItem(RKEY, JSON.stringify(all.slice(0, 100)));
  } catch {}
}

export function getRatings(): Rating[] {
  try { return JSON.parse(localStorage.getItem(RKEY) || "[]"); } catch { return []; }
}

export function getGameRating(gameId: string): Rating | null {
  return getRatings().find(r => r.gameId === gameId) || null;
}

export function averageRating(gameId: string): { avg: number; count: number } {
  const all = getRatings().filter(r => r.gameId === gameId);
  if (!all.length) return { avg: 0, count: 0 };
  return { avg: all.reduce((s, r) => s + r.rating, 0) / all.length, count: all.length };
}

export default function GameRating({ gameId }: { gameId: string }) {
  const [rating, setRating] = useState(0);
  const [hover, setHover] = useState(0);
  const [text, setText] = useState("");
  const [submitted, setSubmitted] = useState(false);
  const [existing, setExisting] = useState<Rating | null>(null);

  useEffect(() => { setExisting(getGameRating(gameId)); }, [gameId]);

  const submit = () => {
    if (rating === 0) return;
    rateGame(gameId, rating, text);
    setSubmitted(true);
    setExisting({ gameId, rating, text, at: Date.now() });
    setTimeout(() => setSubmitted(false), 2000);
  };

  return <div className="card ui-rating-widget">
    <div className="section-head"><div><div className="eyebrow">AVIS</div><h3>Noter ce jeu</h3></div></div>
    {existing && !submitted ? <div className="ui-rating-existing">
      <p>Ta note : {"⭐".repeat(existing.rating)}{"☆".repeat(5 - existing.rating)}</p>
      {existing.text && <p className="muted">« {existing.text} »</p>}
      <button className="button secondary" style={{ marginTop: 8, padding: "4px 12px", fontSize: 12 }} onClick={() => setExisting(null)}>Modifier</button>
    </div> : <div className="ui-rating-form">
      <div className="ui-stars">
        {[1, 2, 3, 4, 5].map(n => <button key={n} className="ui-star" onClick={() => setRating(n)} onMouseEnter={() => setHover(n)} onMouseLeave={() => setHover(0)}>{(hover || rating) >= n ? "⭐" : "☆"}</button>)}
      </div>
      <textarea className="input" value={text} onChange={e => setText(e.target.value)} placeholder="Ton avis (optionnel)" maxLength={300} style={{ minHeight: 60, resize: "vertical" }} />
      <button className="button" onClick={submit} disabled={rating === 0}>Publier mon avis</button>
      {submitted && <p style={{ color: "#10b981", fontWeight: 700, marginTop: 8 }}>Merci pour ton avis ! ✓</p>}
    </div>}
  </div>;
}
