"use client";
import { useEffect, useRef, useState } from "react";

/** Mini-jeu BOBUXTIME : attrape les 🪙 (évite les 💣). Le gain est vérifié et crédité côté serveur. */
export default function BobuxGame({ runId, seconds, onClose }: { runId: string; seconds: number; onClose: () => void }) {
  const cv = useRef<HTMLCanvasElement>(null);
  const [phase, setPhase] = useState<"play" | "end">("play");
  const [res, setRes] = useState<{ amount?: number; balance?: number; error?: string } | null>(null);
  useEffect(() => {
    const c = cv.current!; const ctx = c.getContext("2d")!; let W = 0, H = 0;
    const fit = () => { W = c.width = innerWidth; H = c.height = innerHeight; }; fit(); addEventListener("resize", fit);
    let px = W / 2; const keys = new Set<string>();
    const onMouse = (e: MouseEvent) => { px = e.clientX; };
    const onTouch = (e: TouchEvent) => { e.preventDefault(); px = e.touches[0].clientX; };
    const kd = (e: KeyboardEvent) => keys.add(e.key.toLowerCase()); const ku = (e: KeyboardEvent) => keys.delete(e.key.toLowerCase());
    c.addEventListener("mousemove", onMouse); c.addEventListener("touchmove", onTouch, { passive: false }); c.addEventListener("touchstart", onTouch, { passive: false });
    addEventListener("keydown", kd); addEventListener("keyup", ku);
    const items: { x: number; y: number; v: number; bad: boolean }[] = [];
    let last = performance.now(), spawn = 0, caught = 0, left = seconds, raf = 0, done = false;
    const finish = async () => {
      done = true; setPhase("end");
      try { const r = await fetch("/api/tcb/fun", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ action: "finish", id: runId, caught }) }); setRes(await r.json()); }
      catch { setRes({ error: "Connexion perdue : gain non enregistré." }); }
    };
    const loop = (t: number) => {
      const dt = Math.min(0.05, (t - last) / 1000); last = t;
      if (keys.has("arrowleft") || keys.has("q") || keys.has("a")) px -= 560 * dt;
      if (keys.has("arrowright") || keys.has("d")) px += 560 * dt;
      px = Math.max(44, Math.min(W - 44, px)); left -= dt; spawn -= dt;
      if (spawn <= 0) { spawn = 0.42 - Math.min(0.2, (seconds - left) / 150); items.push({ x: 30 + Math.random() * (W - 60), y: -20, v: 180 + Math.random() * 160 + (seconds - left) * 5, bad: Math.random() < 0.12 }); }
      ctx.fillStyle = "#0b0d14"; ctx.fillRect(0, 0, W, H); const by = H - 70;
      for (let i = items.length - 1; i >= 0; i--) {
        const it = items[i]; it.y += it.v * dt;
        if (it.y > by - 14 && it.y < by + 22 && Math.abs(it.x - px) < 48) { items.splice(i, 1); caught = it.bad ? Math.max(0, caught - 3) : caught + 1; continue; }
        if (it.y > H + 30) { items.splice(i, 1); continue; }
        ctx.font = "32px system-ui"; ctx.textAlign = "center"; ctx.fillText(it.bad ? "💣" : "🪙", it.x, it.y);
      }
      ctx.fillStyle = "#8b7cff"; ctx.fillRect(px - 46, by, 92, 16); ctx.fillStyle = "#5ee7c4"; ctx.fillRect(px - 46, by + 12, 92, 6);
      ctx.fillStyle = "#fff"; ctx.font = "800 22px system-ui"; ctx.textAlign = "left"; ctx.fillText(`🪙 ${caught}`, 16, 36);
      ctx.textAlign = "right"; ctx.fillText(`${Math.ceil(Math.max(0, left))} s`, W - 16, 36);
      if (left <= 0 && !done) { finish(); return; }
      raf = requestAnimationFrame(loop);
    };
    raf = requestAnimationFrame(loop);
    return () => { cancelAnimationFrame(raf); removeEventListener("resize", fit); removeEventListener("keydown", kd); removeEventListener("keyup", ku); c.removeEventListener("mousemove", onMouse); c.removeEventListener("touchmove", onTouch); c.removeEventListener("touchstart", onTouch); };
  }, [runId, seconds]);
  return <div className="tcb-lock" style={{ padding: 0, background: "#0b0d14" }}>
    <canvas ref={cv} style={{ position: "absolute", inset: 0, touchAction: "none" }} />
    {phase === "end" && <div className="tcb-box" style={{ position: "relative" }}>
      <h3>🪙 Partie terminée</h3>
      {!res ? <p>Comptage des Bobux…</p> : res.error ? <p style={{ color: "#ffb3ba" }}>{res.error}</p> : <p><b>+{res.amount} Bobux</b> ajoutés à ton solde. Nouveau solde : <b>{res.balance?.toLocaleString("fr-FR")}</b></p>}
      <div className="tcb-actions"><button className="tcb-btn" onClick={() => { onClose(); if (res && !res.error) location.reload(); }}>Fermer</button></div></div>}
  </div>;
}
