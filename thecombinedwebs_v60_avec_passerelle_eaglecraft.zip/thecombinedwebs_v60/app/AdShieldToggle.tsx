"use client";
import { useEffect, useState } from "react";

const KEY = "steamblox:adshield";
const STATS = "steamblox:adshield:blocked";

/** Interrupteur du bloqueur de pub natif (écosystème + iframes jeux). */
export default function AdShieldToggle() {
  const [on, setOn] = useState(true);
  const [blocked, setBlocked] = useState(0);

  useEffect(() => {
    try {
      setOn(localStorage.getItem(KEY) !== "off");
      setBlocked(parseInt(localStorage.getItem(STATS) || "0", 10) || 0);
    } catch {}
    const w = window as any;
    if (w.AdShield?.onChange) {
      w.AdShield.onChange((enabled: boolean, n: number) => {
        setOn(enabled);
        setBlocked(n);
      });
    }
  }, []);

  const toggle = () => {
    const v = !on;
    setOn(v);
    try {
      localStorage.setItem(KEY, v ? "on" : "off");
    } catch {}
    const w = window as any;
    if (w.AdShield?.set) w.AdShield.set(v);
  };

  return (
    <div className="ui-setting">
      <div>
        <b>🛡 Bloqueur de pub (AdShield)</b>
        <small>
          Bloque pop-ups, scripts publicitaires connus et redirections bizarres. Activé par défaut sur tout le site
          (CinéStream, Vortex, jeux en iframe).
          {blocked > 0 ? ` ${blocked} élément${blocked > 1 ? "s" : ""} bloqué${blocked > 1 ? "s" : ""}.` : ""}
        </small>
      </div>
      <button type="button" role="switch" aria-checked={on} className={`ui-switch ${on ? "on" : ""}`} onClick={toggle}>
        <span />
      </button>
    </div>
  );
}
