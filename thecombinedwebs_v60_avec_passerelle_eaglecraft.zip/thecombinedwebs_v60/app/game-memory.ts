// Transient fallback for legacy engines. Durable progression is account-cloud.
const values=new Map<string,string>();
export const gameMemory={getItem:(key:string)=>values.get(key)||null,setItem:(key:string,value:string)=>values.set(key,value),removeItem:(key:string)=>values.delete(key)};
