"use client";
import Link from "next/link";
import {useEffect} from "react";

export type EcosystemSection = "steamblox"|"vortex"|"cinestream"|"tiktok"|"baldi"|"ultrakill"|"credits"|"discord";

const LINKS: {id:EcosystemSection;href:string;label:string}[] = [
  {id:"steamblox",href:"/steamblox",label:"🎮 Jeux TheCombinedWebs"},
  {id:"cinestream",href:"/cinestream",label:"🍿 CinéStream"},
  {id:"tiktok",href:"/tiktok",label:"🎵 TikTok"},
  {id:"vortex",href:"/vortex",label:"🎬 Vortex"},
  {id:"discord",href:"/discord",label:"💬 Discord"},
  {id:"baldi",href:"/games/baldi-basics-3d",label:"📏 Baldi 3D"},
  {id:"ultrakill",href:"/games/ultrakill",label:"⚡ ULTRAKILL"},
  {id:"credits",href:"/credits",label:"⭐ Crédits"},
];

export default function EcosystemBar({current}:{current:EcosystemSection}){
  useEffect(()=>{try{localStorage.setItem("steamblox:ecosystem:last",current)}catch{}} ,[current]);
  return <div className="ecosystem-bar" aria-label="Écosystème TheCombinedWebs">
    <span className="ecosystem-dot" aria-hidden="true" />
    <strong>THECOMBINEDWEBS ECOSYSTEM</strong>
    {LINKS.map(l=><span key={l.id} style={{display:"contents"}}>
      <span className="ecosystem-sep">·</span>
      {current!==l.id?<Link href={l.href}>{l.label}</Link>:<span className="ecosystem-current">{l.label}</span>}
    </span>)}
    <span className="ecosystem-sep">·</span>
    <span className="ecosystem-credit">Crédits : Walid</span>
  </div>
}
