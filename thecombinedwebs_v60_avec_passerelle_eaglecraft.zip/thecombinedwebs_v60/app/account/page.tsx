import {currentUser} from "@/lib/auth";import {redirect} from "next/navigation";
import BobuxGift from "../BobuxGift";import Link from "next/link";import RedeemCard from "./RedeemCard";
import Friends from "../Friends";
import LogoutButton from "../LogoutButton";
import Coins from "../Coins";
import AvatarStudio from "../AvatarStudio";
import ProgressCenterServer from "../ProgressCenterServer";
export default async function Account(){const u=await currentUser();if(!u){redirect("/login");return null;}return <main className="wrap"><nav className="nav"><Link href="/" className="brand">TheCombinedWebs</Link><Link href="/" className="button secondary">Galerie</Link></nav><section className="profile-hero"><div className="avatar">{u.username.slice(0,1).toUpperCase()}</div><div><div className="eyebrow">PROFIL THECOMBINEDWEBS</div><h1>{u.username}</h1><p className="muted">Rôle · <b>{u.role}</b></p></div></section><div className="stats"><div className="card stat"><strong>{u.owned.length}</strong><span>jeux possédés</span></div><div className="card stat"><strong>{u.role==='creator'?'Créateur':u.role==='vice_creator'?'Vice créateur':u.role==='moderator'?'Modérateur':'Joueur'}</strong><span>statut</span></div><div className="card stat"><strong>7j</strong><span>session sécurisée</span></div></div><Coins initial={u.bobux??0}/><BobuxGift/><AvatarStudio/>
<ProgressCenterServer achievements={u.achievements||[]}/><RedeemCard/><Friends initialFriends={u.friends||[]}/>{u.role!=="user"&&<Link className="button" href="/admin">Administration</Link>}<LogoutButton /></main>}
