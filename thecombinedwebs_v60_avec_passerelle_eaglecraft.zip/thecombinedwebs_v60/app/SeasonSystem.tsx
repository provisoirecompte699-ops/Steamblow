"use client";
import { useEffect, useState } from "react";

type Season = { num: number; name: string; theme: string; icon: string; color: string; rewards: string[] };

const SEASONS: Season[] = [
  { num: 1, name: "Saison Glaciale", theme: "glace", icon: "❄️", color: "#3b82f6", rewards: ["Bordure Givre", "Skin Polaire", "Titre: Explorateur Boréal"] },
  { num: 2, name: "Saison Infernale", theme: "feu", icon: "🔥", color: "#ef4444", rewards: ["Bordure Flamme", "Skin Volcanique", "Titre: Maître des Flammes"] },
  { num: 3, name: "Saison Stellaire", theme: "espace", icon: "🚀", color: "#8b7cff", rewards: ["Bordure Galaxie", "Skin Astronaute", "Titre: Voyageur Stellaire"] },
  { num: 4, name: "Saison Forestière", theme: "forêt", icon: "🌿", color: "#10b981", rewards: ["Bordure Mousse", "Skin Sylvestre", "Titre: Gardien de la Forêt"] },
];

const SKY = "steamblox:current-season";

export default function SeasonSystem() {
  const [season, setSeason] = useState<Season>(SEASONS[0]);

  useEffect(() => {
    const saved = Number(localStorage.getItem(SKY) || "1");
    setSeason(SEASONS.find(s => s.num === saved) || SEASONS[0]);
  }, []);

  const switchSeason = (num: number) => {
    localStorage.setItem(SKY, String(num));
    setSeason(SEASONS.find(s => s.num === num) || SEASONS[0]);
  };

  return <div className="card ui-season-card" style={{ borderColor: season.color + "55", background: `linear-gradient(135deg, ${season.color}11, transparent)` }}>
    <div className="section-head"><div><div className="eyebrow" style={{ color: season.color }}>SAISON {season.num}</div><h3>{season.icon} {season.name}</h3></div></div>
    <div className="ui-season-body">
      <div className="ui-season-theme" style={{ background: season.color + "15" }}>
        <span style={{ fontSize: 48 }}>{season.icon}</span>
        <p style={{ color: season.color, fontWeight: 700 }}>Thème : {season.theme}</p>
      </div>
      <div className="ui-season-rewards">
        <h4>Récompenses de la saison</h4>
        {season.rewards.map((r, i) => <div key={i} className="ui-season-reward"><span>🎁</span>{r}</div>)}
      </div>
    </div>
    <div className="ui-season-switcher">
      <small>Changer de thème de saison :</small>
      <div className="ui-season-options">
        {SEASONS.map(s => <button key={s.num} className={`ui-season-opt ${s.num === season.num ? "on" : ""}`} onClick={() => switchSeason(s.num)} style={{ borderColor: s.num === season.num ? s.color : "#ffffff22" }}>
          {s.icon} {s.theme}
        </button>)}
      </div>
    </div>
  </div>;
}
