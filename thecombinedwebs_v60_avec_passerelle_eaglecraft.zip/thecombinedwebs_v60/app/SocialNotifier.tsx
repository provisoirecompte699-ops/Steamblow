"use client";
import { usePathname, useRouter } from "next/navigation";
import { useEffect, useRef, useState } from "react";
import { askNotifyOnce, systemNotify } from "./notify";

type Call = { from: string; room: string; at: number };
type Unread = { from: string; channel: string; at: number; text: string };

/** Statut d'activité + appels entrants + messages privés, sur toutes les pages (sauf /discord). */
function activity(path: string) {
  if (path.startsWith("/games/")) {
    const id = path.split("/")[2] || "";
    return "Joue à " + id.split("-").map((w) => w.charAt(0).toUpperCase() + w.slice(1)).join(" ");
  }
  if (path.startsWith("/cinestream")) return "Regarde CinéStream";
  if (path.startsWith("/vortex")) return "Regarde Vortex";
  if (path.startsWith("/steamblox") || path === "/") return "Sur TheCombinedWebs";
  return "En ligne";
}

export default function SocialNotifier() {
  const path = usePathname() || "/";
  const router = useRouter();
  const [call, setCall] = useState<Call | null>(null);
  const [dm, setDm] = useState<Unread | null>(null);
  const seen = useRef<{ call: number; dm: number }>({ call: 0, dm: 0 });
  const off = path.startsWith("/discord") || path.startsWith("/login") || path.startsWith("/register") || path.startsWith("/banned") || path.startsWith("/special");

  useEffect(() => {
    askNotifyOnce();
    if (off) return;
    let stop = false, t: ReturnType<typeof setTimeout>;
    try { const s = JSON.parse(sessionStorage.getItem("steamblox:notif:seen") || "{}"); seen.current = { call: s.call || 0, dm: s.dm || 0 }; } catch {}
    const save = () => { try { sessionStorage.setItem("steamblox:notif:seen", JSON.stringify(seen.current)); } catch {} };
    const tick = async () => {
      try {
        const r = await fetch(`/api/discord/ping?where=${encodeURIComponent(activity(path))}`, { cache: "no-store" });
        if (r.status === 401) { stop = true; return; }
        const d = await r.json();
        const c: Call | null = d.call;
        if (c && c.at !== seen.current.call) { setCall((prev) => { if (prev?.at !== c.at) systemNotify({ title: `${c.from} t’appelle`, body: "Appel vocal sur Discord TheCombinedWebs", tag: "call", url: `/discord?dm=${encodeURIComponent(c.from)}&join=1`, sticky: true }); return c; }); } else if (!c) setCall(null);
        const last: Unread | undefined = (d.unread || []).sort((a: Unread, b: Unread) => b.at - a.at)[0];
        if (last && last.at > seen.current.dm) { setDm(last); systemNotify({ title: last.from, body: last.text, tag: `dm-${last.from}`, url: `/discord?dm=${encodeURIComponent(last.from)}` }); seen.current.dm = last.at; save(); setTimeout(() => setDm((x) => (x?.at === last.at ? null : x)), 12000); }
      } catch { /* hors ligne */ }
      if (!stop) t = setTimeout(tick, document.hidden ? 20000 : 7000);
    };
    tick();
    return () => { stop = true; clearTimeout(t); };
  }, [path, off]);

  if (off || (!call && !dm)) return null;
  const dismiss = () => { if (call) { seen.current.call = call.at; try { sessionStorage.setItem("steamblox:notif:seen", JSON.stringify(seen.current)); } catch {} fetch("/api/discord/call", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ action: "dismiss" }) }); } setCall(null); };
  return <div className="sn-wrap" role="status" aria-live="polite">
    {call && <div className="sn-card call">
      <span className="sn-av">{call.from.slice(0, 1).toUpperCase()}</span>
      <div className="sn-txt"><b>{call.from}</b><span>t’appelle sur Discord…</span></div>
      <button className="sn-btn no" onClick={dismiss} aria-label="Refuser l’appel">✕</button>
      <button className="sn-btn yes" onClick={() => { seen.current.call = call.at; setCall(null); router.push(`/discord?dm=${encodeURIComponent(call.from)}&join=1`); }} aria-label="Accepter l’appel">📞</button>
    </div>}
    {dm && !call && <button className="sn-card" onClick={() => { setDm(null); router.push(`/discord?dm=${encodeURIComponent(dm.from)}`); }}>
      <span className="sn-av">{dm.from.slice(0, 1).toUpperCase()}</span>
      <div className="sn-txt"><b>{dm.from}</b><span>{dm.text}</span></div>
    </button>}
  </div>;
}
