"use client";
// Notifications système : pont Android (APK), sinon Service Worker / API Notification.
type N = { title: string; body: string; tag?: string; url?: string; sticky?: boolean };
type Bridge = { notify: (title: string, body: string, url: string, tag: string) => void; canNotify?: () => boolean };
export const androidBridge = () => (typeof window !== "undefined" ? (window as unknown as { SteambloxAndroid?: Bridge }).SteambloxAndroid : undefined);
export function systemNotify(n: N) {
  if (typeof window === "undefined") return;
  const url = n.url || "/discord", tag = n.tag || "steamblox";
  const b = androidBridge();
  if (b) { if (document.hidden) { try { b.notify(n.title, n.body, url, tag); } catch {} } return; }
  if (!document.hidden || !("Notification" in window) || Notification.permission !== "granted") return;
  navigator.serviceWorker?.ready.then((reg) => reg.active?.postMessage({ type: "notify", title: n.title, body: n.body, tag, url, renotify: true, sticky: n.sticky }))
    .catch(() => { try { new Notification(n.title, { body: n.body, tag }); } catch {} });
}
/** Demande la permission une seule fois, au premier clic de l'utilisateur. */
export function askNotifyOnce() {
  if (typeof window === "undefined" || androidBridge() || !("Notification" in window) || Notification.permission !== "default") return;
  if (localStorage.getItem("steamblox:notif-asked") === "1") return;
  const h = () => { localStorage.setItem("steamblox:notif-asked", "1"); Notification.requestPermission().catch(() => {}); window.removeEventListener("pointerdown", h); };
  window.addEventListener("pointerdown", h, { once: true });
}
