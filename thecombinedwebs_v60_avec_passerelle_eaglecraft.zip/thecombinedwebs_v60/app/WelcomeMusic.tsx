"use client";
import {useEffect,useRef,useState} from "react";

export default function WelcomeMusic(){
  const audio=useRef<HTMLAudioElement|null>(null);
  const [muted,setMuted]=useState(true);
  const [volume,setVolume]=useState(0.35);
  useEffect(()=>{
    const saved=Number(localStorage.getItem("steamblox:welcomeVolume"));
    if(Number.isFinite(saved)&&saved>0){setVolume(saved);setMuted(false)}
  },[]);
  useEffect(()=>{
    const el=audio.current;if(!el)return;
    el.volume=volume;el.muted=muted;el.loop=true;
    const start=()=>{if(!muted) el.play().catch(()=>{})};
    window.addEventListener("pointerdown",start,{once:true});
    return()=>window.removeEventListener("pointerdown",start);
  },[muted,volume]);
  const toggle=()=>{
    const next=!muted;setMuted(next);
    if(next){audio.current?.pause();localStorage.setItem("steamblox:welcomeVolume","0")}
    else {localStorage.setItem("steamblox:welcomeVolume",String(volume));audio.current?.play().catch(()=>{})}
  };
  const change=(v:number)=>{setVolume(v);setMuted(v===0);localStorage.setItem("steamblox:welcomeVolume",String(v));if(v>0)audio.current?.play().catch(()=>{})};
  return <div className="welcome-music">
    <audio ref={audio} src="/steamblox-welcome.wav" preload="auto" loop aria-hidden="true" />
    <button className="welcome-music-button" onClick={toggle} aria-label={muted?"Activer la musique":"Couper la musique"}>{muted?"🔇":"♫"}</button>
    <input aria-label="Volume de la musique" type="range" min="0" max="1" step="0.01" value={muted?0:volume} onChange={e=>change(Number(e.target.value))}/>
    <span>Ambiance TheCombinedWebs</span>
  </div>;
}
