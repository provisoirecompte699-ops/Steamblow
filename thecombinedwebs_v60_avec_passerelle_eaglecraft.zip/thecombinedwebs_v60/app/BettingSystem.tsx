"use client";
import { useEffect, useState } from "react";

type Bet = { id: string; tournament: string; player: string; amount: number; on: string; at: number; status: "pending" | "won" | "lost" };
type Tournament = { id: string; name: string; participants: string[]; status: "upcoming" | "active" };

const SAMPLE_TOURNAMENTS: Tournament[] = [
  { id: "t1", name: "Tournoi Meteor Mayhem", participants: ["NeonNinja", "SpeedGamer", "ProGamer_X", "FlashWin"], status: "upcoming" },
  { id: "t2", name: "Duel Crystal Rush", participants: ["ComboKing", "KnightAce", "GamerQueen"], status: "active" },
  { id: "t3", name: "Championnat Neon Tag", participants: ["Alex", "Sam", "Léa", "Tom", "Nina"], status: "upcoming" },
];

const BKEY = "steamblox:bets";

export default function BettingSystem({ username }: { username: string }) {
  const [bets, setBets] = useState<Bet[]>([]);
  const [selected, setSelected] = useState<Tournament | null>(null);
  const [amount, setAmount] = useState(50);
  const [onPlayer, setOnPlayer] = useState("");
  const [bobux, setBobux] = useState(500);

  useEffect(() => {
    try {
      setBets(JSON.parse(localStorage.getItem(BKEY) || "[]"));
      setBobux(Number(localStorage.getItem("steamblox:bobux") || 500));
    } catch {}
  }, []);

  const placeBet = () => {
    if (!selected || !onPlayer || amount <= 0 || amount > bobux) return;
    const bet: Bet = {
      id: Date.now().toString(36), tournament: selected.name, player: username,
      amount, on: onPlayer, at: Date.now(), status: "pending",
    };
    const updated = [bet, ...bets];
    setBets(updated);
    localStorage.setItem(BKEY, JSON.stringify(updated.slice(0, 30)));
    const newBobux = bobux - amount;
    setBobux(newBobux);
    localStorage.setItem("steamblox:bobux", String(newBobux));
    setSelected(null); setOnPlayer(""); setAmount(50);
  };

  const resolveBet = (id: string, won: boolean) => {
    const bet = bets.find(b => b.id === id);
    if (!bet) return;
    const updated = bets.map(b => b.id === id ? { ...b, status: won ? "won" as const : "lost" as const } : b);
    setBets(updated);
    localStorage.setItem(BKEY, JSON.stringify(updated));
    if (won) {
      const newBobux = bobux + bet.amount * 2;
      setBobux(newBobux);
      localStorage.setItem("steamblox:bobux", String(newBobux));
    }
  };

  return <div className="card">
    <div className="section-head"><div><div className="eyebrow">PARIS</div><h3>Paris sur tournois</h3></div>
      <span className="ui-bobux-balance">💰 {bobux} Bobux</span>
    </div>
    {!selected && <div className="ui-bet-tourneys">
      <h4>Tournois disponibles</h4>
      {SAMPLE_TOURNAMENTS.map(t => <div key={t.id} className="ui-bet-tourney">
        <div><b>{t.name}</b><small>{t.participants.length} participants · {t.status === "active" ? "En cours" : "À venir"}</small></div>
        <button className="button" style={{ padding: "4px 10px", fontSize: 12 }} onClick={() => { setSelected(t); setOnPlayer(""); }}>Parier</button>
      </div>)}
    </div>}
    {selected && <div className="ui-bet-form">
      <h4>Parier sur : {selected.name}</h4>
      <div className="ui-bet-players">
        {selected.participants.map(p => <button key={p} className={`ui-bet-player ${onPlayer === p ? "on" : ""}`} onClick={() => setOnPlayer(p)}>{p}</button>)}
      </div>
      <div className="ui-bet-amount">
        <label>Mise (Bobux)</label>
        <input type="number" className="input" value={amount} onChange={e => setAmount(Math.max(1, Number(e.target.value)))} min={1} max={bobux} />
        <div className="ui-bet-quick"><button onClick={() => setAmount(50)}>50</button><button onClick={() => setAmount(100)}>100</button><button onClick={() => setAmount(Math.floor(bobux / 2))}>½</button><button onClick={() => setAmount(bobux)}>Max</button></div>
      </div>
      <p className="muted" style={{ fontSize: 12 }}>Gain potentiel : <b style={{ color: "#10b981" }}>{amount * 2} Bobux</b></p>
      <div className="ui-bet-actions">
        <button className="button secondary" onClick={() => setSelected(null)}>Annuler</button>
        <button className="button" onClick={placeBet} disabled={!onPlayer || amount > bobux}>Confirmer le pari</button>
      </div>
    </div>}
    {bets.length > 0 && <div className="ui-bet-history">
      <h4>Mes paris ({bets.length})</h4>
      {bets.map(b => <div key={b.id} className={`ui-bet-item ${b.status}`}>
        <div><b>{b.tournament}</b><small>Misé {b.amount} sur {b.on}</small></div>
        {b.status === "pending" ? <div className="ui-bet-resolve">
          <button className="button" style={{ padding: "2px 8px", fontSize: 11 }} onClick={() => resolveBet(b.id, true)}>Gagné</button>
          <button className="button secondary" style={{ padding: "2px 8px", fontSize: 11 }} onClick={() => resolveBet(b.id, false)}>Perdu</button>
        </div> : <span className={`ui-bet-status ${b.status}`}>{b.status === "won" ? `✓ +${b.amount * 2}` : "✗ Perdu"}</span>}
      </div>)}
    </div>}
  </div>;
}
