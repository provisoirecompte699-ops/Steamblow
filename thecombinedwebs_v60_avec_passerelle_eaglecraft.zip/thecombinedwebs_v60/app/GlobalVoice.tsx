"use client";
import { useCallback, useEffect, useRef, useState } from "react";
import { io, type Socket } from "socket.io-client";

const SERVER = process.env.NEXT_PUBLIC_MULTIPLAYER_SERVER_URL || process.env.NEXT_PUBLIC_MULTIPLAYER_URL || "";
const ICE: RTCConfiguration = { iceServers: [{ urls: "stun:stun.l.google.com:19302" }, { urls: "stun:stun.cloudflare.com:3478" }] };

type VoiceState = { active: boolean; speaker: string | null; listeners: number };
type Auth = { username: string; token: string; canSpeak: boolean };

export default function GlobalVoice({ admin = false }: { admin?: boolean }) {
  const [enabled, setEnabled] = useState(false);
  const [muted, setMuted] = useState(false);
  const [volume, setVolume] = useState(0.9);
  const [level, setLevel] = useState(0);
  const [state, setState] = useState<VoiceState>({ active: false, speaker: null, listeners: 0 });
  const [status, setStatus] = useState("");
  const [error, setError] = useState("");

  const socket = useRef<Socket | null>(null);
  const auth = useRef<Auth | null>(null);
  const stream = useRef<MediaStream | null>(null);
  const peers = useRef(new Map<string, RTCPeerConnection>());
  const audios = useRef(new Map<string, HTMLAudioElement>());
  const enabledRef = useRef(false);
  const volumeRef = useRef(0.9);
  const meter = useRef<{ ctx: AudioContext; raf: number } | null>(null);

  useEffect(() => { enabledRef.current = enabled; }, [enabled]);
  useEffect(() => {
    volumeRef.current = volume;
    audios.current.forEach(a => { a.volume = volume; });
  }, [volume]);

  const stopMeter = useCallback(() => {
    if (meter.current) { cancelAnimationFrame(meter.current.raf); meter.current.ctx.close().catch(() => {}); meter.current = null; }
    setLevel(0);
  }, []);

  // Jauge de niveau (micro de Younes ou voix reçue)
  const startMeter = useCallback((media: MediaStream) => {
    stopMeter();
    try {
      const ctx = new AudioContext();
      const analyser = ctx.createAnalyser();
      analyser.fftSize = 256;
      ctx.createMediaStreamSource(media).connect(analyser);
      const data = new Uint8Array(analyser.frequencyBinCount);
      const tick = () => {
        analyser.getByteFrequencyData(data);
        let sum = 0; for (const v of data) sum += v;
        setLevel(Math.min(1, sum / data.length / 90));
        if (meter.current) meter.current.raf = requestAnimationFrame(tick);
      };
      meter.current = { ctx, raf: requestAnimationFrame(tick) };
    } catch { /* AudioContext indisponible : la jauge reste à 0 */ }
  }, [stopMeter]);

  const dropPeer = useCallback((id: string) => {
    peers.current.get(id)?.close(); peers.current.delete(id);
    const a = audios.current.get(id); if (a) { a.srcObject = null; a.remove(); } audios.current.delete(id);
  }, []);

  const closeAll = useCallback(() => {
    [...peers.current.keys()].forEach(dropPeer);
    stream.current?.getTracks().forEach(t => t.stop()); stream.current = null;
    stopMeter();
  }, [dropPeer, stopMeter]);

  useEffect(() => () => { closeAll(); socket.current?.disconnect(); }, [closeAll]);

  const makePeer = useCallback((id: string, s: Socket) => {
    let pc = peers.current.get(id);
    if (pc) return pc;
    pc = new RTCPeerConnection(ICE);
    stream.current?.getTracks().forEach(t => pc!.addTrack(t, stream.current!));
    pc.onicecandidate = e => { if (e.candidate) s.emit("global-voice:ice", { to: id, candidate: e.candidate }); };
    pc.ontrack = e => {
      let a = audios.current.get(id);
      if (!a) { a = new Audio(); a.autoplay = true; audios.current.set(id, a); }
      a.srcObject = e.streams[0]; a.volume = volumeRef.current; a.play().catch(() => setStatus("Touche l'écran pour activer le son"));
      if (!admin) startMeter(e.streams[0]);
    };
    pc.onconnectionstatechange = () => {
      if (pc && ["failed", "closed", "disconnected"].includes(pc.connectionState)) dropPeer(id);
    };
    peers.current.set(id, pc);
    return pc;
  }, [admin, dropPeer, startMeter]);

  const connect = useCallback(async () => {
    if (socket.current) return socket.current;
    const r = await fetch("/api/global-voice", { cache: "no-store" });
    const d = await r.json();
    if (!r.ok) throw new Error(d.error === "unauthorized" ? "Connecte-toi pour utiliser le vocal global." : d.error || "Accès refusé");
    auth.current = d;
    const s = io(SERVER || undefined, { transports: ["websocket", "polling"], reconnection: true, reconnectionDelay: 700 });
    socket.current = s;

    const join = async () => {
      // Le token expire après 5 min : on en redemande un à chaque (re)connexion.
      const fresh = await fetch("/api/global-voice", { cache: "no-store" }).then(x => x.json()).catch(() => null);
      if (fresh?.token) auth.current = fresh;
      if (enabledRef.current && auth.current) s.emit("global-voice:join", { token: auth.current.token, username: auth.current.username, speaker: admin && auth.current.canSpeak });
    };
    s.on("connect", () => { setError(""); void join(); });
    s.on("disconnect", () => setStatus("Reconnexion…"));
    s.on("global-voice:joined", () => setStatus(""));
    s.on("global-voice:state", (v: VoiceState) => setState(v));
    s.on("global-voice:error", ({ message }: { message: string }) => { setError(message); });
    s.on("global-voice:left", ({ id }: { id: string }) => dropPeer(id));

    // Le speaker (Younes) appelle chaque auditeur.
    s.on("global-voice:listener", async ({ id }: { id: string }) => {
      if (!enabledRef.current || !admin || !stream.current) return;
      dropPeer(id);
      const pc = makePeer(id, s);
      const offer = await pc.createOffer();
      await pc.setLocalDescription(offer);
      s.emit("global-voice:offer", { to: id, offer });
    });
    s.on("global-voice:offer", async ({ from, offer }: { from: string; offer: RTCSessionDescriptionInit }) => {
      if (!enabledRef.current || admin) return;
      const pc = makePeer(from, s);
      await pc.setRemoteDescription(offer);
      const answer = await pc.createAnswer();
      await pc.setLocalDescription(answer);
      s.emit("global-voice:answer", { to: from, answer });
    });
    s.on("global-voice:answer", async ({ from, answer }: { from: string; answer: RTCSessionDescriptionInit }) => {
      await peers.current.get(from)?.setRemoteDescription(answer).catch(() => {});
    });
    s.on("global-voice:ice", async ({ from, candidate }: { from: string; candidate: RTCIceCandidateInit }) => {
      await peers.current.get(from)?.addIceCandidate(candidate).catch(() => {});
    });
    return s;
  }, [admin, dropPeer, makePeer]);

  async function toggle() {
    setError(""); setStatus("");
    try {
      if (enabled) {
        socket.current?.emit("global-voice:leave");
        closeAll(); setEnabled(false); enabledRef.current = false; setMuted(false);
        return;
      }
      const s = await connect();
      if (admin) {
        if (!navigator.mediaDevices?.getUserMedia) throw new Error("Micro indisponible : ouvre le site en HTTPS.");
        const media = await navigator.mediaDevices.getUserMedia({ audio: { echoCancellation: true, noiseSuppression: true, autoGainControl: true } });
        stream.current = media; startMeter(media);
      }
      enabledRef.current = true; setEnabled(true);
      if (s.connected) s.emit("global-voice:join", { token: auth.current!.token, username: auth.current!.username, speaker: admin && !!auth.current?.canSpeak });
      else setStatus("Connexion au serveur vocal…");
    } catch (e) {
      const name = e instanceof DOMException ? e.name : "";
      setError(name === "NotAllowedError" ? "Autorise le micro dans ton navigateur puis réessaie." : name === "NotFoundError" ? "Aucun micro détecté." : e instanceof Error ? e.message : "Erreur de connexion");
    }
  }

  function toggleMute() {
    const next = !muted; setMuted(next);
    stream.current?.getAudioTracks().forEach(t => { t.enabled = !next; });
  }

  const live = state.active;
  const bars = 18;
  return (
    <section className={`gv ${live ? "is-live" : ""} ${enabled ? "is-joined" : ""}`} aria-label="Vocal global">
      <div className="gv-glow" aria-hidden />
      <header className="gv-head">
        <div className="gv-icon" aria-hidden>{admin ? "🎙️" : "🔊"}</div>
        <div className="gv-title">
          <span className="eyebrow">VOCAL GLOBAL</span>
          <h2>{admin ? "Parler à tous les joueurs" : "Vocal de Younes"}</h2>
        </div>
        <span className={`gv-badge ${live ? "on" : ""}`}><i />{live ? "EN DIRECT" : "HORS LIGNE"}</span>
      </header>

      <p className="gv-sub">
        {admin
          ? "Ton micro est diffusé en direct à tous les joueurs connectés à TheCombinedWebs."
          : live ? `${state.speaker || "Younes"} parle en ce moment. Rejoins le vocal pour l'écouter.` : "Les annonces vocales de Younes s'entendent ici dès qu'il est en direct."}
      </p>

      <div className="gv-meter" aria-hidden>
        {Array.from({ length: bars }, (_, i) => {
          const on = enabled && !muted && level * bars > i;
          return <b key={i} className={on ? "on" : ""} style={{ height: `${28 + ((i * 37) % 60)}%` }} />;
        })}
      </div>

      <div className="gv-row">
        <button className={`button ${enabled ? "danger" : ""}`} onClick={toggle}>
          {enabled ? (admin ? "■ Arrêter la diffusion" : "Quitter le vocal") : admin ? "🎙️ Démarrer le direct" : "🔊 Écouter le vocal"}
        </button>
        {admin && enabled && <button className="button secondary" onClick={toggleMute}>{muted ? "🔇 Micro coupé" : "🎙️ Couper le micro"}</button>}
        <span className="gv-count">👥 {state.listeners} auditeur{state.listeners > 1 ? "s" : ""}</span>
      </div>

      {!admin && enabled && (
        <label className="gv-volume">🔈
          <input type="range" min={0} max={1} step={0.05} value={volume} onChange={e => setVolume(Number(e.target.value))} aria-label="Volume" />
          <span>{Math.round(volume * 100)}%</span>
        </label>
      )}
      {status && <small className="gv-status">{status}</small>}
      {error && <small className="error">{error}</small>}
    </section>
  );
}
