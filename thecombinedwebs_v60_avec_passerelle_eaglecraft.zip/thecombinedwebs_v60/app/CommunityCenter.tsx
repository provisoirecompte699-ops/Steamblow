"use client";
import {useEffect,useState} from "react";

const KEY="steamblox:profilePrefs";
function getPrefs(){try{return JSON.parse(localStorage.getItem(KEY)||"{}")||{}}catch{return {}}}
function makeGroupCode(){return "SB-"+Math.random().toString(36).slice(2,7).toUpperCase()}

export default function CommunityCenter(){
 const [status,setStatus]=useState("Disponible"),[privacy,setPrivacy]=useState("Amis"),[copied,setCopied]=useState(false),[challenge,setChallenge]=useState(false),[code,setCode]=useState("");
 useEffect(()=>{
  const p=getPrefs();
  setStatus(p.status||"Disponible");
  setPrivacy(p.privacy||"Amis");
  const week=new Date().getUTCFullYear()+"-"+Math.floor((Date.now()-new Date(new Date().getUTCFullYear(),0,1).getTime())/604800000);
  setChallenge(localStorage.getItem("steamblox:weeklyChallenge")===week);
  const saved=localStorage.getItem("steamblox:groupCode");
  const next=saved||makeGroupCode();
  setCode(next);
  if(!saved)localStorage.setItem("steamblox:groupCode",next);
 },[]);
 const save=(s:string,p:string)=>{localStorage.setItem(KEY,JSON.stringify({status:s,privacy:p}));setStatus(s);setPrivacy(p)};
 const copy=async()=>{if(!code)return;try{await navigator.clipboard.writeText(code);setCopied(true);setTimeout(()=>setCopied(false),1400)}catch{}};
 const backup=()=>{const data=Object.fromEntries(Object.entries(localStorage).filter(([k])=>k.startsWith("steamblox:")));const blob=new Blob([JSON.stringify({version:1,createdAt:new Date().toISOString(),data},null,2)],{type:"application/json"});const a=document.createElement("a");const url=URL.createObjectURL(blob);a.href=url;a.download="steamblox-sauvegarde.json";a.click();setTimeout(()=>URL.revokeObjectURL(url),0)};
 const weekly=()=>{const week=new Date().getUTCFullYear()+"-"+Math.floor((Date.now()-new Date(new Date().getUTCFullYear(),0,1).getTime())/604800000);setChallenge(true);localStorage.setItem("steamblox:weeklyChallenge",week)};
 return <section className="card community-center"><div className="section-head"><div><div className="eyebrow">SOCIAL & SAUVEGARDE</div><h3>Centre communautaire</h3></div><span className="tag accent">NOUVEAU</span></div>
  <div className="community-grid">
   <div className="community-card"><b>🟢 Statut</b><small>Choisis ce que tes amis voient.</small><select value={status} onChange={e=>save(e.target.value,privacy)}><option>Disponible</option><option>En jeu</option><option>Occupé</option><option>Invisible</option></select></div>
   <div className="community-card"><b>🔒 Confidentialité</b><small>Contrôle qui peut rejoindre tes salons.</small><select value={privacy} onChange={e=>save(status,e.target.value)}><option>Tout le monde</option><option>Amis</option><option>Personne</option></select></div>
   <div className="community-card"><b>🎟️ Code de groupe</b><small>Crée un petit code partageable pour retrouver tes amis.</small><button onClick={copy} disabled={!code}>{copied?"Copié !":code||"Génération…"}</button></div>
   <div className="community-card"><b>🔥 Défi hebdomadaire</b><small>Termine un objectif communautaire pour +100 XP.</small><button disabled={challenge} onClick={weekly}>{challenge?"Défi enregistré":"Participer"}</button></div>
   <div className="community-card wide"><b>☁️ Sauvegarde locale</b><small>Exporte les préférences, progression et réglages TheCombinedWebs dans un fichier JSON. Rien n'est envoyé automatiquement.</small><button onClick={backup}>Exporter ma sauvegarde</button></div>
  </div>
 </section>
}
