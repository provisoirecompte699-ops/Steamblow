"use client";
import { useEffect, useState, useRef } from "react";

type PM = { from: string; to: string; text: string; at: number };
const PMKEY = "steamblox:pm";

function pmKey(a: string, b: string) { return `pm:${[a, b].sort().join("~")}`; }

export function sendPM(from: string, to: string, text: string) {
  try {
    const key = pmKey(from, to);
    const msgs = JSON.parse(localStorage.getItem(key) || "[]");
    msgs.push({ from, to, text: text.slice(0, 500), at: Date.now() });
    localStorage.setItem(key, JSON.stringify(msgs.slice(-100)));
    // Also notify
    const inbox = JSON.parse(localStorage.getItem(PMKEY) || "[]");
    if (!inbox.includes(to)) { inbox.unshift(to); localStorage.setItem(PMKEY, JSON.stringify(inbox.slice(0, 20))); }
  } catch {}
}

export default function PrivateMessages({ username, friends }: { username: string; friends: string[] }) {
  const [active, setActive] = useState<string | null>(null);
  const [msgs, setMsgs] = useState<PM[]>([]);
  const [draft, setDraft] = useState("");
  const [inbox, setInbox] = useState<string[]>([]);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    try { setInbox(JSON.parse(localStorage.getItem(PMKEY) || "[]")); } catch {}
  }, []);

  useEffect(() => {
    if (!active) return;
    try { setMsgs(JSON.parse(localStorage.getItem(pmKey(username, active)) || "[]")); } catch {}
  }, [active, username]);

  useEffect(() => { scrollRef.current?.scrollIntoView({ block: "end" }); }, [msgs.length]);

  const send = () => {
    if (!draft.trim() || !active) return;
    sendPM(username, active, draft);
    setMsgs(prev => [...prev, { from: username, to: active, text: draft.slice(0, 500), at: Date.now() }]);
    setDraft("");
  };

  if (!friends.length) return null;

  return <div className="card">
    <div className="section-head"><div><div className="eyebrow">MESSAGERIE</div><h3>Messages privés</h3></div></div>
    {!active ? <div className="ui-pm-widget">
      {friends.map(f => <div key={f} className="ui-pm-thread" onClick={() => setActive(f)}>
        <div className="ui-pm-avatar">{f.slice(0, 1).toUpperCase()}</div>
        <div className="ui-pm-info"><b>{f}</b><small>{inbox.includes(f) ? "Nouveau message" : "Ouvrir la conversation"}</small></div>
      </div>)}
    </div> : <div>
      <button className="button secondary" style={{ marginBottom: 8, padding: "4px 12px", fontSize: 12 }} onClick={() => setActive(null)}>← Retour</button>
      <div style={{ maxHeight: 200, overflowY: "auto", background: "#0a0b10", borderRadius: 10, padding: 8, display: "flex", flexDirection: "column", gap: 4 }}>
        {msgs.map((m, i) => <div key={i} style={{ alignSelf: m.from === username ? "flex-end" : "flex-start", maxWidth: "75%", padding: "6px 12px", borderRadius: 10, background: m.from === username ? "#6366f133" : "#ffffff14", fontSize: 13, color: "#fff" }}>
          <small style={{ color: "#a9afbd", fontSize: 10 }}>{m.from}</small>
          <div>{m.text}</div>
        </div>)}
        {!msgs.length && <p className="muted" style={{ textAlign: "center" }}>Aucun message. Écris le premier !</p>}
        <div ref={scrollRef} />
      </div>
      <div style={{ display: "flex", gap: 6, marginTop: 8 }}>
        <input className="input" style={{ flex: 1 }} value={draft} onChange={e => setDraft(e.target.value)} placeholder={`Message à ${active}`} onKeyDown={e => { if (e.key === "Enter") send(); }} />
        <button className="button" onClick={send}>Envoyer</button>
      </div>
    </div>}
  </div>;
}
