"use client";
import Link from "next/link";
import dynamic from "next/dynamic";
import {useEffect,useMemo,useState,type ReactNode} from "react";
import WelcomeMusic from "./WelcomeMusic";
import GlobalVoice from "./GlobalVoice";
import { Economy } from "./FeaturePages";
import LogoutButton from "./LogoutButton";
import AdShieldToggle from "./AdShieldToggle";
import ActivityWall from "./ActivityWall";
import WeeklyBoss from "./WeeklyBoss";
import CommunityEvents from "./CommunityEvents";
import HallOfFame from "./HallOfFame";
import FriendChallenges from "./FriendChallenges";
import PrivateMessages from "./PrivateMessages";
import FriendLeaderboard from "./FriendLeaderboard";
import AccountStats from "./AccountStats";
import Tutorial from "./Tutorial";
import RevisionSheet from "./RevisionSheet";
import RealLifeProblems from "./RealLifeProblems";
import CineStats from "./CineStats";
import CineRecommendations from "./CineRecommendations";
import InAppNotifications, { pushNotif } from "./InAppNotifications";
import Mentorship from "./Mentorship";
import ReplayLibrary from "./ReplayLibrary";
import SeasonSystem from "./SeasonSystem";
import TradeMarket from "./TradeMarket";
import CommunityCalendar from "./CommunityCalendar";
import ClanWars from "./ClanWars";
import ThemeCustomizer from "./ThemeCustomizer";
import TrainingMode from "./TrainingMode";
import BettingSystem from "./BettingSystem";
const FeatureHub=dynamic(()=>import("./FeatureHub"));
const ProgressCenter=dynamic(()=>import("./ProgressCenter"));
const PerformanceCenter=dynamic(()=>import("./PerformanceCenter"));
const CommunityCenter=dynamic(()=>import("./CommunityCenter"));
const DashboardExtras=dynamic(()=>import("./DashboardExtras"));

type Game={id:string;title:string;price:number;status:"available"|"coming-soon";playable:boolean;description:string;multiplayer:boolean;is3D?:boolean};

const APPS=[
 {href:"/cinestream",icon:"🍿",title:"CinéStream",sub:"Films et séries"},
 {href:"/tiktok",icon:"🎵",title:"TikTok",sub:"Scroll sans compte"},
 {href:"/vortex",icon:"🎬",title:"Vortex",sub:"Streaming"},
 {href:"/games/baldi-basics-3d",icon:"📏",title:"Baldi 3D",sub:"Jeu d’horreur"},
 {href:"/multiplayer",icon:"👥",title:"Multijoueur",sub:"Créer un salon"},
 {href:"/games/eaglecraft",icon:"🧱",title:"EagleCraft",sub:"Minecraft dans le navigateur"},
];

function fmtTime(m:number){return m>=60?`${Math.floor(m/60)} h ${String(m%60).padStart(2,"0")}`:`${m} min`}

export default function SteambloxDashboard({games,username,owned,playTimeMinutes=0,achievements=0,library,friends,friendList=[]}:{games:Game[];username:string;owned:string[];playTimeMinutes?:number;achievements?:number;library?:ReactNode;friends?:ReactNode;friendList?:string[]}){
 const [last,setLast]=useState("");
 useEffect(()=>{setLast(localStorage.getItem("steamblox:lastGame")||"")},[]);
 const ownedGames=useMemo(()=>games.filter(g=>g.playable||owned.includes(g.id)),[games,owned]);
 const lastGame=games.find(g=>g.id===last)||ownedGames[0]||games.find(g=>g.price===0&&g.playable);
 return <div className="ui">
  <WelcomeMusic />
  <Tutorial />
  <header className="ui-top">
   <Link href="/steamblox" className="ui-brand"><span className="ui-logo">TCB</span>TheCombinedWebs</Link>
   <nav className="ui-nav" aria-label="Navigation principale">
    <a href="#accueil">Accueil</a><a href="#bibliotheque">Jeux</a><Link href="/portails">Portails</Link><Link href="/evenements">Événements</Link><Link href="/social">Groupes & duels</Link><Link href="/economie">Boutique</Link>
   </nav>
   <div className="ui-top-right">
    <Link href="/tcb" className="ui-link">TCB Plus</Link>
    <Link href="/discord" className="ui-link">Discord</Link>
    <Link href="/cinestream" className="ui-link">CinéStream</Link>
    <Link href="/tiktok" className="ui-link">TikTok</Link>
    <Link href="/vortex" className="ui-link">Vortex</Link>
    <Link href="/account" className="ui-avatar-chip"><span>{username.slice(0,1).toUpperCase()}</span><b>{username}</b></Link>
   </div>
  </header>

  <main id="accueil" className="ui-main">
   <section className="ui-hero">
    <div>
     <p className="ui-kicker">Salut {username}</p>
     <h1>Prêt à jouer&nbsp;?</h1>
     <p className="ui-lead">{games.length} jeux, des films et tes amis — au même endroit, avec un seul compte.</p>
     <div className="ui-actions">
      {lastGame&&<Link className="button" href={`/games/${lastGame.id}`} onClick={()=>localStorage.setItem("steamblox:lastGame",lastGame.id)}>▶ {last?"Reprendre":"Jouer à"} {lastGame.title}</Link>}
      <a className="button secondary" href="#bibliotheque">Parcourir les jeux</a>
      <Link className="button secondary" href="/discord">💬 Discord · vocal entre amis</Link>
      <Link className="button secondary" href="/">📐 Algèbre Facile</Link>
      <LogoutButton />
     </div>
    </div>
    <dl className="ui-stats">
     <div><dt>Jeux</dt><dd>{owned.filter(id=>!id.startsWith("film:")).length}</dd></div>
     <div><dt>Temps de jeu</dt><dd>{fmtTime(playTimeMinutes)}</dd></div>
     <div><dt>Succès</dt><dd>{achievements}</dd></div>
    </dl>
   </section>

   <section className="ui-section" aria-label="Boutique et roulette du compte bancaire"><Economy compact /></section>
   <section className="ui-section ui-v54-banner" aria-label="Nouveautés v56">
    <div className="ui-v54-inner">
     <div className="ui-v54-badge">v56</div>
     <div className="ui-v54-content">
      <h2>Mega mise à jour TheCombinedWebs v56</h2>
      <div className="ui-v54-grid">
       <div className="ui-v54-item"><span className="ui-v54-icon">📝</span><div><b>Examen blanc</b><small>15 questions mixtes, note sur 20, corrigé détaillé</small></div></div>
       <div className="ui-v54-item"><span className="ui-v54-icon">📖</span><div><b>Mode histoire algèbre</b><small>6 boss mathématiques à vaincre, 3 vies, difficulté croissante</small></div></div>
       <div className="ui-v54-item"><span className="ui-v54-icon">🧮</span><div><b>Calcul Mental</b><small>Nouveau mini-jeu : 30s pour le maximum de bonnes réponses</small></div></div>
       <div className="ui-v54-item"><span className="ui-v54-icon">➗</span><div><b>Fraction Rush</b><small>Nouveau mini-jeu : compare des fractions le plus vite possible</small></div></div>
       <div className="ui-v54-item"><span className="ui-v54-icon">🔧</span><div><b>Problèmes concrets</b><small>Niveau 7 : géométrie, finances, physique</small></div></div>
       <div className="ui-v54-item"><span className="ui-v54-icon">⭐</span><div><b>Notation des jeux</b><small>Note les jeux de 1 à 5 étoiles et laisse un avis</small></div></div>
       <div className="ui-v54-item"><span className="ui-v54-icon">🏆</span><div><b>Classement entre amis</b><small>Ton rang parmi tes amis, pas seulement mondial</small></div></div>
       <div className="ui-v54-item"><span className="ui-v54-icon">🎓</span><div><b>Tutoriel interactif</b><small>Guide de 8 étapes pour les nouveaux joueurs</small></div></div>
       <div className="ui-v54-item"><span className="ui-v54-icon">📊</span><div><b>Statistiques de compte</b><small>Temps de jeu, succès, exercices, films — tout sur une page</small></div></div>
      </div>
     </div>
    </div>
   </section>

   <section className="ui-apps" aria-label="Écosystème TheCombinedWebs">
    {APPS.map(a=><Link key={a.href} href={a.href} className="ui-app"><span>{a.icon}</span><div><b>{a.title}</b><small>{a.sub}</small></div><i>→</i></Link>)}
   </section>

   <section className="ui-section" aria-label="Compétition et communauté"><div className="ui-section-head"><h2>Compétition et communauté</h2><span>Nouveau</span></div>
    <div className="ui-apps">{[
     {href:"/classements?scope=daily",icon:"🎯",title:"Défi du jour",sub:"Même niveau pour tous · +100 XP"},
     {href:"/classements",icon:"🏅",title:"Classements",sub:"Top par jeu · 150 Bobux au N°1 de la semaine"},
     {href:"/tournois",icon:"🏆",title:"Tournois",sub:"Bracket en direct · 200 Bobux au champion"},
     {href:"/clans",icon:"🛡️",title:"Clans",sub:"Ton équipe, son salon, son classement"},
     {href:"/passe",icon:"🎟️",title:"Passe de saison",sub:"30 paliers · boutique de cosmétiques"},
     {href:"/editeur",icon:"🧱",title:"Éditeur de niveaux",sub:"Crée et partage tes arènes"},
     {href:"/tcb",icon:"✨",title:"TCB Plus",sub:"Jeu du jour · stories · groupes · parrainage"},
     {href:`/u/${encodeURIComponent(username)}`,icon:"👤",title:"Mon profil public",sub:"Badges, scores, avis"},
     {href:"/cinestream",icon:"🍿",title:"Soirée ciné",sub:"Regarder un film à plusieurs"},
    ].map(a=><Link key={a.href} href={a.href} className="ui-app"><span>{a.icon}</span><div><b>{a.title}</b><small>{a.sub}</small></div><i>→</i></Link>)}</div>
   </section>

   <section id="quetes" className="ui-section"><div className="ui-section-head"><h2>Quêtes du jour</h2><span>Gagne des Bobux en jouant</span></div><DashboardExtras games={games} owned={owned}/></section>

   <section className="ui-section"><div className="ui-section-head"><h2>Communauté v55</h2><span>Nouveau</span></div>
    <div style={{display:"grid",gridTemplateColumns:"repeat(auto-fit,minmax(320px,1fr))",gap:16}}>
      <WeeklyBoss />
      <CommunityEvents />
      <HallOfFame />
    </div>
   </section>

   <section className="ui-section"><div className="ui-section-head"><h2>Activité et amis</h2></div>
    <div style={{display:"grid",gridTemplateColumns:"repeat(auto-fit,minmax(320px,1fr))",gap:16}}>
      <ActivityWall />
      <FriendChallenges username={username} friends={friendList} />
      <PrivateMessages username={username} friends={friendList} />
      <FriendLeaderboard username={username} friends={friendList} />
    </div>
   </section>

   <section className="ui-section"><div className="ui-section-head"><h2>Mon profil</h2></div>
    <AccountStats username={username} playTimeMinutes={playTimeMinutes} achievements={achievements} owned={owned} friends={friendList} />
   </section>

   <section id="bibliotheque" className="ui-section"><div className="ui-section-head"><h2>Bibliothèque</h2><span>{games.length} jeux</span></div>{library}</section>

   <section id="social" className="ui-section"><div className="ui-section-head"><h2>Amis et vocal</h2><Link className="button secondary" href="/multiplayer">Créer un salon</Link></div>
    <div className="ui-social">{friends}<CommunityCenter /></div>
    <GlobalVoice admin={username==="Younes"} />
   </section>

   <section className="ui-section"><div className="ui-section-head"><h2>Réglages</h2></div>
    <div className="card ui-settings"><AdShieldToggle /></div>
    <details className="ui-more"><summary>Progression, performance et options avancées</summary>
     <ProgressCenter ownedCount={owned.filter(id=>!id.startsWith("film:")).length} has3D={ownedGames.some(g=>g.is3D)} />
     <PerformanceCenter /><FeatureHub />
    </details>
   </section>
  </main>
 </div>;
}
