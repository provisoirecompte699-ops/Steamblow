"use client";
import { useEffect, useState } from "react";

type Params = { speed: number; enemyCount: number; damage: number; lives: number; timeLimit: number };

const GAMES = ["meteor-mayhem", "crystal-rush", "cyber-siege", "block-brawl", "neon-arena", "castle-clash"];

const DEFAULTS: Record<string, Params> = {
  "meteor-mayhem": { speed: 1, enemyCount: 5, damage: 1, lives: 3, timeLimit: 60 },
  "crystal-rush": { speed: 1, enemyCount: 4, damage: 1, lives: 3, timeLimit: 90 },
  "cyber-siege": { speed: 1, enemyCount: 6, damage: 1, lives: 3, timeLimit: 120 },
  "block-brawl": { speed: 1, enemyCount: 4, damage: 1, lives: 3, timeLimit: 60 },
  "neon-arena": { speed: 1, enemyCount: 5, damage: 1, lives: 3, timeLimit: 90 },
  "castle-clash": { speed: 1, enemyCount: 4, damage: 1, lives: 3, timeLimit: 120 },
};

const PKEY = "steamblox:training-params";

export default function TrainingMode() {
  const [gameId, setGameId] = useState(GAMES[0]);
  const [params, setParams] = useState<Params>(DEFAULTS[GAMES[0]]);
  const [saved, setSaved] = useState(false);

  useEffect(() => {
    try {
      const stored = JSON.parse(localStorage.getItem(PKEY) || "{}");
      if (stored[gameId]) setParams(stored[gameId]);
      else setParams(DEFAULTS[gameId] || DEFAULTS[GAMES[0]]);
    } catch { setParams(DEFAULTS[GAMES[0]]); }
  }, [gameId]);

  const save = () => {
    try {
      const stored = JSON.parse(localStorage.getItem(PKEY) || "{}");
      stored[gameId] = params;
      localStorage.setItem(PKEY, JSON.stringify(stored));
      setSaved(true);
      setTimeout(() => setSaved(false), 2000);
    } catch {}
  };

  const reset = () => { setParams(DEFAULTS[gameId] || DEFAULTS[GAMES[0]]); };

  const presets: { name: string; icon: string; params: Partial<Params> }[] = [
    { name: "Facile", icon: "😊", params: { speed: 0.7, enemyCount: 3, damage: 1, lives: 5, timeLimit: 120 } },
    { name: "Normal", icon: "🎯", params: { speed: 1, enemyCount: 5, damage: 1, lives: 3, timeLimit: 60 } },
    { name: "Difficile", icon: "💀", params: { speed: 1.5, enemyCount: 8, damage: 2, lives: 2, timeLimit: 45 } },
    { name: "Extrême", icon: "🔥", params: { speed: 2, enemyCount: 12, damage: 3, lives: 1, timeLimit: 30 } },
  ];

  const applyPreset = (p: Partial<Params>) => setParams(prev => ({ ...prev, ...p }));

  return <div className="card">
    <div className="section-head"><div><div className="eyebrow">ENTRAÎNEMENT</div><h3>Mode entraînement libre</h3></div></div>
    <div className="ui-train-game-select">
      <label>Jeu</label>
      <select className="input" value={gameId} onChange={e => setGameId(e.target.value)}>
        {GAMES.map(g => <option key={g} value={g}>{g.replace(/-/g, " ").replace(/\b\w/g, c => c.toUpperCase())}</option>)}
      </select>
    </div>
    <div className="ui-train-presets">
      <small>Préréglages :</small>
      {presets.map(p => <button key={p.name} className="ui-train-preset" onClick={() => applyPreset(p.params)}>{p.icon} {p.name}</button>)}
    </div>
    <div className="ui-train-params">
      <div className="ui-train-param">
        <label>Vitesse ennemis : <b>{params.speed.toFixed(1)}×</b></label>
        <input type="range" min={0.5} max={3} step={0.1} value={params.speed} onChange={e => setParams({ ...params, speed: Number(e.target.value) })} />
      </div>
      <div className="ui-train-param">
        <label>Nombre d'ennemis : <b>{params.enemyCount}</b></label>
        <input type="range" min={2} max={20} step={1} value={params.enemyCount} onChange={e => setParams({ ...params, enemyCount: Number(e.target.value) })} />
      </div>
      <div className="ui-train-param">
        <label>Dégâts reçus : <b>{params.damage}</b></label>
        <input type="range" min={1} max={5} step={1} value={params.damage} onChange={e => setParams({ ...params, damage: Number(e.target.value) })} />
      </div>
      <div className="ui-train-param">
        <label>Vies : <b>{params.lives}</b></label>
        <input type="range" min={1} max={10} step={1} value={params.lives} onChange={e => setParams({ ...params, lives: Number(e.target.value) })} />
      </div>
      <div className="ui-train-param">
        <label>Temps limite : <b>{params.timeLimit}s</b></label>
        <input type="range" min={10} max={300} step={5} value={params.timeLimit} onChange={e => setParams({ ...params, timeLimit: Number(e.target.value) })} />
      </div>
    </div>
    <div className="ui-train-actions">
      <button className="button secondary" onClick={reset}>Réinitialiser</button>
      <button className="button" onClick={save}>{saved ? "✓ Sauvegardé !" : "Sauvegarder"}</button>
    </div>
    <p className="muted" style={{ fontSize: 12, marginTop: 8 }}>Les paramètres sont sauvegardés localement et peuvent être appliqués aux jeux compatibles.</p>
  </div>;
}
