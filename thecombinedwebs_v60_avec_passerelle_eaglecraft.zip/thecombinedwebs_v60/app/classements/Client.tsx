"use client";
import Link from "next/link";
import { useEffect, useState } from "react";

type G = { id: string; mode: string; title: string };
type E = { u: string; score: number; at: number; rank: number; friend: boolean; replay?: string };
type D = { games: G[]; game: string; scope: string; week: string; daily: G & { day: string }; prizes: { weekly: number; daily: number }; entries: E[] };

export default function Client({ me }: { me: string }) {
  const [game, setGame] = useState("");
  const [scope, setScope] = useState("week");
  const [onlyFriends, setOnlyFriends] = useState(false);
  const [d, setD] = useState<D | null>(null);
  useEffect(() => { const q = new URLSearchParams(location.search); setGame(q.get("game") || "meteor-mayhem"); setScope(q.get("scope") || "week"); }, []);
  useEffect(() => { if (!game) return; fetch(`/api/leaderboard?game=${game}&scope=${scope}`).then((r) => r.json()).then(setD).catch(() => {}); history.replaceState(null, "", `?game=${game}&scope=${scope}`); }, [game, scope]);
  const list = (d?.entries || []).filter((e) => !onlyFriends || e.friend || e.u.toLowerCase() === me.toLowerCase());
  const mine = d?.entries.find((e) => e.u.toLowerCase() === me.toLowerCase());
  return <>
    <div className="hub-head"><div><span className="hub-kick">Compétition</span><h1>Classements</h1><p>Le N°1 de chaque jeu gagne {d?.prizes.weekly ?? 150} Bobux en fin de semaine. Le meilleur au défi du jour remporte {d?.prizes.daily ?? 50} Bobux.</p></div></div>
    {d?.daily && <div className="hub-card hub-daily" style={{ marginBottom: 16 }}>
      <div><span className="hub-kick">Défi du jour · {d.daily.day}</span><br /><b>{d.daily.title}</b><div className="hub-muted">Même carte et mêmes vagues pour tout le monde. Jouable même sans posséder le jeu. +100 XP à la première partie.</div></div>
      <div className="hub-row"><button className="hub-btn" onClick={() => setScope("daily")}>Voir le classement</button><Link className="hub-btn pri" href={`/games/${d.daily.id}?daily=1`}>Relever le défi</Link></div>
    </div>}
    <div className="hub-tabs">{[["week", `Semaine ${d?.week || ""}`], ["all", "Depuis toujours"], ["daily", "Défi du jour"]].map(([k, l]) => <button key={k} className={scope === k ? "on" : ""} onClick={() => setScope(k)}>{l}</button>)}
      <button className={onlyFriends ? "on" : ""} onClick={() => setOnlyFriends(!onlyFriends)}>Amis seulement</button></div>
    {scope !== "daily" && <div className="hub-tabs">{(d?.games || []).map((g) => <button key={g.id} className={game === g.id ? "on" : ""} onClick={() => setGame(g.id)}>{g.title}</button>)}</div>}
    <div className="hub-card">
      {mine && <p className="hub-muted" style={{ marginTop: 0 }}>Ta place : <b style={{ color: "#fff" }}>{mine.rank}{mine.rank === 1 ? "er" : "e"}</b> avec {mine.score.toLocaleString("fr-FR")} pts</p>}
      {!d ? <div className="hub-empty">Chargement…</div> : !list.length ? <div className="hub-empty">Personne n’a encore joué. Sois le premier.</div> :
        <table className="hub-table"><thead><tr><th>#</th><th>Joueur</th><th>Score</th><th>Date</th></tr></thead><tbody>
          {list.slice(0, scope === "daily" ? 50 : 100).map((e) => <tr key={e.u} className={`${e.u.toLowerCase() === me.toLowerCase() ? "me" : ""} ${e.friend ? "friend" : ""}`}>
            <td className={`hub-rank r${e.rank}`}>{e.rank <= 3 ? ["🥇", "🥈", "🥉"][e.rank - 1] : e.rank}</td>
            <td><Link href={`/u/${encodeURIComponent(e.u)}`}>{e.u}</Link></td>
            <td><b>{e.score.toLocaleString("fr-FR")}</b>{e.replay && <> · <Link href={`/replay/${e.replay}`}>rediffusion</Link></>}</td>
            <td className="hub-muted">{new Date(e.at).toLocaleDateString("fr-FR")}</td></tr>)}
        </tbody></table>}
    </div>
  </>;
}
