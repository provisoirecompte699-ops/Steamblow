"use client";
import { useEffect, useState } from "react";

type Theme = { id: string; name: string; icon: string; bg: string; card: string; accent: string; text: string };

const THEMES: Theme[] = [
  { id: "dark", name: "Sombre", icon: "🌙", bg: "#0a0b10", card: "#12141c", accent: "#8b7cff", text: "#fff" },
  { id: "neon", name: "Néon", icon: "💜", bg: "#0d0221", card: "#1a0b2e", accent: "#bf00ff", text: "#e0d0ff" },
  { id: "retro", name: "Rétro", icon: "🕹️", bg: "#1a1a0a", card: "#2a2a14", accent: "#ffaa00", text: "#fff8dc" },
  { id: "ocean", name: "Océan", icon: "🌊", bg: "#001a2e", card: "#002a4a", accent: "#00b4d8", text: "#d0f0ff" },
  { id: "forest", name: "Forêt", icon: "🌿", bg: "#0a1a0a", card: "#142a14", accent: "#10b981", text: "#d0ffd0" },
  { id: "sunset", name: "Coucher", icon: "🌅", bg: "#2a1010", card: "#3a1818", accent: "#f97316", text: "#ffe0d0" },
];

const TKEY = "steamblox:theme";

export default function ThemeCustomizer() {
  const [theme, setTheme] = useState<Theme>(THEMES[0]);

  useEffect(() => {
    const saved = localStorage.getItem(TKEY) || "dark";
    setTheme(THEMES.find(t => t.id === saved) || THEMES[0]);
  }, []);

  const applyTheme = (t: Theme) => {
    setTheme(t);
    localStorage.setItem(TKEY, t.id);
    // Apply CSS variables
    const root = document.documentElement;
    root.style.setProperty("--sb-bg", t.bg);
    root.style.setProperty("--sb-card", t.card);
    root.style.setProperty("--sb-accent", t.accent);
    root.style.setProperty("--sb-text", t.text);
  };

  return <div className="card">
    <div className="section-head"><div><div className="eyebrow">PERSONNALISATION</div><h3>Thèmes visuels</h3></div></div>
    <div className="ui-themes">
      {THEMES.map(t => <div key={t.id} className={`ui-theme-opt ${t.id === theme.id ? "on" : ""}`} onClick={() => applyTheme(t)}>
        <div className="ui-theme-preview" style={{ background: t.bg, borderColor: t.accent }}>
          <div className="ui-theme-dot" style={{ background: t.accent }} />
          <div className="ui-theme-bar" style={{ background: t.card }} />
        </div>
        <b>{t.icon} {t.name}</b>
        {t.id === theme.id && <small style={{ color: t.accent }}>✓ Actif</small>}
      </div>)}
    </div>
    <div className="ui-theme-note">
      <p className="muted" style={{ fontSize: 12 }}>Le thème s'applique instantanément à l'interface. Sauvegardé automatiquement.</p>
    </div>
  </div>;
}
