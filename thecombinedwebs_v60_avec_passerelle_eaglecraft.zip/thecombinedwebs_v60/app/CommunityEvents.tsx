"use client";
import { useEffect, useState } from "react";
import Link from "next/link";

type Event = { day: string; icon: string; title: string; desc: string; href: string };

const EVENTS: Event[] = [
  { day: "Lundi", icon: "🎯", title: "Défi du jour doublé", desc: "Le défi quotidien rapporte le double d'XP", href: "/classements?scope=daily" },
  { day: "Mardi", icon: "🏆", title: "Tournoi Flash", desc: "Tournoi express à 16 joueurs — inscription 17h", href: "/tournois" },
  { day: "Mercredi", icon: "🍿", title: "Soirée ciné communautaire", desc: "Tout le monde regarde le même film à 20h", href: "/cinestream" },
  { day: "Jeudi", icon: "📐", title: "Défi algèbre", desc: "Le chrono du jour compte double", href: "/" },
  { day: "Vendredi", icon: "👹", title: "Assaut du boss", desc: "Les dégâts au boss hebdo sont doublés", href: "/steamblox" },
  { day: "Samedi", icon: "🎮", title: "Marathon arcade", desc: "Tous les jeux arcade rapportent +50% d'XP", href: "/steamblox#bibliotheque" },
  { day: "Dimanche", icon: "🛡️", title: "Clan Wars", desc: "Les clans s'affrontent pour la suprématie", href: "/clans" },
];

export default function CommunityEvents() {
  const [today, setToday] = useState("");
  useEffect(() => {
    const days = ["Dimanche", "Lundi", "Mardi", "Mercredi", "Jeudi", "Vendredi", "Samedi"];
    setToday(days[new Date().getDay()]);
  }, []);

  return <div className="card">
    <div className="section-head"><div><div className="eyebrow">COMMUNAUTÉ</div><h3>Événements de la semaine</h3></div></div>
    {EVENTS.map(e => <Link key={e.day} href={e.href} className={`ui-event-card ${e.day === today ? "today" : ""}`} style={e.day === today ? { borderColor: "#8b7cff", background: "linear-gradient(135deg,#1a1a2e,#8b7cff22)" } : {}}>
      <span className="ui-event-icon">{e.icon}</span>
      <div className="ui-event-info">
        <b>{e.day === today ? "🔔 " : ""}{e.day} — {e.title}</b>
        <small>{e.desc}</small>
      </div>
    </Link>)}
  </div>;
}
