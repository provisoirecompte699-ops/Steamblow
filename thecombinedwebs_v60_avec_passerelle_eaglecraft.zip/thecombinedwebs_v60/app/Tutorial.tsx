"use client";
import { useEffect, useState } from "react";
import Link from "next/link";

const STEPS = [
  { icon: "🎮", title: "Bienvenue sur TheCombinedWebs !", text: "Découvre 12 jeux arcade gratuits, jouables au clavier, à la manette ou sur mobile." },
  { icon: "📚", title: "Ta bibliothèque", text: "Tous les jeux sont gratuits. Clique sur « Jouer » pour lancer une partie. Tes records sont sauvegardés." },
  { icon: "🏆", title: "Succès et classements", text: "Débloque des succès, grimpe dans les classements et participe aux tournois hebdomadaires." },
  { icon: "🍿", title: "CinéStream", text: "Regarde des films et séries, organise des soirées ciné avec tes amis : chat, vocal et synchronisation." },
  { icon: "📐", title: "Algèbre Facile", text: "Révise l'algèbre avec un solveur pas à pas, des exercices corrigés et un mode histoire avec boss." },
  { icon: "👥", title: "Amis et vocal", text: "Ajoute des amis, discute en vocal, envoie des messages privés et lance des défis." },
  { icon: "🪙", title: "Bobux et quêtes", text: "Accomplis des quêtes quotidiennes et hebdomadaires pour gagner des Bobux et des cosmétiques." },
  { icon: "🛡️", title: "Clans et événements", text: "Rejoins un clan, participe aux événements quotidiens et vaincs le boss hebdomadaire ensemble." },
];

const TKEY = "steamblox:tutorial-done";

export default function Tutorial() {
  const [show, setShow] = useState(false);
  const [step, setStep] = useState(0);

  useEffect(() => {
    try {
      if (!localStorage.getItem(TKEY)) setShow(true);
    } catch {}
  }, []);

  const next = () => {
    if (step < STEPS.length - 1) { setStep(step + 1); }
    else { setShow(false); try { localStorage.setItem(TKEY, "1"); } catch {} }
  };

  const skip = () => { setShow(false); try { localStorage.setItem(TKEY, "1"); } catch {} };

  if (!show) return null;
  const s = STEPS[step];

  return <div className="ui-tutorial-overlay">
    <div className="ui-tutorial-card">
      <div className="ui-tutorial-top">
        <button className="ui-tutorial-skip" onClick={skip}>Passer →</button>
      </div>
      <div className="ui-tutorial-icon">{s.icon}</div>
      <h2>{s.title}</h2>
      <p>{s.text}</p>
      <div className="ui-tutorial-dots">{STEPS.map((_, i) => <span key={i} className={i === step ? "on" : ""} />)}</div>
      <div className="ui-tutorial-actions">
        {step > 0 && <button className="button secondary" onClick={() => setStep(step - 1)}>← Précédent</button>}
        <button className="button" onClick={next}>{step < STEPS.length - 1 ? "Suivant →" : "C'est parti !"}</button>
      </div>
    </div>
  </div>;
}
