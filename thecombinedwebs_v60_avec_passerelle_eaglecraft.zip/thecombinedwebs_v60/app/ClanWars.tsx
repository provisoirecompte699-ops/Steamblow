"use client";
import { useEffect, useState } from "react";

type Clan = { name: string; members: number; wins: number; wars: number; power: number };
type ClanWar = { clan1: string; clan2: string; status: "active" | "upcoming"; endsIn: string };

const SAMPLE_CLANS: Clan[] = [
  { name: "Les Légendes", members: 24, wins: 45, wars: 12, power: 8900 },
  { name: "Shadow Ops", members: 18, wins: 32, wars: 10, power: 7200 },
  { name: "Phoenix Rising", members: 31, wins: 58, wars: 15, power: 11500 },
  { name: "Neon Knights", members: 12, wins: 20, wars: 8, power: 4800 },
  { name: "Ice Wolves", members: 27, wins: 41, wars: 14, power: 9300 },
];

const SAMPLE_WARS: ClanWar[] = [
  { clan1: "Phoenix Rising", clan2: "Ice Wolves", status: "active", endsIn: "2j 14h" },
  { clan1: "Les Légendes", clan2: "Shadow Ops", status: "upcoming", endsIn: "Dans 3 jours" },
];

const CKEY = "steamblox:clan-data";

export default function ClanWars({ username }: { username: string }) {
  const [clans, setClans] = useState<Clan[]>([]);
  const [wars, setWars] = useState<ClanWar[]>([]);
  const [myClan, setMyClan] = useState<string | null>(null);
  const [creating, setCreating] = useState(false);
  const [newName, setNewName] = useState("");

  useEffect(() => {
    setClans(SAMPLE_CLANS);
    setWars(SAMPLE_WARS);
    try { setMyClan(localStorage.getItem(CKEY) || null); } catch {}
  }, []);

  const joinClan = (name: string) => {
    localStorage.setItem(CKEY, name);
    setMyClan(name);
  };

  const createClan = () => {
    if (!newName.trim()) return;
    const newClan: Clan = { name: newName.trim(), members: 1, wins: 0, wars: 0, power: 100 };
    setClans([newClan, ...clans]);
    localStorage.setItem(CKEY, newClan.name);
    setMyClan(newClan.name);
    setCreating(false);
    setNewName("");
  };

  const leaveClan = () => {
    localStorage.removeItem(CKEY);
    setMyClan(null);
  };

  const sorted = [...clans].sort((a, b) => b.power - a.power);

  return <div className="card">
    <div className="section-head"><div><div className="eyebrow">CLANS</div><h3>Clans & Clan Wars</h3></div>
      {!myClan && <button className="button secondary" style={{ padding: "4px 10px", fontSize: 12 }} onClick={() => setCreating(!creating)}>+ Créer</button>}
    </div>
    {creating && <div className="ui-clan-create">
      <input className="input" value={newName} onChange={e => setNewName(e.target.value)} placeholder="Nom du clan" maxLength={20} />
      <button className="button" onClick={createClan}>Créer</button>
    </div>}
    {myClan && <div className="ui-my-clan">
      <p className="ui-clan-badge">🛡️ Ton clan : <b>{myClan}</b></p>
      <button className="button secondary" style={{ padding: "4px 10px", fontSize: 12 }} onClick={leaveClan}>Quitter</button>
    </div>}
    {wars.length > 0 && <div className="ui-clan-wars">
      <h4>⚔️ Guerres en cours</h4>
      {wars.map((w, i) => <div key={i} className={`ui-clan-war ${w.status}`}>
        <div className="ui-war-clan"><b>{w.clan1}</b></div>
        <span className="ui-war-vs">VS</span>
        <div className="ui-war-clan"><b>{w.clan2}</b></div>
        <small>{w.status === "active" ? "En cours" : "À venir"} · {w.endsIn}</small>
      </div>)}
    </div>}
    <div className="ui-clan-ranking">
      <h4>Classement des clans</h4>
      {sorted.map((c, i) => <div key={i} className={`ui-clan-row ${c.name === myClan ? "me" : ""}`}>
        <span className="ui-clan-rank">{i + 1}</span>
        <div className="ui-clan-info"><b>{c.name}{c.name === myClan ? " ⭐" : ""}</b><small>{c.members} membres · {c.wins} victoires</small></div>
        <b className="ui-clan-power">{c.power.toLocaleString()}</b>
        {c.name !== myClan && <button className="button secondary" style={{ padding: "2px 8px", fontSize: 11 }} onClick={() => joinClan(c.name)}>Rejoindre</button>}
      </div>)}
    </div>
  </div>;
}
