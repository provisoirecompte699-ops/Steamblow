"use client";
/**
 * DiscordVoiceProvider — garde le VoiceEngine vivant à travers la navigation.
 *
 * Avant, le VoiceEngine était créé dans DiscordClient et détruit quand on
 * quittait la page /discord. Résultat : le vocal coupait dès qu'on lançait un jeu.
 *
 * Ce provider vit dans le layout racine, donc le moteur persiste. Les pages
 * /discord et /games/* consomment le même engine via useDiscordVoice().
 *
 * Le username est récupéré depuis /api/discord/ping (déjà appelé par SocialNotifier)
 * pour éviter de passer un prop serveur dans le layout racine.
 *
 * Le provider centralise aussi les événements vocaux (join/leave) via un bus
 * d'événements interne, pour éviter que plusieurs composants se disputent
 * engine.onEvent (qui est un seul callback).
 */
import { createContext, useContext, useEffect, useRef, useState, useCallback, type ReactNode } from "react";
import { usePathname } from "next/navigation";
import { VoiceEngine, type VoiceSnapshot } from "./discord/voice";
import { playJoinSound } from "./cosmetics";

type VoiceEvent = { kind: "join" | "leave" | "self-join" | "self-leave"; who: string; at: number };

type Ctx = {
  engine: VoiceEngine | null;
  voice: VoiceSnapshot | null;
  ready: boolean;
  /** S'abonner aux événements vocaux (join/leave). Retourne une fonction de désabonnement. */
  subscribeEvents: (fn: (e: VoiceEvent) => void) => () => void;
};

const DiscordVoiceContext = createContext<Ctx>({
  engine: null,
  voice: null,
  ready: false,
  subscribeEvents: () => () => {},
});

export function useDiscordVoice() {
  return useContext(DiscordVoiceContext);
}

export default function DiscordVoiceProvider({ children }: { children: ReactNode }) {
  const engineRef = useRef<VoiceEngine | null>(null);
  const [voice, setVoice] = useState<VoiceSnapshot | null>(null);
  const [ready, setReady] = useState(false);
  const pathname = usePathname();
  const attemptRef = useRef(0);

  // Bus d'événements vocaux : évite que plusieurs composants se disputent engine.onEvent
  const eventListeners = useRef(new Set<(e: VoiceEvent) => void>());
  const subscribeEvents = useCallback((fn: (e: VoiceEvent) => void) => {
    eventListeners.current.add(fn);
    return () => { eventListeners.current.delete(fn); };
  }, []);

  // Déduplication : ignore le même {kind, who} dans les 2 secondes
  const lastEventRef = useRef<string>("");

  useEffect(() => {
    if (ready || pathname.startsWith("/login") || pathname.startsWith("/register") || pathname.startsWith("/banned") || pathname.startsWith("/special")) return;

    let off: (() => void) | null = null;
    let cancelled = false;

    async function init() {
      try {
        const r = await fetch("/api/discord/ping?where=En%20ligne", { cache: "no-store" });
        if (!r.ok || cancelled) return;
        const d = await r.json();
        if (!d.loggedIn || !d.username || cancelled) return;

        const e = new VoiceEngine(d.username);
        engineRef.current = e;
        off = e.subscribe((s) => setVoice(s));

        // Centralise les événements vocaux dans le bus du provider
        e.onEvent = (kind, who) => {
          const key = `${kind}:${who}`;
          const now = Date.now();
          // Déduplication des événements répétés (reconnexions, battements)
          if (lastEventRef.current === key && now - (lastEventRef as any).ts < 2000) return;
          (lastEventRef as any).ts = now;
          lastEventRef.current = key;

          const evt: VoiceEvent = { kind, who, at: now };
          eventListeners.current.forEach((fn) => fn(evt));

          // Système de sons : join/leave (géré ici, plus dans DiscordClient)
          if (kind === "join" || kind === "self-join") {
            const snd = (window as any).__sbxCos?.[who.toLowerCase()]?.sound;
            if (snd) playJoinSound(snd);
            else {
              try {
                const ctx = new (window.AudioContext || (window as any).webkitAudioContext)();
                const o = ctx.createOscillator(), g = ctx.createGain();
                o.type = "sine"; o.frequency.value = 523;
                g.gain.setValueAtTime(0.06, ctx.currentTime);
                g.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + 0.14);
                o.connect(g).connect(ctx.destination); o.start(); o.stop(ctx.currentTime + 0.14);
                setTimeout(() => { o.frequency.value = 784; }, 90);
              } catch {}
            }
          } else {
            try {
              const ctx = new (window.AudioContext || (window as any).webkitAudioContext)();
              const o = ctx.createOscillator(), g = ctx.createGain();
              o.type = "sine"; o.frequency.value = 659;
              g.gain.setValueAtTime(0.06, ctx.currentTime);
              g.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + 0.16);
              o.connect(g).connect(ctx.destination); o.start(); o.stop(ctx.currentTime + 0.16);
            } catch {}
          }
        };

        byeFn = () => e.leaveBeacon();
        window.addEventListener("pagehide", byeFn);

        setReady(true);
      } catch {
        // Pas connecté ou erreur réseau
      }
    }

    let byeFn: (() => void) | null = null;
    init();

    return () => {
      cancelled = true;
      if (off) off();
      if (byeFn) window.removeEventListener("pagehide", byeFn);
    };
  }, [pathname, ready]);

  return (
    <DiscordVoiceContext.Provider value={{ engine: engineRef.current, voice, ready, subscribeEvents }}>
      {children}
    </DiscordVoiceContext.Provider>
  );
}
