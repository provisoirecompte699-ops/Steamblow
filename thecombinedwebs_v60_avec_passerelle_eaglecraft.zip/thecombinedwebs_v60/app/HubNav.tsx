"use client";
import Link from "next/link";
import { usePathname } from "next/navigation";
import LogoutButton from "./LogoutButton";

const LINKS = [
  { href: "/steamblox", label: "Jeux" },
  { href: "/portails", label: "Portails" },
  { href: "/evenements", label: "Événements" },
  { href: "/economie", label: "Boutique & banque" },
  { href: "/social", label: "Groupes & duels" },
  { href: "/discord", label: "Discord" },
  { href: "/tiktok", label: "TikTok" },
  { href: "/classements", label: "Classements" },
  { href: "/tournois", label: "Tournois" },
  { href: "/clans", label: "Clans" },
  { href: "/passe", label: "Passe & boutique" },
  { href: "/editeur", label: "Éditeur" },
  { href: "/tcb", label: "TCB Plus" },
  { href: "/games/eaglecraft", label: "EagleCraft" },
];

export default function HubNav({ username }: { username?: string }) {
  const path = usePathname() || "";
  return <header className="hub-nav">
    <Link href="/steamblox" className="hub-brand"><span>TCB</span>TheCombinedWebs</Link>
    <nav aria-label="Navigation">{LINKS.map((l) => <Link key={l.href} href={l.href} className={path.startsWith(l.href) ? "on" : ""}>{l.label}</Link>)}</nav>
    <button type="button" className="hub-btn" onClick={()=>{const tv=(window as any).CSTV;tv?.set(!tv.on());}}>Mode TV</button>
    {username && <Link href={`/u/${encodeURIComponent(username)}`} className="hub-me"><span>{username.slice(0, 1).toUpperCase()}</span>{username}</Link>}
    {username && <LogoutButton className="hub-btn" />}
  </header>;
}
