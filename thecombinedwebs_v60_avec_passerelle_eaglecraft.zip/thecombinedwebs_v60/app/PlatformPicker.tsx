"use client";
import {useEffect, useState} from "react";

type Platform="pc"|"ios"|"android"|"tv";

const options:[Platform,string,string,string][]=[
  ["pc","PC","Windows / macOS / Linux","Jouer directement dans le navigateur"],
  ["ios","iOS","iPhone / iPad","Version Safari optimisée"],
  ["android","Android","Téléphone / tablette","Launcher Android TheCombinedWebs"],
  ["tv","Télévision","Android TV / Google TV / Smart TV","Navigation à la télécommande"]
];

function detect():Platform{
  if(typeof navigator==="undefined") return "pc";
  const ua=navigator.userAgent.toLowerCase();
  if(/smarttv|smart-tv|tizen|web0s|webos|netcast|hbbtv|bravia|aft[a-z]|android tv|googletv|crkey|steambloxtv|; ?tv;/.test(ua)) return "tv";
  if(/android/.test(ua)) return "android";
  if(/iphone|ipad|ipod/.test(ua) || (navigator.platform==="MacIntel" && navigator.maxTouchPoints>1)) return "ios";
  return "pc";
}

export default function PlatformPicker(){
  const [open,setOpen]=useState(false);
  const [detected,setDetected]=useState<Platform>("pc");

  useEffect(()=>{
    const d=detect(); setDetected(d);
    const saved=localStorage.getItem("steamblox-platform") as Platform|null;
    if(!saved) setOpen(true);
  },[]);

  function choose(p:Platform){
    localStorage.setItem("steamblox-platform",p);
    localStorage.setItem("steamblox-platform-confirmed","1");
    const w=window as unknown as {CSTV?:{set:(v:boolean)=>void}};
    if(p==="tv"){localStorage.setItem("cs-tv","1");w.CSTV?.set(true)}else if(localStorage.getItem("cs-tv")==="1"){localStorage.setItem("cs-tv","0");w.CSTV?.set(false)}
    setOpen(false);
  }

  if(!open) return null;
  const detectedLabel=options.find(x=>x[0]===detected)?.[1]||"PC";
  return <div className="platform-overlay" role="dialog" aria-modal="true" aria-labelledby="platform-title">
    <div className="platform-modal">
      <div className="platform-orb">TCB</div>
      <div className="platform-kicker">BIENVENUE SUR THECOMBINEDWEBS</div>
      <h2 id="platform-title">Tu joues sur quel appareil ?</h2>
      <p className="platform-copy">On adapte l'interface et les contrôles à ton appareil. On détecte probablement <b>{detectedLabel}</b>, mais c'est toi qui décides.</p>
      <div className="platform-options">
        {options.map(([id,title,subtitle,desc])=><button key={id} className={`platform-option ${id===detected?"detected":""}`} onClick={()=>choose(id)}>
          <span className="platform-icon">{id==="pc"?"▣":id==="ios"?"●":id==="tv"?"▭":"◆"}</span>
          <span className="platform-text"><b>{title}</b><small>{subtitle}</small><em>{desc}</em></span>
          {id===detected && <span className="platform-detected">DÉTECTÉ</span>}
        </button>)}
      </div>
      <p className="platform-note">Tu pourras changer ce choix plus tard dans les réglages.</p>
    </div>
  </div>
}
