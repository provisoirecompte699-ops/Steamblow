import FeaturePage from "../FeaturePages";
export const metadata={title:"Social · TheCombinedWebs"};
export default function Page(){return <FeaturePage mode="social"/>;}
