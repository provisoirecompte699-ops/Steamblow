"use client";
import {
  useEffect,
  useRef,
  useState,
  useId,
  cloneElement,
  isValidElement,
  type ReactNode,
  type ReactElement,
} from "react";
import Link from "next/link";
import { useDiscordVoice } from "./DiscordVoiceProvider";
import RiskDuels from "./RiskDuels";
import "./features.css";

async function api(url: string, body?: unknown, method = "POST") {
  const r = await fetch(
    url,
    body === undefined
      ? { cache: "no-store" }
      : {
          method,
          headers: { "content-type": "application/json" },
          body: JSON.stringify(body),
        },
  );
  const d = await r.json();
  if (!r.ok) throw new Error(d.error || "La requête a échoué.");
  return d;
}
function useData(url: string, interval = 15000) {
  const [data, setData] = useState<any>(null),
    [error, setError] = useState("");
  const load = async () => {
    try {
      setData(await api(url));
      setError("");
    } catch (e) {
      setError(e instanceof Error ? e.message : "Connexion indisponible.");
    }
  };
  useEffect(() => {
    let active = true;
    const tick = async () => {
      try {
        const d = await api(url);
        if (active) {
          setData(d);
          setError("");
        }
      } catch (e) {
        if (active)
          setError(e instanceof Error ? e.message : "Connexion indisponible.");
      }
    };
    tick();
    const t = setInterval(tick, interval);
    return () => {
      active = false;
      clearInterval(t);
    };
  }, [url, interval]);
  return { data, error, load };
}
function Countdown({ end }: { end: number }) {
  const [now, setNow] = useState(Date.now());
  useEffect(() => {
    const t = setInterval(() => setNow(Date.now()), 1000);
    return () => clearInterval(t);
  }, []);
  const s = Math.max(0, Math.floor((end - now) / 1000)),
    days = Math.floor(s / 86400);
  return (
    <time dateTime={new Date(end).toISOString()}>
      {days ? `${days} j ` : ""}
      {String(Math.floor(s / 3600) % 24).padStart(2, "0")}:
      {String(Math.floor(s / 60) % 60).padStart(2, "0")}:
      {String(s % 60).padStart(2, "0")}
    </time>
  );
}
function Field({ label, children }: { label: string; children: ReactNode }) {
  const id = useId();
  return (
    <div className="f-field">
      <label htmlFor={id}>{label}</label>
      {isValidElement(children)
        ? cloneElement(children as ReactElement<{ id?: string }>, { id })
        : children}
    </div>
  );
}
function Notice({ error, message }: { error?: string; message?: string }) {
  return error || message ? (
    <p
      className={`f-note ${error ? "f-error" : ""}`}
      role={error ? "alert" : "status"}
    >
      {error || message}
    </p>
  ) : null;
}
const NAV = [
  ["/steamblox", "Accueil"],
  ["/portails", "Portails"],
  ["/evenements", "Événements"],
  ["/social", "Social"],
  ["/economie", "Boutique & banque"],
];
const TITLES: Record<string, [string, string]> = {
  portails: ["Portails", "Tous tes jeux, une seule bibliothèque."],
  evenements: [
    "Événements du serveur",
    "Rendez-vous en direct avec la communauté.",
  ],
  social: ["Jouer ensemble", "Groupes vocaux, chat et duels entre amis."],
  economie: [
    "Boutique & banque",
    "Cosmétiques, trolls et roulette sur ton compte bancaire.",
  ],
};
export default function FeaturePage({
  mode,
}: {
  mode: "portails" | "evenements" | "social" | "economie";
}) {
  const [light, setLight] = useState(false),
    [tv, setTv] = useState(false);
  return (
    <div
      className={`feature-shell ${light ? "light" : ""} ${tv ? "f-tv" : ""}`}
    >
      <a className="f-skip" href="#feature-main">
        Aller au contenu
      </a>
      <header className="f-header">
        <Link className="f-brand" href="/steamblox">
          <svg aria-label="Logo TCB" viewBox="0 0 32 32" fill="none">
            <path d="M3 7h26v6H19v16h-6V13H3z" fill="currentColor" />
            <path d="M3 20h6v9H3zM23 20h6v9h-6z" fill="currentColor" />
          </svg>
          <span>TheCombinedWebs</span>
        </Link>
        <nav className="f-nav" aria-label="Navigation">
          {NAV.map(([url, label]) => (
            <Link
              key={url}
              href={url}
              aria-current={url === `/${mode}` ? "page" : undefined}
            >
              {label}
            </Link>
          ))}
        </nav>
        <button className="f-btn" onClick={() => setLight(!light)}>
          {light ? "Mode sombre" : "Mode clair"}
        </button>
        <button
          className="f-btn"
          onClick={() => {
            setTv(!tv);
            (window as any).CSTV?.set(!tv);
          }}
        >
          {tv ? "Quitter TV" : "Mode TV"}
        </button>
      </header>
      <main id="feature-main" className="f-main">
        <div className="f-heading">
          <div>
            <span className="f-kicker">TheCombinedWebs / v60</span>
            <h1>{TITLES[mode][0]}</h1>
            <p>{TITLES[mode][1]}</p>
          </div>
          <PushSettings />
        </div>
        {mode === "portails" ? (
          <Portals />
        ) : mode === "evenements" ? (
          <Events />
        ) : mode === "social" ? (
          <Social />
        ) : (
          <Economy />
        )}
      </main>
      <footer className="f-footer">
        TheCombinedWebs · Crédits : Walid · Un compte partagé avec tous les
        services.
      </footer>
    </div>
  );
}
export function Portals() {
  const { data: d, error, load } = useData("/api/portals");
  const [q, setQ] = useState(""),
    [filter, setFilter] = useState("all"),
    [portal, setPortal] = useState("all"),
    [msg, setMsg] = useState(""),
    [err, setErr] = useState(""),
    [busy, setBusy] = useState(false),
    [manage, setManage] = useState(false);
  const blank = {
    id: "",
    name: "",
    url: "",
    hosts: "",
    selector: 'a[href*="/game/"],a[href*="/jeu/"]',
    enabled: true,
    isolated: false,
  };
  const [form, setForm] = useState(blank),
    [importText, setImportText] = useState("");
  const act = async (b: any) => {
    setBusy(true);
    setErr("");
    try {
      await api("/api/portals", b);
      await load();
      setMsg("Bibliothèque mise à jour.");
    } catch (e) {
      setErr((e as Error).message);
    } finally {
      setBusy(false);
    }
  };
  if (!d) return <Notice error={error} message="Chargement du catalogue…" />;
  const favorites = d.library.favorites,
    recent = d.library.recent;
  let games = d.games.filter(
    (g: any) =>
      (portal === "all" || g.portalId === portal) &&
      `${g.title} ${g.category}`
        .toLocaleLowerCase("fr")
        .includes(q.toLocaleLowerCase("fr")) &&
      (filter !== "favorites" || favorites.includes(g.id)) &&
      (filter !== "recent" || recent.some((r: any) => r.id === g.id)),
  );
  if (filter === "recent")
    games = games.sort(
      (a: any, b: any) =>
        recent.findIndex((r: any) => r.id === a.id) -
        recent.findIndex((r: any) => r.id === b.id),
    );
  const launch = async (g: any) => {
    if (d.username) await act({ action: "recent", id: g.id });
  };
  return (
    <div className="f-stack">
      <div className="f-row">
        <input
          className="f-search"
          aria-label="Rechercher dans tous les portails"
          placeholder="Rechercher un jeu, tous portails confondus…"
          value={q}
          onChange={(e) => setQ(e.target.value)}
        />
      </div>
      <div className="f-row">
        <div className="f-tabs" style={{ margin: 0 }}>
          {[
            ["all", "Tous les jeux"],
            ["favorites", "Favoris"],
            ["recent", "Récents"],
          ].map(([v, l]) => (
            <button
              key={v}
              className={`f-btn ${filter === v ? "selected" : ""}`}
              onClick={() => setFilter(v)}
            >
              {l}
            </button>
          ))}
        </div>
        <Field label="Portail">
          <select value={portal} onChange={(e) => setPortal(e.target.value)}>
            <option value="all">Tous les portails</option>
            <option value="local">Jeux locaux</option>
            {d.portals
              .filter((p: any) => p.enabled)
              .map((p: any) => (
                <option key={p.id} value={p.id}>
                  {p.name}
                </option>
              ))}
          </select>
        </Field>
        {d.canControl && (
          <button className="f-btn" onClick={() => setManage(!manage)}>
            Gérer les portails
          </button>
        )}
      </div>
      {!d.username && (
        <p className="f-note">
          <Link href="/login?next=/portails">Connecte-toi</Link> pour jouer,
          enregistrer tes favoris et retrouver tes récents sur tous tes
          appareils.
        </p>
      )}
      <Notice error={err || error} message={msg} />
      {manage && (
        <section className="f-card f-stack">
          <h2>Configuration créateur</h2>
          <p className="f-muted">
            Ajoute les domaines du portail et de ses jeux. Le proxy accepte ces
            hôtes grâce à un ticket signé, sans modification du code.
          </p>
          <div className="f-row">
            {d.portals.map((p: any) => (
              <button
                className="f-btn"
                key={p.id}
                onClick={() => setForm({ ...p, hosts: p.hosts.join(", ") })}
              >
                {p.name}
              </button>
            ))}
            <button className="f-btn" onClick={() => setForm(blank)}>
              Nouveau portail
            </button>
          </div>
          <div className="f-fields">
            <Field label="Nom">
              <input
                required
                value={form.name}
                onChange={(e) => setForm({ ...form, name: e.target.value })}
              />
            </Field>
            <Field label="Identifiant (facultatif)">
              <input
                value={form.id}
                onChange={(e) => setForm({ ...form, id: e.target.value })}
              />
            </Field>
            <Field label="URL HTTPS">
              <input
                type="url"
                value={form.url}
                onChange={(e) => setForm({ ...form, url: e.target.value })}
              />
            </Field>
            <Field label="Hôtes autorisés, séparés par virgules">
              <input
                placeholder="jeux.fr, *.jeux.fr"
                value={form.hosts}
                onChange={(e) => setForm({ ...form, hosts: e.target.value })}
              />
            </Field>
            <Field label="Sélecteur CSS des liens de jeux">
              <input
                value={form.selector}
                onChange={(e) => setForm({ ...form, selector: e.target.value })}
              />
            </Field>
            <div className="f-row">
              <label>
                <input
                  type="checkbox"
                  checked={form.enabled}
                  onChange={(e) =>
                    setForm({ ...form, enabled: e.target.checked })
                  }
                />{" "}
                Portail actif
              </label>
            </div>
          </div>
          <div className="f-row">
            <button
              className="f-btn primary"
              disabled={busy}
              onClick={() => act({ action: "save", ...form })}
            >
              Enregistrer le portail
            </button>
            <button
              className="f-btn"
              disabled={busy || !form.id}
              onClick={() => act({ action: "index", id: form.id })}
            >
              Indexer la page du portail
            </button>
          </div>
          <Field
            label={
              'Catalogue JSON complet : [{"title":"Nom du jeu","url":"https://…"}]'
            }
          >
            <textarea
              rows={4}
              value={importText}
              onChange={(e) => setImportText(e.target.value)}
            />
          </Field>
          <button
            className="f-btn"
            disabled={busy || !form.id || !importText.trim()}
            onClick={() => {
              try {
                act({
                  action: "index",
                  id: form.id,
                  games: JSON.parse(importText),
                });
              } catch {
                setErr("Le JSON n'est pas valide.");
              }
            }}
          >
            Importer le catalogue
          </button>
          <p className="f-muted">
            L'indexation lit les liens de la page configurée. Pour rechercher
            tout le catalogue d'un site, importe son catalogue complet. Un site
            ajouté sans index apparaît ci-dessous comme portail à ouvrir.
          </p>
        </section>
      )}
      <div className="f-row">
        <span className="f-kicker">{games.length} jeux trouvés</span>
        <span className="f-muted">
          {d.portals.filter((p: any) => p.enabled).length} portails connectés
        </span>
      </div>
      <div className="f-games">
        {games.map((g: any, i: number) => (
          <article className="f-game" key={g.id}>
            <span className="f-game-number">
              {String(i + 1).padStart(2, "0")} /{" "}
              {g.portalId === "local"
                ? "TCB ORIGINAL"
                : d.portals
                    .find((p: any) => p.id === g.portalId)
                    ?.name.toUpperCase()}
            </span>
            <h3>{g.title}</h3>
            <p>{g.category || "Jeu du portail"}</p>
            <div className="f-game-actions">
              <Link
                className="f-btn primary"
                href={
                  g.portalId === "local"
                    ? g.url
                    : `/portails/jouer?portal=${g.portalId}&game=${encodeURIComponent(g.id)}`
                }
                onClick={() => launch(g)}
              >
                Jouer
              </Link>
              <button
                aria-label={`${favorites.includes(g.id) ? "Retirer" : "Ajouter"} ${g.title} ${favorites.includes(g.id) ? "des" : "aux"} favoris`}
                className="f-btn"
                disabled={!d.username || busy}
                onClick={() => act({ action: "favorite", id: g.id })}
              >
                {favorites.includes(g.id) ? "★" : "☆"}
              </button>
            </div>
          </article>
        ))}
      </div>
      {!games.length && (
        <div className="f-card">
          <h2>Aucun jeu ne correspond</h2>
          <p className="f-muted">Essaie un autre titre ou change de portail.</p>
          <button
            className="f-btn"
            onClick={() => {
              setQ("");
              setFilter("all");
              setPortal("all");
            }}
          >
            Réinitialiser la recherche
          </button>
        </div>
      )}
      <section className="f-card">
        <h2>Ouvrir un portail</h2>
        <div className="f-row">
          {d.portals
            .filter((p: any) => p.enabled)
            .map((p: any) => (
              <Link
                key={p.id}
                className="f-btn"
                href={`/portails/jouer?portal=${p.id}`}
              >
                {p.name} · {p.games.length} jeux indexés
              </Link>
            ))}
        </div>
      </section>
    </div>
  );
}
export function Events() {
  const { data: d, error, load } = useData("/api/events", 1200);
  const [err, setErr] = useState(""),
    [busy, setBusy] = useState(false),
    [form, setForm] = useState({
      type: "golden",
      title: "",
      minutes: 30,
      reward: 500,
      hp: 10000,
      page: "/portails",
    });
  const act = async (b: any) => {
    setBusy(true);
    setErr("");
    try {
      await api("/api/events", b);
      await load();
    } catch (e) {
      setErr((e as Error).message);
    } finally {
      setBusy(false);
    }
  };
  return (
    <div className="f-stack">
      <Notice
        error={err || error}
        message={!d ? "Chargement des événements…" : ""}
      />
      {d?.canControl && (
        <section className="f-card f-stack">
          <h2>Lancer un événement</h2>
          <div className="f-fields">
            <Field label="Événement">
              <select
                value={form.type}
                onChange={(e) => setForm({ ...form, type: e.target.value })}
              >
                <option value="golden">Heure dorée</option>
                <option value="treasure">Chasse au trésor</option>
                <option value="boss">Boss du serveur</option>
              </select>
            </Field>
            <Field label="Durée, en minutes">
              <input
                type="number"
                min={1}
                max={1440}
                value={form.minutes}
                onChange={(e) =>
                  setForm({ ...form, minutes: Number(e.target.value) })
                }
              />
            </Field>
            {form.type !== "golden" && (
              <Field label="Gros lot, en Bobux">
                <input
                  type="number"
                  min={1}
                  value={form.reward}
                  onChange={(e) =>
                    setForm({ ...form, reward: Number(e.target.value) })
                  }
                />
              </Field>
            )}
            {form.type === "boss" && (
              <Field label="Points de vie partagés">
                <input
                  type="number"
                  min={100}
                  value={form.hp}
                  onChange={(e) =>
                    setForm({ ...form, hp: Number(e.target.value) })
                  }
                />
              </Field>
            )}
            {form.type === "treasure" && (
              <Field label="Page où cacher l'objet">
                <select
                  value={form.page}
                  onChange={(e) => setForm({ ...form, page: e.target.value })}
                >
                  {[
                    "/portails",
                    "/steamblox",
                    "/evenements",
                    "/social",
                    "/economie",
                  ].map((p) => (
                    <option key={p}>{p}</option>
                  ))}
                </select>
              </Field>
            )}
          </div>
          <button
            className="f-btn primary"
            disabled={busy}
            onClick={() => act({ action: "start", ...form })}
          >
            Démarrer pour tout le serveur
          </button>
        </section>
      )}
      {d?.events.map((e: any) => (
        <section className="f-card" key={e.id}>
          <div className="f-row">
            <span className="f-kicker">
              {e.type === "golden"
                ? "Gains ×2"
                : e.type === "boss"
                  ? "Combat collectif"
                  : "Premier arrivé"}
            </span>
            <span className="f-muted">
              Se termine dans <Countdown end={e.endsAt} />
            </span>
          </div>
          <h2 style={{ marginTop: 16 }}>{e.title}</h2>
          {e.type === "golden" ? (
            <p>
              Tes récompenses de jeu et de connexion sont doublées. Les prêts,
              remboursements, mises rendues et gains de roulette ou de loterie
              restent inchangés.
            </p>
          ) : e.type === "treasure" ? (
            <p>
              {e.winner
                ? `${e.winner} a trouvé le trésor et remporté le gros lot.`
                : `Un objet est caché quelque part sur le site. Le premier à le trouver gagne ${e.reward} Bobux.`}
            </p>
          ) : (
            <>
              <div
                className="f-bar"
                role="progressbar"
                aria-label="Vie du boss"
                aria-valuenow={e.hp}
                aria-valuemax={e.maxHp}
                aria-valuemin={0}
              >
                <span style={{ width: `${(e.hp / e.maxHp) * 100}%` }} />
              </div>
              <div className="f-row">
                <b>
                  {e.hp.toLocaleString("fr-FR")} /{" "}
                  {e.maxHp.toLocaleString("fr-FR")} PV
                </b>
                <span className="f-muted">
                  {Object.keys(e.damage || {}).length} participants
                </span>
              </div>
              <p>
                {e.hp
                  ? `Chaque attaque inflige 25 dégâts. Le coup final rapporte ${e.reward} Bobux.`
                  : `Vaincu ! Coup final de ${e.winner}.`}
              </p>
              <button
                className="f-btn primary"
                disabled={busy || !d.username || !e.hp}
                onClick={() => act({ action: "attack", id: e.id })}
              >
                Attaquer le boss
              </button>
            </>
          )}
        </section>
      ))}
      {d && !d.events.length && (
        <section className="f-card">
          <h2>Le serveur reprend son souffle</h2>
          <p className="f-muted">
            Aucun événement en cours. Active les notifications pour être prévenu
            quand le créateur lance le prochain.
          </p>
          <Link href="/portails" className="f-btn">
            Explorer les jeux
          </Link>
        </section>
      )}
    </div>
  );
}
const FX_LABEL: Record<string, string> = {
  flip: "Écran retourné",
  mirror: "Miroir",
  shake: "Secousse",
  spin: "Rotation",
  rainbow: "Arc-en-ciel",
  zoom: "Zoom",
  confetti: "Confettis",
  fakecrash: "Faux plantage",
};
export function Economy({ compact = false }: { compact?: boolean }) {
  const { data: d, error, load } = useData("/api/economy", 10000);
  const [msg, setMsg] = useState(""),
    [err, setErr] = useState(""),
    [busy, setBusy] = useState(false),
    [target, setTarget] = useState(""),
    [stake, setStake] = useState(10),
    [choice, setChoice] = useState("red"),
    [acceptDebt, setAcceptDebt] = useState(false),
    [lastSpin, setLastSpin] = useState<any>(null),
    [rotation, setRotation] = useState(0),
    [spinPending, setSpinPending] = useState(false);
  const [loan, setLoan] = useState({
    borrower: "",
    amount: 100,
    rate: 5,
    days: 7,
  });
  const requestId = useRef<string | null>(null);
  const act = async (b: any) => {
    setBusy(true);
    setErr("");
    setMsg("");
    try {
      const r = await api("/api/economy", b);
      setMsg(r.message);
      await load();
      return r;
    } catch (e) {
      setErr((e as Error).message);
      return null;
    } finally {
      setBusy(false);
    }
  };
  const spin = async () => {
    setSpinPending(true);
    requestId.current ||= crypto.randomUUID();
    const r = await act({
      action: "roulette",
      stake,
      choice,
      acceptDebt,
      requestId: requestId.current,
    });
    if (r) {
      setMsg("");
      setRotation(
        (v) =>
          Math.floor(v / 360) * 360 +
          1800 +
          (r.result === "red" ? 348.75 : 326.25),
      );
      setTimeout(() => {
        setLastSpin(r);
        setMsg(r.message);
        setSpinPending(false);
      }, 1800);
      requestId.current = null;
    } else setSpinPending(false);
  };
  if (!d)
    return <Notice error={error} message="Chargement du compte bancaire…" />;
  const connected = !!d.username,
    borrowed = Math.max(0, stake - d.balance);
  return (
    <div className={compact ? "feature-panel f-stack" : "f-stack"}>
      {compact && (
        <div className="f-row">
          <h2 style={{ margin: 0 }}>Boutique de l'accueil</h2>
          <Link className="f-btn" href="/economie">
            Banque et relevé complet
          </Link>
        </div>
      )}
      <div className="f-card f-balance">
        <div>
          <small>Compte courant</small>
          <span className="f-metric">{d.balance.toLocaleString("fr-FR")}</span>
          <small>Bobux disponibles</small>
        </div>
        <div>
          <small>Dette bancaire</small>
          <span className="f-metric">{d.debt.toLocaleString("fr-FR")}</span>
          <small>Bobux à rembourser</small>
        </div>
        <div>
          <small>Solde net</small>
          <span className="f-metric">
            {d.netBalance.toLocaleString("fr-FR")}
          </span>
          <small>Compte courant moins dette</small>
        </div>
        {d.debt > 0 && (
          <button
            className="f-btn"
            disabled={busy || !d.balance}
            onClick={() => act({ action: "repay-debt" })}
          >
            Rembourser ma dette
          </button>
        )}
      </div>
      {!connected && (
        <p className="f-note">
          <Link href="/login?next=/economie">Connecte-toi</Link> pour utiliser
          ton solde bancaire.
        </p>
      )}
      <Notice error={err || error} message={msg} />
      <section className="f-card">
        <div className="f-row" style={{ justifyContent: "space-between" }}>
          <h2>Boutique quotidienne</h2>
          <span className="f-muted">
            Rotation dans <Countdown end={d.shop.endsAt} />
          </span>
        </div>
        <div className="f-shop">
          {d.shop.items.map((c: any) => (
            <article className="f-shop-item" key={c.id}>
              <div className={`f-cosmetic ${c.type}`} aria-label={c.name}>
                <span>
                  {c.type === "sound" ? "♪" : c.type === "name" ? "TCB" : "T"}
                </span>
              </div>
              <b>{c.name}</b>
              <span className="f-muted">{c.price} Bobux</span>
              <button
                className="f-btn primary"
                disabled={
                  busy ||
                  !connected ||
                  d.shop.owned.includes(c.id) ||
                  d.balance < c.price
                }
                onClick={() => act({ action: "buy", id: c.id })}
              >
                {d.shop.owned.includes(c.id) ? "Possédé" : "Acheter"}
              </button>
            </article>
          ))}
        </div>
        <p className="f-muted">
          Quatre cosmétiques renouvelés à minuit, heure de Paris. Équipe tes
          achats dans <Link href="/passe">Passe & boutique</Link>.
        </p>
      </section>
      <div className="f-split">
        <section className="f-card">
          <h2>Troller un ami</h2>
          <p className="f-muted">
            Effets temporaires, un troll par minute. Un destinataire peut les
            désactiver ; aucun débit si l'envoi est refusé.
          </p>
          <Field label="Destinataire">
            <select
              value={target || d.friends[0] || ""}
              onChange={(e) => setTarget(e.target.value)}
            >
              {!d.friends.length && (
                <option value="">Ajoute d'abord un ami</option>
              )}
              {d.friends.map((f: string) => (
                <option key={f}>{f}</option>
              ))}
            </select>
          </Field>
          <div className="f-row" style={{ marginTop: 16 }}>
            {d.trolls.map((t: any) => (
              <button
                key={t.id}
                className="f-btn"
                disabled={
                  busy || !connected || !d.friends.length || d.balance < t.price
                }
                onClick={() =>
                  act({
                    action: "troll",
                    target: target || d.friends[0],
                    effect: t.id,
                  })
                }
              >
                {FX_LABEL[t.id]} · {t.price}
              </button>
            ))}
          </div>
          <button
            className="f-btn"
            style={{ marginTop: 16 }}
            disabled={!connected || busy}
            onClick={async () => {
              try {
                await api("/api/tcb/fun", {
                  action: "optout",
                  value: !d.trollOptout,
                });
                await load();
              } catch (e) {
                setErr((e as Error).message);
              }
            }}
          >
            {d.trollOptout
              ? "Réactiver les trolls reçus"
              : "Désactiver les trolls reçus"}
          </button>
        </section>
        <section className="f-card">
          <h2>Roulette rouge / noir</h2>
          <p className="f-muted">
            50 % rouge, 50 % noir. Sur la bonne couleur, le versement est égal à
            deux fois ta mise. Sinon, tu perds la mise.
          </p>
          <div className="f-roulette">
            <div className="f-wheel-wrap" aria-hidden="true">
              <div
                className="f-wheel"
                style={{ transform: `rotate(${rotation}deg)` }}
              />
            </div>
            <div className="f-stack" style={{ gap: 12 }}>
              <Field label="Mise en Bobux">
                <input
                  type="number"
                  min={1}
                  max={100000}
                  disabled={busy || spinPending}
                  value={stake}
                  onChange={(e) => {
                    setStake(Number(e.target.value));
                    setAcceptDebt(false);
                    requestId.current = null;
                  }}
                />
              </Field>
              <div className="f-row">
                <button
                  className={`f-btn red ${choice === "red" ? "selected" : ""}`}
                  aria-pressed={choice === "red"}
                  onClick={() => setChoice("red")}
                >
                  Rouge
                </button>
                <button
                  className={`f-btn black ${choice === "black" ? "selected" : ""}`}
                  aria-pressed={choice === "black"}
                  onClick={() => setChoice("black")}
                >
                  Noir
                </button>
              </div>
            </div>
          </div>
          {borrowed > 0 && (
            <div className="f-note">
              <b>
                Cette mise nécessite {borrowed.toLocaleString("fr-FR")} Bobux de
                dette.
              </b>
              <p>
                La dette restera sur ton compte bancaire si tu perds. Un gain
                rembourse la dette en priorité.
              </p>
              <label>
                <input
                  type="checkbox"
                  checked={acceptDebt}
                  onChange={(e) => setAcceptDebt(e.target.checked)}
                />{" "}
                Je confirme cette mise et l'endettement.
              </label>
            </div>
          )}
          <button
            className="f-btn primary"
            disabled={
              busy ||
              spinPending ||
              !connected ||
              stake < 1 ||
              stake > 100000 ||
              (borrowed > 0 && !acceptDebt)
            }
            onClick={spin}
          >
            {spinPending
              ? "La boule tourne…"
              : `Miser ${stake.toLocaleString("fr-FR")} Bobux`}
          </button>
          {lastSpin && !spinPending && (
            <p className="f-note" role="status">
              La boule est tombée sur{" "}
              {lastSpin.result === "red" ? "le rouge" : "le noir"}.{" "}
              {lastSpin.won
                ? `Gain brut : ${lastSpin.payout} Bobux.`
                : "Ta mise est perdue."}
            </p>
          )}
        </section>
      </div>
      <RiskDuels />
      {!compact && (
        <>
          <div className="f-split">
            <section className="f-card">
              <h2>Coffres de récompenses</h2>
              <p className="f-muted">
                Un coffre par jour et un autre par heure de jeu cumulée. Chances
                : 20 Bobux (60 %), 50 (25 %), 100 (12 %), 500 (3 %).
              </p>
              <div className="f-row">
                <button
                  className="f-btn primary"
                  disabled={busy || !d.chest.dailyReady}
                  onClick={() => act({ action: "chest", kind: "daily" })}
                >
                  Ouvrir le coffre quotidien
                </button>
                <button
                  className="f-btn"
                  disabled={busy || !d.chest.playReady}
                  onClick={() => act({ action: "chest", kind: "play" })}
                >
                  Coffre de temps de jeu
                </button>
              </div>
              <p className="f-muted">
                Prochain jour dans <Countdown end={d.chest.endsAt} /> · prochain
                palier : {d.chest.nextPlayMinutes} min.
              </p>
            </section>
            <section className="f-card">
              <h2>Loterie hebdomadaire</h2>
              <span className="f-metric">
                {d.lottery.pot.toLocaleString("fr-FR")} Bobux
              </span>
              <p className="f-muted">
                {d.lottery.tickets} tickets · {d.lottery.myTickets} à ton nom.
                Tirage dimanche à 20 h, heure de Paris, dans{" "}
                <Countdown end={d.lottery.endsAt} />.
              </p>
              <p>90 % de la cagnotte au gagnant, 10 % au Trésor du créateur.</p>
              <button
                className="f-btn primary"
                disabled={
                  busy ||
                  !connected ||
                  d.balance < 10 ||
                  d.lottery.myTickets >= 100
                }
                onClick={() => act({ action: "ticket" })}
              >
                Acheter un ticket · 10 Bobux
              </button>
              {d.lottery.last?.winner && (
                <p>
                  Dernier gagnant : {d.lottery.last.winner},{" "}
                  {d.lottery.last.prize} Bobux.
                </p>
              )}
              {d.treasury !== undefined && (
                <p className="f-muted">
                  Trésor du créateur : {d.treasury.toLocaleString("fr-FR")}{" "}
                  Bobux
                </p>
              )}
            </section>
          </div>
          <section className="f-card f-stack">
            <h2>Prêter des Bobux à un ami</h2>
            <p className="f-muted">
              Ton ami voit et accepte le montant, le taux et l'échéance avant
              tout transfert. Les remboursements partiels réduisent bien le
              total, intérêts compris.
            </p>
            <div className="f-fields">
              <Field label="Ami bénéficiaire">
                <select
                  value={loan.borrower || d.friends[0] || ""}
                  onChange={(e) =>
                    setLoan({ ...loan, borrower: e.target.value })
                  }
                >
                  {!d.friends.length && <option value="">Aucun ami</option>}
                  {d.friends.map((f: string) => (
                    <option key={f}>{f}</option>
                  ))}
                </select>
              </Field>
              <Field label="Montant en Bobux">
                <input
                  type="number"
                  min={10}
                  max={100000}
                  value={loan.amount}
                  onChange={(e) =>
                    setLoan({ ...loan, amount: Number(e.target.value) })
                  }
                />
              </Field>
              <Field label="Intérêt convenu (%)">
                <input
                  type="number"
                  min={0}
                  max={20}
                  value={loan.rate}
                  onChange={(e) =>
                    setLoan({ ...loan, rate: Number(e.target.value) })
                  }
                />
              </Field>
              <Field label="Échéance après acceptation (jours)">
                <input
                  type="number"
                  min={1}
                  max={90}
                  value={loan.days}
                  onChange={(e) =>
                    setLoan({ ...loan, days: Number(e.target.value) })
                  }
                />
              </Field>
            </div>
            <p>
              Total à rembourser :{" "}
              {loan.amount + Math.floor((loan.amount * loan.rate) / 100)} Bobux.
            </p>
            <button
              className="f-btn primary"
              disabled={busy || !connected || !d.friends.length}
              onClick={() =>
                act({
                  action: "offer-loan",
                  ...loan,
                  borrower: loan.borrower || d.friends[0],
                })
              }
            >
              Proposer le prêt
            </button>
            <div className="f-table-wrap">
              <table className="f-table">
                <thead>
                  <tr>
                    <th>Prêteur / bénéficiaire</th>
                    <th>Conditions</th>
                    <th>Reste dû</th>
                    <th>Échéance</th>
                    <th>Action</th>
                  </tr>
                </thead>
                <tbody>
                  {d.loans.map((l: any) => (
                    <tr key={l.id}>
                      <td>
                        {l.lender} → {l.borrower}
                      </td>
                      <td>
                        {l.principal} + {l.rate} %
                      </td>
                      <td>{l.remaining}</td>
                      <td>
                        {new Date(l.dueAt).toLocaleDateString("fr-FR")}
                        {l.status === "active" && l.dueAt < Date.now()
                          ? " · En retard"
                          : ""}
                      </td>
                      <td>
                        {l.borrower === d.username && l.status === "pending" ? (
                          <div className="f-row">
                            <button
                              className="f-btn"
                              disabled={busy}
                              onClick={() =>
                                act({ action: "accept-loan", id: l.id })
                              }
                            >
                              Accepter
                            </button>
                            <button
                              className="f-btn"
                              disabled={busy}
                              onClick={() =>
                                act({ action: "decline-loan", id: l.id })
                              }
                            >
                              Refuser
                            </button>
                          </div>
                        ) : l.borrower === d.username &&
                          l.status === "active" ? (
                          <button
                            className="f-btn"
                            disabled={busy || !d.balance}
                            onClick={() =>
                              act({
                                action: "repay-loan",
                                id: l.id,
                                amount: Math.min(l.remaining, d.balance),
                              })
                            }
                          >
                            Rembourser {Math.min(l.remaining, d.balance)}
                          </button>
                        ) : (
                          l.status
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </section>
          <section className="f-card">
            <h2>Relevé du compte courant</h2>
            <p className="f-muted">
              Les mêmes mouvements apparaissent dans TCB Banque. Les emprunts de
              roulette figurent aussi dans la dette bancaire.
            </p>
            <div className="f-table-wrap">
              <table className="f-table">
                <thead>
                  <tr>
                    <th>Date</th>
                    <th>Opération</th>
                    <th>Bobux</th>
                  </tr>
                </thead>
                <tbody>
                  {d.ledger.map((e: any) => (
                    <tr key={e.id}>
                      <td>{new Date(e.createdAt).toLocaleString("fr-FR")}</td>
                      <td style={{ whiteSpace: "normal" }}>{e.reason}</td>
                      <td>
                        {e.amount > 0 ? "+" : ""}
                        {e.amount}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            <Link className="f-btn" href="/tcb">
              Ouvrir TCB Banque
            </Link>
          </section>
        </>
      )}
    </div>
  );
}
function Social() {
  const { data: d, error, load } = useData("/api/duels", 5000),
    { data: groups, error: groupError, load: loadGroups } = useData("/api/tcb");
  const { engine, voice } = useDiscordVoice();
  const [msg, setMsg] = useState(""),
    [err, setErr] = useState(""),
    [busy, setBusy] = useState(false),
    [form, setForm] = useState({ to: "", gameId: "meteor-mayhem", stake: 10 }),
    [chat, setChat] = useState(""),
    [channel, setChannel] = useState("");
  const { data: messages } = useData(
    `/api/discord/sync?c=${encodeURIComponent(channel ? `group~${channel}` : "general")}`,
    3000,
  );
  const act = async (b: any) => {
    setBusy(true);
    setErr("");
    try {
      const r = await api("/api/duels", b);
      if (r.url) {
        location.assign(r.url);
        return;
      }
      setMsg(r.message);
      await load();
    } catch (e) {
      setErr((e as Error).message);
    } finally {
      setBusy(false);
    }
  };
  return (
    <div className="f-stack">
      <Notice error={err || error || groupError} message={msg} />
      <RiskDuels />
      {!d && (
        <p className="f-note">
          <Link href="/login?next=/social">Connecte-toi</Link> pour retrouver
          tes amis et tes groupes.
        </p>
      )}
      {d && (
        <section className="f-card f-stack">
          <h2>Duel de défis</h2>
          <p className="f-muted">
            Chacun réserve la même mise. Une seule partie par joueur, le
            meilleur score récupère les deux mises. Égalité ou expiration :
            mises rendues.
          </p>
          <div className="f-fields">
            <Field label="Ami à défier">
              <select
                value={form.to || d.friends[0] || ""}
                onChange={(e) => setForm({ ...form, to: e.target.value })}
              >
                {!d.friends.length && <option value="">Aucun ami</option>}
                {d.friends.map((f: string) => (
                  <option key={f}>{f}</option>
                ))}
              </select>
            </Field>
            <Field label="Jeu du duel">
              <select
                value={form.gameId}
                onChange={(e) => setForm({ ...form, gameId: e.target.value })}
              >
                {d.games.map((g: any) => (
                  <option key={g.id} value={g.id}>
                    {g.title}
                  </option>
                ))}
              </select>
            </Field>
            <Field label="Mise de chacun en Bobux">
              <input
                type="number"
                min={1}
                max={10000}
                value={form.stake}
                onChange={(e) =>
                  setForm({ ...form, stake: Number(e.target.value) })
                }
              />
            </Field>
          </div>
          <button
            className="f-btn primary"
            disabled={busy || !d.friends.length}
            onClick={() =>
              act({ action: "create", ...form, to: form.to || d.friends[0] })
            }
          >
            Envoyer le défi
          </button>
          {d.duels.map((duel: any) => (
            <article className="f-card" key={duel.id}>
              <b>
                {duel.from} contre {duel.to}
              </b>
              <p>
                {d.games.find((g: any) => g.id === duel.gameId)?.title} ·{" "}
                {duel.stake} Bobux par joueur · {duel.status}
              </p>
              <div className="f-row">
                {duel.status === "pending" && duel.to === d.username && (
                  <button
                    className="f-btn primary"
                    disabled={busy}
                    onClick={() => act({ action: "accept", id: duel.id })}
                  >
                    Accepter et réserver la mise
                  </button>
                )}
                {duel.status === "pending" && (
                  <button
                    className="f-btn"
                    disabled={busy}
                    onClick={() => act({ action: "decline", id: duel.id })}
                  >
                    Annuler / refuser
                  </button>
                )}
                {duel.status === "active" &&
                  duel.scores[d.username.toLowerCase()] === undefined && (
                    <button
                      className="f-btn primary"
                      disabled={busy}
                      onClick={() => act({ action: "run", id: duel.id })}
                    >
                      Jouer ma partie
                    </button>
                  )}
                {duel.winner && <span>Gagnant : {duel.winner}</span>}
                {duel.draw && <span>Égalité : mises rendues</span>}
                <Link
                  className="f-btn"
                  href={`/u/${encodeURIComponent(duel.from === d.username ? duel.to : duel.from)}`}
                >
                  Voir le profil
                </Link>
              </div>
            </article>
          ))}
        </section>
      )}
      {groups && (
        <section className="f-card f-stack">
          <h2>Groupes : chat et vocal</h2>
          <p className="f-muted">
            Le même vocal reste connecté quand tu ouvres un jeu. Jusqu'à huit
            participants par salon.
          </p>
          {groups.groups.map((g: any) => (
            <div
              key={g.slug}
              className="f-row"
              style={{ justifyContent: "space-between" }}
            >
              <div>
                <b>{g.name}</b>
                <span className="f-muted"> · {g.count} membres</span>
              </div>
              <div className="f-row">
                <button
                  className="f-btn"
                  disabled={busy}
                  onClick={async () => {
                    setBusy(true);
                    try {
                      await api("/api/tcb", {
                        action: "group",
                        slug: g.slug,
                        join: !g.joined,
                      });
                      if (!g.joined) setChannel(g.slug);
                      else if (channel === g.slug) setChannel("");
                      if (voice?.room === `groupvc~${g.slug}` && g.joined)
                        await engine?.leave();
                      await loadGroups();
                    } catch (e) {
                      setErr((e as Error).message);
                    } finally {
                      setBusy(false);
                    }
                  }}
                >
                  {g.joined ? "Quitter le groupe" : "Rejoindre le groupe"}
                </button>
                {g.joined && (
                  <>
                    <button
                      className="f-btn"
                      onClick={() => setChannel(g.slug)}
                    >
                      Chat
                    </button>
                    <button
                      className="f-btn primary"
                      disabled={!engine || voice?.joining}
                      onClick={() => engine?.join(`groupvc~${g.slug}`)}
                    >
                      Rejoindre le vocal
                    </button>
                  </>
                )}
              </div>
            </div>
          ))}
          {voice?.room && (
            <div className="f-note">
              <p>
                Vocal : {voice.room} ·{" "}
                {voice.members.map((m) => m.u).join(", ")}
              </p>
              <div className="f-row">
                <button
                  className="f-btn"
                  onClick={() => engine?.setMuted(!voice.muted)}
                >
                  {voice.muted ? "Activer le micro" : "Couper le micro"}
                </button>
                <button className="f-btn" onClick={() => engine?.leave()}>
                  Quitter le vocal
                </button>
              </div>
            </div>
          )}
          <Notice error={voice?.error} />
          {channel && (
            <>
              <h3>Chat du groupe {channel}</h3>
              <div className="f-chat">
                {messages?.messages?.map((m: any) => (
                  <article key={m.id}>
                    <b>{m.author}</b>
                    <p>{m.text}</p>
                  </article>
                ))}
              </div>
              <form
                className="f-row"
                onSubmit={async (e) => {
                  e.preventDefault();
                  try {
                    await api("/api/discord/message", {
                      action: "send",
                      channel: `group~${channel}`,
                      text: chat,
                    });
                    setChat("");
                  } catch (e) {
                    setErr((e as Error).message);
                  }
                }}
              >
                <Field label="Ton message">
                  <input
                    value={chat}
                    maxLength={1200}
                    onChange={(e) => setChat(e.target.value)}
                  />
                </Field>
                <button className="f-btn primary" disabled={!chat.trim()}>
                  Envoyer
                </button>
              </form>
            </>
          )}
          <Link
            className="f-btn"
            href={`/u/${encodeURIComponent(groups.me.username)}`}
          >
            Mon profil public
          </Link>
        </section>
      )}
    </div>
  );
}
function PushSettings() {
  const [msg, setMsg] = useState(""),
    [busy, setBusy] = useState(false),
    [enabled, setEnabled] = useState(false);
  useEffect(() => {
    try{if ("serviceWorker" in navigator)
      navigator.serviceWorker.ready
        .then((r) => r.pushManager.getSubscription())
        .then((s) => setEnabled(!!s))
        .catch(() => {});}catch{/* Opaque app previews do not allow service workers. */}
  }, []);
  const toggle = async () => {
    setBusy(true);
    try {
      if (!("serviceWorker" in navigator) || !("PushManager" in window))
        throw new Error(
          "Push indisponible dans ce navigateur. Ouvre l'application installée en HTTPS.",
        );
      const d = await api("/api/push");
      if (!d.configured)
        throw new Error(
          "Le créateur doit configurer les clés VAPID pour activer le push.",
        );
      const permission = await Notification.requestPermission();
      if (permission !== "granted")
        throw new Error("Notifications refusées dans le navigateur.");
      const reg = await navigator.serviceWorker.ready;
      let sub = await reg.pushManager.getSubscription();
      if (enabled && sub) {
        await api("/api/push", { action: "remove", endpoint: sub.endpoint });
        await sub.unsubscribe();
        setEnabled(false);
        setMsg("Notifications désactivées.");
      } else {
        const padding = "=".repeat((4 - (d.publicKey.length % 4)) % 4);
        const bytes = Uint8Array.from(
          atob((d.publicKey + padding).replace(/-/g, "+").replace(/_/g, "/")),
          (c) => c.charCodeAt(0),
        );
        sub ||= await reg.pushManager.subscribe({
          userVisibleOnly: true,
          applicationServerKey: bytes,
        });
        await api("/api/push", {
          subscription: sub.toJSON(),
          events: true,
          friends: true,
        });
        setEnabled(true);
        setMsg("Notifications événements et amis en jeu activées.");
      }
    } catch (e) {
      setMsg((e as Error).message);
    } finally {
      setBusy(false);
    }
  };
  return (
    <div>
      <button className="f-btn" disabled={busy} onClick={toggle}>
        {enabled ? "Désactiver les notifications" : "Activer les notifications"}
      </button>
      {msg && (
        <p
          className="f-muted"
          role="status"
          style={{ maxWidth: 300, fontSize: 14 }}
        >
          {msg}
        </p>
      )}
    </div>
  );
}
