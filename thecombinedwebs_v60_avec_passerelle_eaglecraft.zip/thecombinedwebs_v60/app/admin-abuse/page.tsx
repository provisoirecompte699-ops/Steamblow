import { redirect } from "next/navigation";
import Link from "next/link";
import { currentUser } from "@/lib/auth";
import AdminAbuseClient from "./AdminAbuseClient";
import "@/app/hub.css";
export const dynamic = "force-dynamic";
export const metadata = { title: "Admin Abuse · Chasse aux Bobux" };
export default async function AdminAbusePage() {
  const u = await currentUser();
  if (!u) { redirect("/login?next=/admin-abuse"); return null; }
  return <main className="hub"><main className="hub-main"><div className="hub-head"><div><span className="hub-kick">ÉVÉNEMENT QUOTIDIEN</span><h1>💸 Admin Abuse</h1><p>Attrape un maximum de Bobux pendant les 30 secondes de jeu.</p><Link className="hub-btn" href="/tcb">← Retour à TCB Plus</Link></div></div><AdminAbuseClient /></main></main>;
}
