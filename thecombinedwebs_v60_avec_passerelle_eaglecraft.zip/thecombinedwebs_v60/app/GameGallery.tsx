"use client";
import Link from "next/link";
import {useEffect,useMemo,useState} from "react";
import PurchaseCard from "./purchase/PurchaseCard";

type Game={id:string;title:string;price:number;status:"available"|"coming-soon";playable:boolean;description:string;multiplayer:boolean;is3D?:boolean;externalUrl?:string};
export default function GameGallery({games,owned,privileged=false}:{games:Game[];owned:string[];privileged?:boolean}){
 const [query,setQuery]=useState(""); const [filter,setFilter]=useState("all"); const [sort,setSort]=useState("featured"); const [favorites,setFavorites]=useState<string[]>([]);
 useEffect(()=>{fetch("/api/favorites").then(r=>r.ok?r.json():null).then(d=>d&&setFavorites(d.favorites||[])).catch(()=>{})},[]);
 const toggle=async(id:string)=>{const r=await fetch("/api/favorites",{method:"POST",headers:{"content-type":"application/json"},body:JSON.stringify({gameId:id})});const d=await r.json();if(r.ok)setFavorites(d.favorites||[])};
 const filtered=useMemo(()=>{const list=games.filter(g=>{const q=query.toLowerCase();const match=!q||`${g.title} ${g.description}`.toLowerCase().includes(q);const ok=filter==="all"||(filter==="free"&&g.price===0)||(filter==="multi"&&g.multiplayer)||(filter==="3d"&&g.is3D)||(filter==="owned"&&owned.includes(g.id))||(filter==="favorites"&&favorites.includes(g.id));return match&&ok});return [...list].sort((a,b)=>sort==="price-asc"?a.price-b.price:sort==="price-desc"?b.price-a.price:sort==="name"?a.title.localeCompare(b.title):Number(b.is3D)-Number(a.is3D))},[games,owned,query,filter,favorites,sort]);
 return <section>
  <div className="library-tools card">
   <div className="search-row"><input className="input search" value={query} onChange={e=>setQuery(e.target.value)} placeholder="Rechercher un jeu..." aria-label="Rechercher un jeu"/><span className="result-count">{filtered.length} jeu{filtered.length>1?"x":""}</span></div>
   <div className="filters">{[["all","Tout"],["free","Gratuits"],["multi","Multijoueur"],["3d","3D"],["owned","Possédés"],["favorites","Favoris"]].map(([id,label])=><button key={id} className={`filter ${filter===id?"active":""}`} onClick={()=>setFilter(id)}>{label}</button>)}</div>
  </div><div className="search-row" style={{marginTop:10}}><select className="input" value={sort} onChange={e=>setSort(e.target.value)} aria-label="Trier les jeux"><option value="featured">Trier : À la une</option><option value="name">Nom</option><option value="price-asc">Prix croissant</option><option value="price-desc">Prix décroissant</option></select></div>
  <div className="grid sb-games-grid">{filtered.map(g=><article className={`card game-card sb-game-card game-${g.id}`} key={g.id}>
   <div className="game-art"><span>{g.is3D ? "3D" : g.multiplayer ? "MULTI" : "PLAY"}</span><b>{g.title.slice(0,1)}</b><i className="game-art-orb"/><i className="game-art-grid"/></div>
   <div className="game-top"><div>{g.status==="available"?<span className="tag accent">DISPONIBLE</span>:<span className="tag">EN PRÉPARATION</span>}{g.multiplayer&&<span className="tag">MULTI</span>}{g.is3D&&<span className="tag accent">3D</span>}</div><button className={`favorite ${favorites.includes(g.id)?"selected":""}`} onClick={()=>toggle(g.id)} aria-label={favorites.includes(g.id)?"Retirer des favoris":"Ajouter aux favoris"}>{favorites.includes(g.id)?"★":"☆"}</button></div>
   <div className="grow"><h2>{g.title}</h2><p className="muted">{g.description}</p></div>{g.price===0&&<div className="price">Gratuit</div>}
   {g.id==="ultrakill-local"?<Link className="button" href="/games/ultrakill">Configurer</Link>:g.playable&&(g.price===0||owned.includes(g.id)||privileged)?<Link className="button" href={`/games/${g.id}`} onClick={()=>{localStorage.setItem("steamblox:lastGame",g.id)}}>{privileged?"Jouer · Accès créateur":"Jouer"}</Link>:privileged?<span className="button secondary">Accès créateur · bientôt jouable</span>:g.price>0&&g.status==="available"?<details className="ui-buy"><summary className="button">Acheter · {g.price.toFixed(2).replace(".",",")} €</summary><PurchaseCard gameId={g.id} price={g.price}/></details>:<span className="button secondary">Bientôt</span>}
  </article>)}</div>
  {!filtered.length&&<div className="card empty"><h2>Aucun résultat</h2><p className="muted">Même la recherche a abandonné. Essaie un autre filtre.</p><button className="button secondary" onClick={()=>{setQuery("");setFilter("all")}}>Réinitialiser</button></div>}
 </section>
}
