"use client";
import { useEffect, useRef, useState } from "react";
export default function useCloudRecord(
  gameId: string,
  score: number,
  onRestore?: (score: number) => void,
) {
  const state = useRef({
      ready: false,
      version: 0,
      best: 0,
      busy: false,
      achievements: [] as string[],
      difficulty: "normal",
    }),
    restore = useRef(onRestore);
  restore.current = onRestore;
  const [status, setStatus] = useState("Chargement du cloud…");
  useEffect(() => {
    let off = false;
    fetch(`/api/saves?game=${encodeURIComponent(gameId)}`, {
      cache: "no-store",
    })
      .then((r) => r.json())
      .then((d) => {
        if (d.error) throw new Error(d.error);
        if (off) return;
        state.current = {
          ready: true,
          version: d.save.version,
          best: d.save.data.bestScore,
          busy: false,
          achievements: d.save.data.achievements,
          difficulty: d.save.data.difficulty,
        };
        restore.current?.(d.save.data.bestScore);
        setStatus("Progression cloud restaurée");
      })
      .catch(() => {
        if (!off) setStatus("Cloud indisponible");
      });
    return () => {
      off = true;
    };
  }, [gameId]);
  const scoreRef = useRef(score);
  scoreRef.current = score;
  useEffect(() => {
    const t = setInterval(async () => {
      const s = state.current,
        value = Math.min(2000000, Math.floor(scoreRef.current));
      if (!s.ready || s.busy || value <= s.best) return;
      s.busy = true;
      try {
        const r = await fetch("/api/saves", {
          method: "PUT",
          headers: { "content-type": "application/json" },
          body: JSON.stringify({
            gameId,
            baseVersion: s.version,
            data: {
              bestScore: value,
              achievements: s.achievements,
              difficulty: s.difficulty,
            },
          }),
        });
        const d = await r.json();
        if (r.status === 409) {
          const latest = await fetch(`/api/saves?game=${gameId}`, {
            cache: "no-store",
          }).then((r) => r.json());
          s.version = latest.save.version;
          s.best = latest.save.data.bestScore;
          setStatus("Autre session détectée, fusion du record");
        } else if (!r.ok) throw new Error(d.error);
        else {
          s.version = d.save.version;
          s.best = d.save.data.bestScore;
          setStatus("Record sauvegardé dans ton compte");
        }
      } catch {
        setStatus("Synchronisation suspendue, nouvelle tentative automatique");
      } finally {
        s.busy = false;
      }
    }, 3000);
    return () => clearInterval(t);
  }, [gameId]);
  return status;
}
