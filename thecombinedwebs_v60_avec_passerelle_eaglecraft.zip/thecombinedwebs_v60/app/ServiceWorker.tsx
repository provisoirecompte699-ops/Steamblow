"use client";
import {useEffect} from "react";
export default function ServiceWorker(){useEffect(()=>{try{if("serviceWorker" in navigator) navigator.serviceWorker.register("/sw.js").catch(()=>{});}catch{}},[]);return null}
