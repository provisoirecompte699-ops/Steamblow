"use client";
import {useEffect} from "react";import {useRouter} from "next/navigation";
export default function AdminLiveRefresh(){const router=useRouter();useEffect(()=>{const id=window.setInterval(()=>router.refresh(),1000);return()=>window.clearInterval(id)},[router]);return <p className="muted" aria-live="polite">🟢 Surveillance en direct · les nouvelles demandes apparaissent automatiquement.</p>}
