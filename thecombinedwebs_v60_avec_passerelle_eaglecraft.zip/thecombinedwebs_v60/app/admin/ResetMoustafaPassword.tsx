"use client";
import { useState, type FormEvent } from "react";

export default function ResetMoustafaPassword() {
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState("");
  const [success, setSuccess] = useState(false);
  async function reset(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (busy) return;
    const form = event.currentTarget;
    const data = new FormData(form);
    if (data.get("newPassword") !== data.get("confirmation")) { setSuccess(false); setMessage("Les nouveaux mots de passe ne correspondent pas."); return; }
    setBusy(true); setSuccess(false); setMessage("");
    try {
      const response = await fetch("/api/admin/reset-moustafa", {
        method: "POST", credentials: "same-origin", cache: "no-store",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ currentPassword: data.get("currentPassword"), newPassword: data.get("newPassword"), confirmation: data.get("confirmation") }),
      });
      const result = await response.json();
      if (!response.ok || !result.ok) { setMessage(result.error || "Réinitialisation impossible."); return; }
      form.reset();
      setSuccess(true); setMessage("Mot de passe de Moustafa remplacé. Ses anciennes sessions ne sont plus valides. Communique-lui le nouveau mot de passe par un moyen privé.");
    } catch { setMessage("Connexion réseau indisponible. Réessaie."); }
    finally { setBusy(false); }
  }
  return <section className="card" aria-labelledby="reset-moustafa-title">
    <h2 id="reset-moustafa-title">Réinitialiser le mot de passe de Moustafa</h2>
    <p className="muted">Réservé au créateur. Les anciennes connexions de Moustafa seront invalidées ; son solde, ses jeux et sa progression seront conservés.</p>
    <form className="form-stack" onSubmit={reset} aria-busy={busy}>
      <label>Ton mot de passe créateur<input className="input" name="currentPassword" type="password" required maxLength={200} autoComplete="current-password" /></label>
      <label>Nouveau mot de passe de Moustafa<input className="input" name="newPassword" type="password" required minLength={12} maxLength={128} autoComplete="new-password" /></label>
      <label>Confirmer le nouveau mot de passe<input className="input" name="confirmation" type="password" required minLength={12} maxLength={128} autoComplete="new-password" /></label>
      <label><input type="checkbox" required /> Je confirme vouloir remplacer le mot de passe de Moustafa et invalider ses sessions.</label>
      <button className="button" disabled={busy}>{busy ? "Réinitialisation…" : "Réinitialiser le mot de passe de Moustafa"}</button>
    </form>
    {message && <p className={`status ${success ? "" : "error"}`} role={success ? "status" : "alert"}>{message}</p>}
  </section>;
}
