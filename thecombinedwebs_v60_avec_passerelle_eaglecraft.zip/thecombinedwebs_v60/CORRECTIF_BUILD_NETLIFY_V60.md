# TheCombinedWebs v60.0.4 : correctif de build Netlify

L'erreur « Stockage des comptes indisponible » a été reproduite avec `NETLIFY=true` sans accès au stockage Blobs pendant la génération des pages. Le build tentait d'initialiser les comptes au début du rendu de `/admin`, avant toute lecture de session.

## Correction

- **Rendu** : `/admin`, `/steamblox` et `/games/3d` déclarent explicitement `force-dynamic`. Le layout racine est également dynamique, car il personnalise l'interface selon la session et l'état de maintenance.
- **Initialisation** : aucun appel à `ensureSeeded()` dans les pages. L'initialisation reste dans les actions de connexion et d'inscription, exécutées lors d'une requête réelle.
- **Runtime** : Node.js, avec stockage persistant accessible pendant l'exécution des fonctions. Les pages authentifiées ne sont pas exportées en HTML statique.
- **Sécurité** : aucune clé de session manuelle n'est réintroduite. Les erreurs de stockage de comptes à l'exécution restent des erreurs ; ce correctif ne crée pas de repli fictif ni ne désactive les contrôles d'accès.

Le build ne nécessite donc pas de fournir des identifiants de stockage simplement pour pré-rendre les pages privées. Le stockage Netlify Blobs doit toutefois fonctionner au runtime pour les comptes, sessions et mots de passe réinitialisés.

## Vérification reproductible

```sh
npm ci
npm run test:build-netlify
npm run test:login
npm run test:password-reset
npm run test:features
npm run smoke
```

Le test de build active `NETLIFY=true`, retire le contexte Netlify du processus enfant et utilise un dossier de données vide. Il vérifie le succès de compilation, l'absence des pages privées dans le manifeste de pré-rendu et l'absence d'écriture de comptes, sessions ou progression.

## Déploiement

Redéploie le projet complet avec le runtime Next.js de Netlify et la commande `npm run build`. Ne configure pas `output: "export"` : cette application utilise l'authentification, les Server Actions et les routes API à l'exécution.

Cette version conserve les fonctionnalités v60, la déconnexion et la réinitialisation de Moustafa réservée au créateur. Le site hébergé n'est pas modifié automatiquement par le ZIP.
