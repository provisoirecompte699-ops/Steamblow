# TheCombinedWebs v54

## Algèbre Facile — couverture élargie
- **Inéquations du premier degré** : solveur pas à pas avec gestion du sens de l'inégalité
  (inversion quand on divise par un nombre négatif), ensemble des solutions en intervalles.
  - Vérifié : `3x − 7 ≤ 5` → `x ≤ 4`, `−2x + 5 > 11` → `x < −3`.
- **Étude de fonctions** : analyse complète des fonctions affines et du second degré.
  - Fonctions affines : racine, sens de variation, tableau de signes.
  - Fonctions du second degré : forme canonique (signes corrigés), sommet, axe de symétrie,
    racines, sens de variation, tableau de signes.
- **6 niveaux d'exercices** (au lieu de 4) :
  - Niveau 4 : second degré développé (restauré).
  - Niveau 5 : équations avec fractions et décimaux (coefficient non nul garanti).
  - Niveau 6 : équations produit nul (x − a)(x − b) = 0.
- **11 chapitres de cours** (au lieu de 9) : ajout de « Étude de fonctions affines » (2nde)
  et « Étude de fonctions du second degré » (1re).
- **Formulaire enrichi** : forme canonique, sommet de la parabole, racine d'une fonction affine.
- Nouvelle quête quotidienne : « Réviser l'algèbre » (+50 Bobux), déclenchée quand un exercice
  est réussi dans l'ExerciseTrainer (API `/api/quests` avec action `progress`).

## Jeux arcade — succès et options
- **Système de succès partagé** : 12 succès à débloquer dans tous les jeux arcade.
  - Suivi en temps réel via refs dans la boucle d'animation : coups encaissés, dashs utilisés,
    combo atteint, temps de survie, PV restants.
  - Toast de notification quand un succès est débloqué.
  - Fenêtre de consultation des succès depuis le menu de chaque jeu.
  - Sauvegarde locale (localStorage) — persistant entre les sessions.
- **Options de jeu** : choix de la difficulté (Facile, Normal, Difficile) par jeu.
  - Sauvegarde par jeu et par appareil. (L'effet sur le gameplay sera appliqué dans une future version.)

## CinéStream — soirées plus sociales
- **Barre de réactions** : 8 emojis flottants (❤️ 😂 😱 🔥 👏 😭 🤯 😍) qui s'envolent
  à l'écran et sont partagés dans le chat de la soirée.
- **Messages rapides** : 6 messages pré-rédigés pour réagir vite pendant le film.
- **Statut « prêt »** : chaque membre peut indiquer qu'il est prêt, l'hôte voit le
  compte de membres prêts et le bouton s'adapte. L'hôte est automatiquement compté comme prêt.
- Les membres prêts sont affichés avec un ✓ dans la liste.

## Dashboard
- **Bannière « Nouveautés v54 »** : présente les nouvelles fonctionnalités dès l'arrivée.
- **Accès rapide à Algèbre Facile** depuis le bouton d'action du hero.
- Mise à jour des compteurs (11 chapitres, 6 niveaux, étude de fonctions, inéquations).
