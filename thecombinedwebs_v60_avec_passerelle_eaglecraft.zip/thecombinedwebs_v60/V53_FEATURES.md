# TheCombinedWebs v53

## Tous les jeux sont gratuits
- Tous les jeux du catalogue sont à 0 € et jouables par tous les comptes (`hasGameAccess`).
- La bibliothèque du tableau de bord affiche tous les jeux jouables.
- Les films et séries de CinéStream / Vortex restent payants (espèces ou blague), comme avant.

## Mode TV (TheCombinedWebs et CinéStream)
- Script commun : `public/eco/tv.js`, chargé sur tout le site (layout) et dans CinéStream.
- Activation automatique sur Android TV, Google TV, Fire TV, Samsung Tizen, LG webOS, Sony, Philips, Hisense…
  Aussi : choix « Télévision » dans l'écran de démarrage, `?tv=1` dans l'adresse (`?tv=0` pour désactiver),
  bouton « Mode TV » dans l'en-tête de CinéStream.
- Télécommande : flèches = déplacer le focus (navigation spatiale), OK = ouvrir, Retour = fermer
  (lecteur, écran de paiement, fenêtres), touches Retour Tizen (10009) et webOS (461) gérées.
- CinéStream en TV : interface agrandie, grandes affiches, focus très visible, défilement automatique des rangées.
- Pendant une partie, le mode TV laisse les flèches et OK au jeu (`data-tvgame`).

## Amélioration des jeux arcade (11 jeux)
- Manettes (Xbox, PlayStation, manettes Bluetooth de TV) : stick gauche ou croix pour bouger, A action,
  B / gâchettes dash, stick droit pour viser, Start pause, A ou Start pour lancer / rejouer depuis les menus.
- Vibrations de la manette quand on prend un coup.
- Télécommande TV : flèches pour bouger, OK pour l'action, Retour met en pause.
- Qualité graphique adaptée automatiquement aux téléviseurs (résolution limitée pour rester fluide).

## Android TV (APK)
- L'APK s'affiche dans le lanceur Android TV / Google TV (catégorie LEANBACK_LAUNCHER, bannière 320×180).
- Sur un téléviseur, l'application ouvre directement CinéStream en mode TV.
- Le bouton Retour de la télécommande ferme d'abord le lecteur ou la fenêtre ouverte, puis revient en arrière.
- Version 53 (`versionCode 53`).

## Limites
- Les lecteurs vidéo externes (iframes) ne se pilotent pas à la télécommande : une fois le lecteur sélectionné,
  la lecture/pause se fait dans le lecteur lui-même ; Retour ferme le lecteur.
- Les jeux 3D (Sky Jump 3D, Turbo Kart 3D, Neon Drift 3D…) restent au clavier / tactile ; la manette est gérée
  dans les 11 jeux arcade.
- Sur les navigateurs de TV très anciens, certaines fonctions (vocal, partage d'écran) peuvent ne pas exister.
