# Configuration à finaliser

Cette passerelle n'est pas configurée automatiquement, car les paramètres changent entre EaglerXServer, EaglercraftXBungee et EaglercraftXVelocity.

Après avoir choisi le plugin et la version exacte :
- suivez son README et son exemple de `listeners.yml`/`settings.yml`;
- configurez le backend et le forwarding dans Velocity/BungeeCord;
- assurez-vous que le backend accepte ce mode de forwarding;
- configurez un reverse proxy TLS qui conserve les en-têtes WebSocket;
- testez avec le client Eaglercraft correspondant.

Ne copiez pas des configurations d'une version de plugin à une autre.
