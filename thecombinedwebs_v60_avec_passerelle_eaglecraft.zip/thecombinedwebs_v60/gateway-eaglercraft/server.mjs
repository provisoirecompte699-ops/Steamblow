import http from 'node:http';
import { URL } from 'node:url';
import { WebSocket, WebSocketServer } from 'ws';

const PORT = Number(process.env.PORT || 8080);
const PATH = process.env.GATEWAY_PATH || '/websocket';
const UPSTREAM_RAW = (process.env.UPSTREAM_WS_URL || '').trim();
const MAX_CONNECTIONS = Math.max(1, Number(process.env.MAX_CONNECTIONS || 100));
const MAX_PAYLOAD = Math.max(1024, Number(process.env.MAX_PAYLOAD_BYTES || 8388608));
const ALLOWED_ORIGINS = (process.env.ALLOWED_ORIGINS || '').split(',').map(x => x.trim()).filter(Boolean);

let upstreamUrl;
try {
  upstreamUrl = new URL(UPSTREAM_RAW);
  if (!['ws:', 'wss:'].includes(upstreamUrl.protocol)) throw new Error('protocol');
} catch {
  console.error('[gateway] UPSTREAM_WS_URL invalide. Utilise ws:// ou wss:// avec le point d’accès EaglerXServer exact.');
  process.exit(1);
}
if (process.env.NODE_ENV === 'production' && upstreamUrl.protocol !== 'wss:' && process.env.ALLOW_INSECURE_UPSTREAM !== 'true') {
  console.error('[gateway] En production, UPSTREAM_WS_URL doit utiliser wss:// (ou définir ALLOW_INSECURE_UPSTREAM=true en connaissance de cause).');
  process.exit(1);
}

const server = http.createServer((req, res) => {
  const pathname = new URL(req.url || '/', `http://${req.headers.host || 'localhost'}`).pathname;
  if (req.method === 'GET' && pathname === '/health') {
    const body = JSON.stringify({ ok: true, service: 'tcb-eaglercraft-gateway', websocketPath: PATH, activeConnections: active.size });
    res.writeHead(200, { 'content-type': 'application/json; charset=utf-8', 'cache-control': 'no-store' });
    res.end(body);
    return;
  }
  if (req.method === 'GET' && pathname === '/') {
    res.writeHead(200, { 'content-type': 'text/plain; charset=utf-8', 'cache-control': 'no-store' });
    res.end(`TCB Eaglercraft WebSocket gateway is running. Connect at ${PATH}; health at /health.\n`);
    return;
  }
  res.writeHead(404, { 'content-type': 'text/plain; charset=utf-8' });
  res.end('Not found');
});

const wss = new WebSocketServer({ noServer: true, perMessageDeflate: true, maxPayload: MAX_PAYLOAD });
const active = new Set();

server.on('upgrade', (req, socket, head) => {
  let pathname;
  try { pathname = new URL(req.url || '/', `http://${req.headers.host || 'localhost'}`).pathname; }
  catch { socket.end('HTTP/1.1 400 Bad Request\r\n\r\n'); return; }
  if (pathname !== PATH) { socket.end('HTTP/1.1 404 Not Found\r\nConnection: close\r\n\r\n'); return; }
  const origin = req.headers.origin;
  if (ALLOWED_ORIGINS.length && origin && !ALLOWED_ORIGINS.includes(origin)) {
    socket.end('HTTP/1.1 403 Forbidden\r\nConnection: close\r\n\r\n'); return;
  }
  if (active.size >= MAX_CONNECTIONS) { socket.end('HTTP/1.1 503 Service Unavailable\r\nConnection: close\r\n\r\n'); return; }
  const protocols = String(req.headers['sec-websocket-protocol'] || '').split(',').map(x => x.trim());
  if (!protocols.includes('binary')) { socket.end('HTTP/1.1 400 Bad Request\r\nConnection: close\r\n\r\n'); return; }
  wss.handleUpgrade(req, socket, head, client => {
    active.add(client);
    client.once('close', () => active.delete(client));
    bridge(client);
  });
});

function bridge(client) {
  const upstream = new WebSocket(upstreamUrl, 'binary', {
    perMessageDeflate: true,
    handshakeTimeout: 12000,
    maxPayload: MAX_PAYLOAD,
    headers: process.env.UPSTREAM_ORIGIN ? { Origin: process.env.UPSTREAM_ORIGIN } : undefined,
  });
  let closed = false;
  const queued = [];
  const closeBoth = (code = 1011, reason = 'Gateway upstream closed') => {
    if (closed) return;
    closed = true;
    try { if (client.readyState === WebSocket.OPEN || client.readyState === WebSocket.CONNECTING) client.close(code, reason.slice(0, 120)); } catch {}
    try { if (upstream.readyState === WebSocket.OPEN || upstream.readyState === WebSocket.CONNECTING) upstream.close(code, reason.slice(0, 120)); } catch {}
  };

  const waitTimer = setTimeout(() => closeBoth(1013, 'Upstream connection timeout'), 15000);
  upstream.once('open', () => {
    clearTimeout(waitTimer);
    while (queued.length && upstream.readyState === WebSocket.OPEN) {
      const frame = queued.shift();
      upstream.send(frame.data, { binary: frame.isBinary }, err => { if (err) closeBoth(); });
    }
  });
  // Relay every application frame byte-for-byte; never inject synthetic packets.
  client.on('message', (data, isBinary) => {
    if (upstream.readyState === WebSocket.OPEN) upstream.send(data, { binary: isBinary }, err => { if (err) closeBoth(); });
    else if (upstream.readyState === WebSocket.CONNECTING && queued.length < 256) queued.push({ data, isBinary });
    else closeBoth(1013, 'Upstream not ready');
  });
  upstream.on('message', (data, isBinary) => {
    if (client.readyState === WebSocket.OPEN) client.send(data, { binary: isBinary }, err => { if (err) closeBoth(); });
  });
  client.on('error', () => closeBoth(1011, 'Client socket error'));
  upstream.on('error', err => {
    console.error('[gateway] upstream:', err.message);
    closeBoth(1011, 'Upstream connection failed');
  });
  client.on('close', () => { clearTimeout(waitTimer); try { upstream.close(); } catch {} });
  upstream.on('close', () => { clearTimeout(waitTimer); if (!closed && client.readyState === WebSocket.OPEN) client.close(1011, 'Upstream closed'); });
}

server.listen(PORT, '0.0.0.0', () => {
  console.log(`[gateway] listening on 0.0.0.0:${PORT}${PATH}`);
  console.log(`[gateway] upstream host: ${upstreamUrl.host}; upstream path: ${upstreamUrl.pathname}`);
});

function shutdown() {
  for (const client of active) { try { client.close(1001, 'Gateway shutting down'); } catch {} }
  server.close(() => process.exit(0));
  setTimeout(() => process.exit(1), 8000).unref();
}
process.on('SIGTERM', shutdown);
process.on('SIGINT', shutdown);
