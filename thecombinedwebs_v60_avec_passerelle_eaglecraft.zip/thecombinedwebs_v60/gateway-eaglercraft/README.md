# Passerelle WebSocket Eaglercraft de TheCombinedWebs

Ce service Node relaie les frames WebSocket entre le client Eaglercraft et **un point d’accès EaglerXServer déjà existant**. Il ne transforme pas un serveur Minecraft TCP ordinaire en serveur Eaglercraft : le backend doit déjà exécuter EaglerXServer ou un proxy compatible. Le relais ne choisit jamais une cible fournie par le visiteur, afin de ne pas devenir un proxy ouvert.

## Déploiement gratuit avec Render

1. Décompresse le ZIP de TheCombinedWebs et pousse le dossier du projet dans un dépôt GitHub.
2. Dans Render, choisis **New → Blueprint** et sélectionne ce dépôt. Render lira `gateway-eaglercraft/render.yaml`.
3. Ouvre le service `tcb-eaglercraft-gateway` → **Environment**.
4. Vérifie `UPSTREAM_WS_URL`. La valeur préremplie `wss://youknowbro.eagler.host/` est une hypothèse à confirmer dans le panneau EaglerHost. Si le panneau indique une adresse WebSocket avec un port ou un chemin, utilise exactement cette adresse, en `wss://` si TLS est disponible. Ne mets pas l’URL du site web d’administration.
5. Attends le déploiement. Teste `https://NOM-DU-SERVICE.onrender.com/health`; le résultat doit contenir `"ok":true`.
6. L’URL du jeu relayée sera `wss://NOM-DU-SERVICE.onrender.com/websocket`.
7. Dans les paramètres de déploiement de TheCombinedWebs, définis `NEXT_PUBLIC_EAGLECRAFT_GATEWAY_URL` avec cette URL puis redéploie TCB. La page EagleCraft pourra la préremplir. Sinon, ajoute manuellement cette URL dans le champ WebSocket de la page.

## Configuration locale / Docker

```sh
cd gateway-eaglercraft
cp .env.example .env
# Modifie UPSTREAM_WS_URL avec le point d’accès exact donné par l’hébergeur.
docker compose up --build -d
```

Le service expose `GET /health`, `GET /` et le WebSocket `GET /websocket`. Le client Eaglercraft doit négocier le sous-protocole `binary`; le code relaie les messages sans les interpréter.

## Limites importantes

- Je ne peux pas déployer ce service sur ton compte Render ni tester ton serveur privé depuis cette archive. La passerelle est fournie prête à déployer, pas déjà hébergée.
- Si `youknowbro.eagler.host` n’est pas le véritable point d’accès WebSocket EaglerXServer, la passerelle se déploiera mais les connexions au jeu échoueront. Copie alors l’adresse WebSocket exacte affichée dans le panneau de l’hébergeur dans `UPSTREAM_WS_URL`.
- Un simple test `/health` confirme que le relais tourne, pas que le protocole de jeu fonctionne. Le test final consiste à ouvrir le client, se connecter, entrer dans le monde et vérifier le chat et le déplacement.
- Render Free peut mettre le service en veille après une période d’inactivité et provoquer un délai au premier démarrage.
- Le service ne doit être déployé que vers un backend que tu contrôles ou que tu es autorisé à utiliser. N’ajoute aucun mot de passe au dépôt.
