# Validation de la passerelle TCB Eaglercraft

## Déploiement
- [ ] Le service Render `tcb-eaglercraft-gateway` passe au statut Live.
- [ ] `https://NOM-DU-SERVICE.onrender.com/health` renvoie `{"ok":true,...}`.
- [ ] `UPSTREAM_WS_URL` correspond à l'adresse WebSocket EaglerXServer exacte du panneau EaglerHost, avec le port et le chemin si nécessaires.
- [ ] L'URL publique du relais est `wss://NOM-DU-SERVICE.onrender.com/websocket`.
- [ ] La variable TCB `NEXT_PUBLIC_EAGLECRAFT_GATEWAY_URL` est définie sur cette URL avant le build de TCB.

## Test réel du jeu
- [ ] Le client EagleCraft en version compatible se connecte à l'URL `wss://.../websocket`.
- [ ] La négociation du sous-protocole WebSocket `binary` réussit.
- [ ] Le joueur entre dans le monde.
- [ ] Déplacement, chat, inventaire et déconnexion fonctionnent.
- [ ] Un second joueur rejoint et les deux joueurs se voient.

Un test HTTP `/health` vérifie uniquement que le processus tourne. Un test WebSocket valide uniquement le transport, pas le protocole Minecraft. Seul un test dans le jeu valide la chaîne complète.
