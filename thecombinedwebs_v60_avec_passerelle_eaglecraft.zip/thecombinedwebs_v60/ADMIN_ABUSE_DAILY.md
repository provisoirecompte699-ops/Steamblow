# Admin Abuse quotidien

- Le calendrier affiche la chasse aux Bobux chaque jour.
- Le créateur ou le vice-créateur peut lancer l’événement pendant 15 minutes depuis `/admin-abuse`.
- Les taxes sont suspendues pendant l’événement. Le prélèvement reprend après sa fin.
- Les taxes normales ont été réduites de 0,2 % à 0,1 %, Premium de 0,1 % à 0,05 %, et le plafond journalier passe de 200 à 100 Bobux.
- Chaque joueur peut jouer une fois par jour, pendant 30 secondes, avec une récompense jusqu’à 300 Bobux. Le classement quotidien affiche les meilleurs scores.
