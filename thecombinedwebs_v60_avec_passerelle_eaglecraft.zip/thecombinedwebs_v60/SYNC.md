# Synchronisation Younes + Moustafa

Le projet ne peut pas synchroniser automatiquement deux copies d'un ZIP entre elles. Le ZIP est seulement une archive. La source commune doit être un dépôt Git partagé.

## Mise en place

1. Créer un dépôt GitHub privé nommé `steamblox`.
2. Ajouter Younes et Moustafa comme collaborateurs avec le droit d'écriture.
3. Pousser ce projet sur `main`.
4. Chaque personne travaille depuis un clone du même dépôt.

## Workflow recommandé

```bash
git pull --rebase origin main
# modifier les fichiers
npm run check
git add .
git commit -m "feat: ..."
git push origin main
```

Le workflow CI de `.github/workflows/ci.yml` reconstruit le projet à chaque push et pull request.

Pour resynchroniser une copie locale :

```bash
npm run sync
```

Le script fait un `fetch` puis un `pull --rebase` depuis `origin`.

## Important

Une modification poussée sur GitHub devient disponible pour l'autre personne après son `git pull`. Il n'est pas possible de modifier physiquement les fichiers présents sur l'iPhone ou le PC de l'autre personne sans passer par un dépôt partagé, une synchronisation cloud ou un outil de collaboration.
