# TheCombinedWebs v60.0.3 : sessions sans clé manuelle et déconnexion

La connexion n'utilise plus de JWT ni de clé de signature à configurer. Elle crée un jeton aléatoire de 256 bits, stocké dans un cookie HTTP-only ; seule son empreinte SHA-256 est utilisée comme identifiant de stockage côté serveur. Aucune clé fixe publique ne permet de fabriquer une session.

## Déploiement

- **Netlify** : les sessions sont conservées dans Netlify Blobs, avec lecture fortement cohérente et écriture avant validation de la connexion. Le stockage doit être accessible aux fonctions ; une erreur du stockage ne déclenche pas un repli non sécurisé.
- **Serveur Node** : les sessions sont dans `data/sessions/`, ou dans le dossier persistant défini par `TCB_DATA_DIR`. Conserver ce volume à travers les redémarrages. Ne pas copier les sessions de test dans le projet livré.
- **Migration** : les anciennes sessions sont invalidées. Les comptes, mots de passe, rôles, soldes et sauvegardes restent inchangés. Il faut se reconnecter après le redéploiement.
- **Déconnexion** : bouton « Se déconnecter » sur l'accueil, la page Compte et la navigation des nouvelles pages. La déconnexion supprime la session côté serveur, efface le cookie et revient à la connexion. Rejouer l'ancien jeton ne reconnecte plus le compte.
- **Expiration** : sept jours. Les sessions expirées ne sont pas acceptées et sont supprimées lorsqu'elles sont consultées.
- **Réinitialisation** : le créateur peut remplacer le mot de passe de Moustafa dans `/admin`, avec réauthentification et invalidation de ses anciennes sessions. Voir `REINITIALISATION_MOUSTAFA_V60.md`.

Les services externes restent distincts de l'authentification des comptes : `PROXY_SECRET` signe les tickets de proxy, et `REALTIME_SECRET` signe les tickets du serveur multijoueur/vocal. Configurer ces valeurs uniquement si ces services sont utilisés, et mettre la même valeur sur les deux services concernés. Leur absence n'empêche pas de se connecter.

Les anciennes chasses au trésor sans nonce privé doivent être relancées. Les nouvelles chasses utilisent leur propre secret généré automatiquement, jamais exposé dans les réponses publiques.

## Vérifications

```sh
npm ci
npm run test:login
npm run test:features
npm run smoke
npm run build
```

Les nouvelles opérations économiques exigent toujours un serveur Node à écrivain unique ; ce changement de sessions ne transforme pas les transactions financières en transactions distribuées.
