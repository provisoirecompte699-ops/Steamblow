# TCB Proxy (Snokido + GTA Web)

Petit proxy inverse personnalisé (`proxy-server/`, Node 18+, aucune dépendance). Il sert à deux choses :

1. **GTA Web** : le jeu a besoin de `SharedArrayBuffer`, donc de l'isolation cross-origin (COOP/COEP). Une iframe vers `gta.deloskiyt.pl` ne peut pas être isolée depuis ton site. Le proxy sert le jeu avec `COOP: same-origin`, `COEP: require-corp` et `CORP: cross-origin`, et le site ajoute COOP/COEP à la page `/games/gta-web`. Résultat : `crossOriginIsolated = true`, le chargement continue.
2. **Snokido** (`snokido.fr`) : le proxy retire `X-Frame-Options` / CSP, réécrit les URL (HTML, CSS) et injecte un petit script qui corrige `fetch`, `XMLHttpRequest`, les `<script>`/`<img>` créés dynamiquement, les workers, etc. Page : `/games/snokido`.

## Sécurité
- **Liste blanche stricte** d'hôtes (`gta.deloskiyt.pl`, `deloskiyt.pl`, `snokido.fr` et leurs sous-domaines + `PROXY_ALLOW`). Pas de proxy ouvert : IP, `localhost`, `.local`, `.internal` refusés, redirections vers un hôte non autorisé bloquées.
- **Ticket signé** par le site (`PROXY_SECRET`, valable 7 à 14 jours, stable pour garder le cache du navigateur) : sans connexion au site, pas d'accès.
- GET / HEAD uniquement. Les cookies amont sont supprimés.

## Déploiement (Render, Fly, Railway, VPS…)
1. Déploie le dossier `proxy-server/` (un `Dockerfile` et un `render.yaml` sont fournis). Pas de limite de taille de réponse : les gros fichiers WASM passent en streaming (Range pris en charge). Netlify ne convient pas pour GTA (réponses limitées).
2. Variables du proxy : `PROXY_SECRET` (**identique au site**), `SITE_ORIGINS` (ex. `https://ton-site.netlify.app`, restreint qui peut l'afficher), `PROXY_ALLOW` (hôtes en plus), `PROXY_ISOLATE` (hôtes à isoler en plus).
3. Variable du site : `NEXT_PUBLIC_PROXY_URL=https://ton-proxy.onrender.com`, puis **redéploie** (les en-têtes COOP/COEP sont ajoutés au build).
4. Ouvre `/games/gta-web` : le badge « Isolation cross-origin active ✓ » doit s'afficher. Sinon, vérifie dans DevTools que `crossOriginIsolated` vaut `true`.

## Si un jeu Snokido ne se charge pas
Les jeux sont souvent servis depuis d'autres domaines. Ouvre la console du navigateur : `[TCB proxy] hote non autorise : xxx` indique le domaine à ajouter dans `PROXY_ALLOW` (les refus sont aussi dans les logs du proxy : `[bloqué] xxx`). N'ajoute que des domaines de jeux de confiance.

## Limites connues
- Pas de WebSocket ni de POST via le proxy ; les service workers des sites sont désactivés.
- Un site qui vérifie `location.hostname` ou casse dans une iframe peut ne pas fonctionner.
- Ce proxy n'a pas pu être testé contre les vrais `snokido.fr` et `gta.deloskiyt.pl` (pas d'accès réseau pendant le développement) : il a été validé avec un faux site amont (réécriture, en-têtes, redirections, Range, refus d'hôtes).
- Le contenu appartient à ses éditeurs ; ce proxy ne fait que l'afficher.
