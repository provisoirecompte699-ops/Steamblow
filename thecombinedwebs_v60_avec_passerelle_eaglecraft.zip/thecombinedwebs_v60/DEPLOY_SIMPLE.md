# TheCombinedWebs : déploiement simplifié

## Le plus simple : Netlify + GitHub

1. Pousse le dossier du projet sur le dépôt GitHub `TheCombinedWebs`.
2. Sur Netlify, clique sur **Add new site → Import an existing project → GitHub**.
3. Sélectionne `provisoirecompte699-ops/Steamblox`.
4. Laisse les réglages venant de `netlify.toml` :
   - Build command : `npm run build`
   - Publish directory : `.next`
   - Node : 22
5. Ajoute ces variables dans **Site configuration → Environment variables** :
   - Aucune clé de signature à configurer pour les sessions de connexion.
   - `REALTIME_SECRET` : signature de service identique sur le site et le serveur temps réel, uniquement pour le multijoueur/vocal.
   - `YOUNES_PASSWORD` : mot de passe du compte Younes
   - `MOUSTAFA_PASSWORD` : mot de passe du compte Moustafa
   - `ISSAMNPC_PASSWORD` : facultatif
   - `NEXT_PUBLIC_MULTIPLAYER_SERVER_URL` : URL publique (https) du serveur Socket.IO, nécessaire pour le multijoueur et le vocal global. Le préfixe `NEXT_PUBLIC_` est obligatoire et la variable doit être définie **avant** le build.
6. Lance le déploiement.

## Mode de secours pour les comptes

TheCombinedWebs conserve les comptes et sessions dans Netlify Blobs sur Netlify, ou dans un volume persistant sur Node. Le cookie HTTP-only contient uniquement un jeton aléatoire de session ; il ne contient ni compte ni mot de passe.

Netlify Blobs doit être accessible aux fonctions. Une erreur de stockage ne permet pas de contourner l'authentification.

## Serveur temps réel (multijoueur + vocal global)

Netlify ne peut pas héberger `multiplayer-server/` (connexions WebSocket longues). Déploie ce dossier sur Render, Railway ou Fly.io :
- Start command : `npm start` — `NODE_ENV=production` ; mets la même signature `REALTIME_SECRET` sur les services concernés.
- Reporte l'URL obtenue dans `NEXT_PUBLIC_MULTIPLAYER_SERVER_URL` sur Netlify, puis relance un déploiement.
- Vérifie `https://ton-serveur/health` → `{"ok":true}`.
